#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$project_dir"
mkdir -p build/host-tests
javac --release 8 -encoding UTF-8 -d build/host-tests app/src/main/java/fr/lemegageek/rhythmbox/Crypto.java app/src/test/java/fr/lemegageek/rhythmbox/CryptoTest.java
java -cp build/host-tests fr.lemegageek.rhythmbox.CryptoTest ../tests/fixtures/protocol-v1.rbx ../tests/fixtures/protocol-v1.plain.json
sdk_platform="${RBX_ANDROID_PLATFORM:-$project_dir/.toolchain/android-36/android.jar}"
json_jar="${RBX_JSON_TEST_JAR:-$project_dir/.toolchain/json-test.jar}"
if [[ ! -f "$sdk_platform" || ! -f "$json_jar" ]]; then
  printf '%s\n' 'Exécuter ./prepare-toolchain.sh, ou définir RBX_ANDROID_PLATFORM et RBX_JSON_TEST_JAR (org.json).' >&2
  exit 1
fi
javac --release 8 -encoding UTF-8 -classpath "$json_jar:$sdk_platform:build/host-tests" -d build/host-tests app/src/main/java/fr/lemegageek/rhythmbox/FolderProtocol.java app/src/main/java/fr/lemegageek/rhythmbox/Library.java app/src/main/java/fr/lemegageek/rhythmbox/SyncEngine.java app/src/test/java/fr/lemegageek/rhythmbox/ProtocolTest.java app/src/test/java/fr/lemegageek/rhythmbox/FolderProtocolTest.java
java -cp "build/host-tests:$json_jar:$sdk_platform" fr.lemegageek.rhythmbox.ProtocolTest ../tests/fixtures/protocol-v1.plain.json
java -cp "build/host-tests:$json_jar:$sdk_platform" fr.lemegageek.rhythmbox.FolderProtocolTest
javac --release 8 -encoding UTF-8 -classpath "$json_jar:$sdk_platform:build/host-tests" -d build/host-tests app/src/main/java/fr/lemegageek/rhythmbox/UiPresentation.java app/src/main/java/fr/lemegageek/rhythmbox/DemoAudio.java app/src/main/java/fr/lemegageek/rhythmbox/PlaybackQueue.java app/src/test/java/fr/lemegageek/rhythmbox/PresentationTest.java
java -cp "build/host-tests:$json_jar:$sdk_platform" fr.lemegageek.rhythmbox.PresentationTest
javac --release 8 -Xlint:-options -encoding UTF-8 -classpath "$json_jar" -d build/host-tests app/src/main/java/fr/lemegageek/rhythmbox/PCloudAccount.java app/src/main/java/fr/lemegageek/rhythmbox/PCloudOAuthProtocol.java app/src/main/java/fr/lemegageek/rhythmbox/PCloudDirectLoginProtocol.java app/src/main/java/fr/lemegageek/rhythmbox/PCloudDeviceLoginProtocol.java app/src/test/java/fr/lemegageek/rhythmbox/PCloudOAuthProtocolTest.java app/src/test/java/fr/lemegageek/rhythmbox/PCloudDirectLoginProtocolTest.java app/src/test/java/fr/lemegageek/rhythmbox/PCloudDeviceLoginProtocolTest.java
java -cp "build/host-tests:$json_jar" fr.lemegageek.rhythmbox.PCloudOAuthProtocolTest
java -cp "build/host-tests:$json_jar" fr.lemegageek.rhythmbox.PCloudDirectLoginProtocolTest
java -cp "build/host-tests:$json_jar" fr.lemegageek.rhythmbox.PCloudDeviceLoginProtocolTest
python3 - <<'PY'
import xml.etree.ElementTree as ET
from pathlib import Path
n='{http://schemas.android.com/apk/res/android}'
m=ET.parse('app/src/main/AndroidManifest.xml').getroot()
assert {x.attrib[n+'name'] for x in m.findall('uses-permission')} == {'android.permission.INTERNET','android.permission.ACCESS_NETWORK_STATE','android.permission.RECEIVE_BOOT_COMPLETED','android.permission.FOREGROUND_SERVICE','android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK','android.permission.WAKE_LOCK'}
a=m.find('application'); assert a.attrib[n+'allowBackup']=='false' and a.attrib[n+'usesCleartextTraffic']=='false'
assert a.find('service').attrib[n+'exported']=='false'
assert not any(x.attrib[n+'name']=='.SpotifyNotificationListener' for x in a.findall('service'))
controller=Path('app/src/main/java/fr/lemegageek/rhythmbox/SpotifyController.java').read_text()
assert 'SpotifyAppRemote.connect' in controller and 'getTransportControls' not in controller
assert 'subscribeToPlayerState' in controller and 'getImagesApi' in controller
assert [x.attrib[n+'name'] for x in m.findall('queries/package')]==['com.spotify.music']
assert m.attrib['package']=='fr.lemegageek.rhythmbox' and m.attrib[n+'versionCode']=='21' and m.attrib[n+'versionName']=='0.11.0'
assert m.find('uses-sdk').attrib[n+'targetSdkVersion']=='36'
assert a.attrib[n+'debuggable']=='false'
source=Path('app/src/main/java/fr/lemegageek/rhythmbox/PlaybackService.java').read_text()
assert 'setSurface(null)' in source and 'p.hasAudio()' in source
assert 'MEDIA_TRACK_TYPE_AUDIO' in Path('app/src/main/java/fr/lemegageek/rhythmbox/NativeAudioPlayer.java').read_text()
assert all('VideoView' not in p.read_text() and 'SurfaceView' not in p.read_text() for p in Path('app/src/main/java').rglob('*.java'))
print('PASS : manifest permissions, backup disabled, TLS required, service private')
print('PASS : version 0.11.0/fr.lemegageek.rhythmbox/API36, release not debuggable, audio track required, no video surface/view')
PY
bash "$project_dir/test-pcloud-native.sh"
bash "$project_dir/test-suno-catalog.sh"
bash "$project_dir/test-suno-library.sh"
bash "$project_dir/test-suno-browser.sh"
bash "$project_dir/test-suno-audio.sh"
bash "$project_dir/test-spotify-controller.sh"
bash "$project_dir/test-spotify-library.sh"
bash "$project_dir/test-playback-ownership.sh"
bash "$project_dir/test-volume.sh"

bash "$project_dir/test-audio-cache.sh"
bash "$project_dir/test-pcm.sh"
