package fr.lemegageek.rhythmbox;

/** Retry App Remote once after returning from a login opened explicitly for this selection. */
enum SpotifyLoginReturn {
    NONE, OPENED, AWAY, RETURNED;

    SpotifyLoginReturn paused(){return this==OPENED?AWAY:this;}
    SpotifyLoginReturn resumed(){return this==AWAY?RETURNED:this;}
    static SpotifyLoginReturn restore(String value){
        try{return value==null?NONE:valueOf(value);}
        catch(IllegalArgumentException invalid){return NONE;}
    }
}
