package fr.lemegageek.rhythmbox;

import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

public final class SunoLibraryTest {
    static int checks;
    static final String A="11111111-1111-4111-8111-111111111111",B="22222222-2222-4222-8222-222222222222",P="33333333-3333-4333-8333-333333333333";
    interface Op {void run() throws Exception;}
    static void yes(boolean test,String why){checks++;if(!test)throw new AssertionError(why);}
    static void reject(Op action,String why) throws Exception {boolean rejected=false;try{action.run();}catch(Exception expected){rejected=true;}yes(rejected,why);}
    static JSONObject track(String id) throws Exception {return new JSONObject().put("id","suno:"+id).put("service","suno").put("title","Synthetic "+id.charAt(0)).put("artist","Fixture").put("album","").put("duration",8).put("source_url","https://suno.com/song/"+id).put("stream_uri","https://d2lwuy8qc234o3.cloudfront.net/1/clip/"+id+".m4a").put("stream_encoding",JSONObject.NULL).put("cover_uri","");}
    static JSONObject song() throws Exception {return new JSONObject().put("version",1).put("id","suno:"+A).put("name","First").put("source_url","https://suno.com/song/"+A).put("tracks",new JSONArray().put(track(A))).put("playlists",new JSONArray());}
    static JSONObject playlist() throws Exception {return new JSONObject().put("version",1).put("id","suno-playlist:"+P).put("name","Ordered").put("source_url","https://suno.com/playlist/"+P).put("tracks",new JSONArray().put(track(A)).put(track(B))).put("playlists",new JSONArray().put(new JSONObject().put("id","suno-playlist:"+P).put("name","Ordered").put("track_ids",new JSONArray().put("suno:"+B).put("suno:"+A).put("suno:"+B))));}
    public static void main(String[] args) throws Exception {
        Path directory=Files.createTempDirectory("rbx-suno-library-test-");Path file=directory.resolve("suno.json");
        SunoLibrary library=new SunoLibrary(file.toFile());yes(library.sources().length()==0,"new private catalog starts empty");
        library.put(song());yes(Files.isRegularFile(file),"explicit import persists metadata");
        yes(library.queue("suno:"+A).length()==1,"single song can play natively");
        library.put(playlist());JSONArray queue=library.queue("suno-playlist:"+P);
        java.util.List<SunoLibrary.Playlist> lists=library.playlists();
        yes(lists.size()==1&&lists.get(0).id.equals("suno-playlist:"+P)&&lists.get(0).name.equals("Ordered")&&lists.get(0).count==3,
            "playlist menu contains only named playlists and counts every occurrence");
        JSONArray singles=library.singles();
        yes(singles.length()==1&&singles.getJSONObject(0).getString("id").equals("suno:"+A),
            "standalone tracks are kept separate from imported playlist members");
        yes(queue.length()==3&&queue.getJSONObject(0).getString("id").equals("suno:"+B)&&queue.getJSONObject(1).getString("id").equals("suno:"+A),"playlist order and legitimate repeated members preserved");
        queue.getJSONObject(0).put("title","outside change");yes(!library.registeredTrack("suno:"+B).getString("title").equals("outside change"),"returned data cannot mutate registry");
        JSONArray listing=library.sources();listing.getJSONObject(0).put("name","outside change");yes(!library.sources().getJSONObject(0).getString("name").equals("outside change"),"source listing is a copy");
        SunoLibrary restarted=new SunoLibrary(file.toFile());yes(restarted.sources().length()==2&&restarted.queue("suno-playlist:"+P).length()==3,"phone restart keeps registered metadata and exact queue");
        yes(restarted.playlists().size()==1 && restarted.playlists().get(0).count==3 && restarted.singles().length()==1,
            "closing and reopening keeps the playlist in the first-level menu");
        library.put(song().put("name","Updated"));yes(library.sources().length()==2&&library.sources().getJSONObject(0).getString("name").equals("Updated"),"refresh replaces same identity instead of duplicating catalog");
        byte[] before=Files.readAllBytes(file);
        for(String foreign:new String[]{"media_path","local_uri","pcloud_fileid","pcloud_account_userid","pcloud_music_folderid","key","iv","glt","access_token","cookie"}){
            JSONObject invalid=song();invalid.getJSONArray("tracks").getJSONObject(0).put(foreign,"foreign");reject(()->library.put(invalid),"cross-source/private material rejected: "+foreign);yes(Arrays.equals(before,Files.readAllBytes(file)),"invalid import preserves catalog: "+foreign);
        }
        JSONObject missing=playlist();missing.getJSONArray("tracks").remove(1);reject(()->library.put(missing),"missing member is not silently dropped");
        JSONObject extra=playlist();extra.getJSONArray("playlists").getJSONObject(0).put("track_ids",new JSONArray().put("suno:"+A));reject(()->library.put(extra),"unused source member rejects inconsistent manifest");
        JSONObject wrong=playlist().put("source_url","https://suno.com/playlist/"+A);reject(()->library.put(wrong),"playlist identity anchored to its official link");
        reject(()->library.registeredTrack("suno:00000000-0000-4000-8000-000000000000"),"unregistered cloud input cannot open a Suno stream");
        yes(Arrays.equals(before,Files.readAllBytes(file)),"all failed imports leave original file intact");
        library.remove("suno-playlist:"+P);yes(library.sources().length()==1,"removing catalog does not remove independent song source");
        reject(()->library.registeredTrack("suno:"+B),"removed source no longer grants playback registration");
        yes(library.registeredTrack("suno:"+A).getString("service").equals("suno"),"other registered source stays usable");
        byte[] good=Files.readAllBytes(file);Files.write(file,new byte[]{(byte)0xc3,(byte)0x28});reject(()->new SunoLibrary(file.toFile()),"corrupt UTF8 is rejected without reset");yes(Files.size(file)==2,"unreadable existing data is preserved");Files.write(file,good);
        Path alias=directory.resolve("alias.json");Files.createSymbolicLink(alias,file);reject(()->new SunoLibrary(alias.toFile()),"catalog symlink is refused");
        yes(Files.list(directory).noneMatch(p->p.getFileName().toString().startsWith(".suno-library-")),"atomic writes leave no temporary files");
        System.out.println("PASS: "+checks+" private Suno registry/order/atomicity/source-isolation assertions; synthetic metadata only");
    }
}
