package fr.lemegageek.rhythmbox;

import android.app.*;
import android.content.*;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.text.*;
import android.text.method.PasswordTransformationMethod;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native, scoped music client: local listening works without a cloud account. */
public final class MainActivity extends Activity {
    private static final int BG=0xff10151e,CARD=0xff1c2635,SURFACE=0xff263548,TEXT=0xfff3f7fd,MUTED=0xffb4c3d7,ACCENT=0xff72e1bb,PURPLE=0xffbba9ff;
    private static final int PICK_PLAYLISTS=201,PICK_MEDIA=202,PICK_PAIRING=203;
    private LinearLayout root,libraryScreen,playerPane,settingsScreen,playlistArea,emptyArea,miniPlayer;
    private FrameLayout content; private ScrollView playerScroll,settingsScroll;private HorizontalScrollView playlistScroller;private LinearLayout searchBox,listHeader;private Button syncButton;private ListView trackList;
    private TextView subtitle,libraryCount,listTitle,listCount,nowTitle,nowArtist,playbackStatus,time,miniTitle,miniArtist,volumeSummary;
    private ImageView artwork,miniArtwork;private ImageButton playButton,miniPlay,previousButton,nextButton,shuffleButton,stopButton;
    private LinearLayout[] tabs=new LinearLayout[2];private ImageView[] tabIcons=new ImageView[2];private TextView[] tabLabels=new TextView[2];
    private ProgressBar activityProgress,loadingProgress,miniProgress;private EditText search;private SeekBar seek;private TrackAdapter adapter;
    private AlertDialog settingsDialog;private Library library;private JSONObject config=new JSONObject();private PlaybackService player;
    private int selected=0,activeTab=1,beforeDemoSelection=0;private boolean demoMode=false,busy=false,bound=false,dragging=false,uiVisible=false,importAfterChoice=false;
    private String displayedId="";private Bitmap displayedArtwork;private List<JSONObject> visibleRows=new ArrayList<>();private UiPresentation.SearchIndex searchIndex;
    private PCloudAccount musicAccount;
    private StereoSpectrumView stereoView,miniStereoView;
    private TextView spotifyStereoNote,miniSpotifyStereoNote;
    private PCloudOfflineAudio.Cancellation offlineCancellation;
    private TextView offlineSummary;private ProgressBar offlineProgress;
    private String offlineMessage="",offlineFingerprint="";private long nextOfflineCheck;
    private PCloudDirectLogin.Session directSession;
    private AlertDialog directDialog;
    private PCloudDeviceLogin.Session browserSession;
    private boolean browserPolling;
    private long nextBrowserPoll;
    private boolean browserResumed;
    private int browserNetworkRetries;
    private Exception browserFailure;
    private long nextCloudSync=0;private String lastCloudFingerprint="",cloudStatus="";
    private SunoLibrary sunoLibrary;private SpotifyController spotify;
    private String pendingSunoImportUrl,pendingSunoImportTitle,sunoPreviewError="";
    private JSONObject pendingSunoCatalog;private int sunoPreviewGeneration;private boolean sunoSaving;
    private ImageButton repeatButton;
    private enum ListenPage { SOURCES, SPOTIFY, SUNO, PHONE, PCLOUD, PLAYER }
    private ListenPage listenPage=ListenPage.SOURCES;
    private String collectionId="";
    private SpotifyUri.Selection pendingSpotify;
    private boolean playAfterSpotifyConsent,reconnectRestoredSpotify;
    private Runnable capabilityTimeout;
    private SpotifyLoginReturn spotifyLoginReturn=SpotifyLoginReturn.NONE;
    private int settingsReturnTab=1;
    private LinearLayout guide, guideBody;
    private SpotifyLibraryBrowser spotifyLibrary;
    private Button spotifyAction, spotifyResume;
    private TextView spotifyMessage;
    private View spotifyCatalog;
    private int selectionEpoch;
    private final ExecutorService sunoWorker=Executors.newSingleThreadExecutor();
    private boolean spotifyActive=false;
    private final PlaybackOwnership playbackOwnership=new PlaybackOwnership();
    private long nativeIntentGeneration=-1,pauseWaitSerial,pauseWaitGeneration=-1;private boolean pauseWaitArmed;
    private Runnable pendingNativePlayback,nativeResumePlayback;
    private final List<View> busyActions=new ArrayList<>();
    private final ExecutorService worker=Executors.newSingleThreadExecutor();private final Handler handler=new Handler(Looper.getMainLooper());
    private final ServiceConnection connection=new ServiceConnection(){
        public void onServiceConnected(ComponentName n,IBinder b){player=((PlaybackService.LocalBinder)b).service();player.setUniformVolumeEnabled(VolumePreferences.enabled(MainActivity.this));if(spotifyActive&&spotify!=null&&spotify.state().playing)player.suspendForExternal();updatePlayback();}
        public void onServiceDisconnected(ComponentName n){player=null;updatePlayback();}
    };
    private final Runnable ticker=new Runnable(){public void run(){if(!uiVisible)return;updatePlayback();maybeBrowserLogin();maybeCloudSync();maybeOfflineSync();handler.postDelayed(this,500);}};
    @Override public void onCreate(Bundle state){
        super.onCreate(state);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        try{library=new Library(this);}catch(Exception failure){new AlertDialog.Builder(this).setTitle("Bibliothèque locale illisible").setMessage("Les données existantes ont été conservées. Ferme l’application et vérifie le stockage.").setPositiveButton("Fermer",(d,w)->finish()).setCancelable(false).show();return;}
        try{config=new SecretStore(this).load();}catch(Exception failure){toast("Les réglages chiffrés sont illisibles. Associe à nouveau le PC dans Réglages.");}
        refreshMusicAccount();
        try{sunoLibrary=new SunoLibrary(this);}catch(Exception failure){toast("Le catalogue Suno existant est illisible et reste conservé. La bibliothèque musicale reste disponible.");}
        spotify=new SpotifyController(this,this::spotifyChanged);
        spotifyLibrary=new SpotifyLibraryBrowser(this,this::playSpotifySelection,this::continueSpotifySelection,this::clearSpotifySelection);
        String savedPage=state==null?getPreferences(MODE_PRIVATE).getString("listen_page","SOURCES"):state.getString("listen_page","SOURCES");
        try{listenPage=ListenPage.valueOf(savedPage);}catch(IllegalArgumentException invalid){listenPage=ListenPage.SOURCES;}
        collectionId=state==null?getPreferences(MODE_PRIVATE).getString("listen_collection",""):state.getString("listen_collection","");
        if(state!=null){settingsReturnTab=state.getInt("settings_return",1);restoreSpotifySelection(state);spotifyLibrary.restoreState(state);}
        if(state!=null){selected=state.getInt("selected",0);activeTab=state.getInt("tab",1);demoMode=state.getBoolean("demo",false);beforeDemoSelection=state.getInt("beforeDemo",0);importAfterChoice=state.getBoolean("importAfterChoice",false);}
        if(state!=null)spotifyActive=state.getBoolean("spotifyActive",false);
        if(activeTab==3){activeTab=1;listenPage=ListenPage.SOURCES;}
        if(getIntent().getBooleanExtra("open_player",false)){activeTab=1;listenPage=ListenPage.PLAYER;}
        if(SpotifyLibraryBrowser.ACTION_AUTH_RETURN.equals(getIntent().getAction())){activeTab=1;listenPage=ListenPage.SPOTIFY;}
        if(getIntent().hasExtra(PCloudOAuth.EXTRA_AUTH_RESULT)&&listenPage!=ListenPage.PCLOUD)activeTab=2;
        build();bound=bindService(new Intent(this,PlaybackService.class),connection,BIND_AUTO_CREATE);
        boolean incoming=offerSunoBrowser(getIntent())||offerMusicShare(getIntent());setIntent(new Intent(this,MainActivity.class));
        if(!incoming&&state!=null&&state.getString("suno_pending_url")!=null)try{String official=SunoBrowserProtocol.musicPage(state.getString("suno_pending_url"));confirmSunoImport(official,SunoBrowserProtocol.title(state.getString("suno_pending_title"),official));}catch(Exception invalid){/* A saved selection never bypasses URL validation or confirmation. */}
    }
    @Override protected void onStart(){super.onStart();PCloudSyncController.setUiActive(true);PCloudSyncJobService.cancelCopiesForForeground();uiVisible=true;if(spotify!=null)spotify.start();if(library!=null)try{library.reload();refreshMusicAccount();render();}catch(Exception failure){error(failure);}if(root!=null){handler.removeCallbacks(ticker);handler.post(ticker);}}
    @Override protected void onResume(){super.onResume();browserResumed=true;spotifyLoginReturn=spotifyLoginReturn.resumed();nextBrowserPoll=0;if(spotify!=null)spotify.refresh();if(library!=null){refreshMusicAccount();if(activeTab==2)buildSettings();if(activeTab==1&&listenPage==ListenPage.SPOTIFY)spotifyLibrary.refresh();}if(browserFailure!=null){Exception failure=browserFailure;browserFailure=null;error(failure);}}
    @Override protected void onPause(){browserResumed=false;spotifyLoginReturn=spotifyLoginReturn.paused();super.onPause();}
    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        setIntent(new Intent(this,MainActivity.class));
        if(root==null)return;
        refreshMusicAccount();
        if(offerSunoBrowser(intent)||offerMusicShare(intent))return;
        if(SpotifyLibraryBrowser.ACTION_AUTH_RETURN.equals(intent.getAction()))openListenPage(ListenPage.SPOTIFY);
        else if(intent.getBooleanExtra("open_player",false))openListenPage(ListenPage.PLAYER);
        else if(intent.hasExtra(PCloudOAuth.EXTRA_AUTH_RESULT)){if(listenPage==ListenPage.PCLOUD)openListenPage(ListenPage.PCLOUD);else settings();}
    }
    @Override protected void onStop(){uiVisible=false;deactivateSpectra();playbackOwnership.clear();pauseWaitArmed=false;pauseWaitSerial++;pendingNativePlayback=null;nativeResumePlayback=null;if(spotify!=null)spotify.background();handler.removeCallbacks(ticker);PCloudSyncController.setUiActive(false);try{PCloudSyncController.schedule(this);}catch(Exception ignored){/* An unavailable account leaves local playback usable. */}super.onStop();}
    @Override protected void onSaveInstanceState(Bundle state){state.putString("listen_page",listenPage.name());state.putString("listen_collection",collectionId);state.putInt("settings_return",settingsReturnTab);saveSpotifySelection(state);if(spotifyLibrary!=null)spotifyLibrary.saveState(state);state.putInt("selected",selected);state.putInt("tab",activeTab);state.putBoolean("demo",demoMode);state.putInt("beforeDemo",beforeDemoSelection);state.putBoolean("importAfterChoice",importAfterChoice);state.putBoolean("spotifyActive",spotifyActive);if(pendingSunoImportUrl!=null){state.putString("suno_pending_url",pendingSunoImportUrl);state.putString("suno_pending_title",pendingSunoImportTitle);}super.onSaveInstanceState(state);}
    private int dp(int value){return (int)(value*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable background(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private TextView text(String value,int size,int color){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setFontFeatureSettings("kern");return t;}
    private TextView heading(String value,int size){TextView t=text(value,size,TEXT);t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return t;}
    private Button button(String label,Runnable action){Button b=new Button(this);b.setText(label);b.setTextColor(TEXT);b.setAllCaps(false);b.setTextSize(14);b.setMinWidth(0);b.setMinimumWidth(0);b.setMinHeight(dp(48));b.setPadding(dp(14),dp(6),dp(14),dp(6));b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(SURFACE));b.setOnClickListener(v->action.run());return b;}
    private Button action(String label,String glyph,boolean primary,Runnable run){Button b=button(label,run);b.setTextColor(primary?BG:TEXT);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(primary?ACCENT:SURFACE));android.graphics.drawable.Drawable icon=UiIcons.icon(glyph,primary?BG:ACCENT);icon.setBounds(0,0,dp(20),dp(20));b.setCompoundDrawablesRelative(icon,null,null,null);b.setCompoundDrawablePadding(dp(8));return b;}
    private ImageButton iconButton(String glyph,String description,Runnable run){ImageButton b=new ImageButton(this);b.setImageDrawable(UiIcons.icon(glyph,TEXT));b.setContentDescription(description);b.setTooltipText(description);b.setScaleType(ImageView.ScaleType.CENTER_INSIDE);b.setPadding(dp(12),dp(12),dp(12),dp(12));b.setBackground(background(SURFACE,16));b.setOnClickListener(v->run.run());b.setMinimumWidth(dp(48));b.setMinimumHeight(dp(48));return b;}
    private LinearLayout.LayoutParams margin(int width,int height,int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(width,height);p.setMargins(0,dp(top),0,dp(bottom));return p;}
    private void build(){
        root=column();root.setPadding(dp(18),dp(10),dp(18),dp(4));root.setBackgroundColor(BG);setContentView(root);
        root.setOnApplyWindowInsetsListener((view,insets)->{int l,r,t,b;if(Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());l=bars.left;r=bars.right;t=bars.top;b=bars.bottom;}else{l=insets.getSystemWindowInsetLeft();r=insets.getSystemWindowInsetRight();t=insets.getSystemWindowInsetTop();b=insets.getSystemWindowInsetBottom();}view.setPadding(dp(18)+l,dp(8)+t,dp(18)+r,dp(2)+b);return insets;});root.requestApplyInsets();
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView mark=new ImageView(this);mark.setImageDrawable(UiIcons.icon("wave",ACCENT));mark.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);top.addView(mark,new LinearLayout.LayoutParams(dp(30),dp(30)));
        TextView name=heading("Rhythmbox",27);name.setSingleLine(true);name.setEllipsize(TextUtils.TruncateAt.END);LinearLayout.LayoutParams nameParams=new LinearLayout.LayoutParams(0,-2,1);nameParams.setMargins(dp(9),0,0,0);top.addView(name,nameParams);
        top.addView(iconButton("settings","Ouvrir les réglages",this::settings),new LinearLayout.LayoutParams(dp(48),dp(48)));root.addView(top);
        subtitle=text("",12,MUTED);subtitle.setVisibility(View.GONE);root.addView(subtitle,margin(-1,-2,0,6));
        activityProgress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);activityProgress.setIndeterminate(true);activityProgress.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));activityProgress.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(ACCENT));activityProgress.setVisibility(View.GONE);root.addView(activityProgress,new LinearLayout.LayoutParams(-1,dp(3)));
        content=new FrameLayout(this);root.addView(content,new LinearLayout.LayoutParams(-1,0,1));buildLibrary();buildPlayer();
        settingsScroll=new ScrollView(this);settingsScroll.setFillViewport(true);content.addView(settingsScroll,new FrameLayout.LayoutParams(-1,-1));
        guide=column();content.addView(guide,new FrameLayout.LayoutParams(-1,-1));
        buildMiniPlayer();buildNavigation();render();showTab(activeTab);
    }
    private void buildLibrary(){
        libraryScreen=column();content.addView(libraryScreen,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);LinearLayout names=column();names.addView(heading("Bibliothèque",25));libraryCount=text("",12,MUTED);names.addView(libraryCount);header.addView(names,new LinearLayout.LayoutParams(0,-2,1));
        ImageButton more=iconButton("more","Actions de la bibliothèque",this::libraryMenu);header.addView(more,new LinearLayout.LayoutParams(dp(48),dp(48)));libraryScreen.addView(header,margin(-1,-2,12,12));
        syncButton=action("Synchroniser","sync",true,this::syncMenu);busyActions.add(syncButton);libraryScreen.addView(syncButton,new LinearLayout.LayoutParams(-1,-2));
        playlistScroller=new HorizontalScrollView(this);playlistScroller.setHorizontalScrollBarEnabled(false);playlistArea=new LinearLayout(this);playlistScroller.addView(playlistArea);libraryScreen.addView(playlistScroller,margin(-1,dp(88),14,6));
        searchBox=new LinearLayout(this);searchBox.setGravity(Gravity.CENTER_VERTICAL);searchBox.setBackground(background(CARD,16));ImageView glass=new ImageView(this);glass.setImageDrawable(UiIcons.icon("search",MUTED));glass.setPadding(dp(12),dp(12),dp(8),dp(12));searchBox.addView(glass,new LinearLayout.LayoutParams(dp(44),dp(48)));
        search=new EditText(this);search.setSingleLine(true);search.setTextColor(TEXT);search.setHintTextColor(MUTED);search.setTextSize(15);search.setHint("Titre, artiste ou album");search.setContentDescription("Rechercher dans la liste");search.setBackgroundColor(Color.TRANSPARENT);search.setPadding(0,dp(10),0,dp(10));search.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);search.setFilters(new InputFilter[]{new InputFilter.LengthFilter(256)});search.setMinHeight(dp(52));searchBox.addView(search,new LinearLayout.LayoutParams(0,-2,1));
        ImageButton clear=iconButton("close","Effacer la recherche",()->search.setText(""));clear.setBackgroundColor(Color.TRANSPARENT);searchBox.addView(clear,new LinearLayout.LayoutParams(dp(48),dp(48)));libraryScreen.addView(searchBox,margin(-1,-2,0,10));
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){renderTracks();}public void afterTextChanged(Editable e){}});
        search.setOnEditorActionListener((v,action,event)->{((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(search.getWindowToken(),0);search.clearFocus();return false;});
        listHeader=new LinearLayout(this);listHeader.setGravity(Gravity.CENTER_VERTICAL);listTitle=heading("Tes titres",17);listTitle.setMaxLines(2);listTitle.setEllipsize(TextUtils.TruncateAt.END);listHeader.addView(listTitle,new LinearLayout.LayoutParams(0,-2,1));listCount=text("",12,MUTED);listHeader.addView(listCount);listHeader.setMinimumHeight(dp(48));listHeader.setOnClickListener(v->chooseList());libraryScreen.addView(listHeader,margin(-1,-2,0,6));
        FrameLayout tracks=new FrameLayout(this);libraryScreen.addView(tracks,new LinearLayout.LayoutParams(-1,0,1));
        trackList=new ListView(this);trackList.setDivider(null);trackList.setCacheColorHint(Color.TRANSPARENT);trackList.setSelector(android.R.color.transparent);trackList.setItemsCanFocus(true);trackList.setClipToPadding(false);trackList.setPadding(0,0,0,dp(8));adapter=new TrackAdapter();trackList.setAdapter(adapter);tracks.addView(trackList,new FrameLayout.LayoutParams(-1,-1));
        ScrollView emptyScroll=new ScrollView(this);emptyScroll.setFillViewport(true);emptyArea=column();emptyArea.setGravity(Gravity.CENTER);emptyArea.setPadding(dp(16),dp(18),dp(16),dp(18));emptyScroll.addView(emptyArea);tracks.addView(emptyScroll,new FrameLayout.LayoutParams(-1,-1));trackList.setEmptyView(emptyScroll);
    }
    private void buildPlayer(){
        playerPane=column();content.addView(playerPane,new FrameLayout.LayoutParams(-1,-1));
        playerPane.addView(button("Changer de source",()->openListenPage(ListenPage.SOURCES)),margin(-1,-2,4,4));
        boolean constrained=getResources().getConfiguration().screenHeightDp<820 || getResources().getConfiguration().fontScale>1.3f;
        LinearLayout transport=column();transport.setGravity(Gravity.CENTER_HORIZONTAL);transport.setPadding(dp(8),dp(6),dp(8),dp(8));
        LinearLayout trackLabels=transport;
        artwork=new ImageView(this);artwork.setScaleType(ImageView.ScaleType.CENTER_CROP);artwork.setImageDrawable(UiIcons.album("rhythmbox"));artwork.setBackground(background(CARD,24));artwork.setClipToOutline(true);artwork.setContentDescription("Illustration du morceau");
        if(constrained){
            // Give the cover its own space next to the title, even when the spectrum is tall.
            playerScroll=new ScrollView(this);playerScroll.setFillViewport(true);
            playerPane.addView(playerScroll,new LinearLayout.LayoutParams(-1,-1));
            playerScroll.addView(transport);
            LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
            header.addView(artwork,new LinearLayout.LayoutParams(dp(64),dp(64)));
            trackLabels=column();trackLabels.setPadding(dp(10),0,0,0);
            header.addView(trackLabels,new LinearLayout.LayoutParams(0,-2,1));
            transport.addView(header,margin(-1,-2,2,4));
        }else{
            // Keep transport visible. The cover uses the remaining height,
            // preserving a square even in Android's edge-to-edge layout.
            FrameLayout coverArea=new FrameLayout(this);playerPane.addView(coverArea,new LinearLayout.LayoutParams(-1,0,1));coverArea.addView(artwork,new FrameLayout.LayoutParams(dp(180),dp(180),Gravity.CENTER));
            coverArea.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->{int side=Math.max(1,Math.min(dp(256),Math.min(r-l,b-t)-dp(16)));android.view.ViewGroup.LayoutParams size=artwork.getLayoutParams();if(size.width!=side || size.height!=side){size.width=side;size.height=side;artwork.setLayoutParams(size);}});playerPane.addView(transport,new LinearLayout.LayoutParams(-1,-2));
        }
        nowTitle=heading("Aucun morceau en cours",24);nowTitle.setGravity(constrained?Gravity.START:Gravity.CENTER);nowTitle.setMaxLines(2);nowTitle.setEllipsize(TextUtils.TruncateAt.END);trackLabels.addView(nowTitle,margin(-1,-2,8,4));
        nowArtist=text("",15,MUTED);nowArtist.setGravity(constrained?Gravity.START:Gravity.CENTER);nowArtist.setMaxLines(constrained?2:1);nowArtist.setEllipsize(TextUtils.TruncateAt.END);trackLabels.addView(nowArtist,margin(-1,-2,0,4));
        playbackStatus=text("",12,ACCENT);playbackStatus.setGravity(Gravity.CENTER);playbackStatus.setMaxLines(2);transport.addView(playbackStatus,margin(-1,-2,0,4));
        loadingProgress=new ProgressBar(this);loadingProgress.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(ACCENT));loadingProgress.setVisibility(View.GONE);transport.addView(loadingProgress,new LinearLayout.LayoutParams(dp(24),dp(24)));
        stereoView=addNativeSpectrum(transport,false);
        spotifyStereoNote=addSpotifyStereoNote(transport);
        seek=new SeekBar(this);seek.setContentDescription("Position de lecture");seek.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));seek.setThumbTintList(android.content.res.ColorStateList.valueOf(ACCENT));transport.addView(seek,margin(-1,dp(48),4,0));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int progress,boolean user){}public void onStartTrackingTouch(SeekBar s){dragging=true;}public void onStopTrackingTouch(SeekBar s){dragging=false;if(spotifyActive){if(spotify!=null)spotify.seekTo(s.getProgress());}else if(player!=null)player.seek(s.getProgress());}});
        time=text("0:00 / 0:00",12,MUTED);time.setGravity(Gravity.CENTER);transport.addView(time,margin(-1,-2,0,8));
        LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER);previousButton=iconButton("previous","Morceau précédent",()->skipPlayback(-1));controls.addView(previousButton,new LinearLayout.LayoutParams(dp(56),dp(56)));
        playButton=iconButton("play","Lire",this::togglePlayback);playButton.setBackground(background(ACCENT,24));LinearLayout.LayoutParams playParams=new LinearLayout.LayoutParams(dp(76),dp(76));playParams.setMargins(dp(22),0,dp(22),0);controls.addView(playButton,playParams);
        nextButton=iconButton("next","Morceau suivant",()->skipPlayback(1));controls.addView(nextButton,new LinearLayout.LayoutParams(dp(56),dp(56)));transport.addView(controls,margin(-1,-2,0,12));
        LinearLayout secondary=new LinearLayout(this);secondary.setGravity(Gravity.CENTER);shuffleButton=iconButton("shuffle","Activer la lecture aléatoire",()->{if(spotifyActive&&spotify!=null){spotify.setShuffle(!spotify.state().shuffled);}else if(player!=null){player.setShuffle(!player.isShuffle());}updatePlayback();});secondary.addView(shuffleButton,new LinearLayout.LayoutParams(dp(48),dp(48)));repeatButton=iconButton("repeat","Répétition Spotify",()->{if(spotifyActive&&spotify!=null)spotify.cycleRepeat();});secondary.addView(repeatButton,new LinearLayout.LayoutParams(dp(48),dp(48)));stopButton=iconButton("stop","Arrêter la lecture",this::stopPlayback);LinearLayout.LayoutParams stopParams=new LinearLayout.LayoutParams(dp(48),dp(48));stopParams.setMargins(dp(24),0,0,0);secondary.addView(stopButton,stopParams);transport.addView(secondary);
    }
    private void buildMiniPlayer(){
        miniPlayer=column();miniPlayer.setBackground(background(CARD,18));miniPlayer.setPadding(dp(10),dp(8),dp(8),dp(2));
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);miniArtwork=new ImageView(this);miniArtwork.setScaleType(ImageView.ScaleType.CENTER_CROP);miniArtwork.setImageDrawable(UiIcons.album("rhythmbox"));miniArtwork.setBackground(background(SURFACE,11));miniArtwork.setClipToOutline(true);miniArtwork.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);row.addView(miniArtwork,new LinearLayout.LayoutParams(dp(44),dp(44)));
        LinearLayout labels=column();labels.setPadding(dp(10),0,dp(8),0);miniTitle=heading("Aucun morceau en cours",14);miniTitle.setSingleLine(true);miniTitle.setEllipsize(TextUtils.TruncateAt.END);miniArtist=text("",12,MUTED);miniArtist.setSingleLine(true);labels.addView(miniTitle);labels.addView(miniArtist);row.addView(labels,new LinearLayout.LayoutParams(0,-2,1));row.setOnClickListener(v->openListenPage(ListenPage.PLAYER));row.setContentDescription("Ouvrir le lecteur");
        miniPlay=iconButton("play","Lire",this::togglePlayback);miniPlay.setBackground(background(ACCENT,16));row.addView(miniPlay,new LinearLayout.LayoutParams(dp(48),dp(48)));miniPlayer.addView(row);
        miniStereoView=addNativeSpectrum(miniPlayer,true);
        miniSpotifyStereoNote=addSpotifyStereoNote(miniPlayer);
        miniProgress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);miniProgress.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));miniPlayer.addView(miniProgress,margin(-1,dp(2),5,0));root.addView(miniPlayer,margin(-1,-2,6,0));miniPlayer.setVisibility(View.GONE);
    }
    private StereoSpectrumView addNativeSpectrum(LinearLayout parent,boolean compact){
        StereoSpectrumView view=new StereoSpectrumView(this);
        view.setCompact(compact);
        view.setVisibility(View.GONE);
        view.setSource(()->spotifyActive||player==null?StereoSpectrum.Snapshot.unavailable():player.spectrum(),
            ()->player==null?"En attente de lecture":player.spectrumStatus());
        parent.addView(view,margin(-1,-2,compact?2:4,compact?0:8));
        return view;
    }
    private TextView addSpotifyStereoNote(LinearLayout parent){
        TextView note=text("Spotify ne transmet pas les canaux gauche et droit à Rhythmbox.",13,MUTED);
        note.setVisibility(View.GONE);
        parent.addView(note,margin(-1,-2,2,4));
        return note;
    }
    private void deactivateSpectra(){
        if(stereoView!=null)stereoView.setActive(false);
        if(miniStereoView!=null)miniStereoView.setActive(false);
    }
    private void updateSpectrum(boolean external,boolean has){
        boolean full=activeTab==1&&listenPage==ListenPage.PLAYER;
        boolean nativeAudio=has&&!external;
        stereoView.setVisibility(nativeAudio&&full?View.VISIBLE:View.GONE);
        miniStereoView.setVisibility(nativeAudio&&!full?View.VISIBLE:View.GONE);
        spotifyStereoNote.setVisibility(external&&full?View.VISIBLE:View.GONE);
        miniSpotifyStereoNote.setVisibility(external&&!full?View.VISIBLE:View.GONE);
        stereoView.setActive(uiVisible&&nativeAudio&&full);
        miniStereoView.setActive(uiVisible&&nativeAudio&&!full);
    }
    private void buildNavigation(){
        LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);String[] names={"Bibliothèque","Lecture"},glyphs={"library","music"};
        for(int i=1;i>=0;i--){final int tab=i;LinearLayout item=column();item.setGravity(Gravity.CENTER);item.setMinimumHeight(dp(64));item.setPadding(dp(4),dp(8),dp(4),dp(4));item.setContentDescription(names[i]);item.setFocusable(true);item.setOnClickListener(v->showTab(tab));ImageView icon=new ImageView(this);icon.setImageDrawable(UiIcons.icon(glyphs[i],MUTED));icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);item.addView(icon,new LinearLayout.LayoutParams(dp(22),dp(22)));TextView label=text(names[i],11,MUTED);label.setPadding(0,dp(5),0,0);label.setGravity(Gravity.CENTER);item.addView(label);tabs[i]=item;tabIcons[i]=icon;tabLabels[i]=label;nav.addView(item,new LinearLayout.LayoutParams(0,-2,1));}
        root.addView(nav,new LinearLayout.LayoutParams(-1,-2));
    }
    private void showTab(int tab){
        activeTab=Math.max(0,Math.min(2,tab));
        if(activeTab!=1)clearSpotifySelection();
        if(guide==null)return;
        libraryScreen.setVisibility(activeTab==0?View.VISIBLE:View.GONE);
        playerPane.setVisibility(activeTab==1&&listenPage==ListenPage.PLAYER?View.VISIBLE:View.GONE);
        guide.setVisibility(activeTab==1&&listenPage!=ListenPage.PLAYER?View.VISIBLE:View.GONE);
        settingsScroll.setVisibility(activeTab==2?View.VISIBLE:View.GONE);
        if(activeTab==2)buildSettings();
        if(guide.getVisibility()==View.VISIBLE)buildGuide();else selectionEpoch++;
        String[] glyphs={"library","music"};
        for(int i=0;i<tabs.length;i++){
            boolean active=i==activeTab;
            tabs[i].setSelected(active);
            tabIcons[i].setImageDrawable(UiIcons.icon(glyphs[i],active?ACCENT:MUTED));
            tabLabels[i].setTextColor(active?ACCENT:MUTED);
        }
        updatePlayback();
    }

    private void openListenPage(ListenPage page){
        if(page!=listenPage){selectionEpoch++;collectionId="";if(page!=ListenPage.SPOTIFY)clearSpotifySelection();}
        if(listenPage==ListenPage.SOURCES&&page==ListenPage.SPOTIFY)spotifyLibrary.openPlaylists();
        listenPage=page;
        saveListenPage();
        showTab(1);
    }

    private void saveListenPage(){
        // A new listening session starts with sources. Keep incomplete selection steps resumable.
        getPreferences(MODE_PRIVATE).edit()
            .putString("listen_page",listenPage==ListenPage.PLAYER?"SOURCES":listenPage.name())
            .putString("listen_collection",collectionId).apply();
    }

    @Override public void onBackPressed(){
        if(activeTab==2){showTab(settingsReturnTab);return;}
        if(activeTab==0){showTab(1);return;}
        if(listenPage==ListenPage.SPOTIFY&&spotifyLibrary.onBack())return;
        if(listenPage==ListenPage.SUNO&&pendingSunoImportUrl!=null){clearSunoSelection();buildGuide();return;}
        if(!collectionId.isEmpty()){collectionId="";saveListenPage();buildGuide();return;}
        if(listenPage!=ListenPage.SOURCES){openListenPage(ListenPage.SOURCES);return;}
        super.onBackPressed();
    }
    private JSONArray lists(){if(!demoMode)return library.playlists();try{return new JSONArray().put(new JSONObject().put("id","demo").put("name","Découverte").put("tracks",DemoAudio.tracks()));}catch(Exception impossible){throw new IllegalStateException(impossible);}}
    private JSONObject current(){JSONArray lists=lists();return selected>=0 && selected<lists.length()?lists.optJSONObject(selected):null;}
    private String duration(long millis){long seconds=Math.max(0,millis/1000);return String.format(java.util.Locale.ROOT,"%d:%02d",seconds/60,seconds%60);}
    private void render(){
        if(playlistArea==null)return;JSONArray lists=lists();java.util.Set<String> hidden=demoMode?Collections.emptySet():library.hidden();boolean compact=getResources().getConfiguration().screenHeightDp<720||getResources().getConfiguration().fontScale>1.15f;playlistScroller.setVisibility(lists.length()>1&&!compact?View.VISIBLE:View.GONE);searchBox.setVisibility(lists.length()>0?View.VISIBLE:View.GONE);listHeader.setVisibility(lists.length()>0?View.VISIBLE:View.GONE);syncButton.setVisibility(!demoMode&&!compact&&(lists.length()>0||!config.optString("key","").isEmpty())?View.VISIBLE:View.GONE);selected=Math.max(0,Math.min(selected,lists.length()-1));playlistArea.removeAllViews();
        libraryCount.setText(demoMode?"Mode découverte · extraits originaux hors ligne":UiPresentation.count(UiPresentation.uniqueCount(lists,hidden),"titre","titres")+" · "+UiPresentation.count(lists.length(),"liste","listes"));
        for(int i=0;i<lists.length();i++){final int index=i;JSONObject list=lists.optJSONObject(i);LinearLayout card=column();card.setPadding(dp(14),dp(12),dp(14),dp(10));card.setBackground(background(i==selected?0xff264b49:CARD,16));TextView title=heading(list.optString("name"),15);title.setSingleLine(true);title.setEllipsize(TextUtils.TruncateAt.END);card.addView(title);int count=UiPresentation.filter(list.optJSONArray("tracks"),hidden,"").size();TextView countLabel=text(UiPresentation.count(count,"titre","titres"),12,i==selected?ACCENT:MUTED);countLabel.setPadding(0,dp(5),0,0);card.addView(countLabel);LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(dp(164),-1);params.setMargins(0,0,dp(9),0);playlistArea.addView(card,params);card.setContentDescription(list.optString("name")+", "+countLabel.getText());card.setFocusable(true);card.setSelected(i==selected);card.setOnClickListener(v->{selected=index;render();});if(!demoMode)card.setOnLongClickListener(v->{playlistOptions(index);return true;});}
        playlistArea.getParent().requestLayout();searchIndex=new UiPresentation.SearchIndex(current()==null?null:current().optJSONArray("tracks"),hidden);renderTracks();updateSyncStatus();if(activeTab==2)buildSettings();if(guide!=null&&activeTab==1&&(listenPage==ListenPage.PHONE||listenPage==ListenPage.PCLOUD))buildGuide();updatePlayback();
    }
    private JSONArray visibleTracks(){return new JSONArray(UiPresentation.filter(current()==null?null:current().optJSONArray("tracks"),demoMode?Collections.emptySet():library.hidden(),search==null?"":search.getText().toString()));}
    private void renderTracks(){if(adapter==null)return;if(searchIndex==null)searchIndex=new UiPresentation.SearchIndex(current()==null?null:current().optJSONArray("tracks"),demoMode?Collections.emptySet():library.hidden());visibleRows=searchIndex.filter(search==null?"":search.getText().toString());listTitle.setText(current()==null?"Pour commencer":current().optString("name","Tes titres"));if(lists().length()>1){android.graphics.drawable.Drawable arrow=UiIcons.icon("chevron",ACCENT);arrow.setBounds(0,0,dp(18),dp(18));listTitle.setCompoundDrawablesRelative(null,null,arrow,null);listTitle.setCompoundDrawablePadding(dp(8));}else listTitle.setCompoundDrawablesRelative(null,null,null,null);listHeader.setContentDescription("Choisir une liste : "+listTitle.getText());listCount.setText(visibleRows.isEmpty()?"":UiPresentation.count(visibleRows.size(),"titre","titres"));buildEmpty();adapter.notifyDataSetChanged();}
    private void buildEmpty(){emptyArea.removeAllViews();boolean filtering=search!=null&&!search.getText().toString().trim().isEmpty();ImageView icon=new ImageView(this);icon.setImageDrawable(UiIcons.icon(filtering?"search":"music",ACCENT));emptyArea.addView(icon,new LinearLayout.LayoutParams(dp(36),dp(36)));TextView heading=heading(filtering?"Aucun résultat":"Aucun morceau dans la bibliothèque",20);heading.setGravity(Gravity.CENTER);emptyArea.addView(heading,margin(-1,-2,14,8));TextView body=text(filtering?"Essaie un autre titre, artiste ou album.":"Importer un dossier ou choisir une source dans Lecture.",14,MUTED);body.setGravity(Gravity.CENTER);emptyArea.addView(body,margin(-1,-2,0,16));if(filtering){emptyArea.addView(button("Effacer la recherche",()->search.setText("")));return;}emptyArea.addView(action("Choisir ma musique","folder",true,this::chooseLocalMusic),new LinearLayout.LayoutParams(-1,-2));emptyArea.addView(button("Choisir une source",()->openListenPage(ListenPage.SOURCES)),margin(-1,-2,8,0));}
    private void chooseLocalMusic(){if(busy){toast("Une opération est déjà en cours");return;}if(demoMode)exitDemo();importAfterChoice=true;chooseTree(PICK_MEDIA);}
    private void enterDemo(){if(busy)return;if(!demoMode){beforeDemoSelection=selected;demoMode=true;selected=0;if(search!=null)search.setText("");render();showTab(0);toast("Découverte hors ligne · extraits originaux, aucune donnée personnelle");}}
    private void exitDemo(){if(player!=null&&player.currentTrackId().startsWith("demo-"))player.stopPlayback();demoMode=false;selected=beforeDemoSelection;render();}
    private void chooseList(){JSONArray source=lists();if(source.length()<2)return;String[] names=new String[source.length()];for(int i=0;i<source.length();i++)names[i]=source.optJSONObject(i).optString("name");new AlertDialog.Builder(this).setTitle("Choisir une liste").setSingleChoiceItems(names,selected,(d,w)->{selected=w;d.dismiss();render();}).setNegativeButton("Annuler",null).show();}
    private void libraryMenu(){if(demoMode){new AlertDialog.Builder(this).setTitle("Mode découverte").setItems(new String[]{"Écouter les extraits","Quitter la découverte"},(d,w)->{if(w==0)showTab(1);else exitDemo();}).show();return;}new AlertDialog.Builder(this).setTitle("Ta bibliothèque").setItems(new String[]{"Créer une liste","Importer la musique d’un dossier","Synchroniser les listes","Options de cette liste"},(d,w)->{if(w==0)createPlaylist();if(w==1)importMedia();if(w==2)syncMenu();if(w==3){if(current()!=null)playlistOptions(selected);else createPlaylist();}}).show();}
    private void playAt(int position){beginNativePlayback(new JSONArray(visibleRows),position);}
    private void togglePlayback(){
        clearSpotifySelection();
        if(spotifyActive){
            if(spotify==null)return;SpotifyController.State state=spotify.state();
            if(state.playing||state.loading){applyPlaybackDecision(playbackOwnership.spotifyPauseIntent());pauseSpotifyVerified();}
            else if(state.canPlay){PlaybackOwnership.Decision intent=playbackOwnership.spotifyIntent();applyPlaybackDecision(intent);if(!spotify.resume(()->spotifyStartRejected(intent.generation)))playbackOwnership.spotifyRejected(intent.generation);}
        }else if(player!=null){
            if(player.loading){playbackOwnership.nativePaused();player.stopPlayback();}
            else if(player.isPlaying()){playbackOwnership.nativePaused();player.toggle();}
            else requestNativePlayback(()->player.toggle(),()->player.resumeAfterExternal());
        }
        updatePlayback();
    }
    private void skipPlayback(int direction){
        clearSpotifySelection();
        if(spotifyActive){if(spotify!=null){PlaybackOwnership.Decision intent=playbackOwnership.spotifyIntent();applyPlaybackDecision(intent);boolean sent=direction<0?spotify.previous(()->spotifyStartRejected(intent.generation)):spotify.next(()->spotifyStartRejected(intent.generation));if(!sent)playbackOwnership.spotifyRejected(intent.generation);}}
        else if(player!=null)requestNativePlayback(()->player.next(direction),()->player.resumeAfterExternal());
        updatePlayback();
    }
    private void stopPlayback(){
        clearSpotifySelection();
        pendingNativePlayback=null;nativeResumePlayback=null;
        if(spotifyActive){applyPlaybackDecision(playbackOwnership.spotifyPauseIntent());if(spotify!=null)pauseSpotifyVerified();}
        else{playbackOwnership.nativePaused();if(player!=null)player.stopPlayback();}
        updatePlayback();
    }
    private void value(TextView view,CharSequence text){if(!TextUtils.equals(view.getText(),text))view.setText(text);}
    private void enabled(View view,boolean value){view.setEnabled(value);view.setAlpha(value?1:.35f);}
    private void updatePlayback(){
        if(nowTitle==null)return;
        SpotifyController.State remote=spotify==null?null:spotify.state();
        boolean external=spotifyActive&&remote!=null;
        boolean has=external?remote.available:player!=null&&player.hasCurrentTrack();
        boolean playing=has&&(external?remote.playing:player.isPlaying());
        boolean loading=has&&(external?remote.loading:player.loading);
        String id=has?(external?"spotify:"+remote.id:player.currentTrackId()):"";
        String title=has?(external?(remote.title.isEmpty()?"Spotify":remote.title):player.title):"Aucun morceau en cours";
        String artist=has?(external?remote.artist:player.artist):"";
        String source=external?"Spotify":has&&id.startsWith("suno:")?"Suno":"";
        value(nowTitle,title);value(nowArtist,source.isEmpty()?artist:source+(artist.isEmpty()?"":" · "+artist));
        value(playbackStatus,external?(remote.playing?"Spotify · En lecture":"Spotify · En pause"):has?player.status+(player.isUniformVolumeEnabled()?"\n"+player.volumeStatus:""):"");
        if(volumeSummary!=null)value(volumeSummary,external?"Spotify · niveau sonore réglé dans Spotify":player!=null?player.volumeStatus:
            VolumePreferences.enabled(this)?"Uniformisation activée pour les prochaines écoutes":"Uniformisation désactivée");
        value(miniTitle,title);value(miniArtist,loading?"Préparation du morceau…":has?source.isEmpty()?artist:source+" · "+artist:"");
        loadingProgress.setVisibility(loading?View.VISIBLE:View.GONE);
        boolean pauseAction=playing||(external&&loading);
        String glyph=loading&&!external?"stop":pauseAction?"pause":"play";
        String description=loading&&!external?"Annuler le chargement":pauseAction?"Mettre en pause":"Lire";
        if(!glyph.equals(playButton.getTag())){playButton.setTag(glyph);playButton.setImageDrawable(UiIcons.icon(glyph,BG));miniPlay.setImageDrawable(UiIcons.icon(glyph,BG));}
        playButton.setContentDescription(description);miniPlay.setContentDescription(description);playButton.setTooltipText(description);miniPlay.setTooltipText(description);
        if(playbackOwnership.awaitingPause())value(playbackStatus,"En attente de la pause Spotify…");
        boolean toggle=has&&!playbackOwnership.awaitingPause()&&(!external||(pauseAction?remote.canPause:remote.canPlay));
        enabled(playButton,toggle);enabled(miniPlay,toggle);
        enabled(previousButton,has&&!playbackOwnership.awaitingPause()&&(external?remote.canPrevious:player.canPrevious()));
        enabled(nextButton,has&&!playbackOwnership.awaitingPause()&&(external?remote.canNext:player.canNext()));
        enabled(stopButton,has&&(!external||remote.canPause));enabled(shuffleButton,has&&(external?remote.shufflePossible:true));if(repeatButton!=null){repeatButton.setVisibility(external?View.VISIBLE:View.GONE);enabled(repeatButton,has&&external&&remote.repeatPossible);repeatButton.setSelected(external&&remote.repeatMode!=0);repeatButton.setContentDescription("Répétition Spotify : "+(!external||remote.repeatMode==0?"désactivée":remote.repeatMode==1?"un morceau":"le contexte"));}
        boolean shuffled=has&&(external?remote.shuffled:player.isShuffle());
        if(!Boolean.valueOf(shuffled).equals(shuffleButton.getTag())){shuffleButton.setTag(shuffled);shuffleButton.setImageDrawable(UiIcons.icon("shuffle",shuffled?ACCENT:MUTED));}
        shuffleButton.setSelected(shuffled);shuffleButton.setContentDescription(shuffled?"Désactiver la lecture aléatoire":"Activer la lecture aléatoire");
        long length=has?(external?remote.duration:player.duration()):0,position=has?(external?remote.positionNow():player.position()):0;
        int maximum=(int)Math.max(1,Math.min(Integer.MAX_VALUE,length)),progress=(int)Math.max(0,Math.min(maximum,position));
        seek.setEnabled(has&&!loading&&length>0&&(!external||remote.canSeek));
        if(!dragging){seek.setMax(maximum);seek.setProgress(progress);}miniProgress.setMax(maximum);miniProgress.setProgress(progress);
        value(time,has?duration(position)+" / "+duration(length):"0:00 / 0:00");miniPlayer.setVisibility(has&&(activeTab!=1||listenPage!=ListenPage.PLAYER)?View.VISIBLE:View.GONE);
        updateSpectrum(external,has);
        Bitmap cover=has?(external?remote.cover:player.artwork):null;
        if(!id.equals(displayedId)||cover!=displayedArtwork){
            displayedId=id;displayedArtwork=cover;
            if(cover!=null){artwork.setImageBitmap(cover);miniArtwork.setImageBitmap(cover);artwork.setContentDescription("Pochette de "+title);}
            else{artwork.setImageDrawable(UiIcons.album(has?artist+title:"rhythmbox"));miniArtwork.setImageDrawable(UiIcons.album(has?artist+title:"rhythmbox"));artwork.setContentDescription("Illustration du morceau");}
            if(adapter!=null)adapter.notifyDataSetChanged();
        }
        updateSpotifyLabels();
    }
    private void spotifyStartRejected(long intent){
        if(isFinishing()||isDestroyed())return;
        playbackOwnership.spotifyRejected(intent);
        if(spotify!=null)spotifyChanged(spotify.state());else updatePlayback();
        if(activeTab==1&&listenPage==ListenPage.PLAYER&&playbackOwnership.generation()==intent&&spotify!=null&&!spotify.state().playing){
            openListenPage(ListenPage.SPOTIFY);toast("Spotify n’a pas confirmé la lecture. Réessaie depuis le morceau.");
        }
    }
    private boolean pauseSpotifyVerified(){
        if(spotify==null)return false;
        final long possibleStart=playbackOwnership.pendingSpotifyStart();
        return spotify.pause(()->{if(!isFinishing()&&!isDestroyed()){playbackOwnership.spotifyPauseConfirmed(possibleStart);spotifyChanged(spotify.state());}});
    }
    private void spotifyChanged(SpotifyController.State state){
        if(isFinishing()||isDestroyed())return;
        applyPlaybackDecision(playbackOwnership.onSpotifyState(state.sessionGeneration,state.playerRevision,state.available,state.playing,state.loading));
        if((spotify.needsAuthorization()||spotify.needsLogin())&&!state.loading)playAfterSpotifyConsent=false;
        continueSpotifySelection();
        updatePlayback();
    }
    private void applyPlaybackDecision(PlaybackOwnership.Decision decision){
        if(decision.suspendNative&&player!=null)player.suspendForExternal();
        if(decision.spotifySelected)spotifyActive=true;
        else if(decision.pauseSpotify||decision.startNative||decision.resumeNative)spotifyActive=false;
        if(!playbackOwnership.awaitingPause()||pauseWaitGeneration!=decision.generation){pauseWaitArmed=false;pauseWaitSerial++;pauseWaitGeneration=decision.generation;}
        if(decision.pauseSpotify&&(spotify==null||!pauseSpotifyVerified())){
            if(playbackOwnership.timeout(decision.generation)){pendingNativePlayback=null;nativeResumePlayback=null;toast("Mets Spotify en pause avant de lancer ce morceau.");}
            pauseWaitArmed=false;pauseWaitSerial++;return;
        }
        if(decision.pauseSpotify&&playbackOwnership.awaitingPause()&&!pauseWaitArmed){
            pauseWaitArmed=true;final long wait=++pauseWaitSerial,generation=decision.generation;
            handler.postDelayed(()->{if(wait==pauseWaitSerial&&playbackOwnership.timeout(generation)){pauseWaitArmed=false;pauseWaitSerial++;pendingNativePlayback=null;nativeResumePlayback=null;toast("La pause Spotify n’a pas été confirmée. Réessaie après l’avoir mis en pause.");updatePlayback();}},3500);
        }
        if(decision.generation!=nativeIntentGeneration||decision.generation!=playbackOwnership.generation()||isFinishing()||isDestroyed())return;
        if(decision.startNative&&pendingNativePlayback!=null)pendingNativePlayback.run();
        else if(decision.resumeNative&&nativeResumePlayback!=null)nativeResumePlayback.run();
    }
    private void requestNativePlayback(Runnable start,Runnable resume){
        clearSpotifySelection();
        if(player==null){toast("Le lecteur se prépare. Réessaie dans un instant.");return;}
        SpotifyController.State state=spotify==null?null:spotify.state();
        PlaybackOwnership.Decision intent=playbackOwnership.nativeIntent(state==null?-1:state.sessionGeneration,state==null?0:state.playerRevision,state!=null&&state.available,state!=null&&state.playing,state!=null&&state.loading);
        final long generation=intent.generation;nativeIntentGeneration=generation;
        pendingNativePlayback=()->{if(player==null||generation!=playbackOwnership.generation()||isFinishing()||isDestroyed())return;spotifyActive=false;start.run();openListenPage(ListenPage.PLAYER);};
        nativeResumePlayback=()->{if(player==null||generation!=playbackOwnership.generation()||isFinishing()||isDestroyed())return;spotifyActive=false;resume.run();updatePlayback();};
        applyPlaybackDecision(intent);
        if(playbackOwnership.awaitingPause()){
            toast("Mise en pause de Spotify avant la lecture…");
        }
    }
    private void beginNativePlayback(JSONArray tracks,int selectedTrack){
        beginNativePlayback(tracks,selectedTrack,false);
    }
    private void beginNativePlayback(JSONArray tracks,int selectedTrack,boolean ordered){
        if(player==null){toast("Le lecteur se prépare. Réessaie dans un instant.");return;}
        if(selectedTrack<0||selectedTrack>=tracks.length())return;
        final JSONArray frozen;try{frozen=new JSONArray(tracks.toString());}catch(Exception failure){error(failure);return;}
        requestNativePlayback(()->player.play(frozen,selectedTrack,ordered),()->player.resumeAfterExternal());
    }
    private void buildGuide(){
        spotifyAction=null;
        spotifyMessage=null;
        spotifyResume=null;
        if(spotifyCatalog!=null&&spotifyCatalog.getParent() instanceof ViewGroup)
            ((ViewGroup)spotifyCatalog.getParent()).removeView(spotifyCatalog);
        guide.removeAllViews();
        guide.setPadding(0,dp(6),0,dp(4));
        if(listenPage==ListenPage.PLAYER)return;
        if(listenPage==ListenPage.SOURCES){
            guide.addView(heading("Lecture",26),margin(-1,-2,2,6));
            ScrollView choices=new ScrollView(this);
            LinearLayout rows=column();
            choices.addView(rows);
            guide.addView(choices,new LinearLayout.LayoutParams(-1,0,1));
            addSource(rows,"Spotify","music",0xff65d990,ListenPage.SPOTIFY);
            addSource(rows,"Suno","wave",0xffffa783,ListenPage.SUNO);
            addSource(rows,"Sur ce téléphone","folder",0xff99bcff,ListenPage.PHONE);
            addSource(rows,"pCloud","library",0xff82d8e8,ListenPage.PCLOUD);
            return;
        }
        LinearLayout header=new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        String source=listenPage==ListenPage.SPOTIFY?"Spotify":listenPage==ListenPage.SUNO?"Suno":
            listenPage==ListenPage.PCLOUD?"pCloud":"Sur ce téléphone";
        header.addView(heading(source,23),new LinearLayout.LayoutParams(0,-2,1));
        header.addView(button("Sources",()->openListenPage(ListenPage.SOURCES)));
        guide.addView(header,margin(-1,-2,0,8));
        guideBody=column();
        guideBody.setFocusableInTouchMode(true);
        guide.addView(guideBody,new LinearLayout.LayoutParams(-1,0,1));
        if(listenPage==ListenPage.SPOTIFY){buildSpotifyGuide();return;}
        if(listenPage==ListenPage.SUNO&&pendingSunoImportUrl!=null){showSunoPreview();return;}
        buildCollectionGuide();
    }

    private void addSource(LinearLayout rows,String label,String glyph,int color,ListenPage page){
        Button entry=action(label,glyph,false,()->openListenPage(page));
        entry.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
        entry.setTextSize(19);
        entry.setTextColor(TEXT);
        entry.setPadding(dp(18),dp(8),dp(18),dp(8));
        entry.setCompoundDrawablePadding(dp(16));
        android.graphics.drawable.Drawable mark=UiIcons.icon(glyph,color);
        mark.setBounds(0,0,dp(25),dp(25));
        entry.setCompoundDrawablesRelative(mark,null,null,null);
        entry.setMinHeight(dp(58));
        rows.addView(entry,margin(-1,-2,4,2));
    }

    private void buildSpotifyGuide(){
        spotifyCatalog=spotifyLibrary.view();
        guideBody.addView(spotifyCatalog,new LinearLayout.LayoutParams(-1,0,1));
        spotifyLibrary.refresh();
        spotifyMessage=text("",14,MUTED);
        guideBody.addView(spotifyMessage,margin(-1,-2,2,4));
        spotifyAction=action("Autoriser dans Spotify","music",true,()->{
            if(pendingSpotify==null)return;
            if(spotify.needsLogin()&&spotify.isSpotifyInstalled())openSpotifyForLogin();
            else playSpotifySelection(pendingSpotify);
        });
        guideBody.addView(spotifyAction,margin(-1,-2,2,4));
        spotifyResume=button("",()->{
            if(pendingSpotify!=null){playSpotifySelection(pendingSpotify);return;}
            SpotifyController.State remote=spotify.state();
            if(!remote.available||remote.id.isEmpty())return;
            if(remote.playing){spotifyActive=true;openListenPage(ListenPage.PLAYER);return;}
            PlaybackOwnership.Decision intent=playbackOwnership.spotifyIntent();
            applyPlaybackDecision(intent);
            if(spotify.resume(()->spotifyStartRejected(intent.generation)))openListenPage(ListenPage.PLAYER);
            else spotifyStartRejected(intent.generation);
        });
        guideBody.addView(spotifyResume,margin(-1,-2,0,4));
        updateSpotifyLabels();
    }

    private void updateSpotifyLabels(){
        if(activeTab!=1||listenPage!=ListenPage.SPOTIFY||spotifyAction==null)return;
        SpotifyController.State state=spotify.state();
        boolean pending=pendingSpotify!=null;
        String label=!spotify.isSpotifyInstalled()?"Installer Spotify":spotify.needsLogin()?"Ouvrir Spotify pour se connecter":
            spotify.needsAuthorization()?"Autoriser dans Spotify":"Écouter dans Spotify";
        value(spotifyAction,label);
        spotifyAction.setVisibility(pending&&!state.available?View.VISIBLE:View.GONE);
        enabled(spotifyAction,!state.loading);
        String message=pending&&!state.available?state.status:
            pending&&playAfterSpotifyConsent&&!state.capabilitiesKnown?"Vérification des possibilités de lecture…":"";
        value(spotifyMessage,message);
        spotifyMessage.setVisibility(message.isEmpty()?View.GONE:View.VISIBLE);
        String resume=pending?"Écouter "+(pendingSpotify.name.isEmpty()?"la sélection":pendingSpotify.name):
            state.title.isEmpty()?"":(state.playing?"En lecture · ":"Reprendre · ")+state.title;
        value(spotifyResume,resume);
        spotifyResume.setVisibility(state.available&&!playAfterSpotifyConsent&&!resume.isEmpty()?View.VISIBLE:View.GONE);
    }

    private void buildCollectionGuide(){
        try{
            if(listenPage==ListenPage.SUNO){showSunoCollections();return;}
            List<SourceCollection> collections=SourceCollection.fromLibrary(library,musicAccount,listenPage==ListenPage.PCLOUD);
            if(!collectionId.isEmpty()){
                for(SourceCollection collection:collections)if(collectionId.equals(collection.id)){
                    showCollectionTracks(collection);return;
                }
                collectionId="";saveListenPage();
            }
            if(!collections.isEmpty())showSourceCollections(collections);
            if(listenPage==ListenPage.PHONE){
                boolean hasFolder=!config.optString("media_tree","").isEmpty();
                if(collections.isEmpty()||!hasFolder)
                    guideBody.addView(button(hasFolder?"Importer le dossier musical":"Choisir un dossier musical",
                        hasFolder?this::importLocalMusic:this::chooseLocalMusic),margin(-1,-2,6,0));
            }else if(browserSession!=null){
                guideBody.addView(button("Revenir à la connexion pCloud",()->openBrowserLogin(browserSession)));
            }else if(musicAccount==null){
                if(collections.isEmpty())guideBody.addView(button("Connecter pCloud",this::connectMusicAccount));
            }else if(!musicAccount.hasMusicFolder()){
                guideBody.addView(button("Choisir le dossier musical",()->chooseCloudFolder(0,"Mon espace pCloud")));
            }else{
                guideBody.addView(button("Choisir une liste pCloud",()->chooseCloudCollection(null)),margin(-1,-2,6,0));
            }
        }catch(Exception failure){guideBody.addView(text("Impossible de charger les listes.",14,MUTED));}
    }

    private static final String SUNO_SINGLES="individual-suno-songs";

    private void showSunoCollections() throws Exception {
        if(sunoLibrary==null){
            guideBody.addView(text("Les playlists Suno enregistrées sont illisibles.",14,MUTED));return;
        }
        List<SunoLibrary.Playlist> playlists=sunoLibrary.playlists();
        JSONArray singles=sunoLibrary.singles();
        if(collectionId.equals(SUNO_SINGLES)&&singles.length()>0){
            showCollectionTracks(new SourceCollection(SUNO_SINGLES,"Morceaux ajoutés",singles));return;
        }
        if(!collectionId.isEmpty()){
            for(SunoLibrary.Playlist item:playlists)if(collectionId.equals(item.id)){
                showCollectionTracks(new SourceCollection(item.id,item.name,sunoLibrary.queue(item.id)));return;
            }
            collectionId="";saveListenPage();
        }
        if(playlists.isEmpty())guideBody.addView(text("Aucune playlist Suno ajoutée.",16,MUTED),margin(-1,-2,8,12));
        else{
            List<String> labels=new ArrayList<>();
            for(SunoLibrary.Playlist item:playlists)
                labels.add(item.name+"\n"+UiPresentation.count(item.count,"morceau","morceaux"));
            ListView list=choiceList(labels);
            list.setOnItemClickListener((parent,view,row,id)->openCollection(playlists.get(row).id));
            list.setOnItemLongClickListener((parent,view,row,id)->{
                SunoLibrary.Playlist item=playlists.get(row);sunoOptions(item.id,item.name);return true;
            });
        }
        guideBody.addView(button("Ajouter depuis Suno",this::chooseFromSuno),margin(-1,-2,6,0));
        if(!getPreferences(MODE_PRIVATE).getBoolean("suno_share_hint",false))
            guideBody.addView(text("Dans Suno, ouvre une playlist puis touche Partager → Rhythmbox LeMegaGeek.",14,MUTED),margin(-1,-2,2,4));
        if(singles.length()>0)
            guideBody.addView(button("Morceaux ajoutés ("+singles.length()+")",()->openCollection(SUNO_SINGLES)),margin(-1,-2,6,0));
    }

    private void openCollection(String id){collectionId=id;saveListenPage();buildGuide();}

    private void showSourceCollections(List<SourceCollection> collections){
        List<String> labels=new ArrayList<>();
        for(SourceCollection collection:collections){
            labels.add(collection.name+"\n"+UiPresentation.count(collection.tracks.length(),"morceau","morceaux"));
        }
        ListView list=choiceList(labels);
        list.setOnItemClickListener((parent,view,index,rowId)->openCollection(collections.get(index).id));
    }

    private void sunoOptions(String sourceId,String name){
        new AlertDialog.Builder(this).setTitle(name)
            .setItems(new String[]{"Actualiser depuis Suno","Retirer de ce téléphone"},(d,choice)->{
                if(choice==1){removeSunoSource(sourceId,name);return;}
                try{
                    JSONArray sources=sunoLibrary.sources();
                    for(int i=0;i<sources.length();i++){
                        JSONObject entry=sources.getJSONObject(i);
                        if(entry.getString("id").equals(sourceId)){refreshSunoCatalog(entry.getString("source_url"));break;}
                    }
                }catch(Exception failure){error(failure);}
            }).setNegativeButton("Annuler",null).show();
    }

    private void showCollectionTracks(SourceCollection collection){
        LinearLayout title=new LinearLayout(this);
        title.setGravity(Gravity.CENTER_VERTICAL);
        TextView name=heading(collection.name,18);
        title.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        title.addView(button("Listes",()->{collectionId="";saveListenPage();buildGuide();}));
        guideBody.addView(title,margin(-1,-2,0,4));
        if(collection.tracks.length()==0){guideBody.addView(text("Cette liste est vide.",14,MUTED));return;}
        boolean sunoPlaylist=listenPage==ListenPage.SUNO && !SUNO_SINGLES.equals(collection.id);
        if(sunoPlaylist){
            guideBody.addView(action("Lire la playlist","play",true,()->playSunoPlaylist(collection.tracks,0)),margin(-1,-2,0,6));
        }
        EditText filter=new EditText(this);
        filter.setSingleLine(true);filter.setHint("Titre, artiste ou album");
        filter.setContentDescription("Rechercher dans "+collection.name);
        filter.setTextColor(TEXT);filter.setHintTextColor(MUTED);
        filter.setFilters(new InputFilter[]{new InputFilter.LengthFilter(256)});
        guideBody.addView(filter,new LinearLayout.LayoutParams(-1,-2));
        List<Integer> sourcePositions=new ArrayList<>();
        ListView tracks=choiceList(new ArrayList<>());
        @SuppressWarnings("unchecked") ArrayAdapter<String> names=(ArrayAdapter<String>)tracks.getAdapter();
        UiPresentation.SearchIndex index=new UiPresentation.SearchIndex(collection.tracks,Collections.emptySet());
        Runnable fill=()->{
            sourcePositions.clear();sourcePositions.addAll(index.filterSourcePositions(filter.getText().toString()));
            names.setNotifyOnChange(false);names.clear();
            for(int position:sourcePositions){
                JSONObject track=collection.tracks.optJSONObject(position);
                String artist=track.optString("artist","");
                names.add(UiPresentation.title(track)+(artist.isEmpty()?"":"\n"+artist));
            }
            names.notifyDataSetChanged();
        };
        filter.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){fill.run();}
            public void afterTextChanged(Editable value){}
        });
        fill.run();
        tracks.setOnItemClickListener((a,v,row,id)->{
            if(sunoPlaylist){playSunoPlaylist(collection.tracks,sourcePositions.get(row));return;}
            JSONArray filtered=new JSONArray();
            for(int position:sourcePositions)filtered.put(collection.tracks.optJSONObject(position));
            playSourceQueue(filtered,row);
        });
        if(SUNO_SINGLES.equals(collection.id)){
            tracks.setOnItemLongClickListener((a,v,row,id)->{
                JSONObject track=collection.tracks.optJSONObject(sourcePositions.get(row));
                sunoOptions(track.optString("id"),UiPresentation.title(track));return true;
            });
        }
    }

    private ListView choiceList(List<String> labels){
        ListView list=new ListView(this);
        list.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,labels){
            @Override public View getView(int position,View reusable,ViewGroup parent){
                TextView label=(TextView)super.getView(position,reusable,parent);
                label.setSingleLine(false);label.setTextColor(TEXT);label.setTextSize(16);
                label.setPadding(dp(10),dp(10),dp(10),dp(10));label.setMinHeight(dp(54));
                return label;
            }
        });
        guideBody.addView(list,new LinearLayout.LayoutParams(-1,0,1));
        return list;
    }

    private void playSourceQueue(JSONArray songs,int index){
        if(demoMode)exitDemo();
        beginNativePlayback(songs,index);
    }
    private void playSunoPlaylist(JSONArray songs,int index){
        if(demoMode)exitDemo();
        beginNativePlayback(songs,index,true);
    }
    private void refreshSourceIfOpen(ListenPage page){
        if(activeTab==1&&listenPage==page)buildGuide();
    }
    private void chooseFromSuno(){
        getPreferences(MODE_PRIVATE).edit().putBoolean("suno_share_hint",true).apply();
        openSunoBrowser(SunoBrowserProtocol.Destination.PLAYLISTS);
    }
    private void configureSpotify(){
        if(spotify==null)return;
        LinearLayout panel=column();panel.setPadding(dp(20),dp(6),dp(20),0);
        panel.addView(text("Le Client ID public identifie Rhythmbox chez Spotify. Aucun mot de passe ni Client Secret n’est demandé. L’application doit être enregistrée avec son empreinte de signature Android et cette redirection exacte :\n"+SpotifyController.REDIRECT_URI,13,MUTED));
        EditText id=new EditText(this);id.setSingleLine(true);id.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);id.setHint("Client ID Spotify (32 caractères)");id.setText(spotify.clientId());id.setSelectAllOnFocus(true);panel.addView(id,margin(-1,-2,10,0));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Configuration App Remote").setView(panel).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",null).create();
        dialog.setOnShowListener(ignored->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{clearSpotifySelection();spotify.configure(id.getText().toString());dialog.dismiss();updateSpotifyLabels();}catch(IllegalArgumentException invalid){id.setError(invalid.getMessage());}}));dialog.show();
    }
    private void showSpotifyNotices(){
        String[] labels={"Spotify SDK : licence amont","Spotify SDK : notices","Gson : licence Apache 2.0","Conditions d’utilisation Spotify"};
        new AlertDialog.Builder(this).setTitle("Composants et service Spotify").setItems(labels,(dialog,which)->{
            if(which==3){try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://developer.spotify.com/terms")));}catch(ActivityNotFoundException missing){toast("Aucun navigateur disponible.");}return;}
            String[] files={"spotify-sdk-LICENSE.txt","spotify-sdk-NOTICE.txt","gson-LICENSE.txt"};
            try(java.io.InputStream source=getAssets().open("third-party-licenses/"+files[which]);java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream()){
                byte[] chunk=new byte[4096];int count;while((count=source.read(chunk))!=-1){if(bytes.size()+count>65536)throw new java.io.IOException("Notice trop volumineuse");bytes.write(chunk,0,count);}
                ScrollView scroll=new ScrollView(this);TextView body=text(new String(bytes.toByteArray(),java.nio.charset.StandardCharsets.UTF_8),12,TEXT);body.setPadding(dp(18),dp(12),dp(18),dp(12));body.setTextIsSelectable(true);scroll.addView(body);
                new AlertDialog.Builder(this).setTitle(labels[which]).setView(scroll).setPositiveButton("Fermer",null).show();
            }catch(Exception failure){toast("Notice de licence indisponible.");}
        }).setNegativeButton("Fermer",null).show();
    }
    private void clearSpotifySelection(){
        pendingSpotify=null;
        spotifyLoginReturn=SpotifyLoginReturn.NONE;
        playAfterSpotifyConsent=false;reconnectRestoredSpotify=false;
        cancelCapabilityTimeout();
    }

    private void saveSpotifySelection(Bundle out){
        if(pendingSpotify==null)return;
        out.putString("spotify_selection",pendingSpotify.uri);
        out.putString("spotify_selection_name",pendingSpotify.name);
        out.putString("spotify_selection_context",pendingSpotify.context);
        out.putString("spotify_selection_session",pendingSpotify.session);
        out.putInt("spotify_selection_index",pendingSpotify.index);
        out.putBoolean("spotify_selection_play",playAfterSpotifyConsent);
        out.putString("spotify_login_visit",spotifyLoginReturn.name());
        out.putBoolean("spotify_login_needed",spotify!=null && spotify.needsLogin());
    }

    private void restoreSpotifySelection(Bundle state){
        String uri=state.getString("spotify_selection");
        if(uri==null)return;
        try{
            pendingSpotify=new SpotifyUri.Selection(uri,state.getString("spotify_selection_context"),
                state.getInt("spotify_selection_index",-1),state.getString("spotify_selection_name"),
                state.getString("spotify_selection_session"));
            playAfterSpotifyConsent=state.getBoolean("spotify_selection_play");
            reconnectRestoredSpotify=playAfterSpotifyConsent;
            spotifyLoginReturn=SpotifyLoginReturn.restore(state.getString("spotify_login_visit"));
            if(state.getBoolean("spotify_login_needed"))spotify.restoreLoginHint();
        }catch(IllegalArgumentException invalid){clearSpotifySelection();}
    }

    private void playSpotifySelection(SpotifyUri.Selection selection){
        cancelCapabilityTimeout();
        pendingSpotify=selection;
        spotifyLoginReturn=SpotifyLoginReturn.NONE;
        playAfterSpotifyConsent=true;reconnectRestoredSpotify=false;
        SpotifyController.State state=spotify.state();
        if(state.available){continueSpotifySelection();return;}
        if(!spotify.isSpotifyInstalled()){
            playAfterSpotifyConsent=false;
            openSpotify();
        }else if(spotify.needsLogin()){
            playAfterSpotifyConsent=false;
        }else if(!state.loading){
            if(!spotify.connect())playAfterSpotifyConsent=false;
        }
        updateSpotifyLabels();
    }

    private void continueSpotifySelection(){
        if(!uiVisible||!browserResumed||activeTab!=1||listenPage!=ListenPage.SPOTIFY||pendingSpotify==null)return;
        final SpotifyUri.Selection selection=pendingSpotify;
        if(!selection.session.isEmpty()){
            if(spotifyLibrary.checkingAccount())return;
            if(!spotifyLibrary.matches(selection.session)){
                clearSpotifySelection();updateSpotifyLabels();return;
            }
        }
        if(spotifyLoginReturn==SpotifyLoginReturn.RETURNED){
            spotifyLoginReturn=SpotifyLoginReturn.NONE;
            reconnectRestoredSpotify=false;
            playAfterSpotifyConsent=true;
            SpotifyController.State current=spotify.state();
            if(!current.available&&!current.loading&&!spotify.connect())playAfterSpotifyConsent=false;
        }
        if(!playAfterSpotifyConsent)return;
        SpotifyController.State remote=spotify.state();
        if(!remote.available){
            if(reconnectRestoredSpotify&&!remote.loading){
                reconnectRestoredSpotify=false;
                if(!spotify.restoreAfterConsent())playAfterSpotifyConsent=false;
            }
            return;
        }
        reconnectRestoredSpotify=false;
        if(selection.isTrack()&&!remote.capabilitiesKnown){
            if(capabilityTimeout==null){
                capabilityTimeout=()->{
                    capabilityTimeout=null;
                    if(pendingSpotify!=selection||!playAfterSpotifyConsent||!browserResumed||!uiVisible||
                        activeTab!=1||listenPage!=ListenPage.SPOTIFY||!spotify.state().available)return;
                    if(spotify.state().capabilitiesKnown){continueSpotifySelection();return;}
                    playAfterSpotifyConsent=false;
                    offerWholeSpotifyContext(selection,"Spotify n’a pas confirmé la lecture de ce titre.");
                };
                handler.postDelayed(capabilityTimeout,10000);
            }
            return;
        }
        cancelCapabilityTimeout();
        // Claim once, before any callbacks or dialogs can re-enter this method.
        playAfterSpotifyConsent=false;
        if(selection.isTrack()&&!remote.canPlayOnDemand){
            offerWholeSpotifyContext(selection,"Ce compte Spotify permet de lancer un album ou une playlist.");
            return;
        }
        PlaybackOwnership.Decision intent=playbackOwnership.spotifyIntent();
        applyPlaybackDecision(intent);
        Runnable rejected=()->spotifyStartRejected(intent.generation);
        boolean sent=selection.context.isEmpty()?spotify.playUri(selection.uri,rejected):
            spotify.playContextTrack(selection.context,selection.index,rejected);
        if(sent){clearSpotifySelection();openListenPage(ListenPage.PLAYER);}
        else{spotifyStartRejected(intent.generation);toast(spotify.state().status);}
    }

    private void cancelCapabilityTimeout(){
        if(capabilityTimeout!=null){handler.removeCallbacks(capabilityTimeout);capabilityTimeout=null;}
    }
    private void offerWholeSpotifyContext(SpotifyUri.Selection selection,String message){
        AlertDialog.Builder explanation=new AlertDialog.Builder(this).setTitle("Lecture Spotify")
            .setMessage(message).setNegativeButton("Fermer",null);
        if(!selection.context.isEmpty()){
            boolean album=selection.context.startsWith("spotify:album:");
            explanation.setPositiveButton(album?"Lire cet album":"Lire cette playlist",(d,w)->{
                if(pendingSpotify==selection)playSpotifySelection(selection.wholeContext());
            });
        }
        explanation.show();
        updateSpotifyLabels();
    }
    private void openSpotifyForLogin(){
        if(pendingSpotify==null||spotifyLoginReturn!=SpotifyLoginReturn.NONE)return;
        Intent launch=getPackageManager().getLaunchIntentForPackage(SpotifyController.SPOTIFY_PACKAGE);
        if(launch==null){toast("Impossible d’ouvrir l’application Spotify.");return;}
        // This launches the official app, without a track URI or a playback command.
        launch.setPackage(SpotifyController.SPOTIFY_PACKAGE);
        spotifyLoginReturn=SpotifyLoginReturn.OPENED;
        playAfterSpotifyConsent=false;reconnectRestoredSpotify=false;
        try{startActivity(launch);}
        catch(ActivityNotFoundException|SecurityException unavailable){
            spotifyLoginReturn=SpotifyLoginReturn.NONE;
            toast("Impossible d’ouvrir l’application Spotify.");
        }
    }

    private void openSpotify(){
        Intent launch=getPackageManager().getLaunchIntentForPackage("com.spotify.music");
        if(launch!=null){try{startActivity(launch);return;}catch(ActivityNotFoundException ignored){}}
        new AlertDialog.Builder(this).setTitle("Installer Spotify").setMessage("L’application Spotify doit être installée sur ce téléphone pour être pilotée ici.").setNegativeButton("Fermer",null).setPositiveButton("Voir dans Google Play",(d,w)->{try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://play.google.com/store/apps/details?id=com.spotify.music")));}catch(ActivityNotFoundException missing){toast("Aucun navigateur ou Google Play disponible.");}}).show();
    }
    private boolean offerMusicShare(Intent intent){
        if(intent==null||!Intent.ACTION_SEND.equals(intent.getAction())||!"text/plain".equals(intent.getType()))return false;
        try{
            SharedMusic item=SharedMusic.parse(intent.getCharSequenceExtra(Intent.EXTRA_TEXT));
            String title=intent.getStringExtra(Intent.EXTRA_SUBJECT);
            if(item.spotify){
                clearSpotifySelection();
                String name=title==null||title.trim().isEmpty()?"la sélection Spotify":SunoBrowserProtocol.title(title,null);
                pendingSpotify=new SpotifyUri.Selection(item.reference,"",-1,name,"");
                openListenPage(ListenPage.SPOTIFY);
            }else{
                openListenPage(ListenPage.SUNO);
                confirmSunoImport(item.reference,title);
            }
        }catch(Exception invalid){toast("Partager un morceau ou une playlist depuis Spotify ou Suno.");}
        return true;
    }
    private void openSunoBrowser(SunoBrowserProtocol.Destination destination){
        try{SunoBrowser.open(this,destination);}
        catch(ActivityNotFoundException missing){toast("Active un navigateur pour ouvrir la page officielle Suno.");}
        catch(Exception unavailable){toast("Impossible d’ouvrir Suno. Vérifie ton navigateur puis réessaie.");}
    }
    private boolean offerSunoBrowser(Intent intent){
        if(intent==null||!SunoBrowser.ACTION_RETURN.equals(intent.getAction()))return false;
        try{SunoBrowser.Selection chosen=SunoBrowser.consume(this,intent);openListenPage(ListenPage.SUNO);handler.post(()->{if(!isFinishing()&&!isDestroyed())confirmSunoImport(chosen.url,chosen.title);});}
        catch(Exception invalid){new AlertDialog.Builder(this).setTitle("Choisis un morceau ou une playlist partageable")
            .setMessage(invalid instanceof IllegalArgumentException&&invalid.getMessage()!=null?invalid.getMessage():"Retour Suno interrompu. Rouvre Suno depuis Rhythmbox.")
            .setNegativeButton("Fermer",null).setPositiveButton("Mes playlists Suno",(dialog,which)->openSunoBrowser(SunoBrowserProtocol.Destination.PLAYLISTS)).show();}
        return true;
    }
    private void confirmSunoImport(String official,String title){
        if(sunoLibrary==null){toast("Les morceaux Suno enregistrés sont illisibles.");return;}
        pendingSunoImportUrl=official;
        pendingSunoImportTitle=SunoBrowserProtocol.title(title,official);
        pendingSunoCatalog=null;
        sunoPreviewError="";
        final int preview=++sunoPreviewGeneration;
        refreshSourceIfOpen(ListenPage.SUNO);
        // Resolve only metadata from the validated music page. Writing the selection
        // and starting the player both wait for the user's explicit Listen action.
        sunoWorker.execute(()->{
            try{
                JSONObject catalog=null;
                JSONArray saved=sunoLibrary.sources();
                for(int i=0;i<saved.length();i++){
                    JSONObject old=saved.getJSONObject(i);
                    if(official.equals(old.optString("source_url"))){catalog=old;break;}
                }
                if(catalog==null)catalog=SunoCatalog.resolve(official);
                final JSONObject result=catalog;
                postUi(()->{
                    if(preview!=sunoPreviewGeneration)return;
                    pendingSunoCatalog=result;pendingSunoImportTitle=result.optString("name",pendingSunoImportTitle);
                    refreshSourceIfOpen(ListenPage.SUNO);
                });
            }catch(Exception unavailable){
                postUi(()->{
                    if(preview!=sunoPreviewGeneration)return;
                    sunoPreviewError="Impossible d’ouvrir cette sélection. Vérifie la connexion et le partage du morceau dans Suno.";
                    refreshSourceIfOpen(ListenPage.SUNO);
                });
            }
        });
    }

    private void clearSunoSelection(){
        sunoPreviewGeneration++;
        pendingSunoImportUrl=null;pendingSunoImportTitle=null;pendingSunoCatalog=null;sunoPreviewError="";
        sunoSaving=false;
    }

    private void showSunoPreview(){
        guideBody.addView(heading(pendingSunoImportTitle,22),margin(-1,-2,6,4));
        if(!sunoPreviewError.isEmpty()){
            guideBody.addView(text(sunoPreviewError,14,MUTED));
            guideBody.addView(button("Réessayer",()->confirmSunoImport(pendingSunoImportUrl,pendingSunoImportTitle)));
        }else{
            JSONObject metadata=pendingSunoCatalog;
            String detail="Chargement…";
            if(metadata!=null){
                JSONArray tracks=metadata.optJSONArray("tracks");
                JSONObject track=tracks!=null&&tracks.length()==1?tracks.optJSONObject(0):null;
                detail=track!=null?track.optString("artist",""):UiPresentation.count(tracks==null?0:tracks.length(),"morceau","morceaux");
            }
            if(!detail.isEmpty())guideBody.addView(text(detail,14,MUTED),margin(-1,-2,0,8));
            boolean playlist=metadata!=null&&metadata.optJSONArray("playlists").length()>0;
            Button listen=action(playlist?"Ajouter la playlist":"Écouter",playlist?"add":"play",true,this::listenToSunoSelection);
            enabled(listen,metadata!=null&&!sunoSaving);
            guideBody.addView(listen,margin(-1,-2,2,6));
        }
        guideBody.addView(button("Annuler",()->{clearSunoSelection();buildGuide();}));
    }

    private void listenToSunoSelection(){
        final JSONObject catalog=pendingSunoCatalog;
        if(catalog==null||sunoSaving)return;
        sunoSaving=true;
        final int request=selectionEpoch,preview=sunoPreviewGeneration;
        buildGuide();
        sunoWorker.execute(()->{
            try{
                sunoLibrary.put(catalog);
                String id=catalog.getString("id");
                JSONArray songs=sunoLibrary.queue(id);
                postUi(()->{
                    if(preview!=sunoPreviewGeneration)return;
                    clearSunoSelection();
                    if(activeTab!=1||listenPage!=ListenPage.SUNO||request!=selectionEpoch)return;
                    if(catalog.optJSONArray("playlists").length()==0){playSourceQueue(songs,0);return;}
                    collectionId=id;saveListenPage();buildGuide();
                });
            }catch(Exception failure){postUi(()->{
                if(preview!=sunoPreviewGeneration)return;
                sunoSaving=false;refreshSourceIfOpen(ListenPage.SUNO);error(failure);
            });}
        });
    }

    private void refreshSunoCatalog(String official){
        sunoWorker.execute(()->{
            try{sunoLibrary.put(SunoCatalog.resolve(official));postUi(()->refreshSourceIfOpen(ListenPage.SUNO));}
            catch(Exception failure){postUi(()->error(failure));}
        });
    }
    private void removeSunoSource(String sourceId,String name){
        if(busy)return;new AlertDialog.Builder(this).setTitle("Retirer ce catalogue ?").setMessage(name+" sera retiré de Rhythmbox sur ce téléphone. Les morceaux restent sur Suno.").setNegativeButton("Annuler",null).setPositiveButton("Retirer",(d,w)->{try{JSONArray removed=sunoLibrary.queue(sourceId);sunoLibrary.remove(sourceId);java.util.Set<String> retained=new java.util.HashSet<>();JSONArray remaining=sunoLibrary.sources();for(int i=0;i<remaining.length();i++){JSONArray tracks=remaining.getJSONObject(i).getJSONArray("tracks");for(int n=0;n<tracks.length();n++)retained.add(tracks.getJSONObject(n).getString("id"));}JSONArray unavailable=new JSONArray();for(int i=0;i<removed.length();i++)if(!retained.contains(removed.getJSONObject(i).getString("id")))unavailable.put(removed.getJSONObject(i));if(player!=null)player.excludeTracks(unavailable);refreshSourceIfOpen(ListenPage.SUNO);updatePlayback();}catch(Exception failure){error(failure);}}).show();
    }
    private final class TrackAdapter extends BaseAdapter {
        public int getCount(){return visibleRows.size();}public JSONObject getItem(int i){return visibleRows.get(i);}public long getItemId(int i){return i;}
        public View getView(int position,View reusable,android.view.ViewGroup parent){LinearLayout row;Row holder;if(reusable==null){row=new LinearLayout(MainActivity.this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(9),0,dp(9));row.setMinimumHeight(dp(76));row.setFocusable(true);ImageView art=new ImageView(MainActivity.this);art.setScaleType(ImageView.ScaleType.CENTER_CROP);art.setBackground(background(CARD,12));art.setClipToOutline(true);art.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);row.addView(art,new LinearLayout.LayoutParams(dp(46),dp(46)));LinearLayout labels=column();labels.setPadding(dp(12),0,dp(5),0);TextView title=heading("",15);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);TextView detail=text("",12,MUTED);detail.setPadding(0,dp(3),0,0);detail.setMaxLines(2);detail.setEllipsize(TextUtils.TruncateAt.END);labels.addView(title);labels.addView(detail);row.addView(labels,new LinearLayout.LayoutParams(0,-2,1));ImageButton more=iconButton("more","Options du morceau",()->{});more.setBackgroundColor(Color.TRANSPARENT);row.addView(more,new LinearLayout.LayoutParams(dp(48),dp(48)));holder=new Row(art,title,detail,more);row.setTag(holder);}else{row=(LinearLayout)reusable;holder=(Row)row.getTag();}JSONObject track=getItem(position);String title=UiPresentation.title(track);boolean current=!spotifyActive&&player!=null&&track.optString("id").equals(player.currentTrackId());holder.title.setText(title);holder.title.setTextColor(current?ACCENT:TEXT);holder.detail.setText(UiPresentation.detail(track));holder.art.setImageDrawable(UiIcons.album(track.optString("artist")+track.optString("album")));row.setBackground(background(current?0xff1d3738:BG,14));row.setContentDescription(title+", "+UiPresentation.detail(track));row.setOnClickListener(v->playAt(position));row.setOnLongClickListener(v->{trackOptions(track);return true;});holder.more.setContentDescription("Options pour "+title);holder.more.setOnClickListener(v->trackOptions(track));return row;}
    }
    private static final class Row {final ImageView art;final TextView title,detail;final ImageButton more;Row(ImageView art,TextView title,TextView detail,ImageButton more){this.art=art;this.title=title;this.detail=detail;this.more=more;}}
    private LinearLayout settingsCard(String title,String description){LinearLayout card=column();card.setPadding(dp(16),dp(14),dp(16),dp(14));card.setBackground(background(CARD,18));card.addView(heading(title,18));TextView body=text(description,13,MUTED);body.setPadding(0,dp(7),0,dp(8));if(!description.isEmpty())card.addView(body);settingsScreen.addView(card,margin(-1,-2,0,12));return card;}
    private void buildSettings(){settingsScroll.removeAllViews();settingsScreen=column();settingsScreen.setPadding(0,dp(14),0,dp(16));settingsScroll.addView(settingsScreen);settingsScreen.addView(heading("Réglages",25),margin(-1,-2,0,16));if(demoMode){LinearLayout demo=settingsCard("Mode découverte","Les extraits sont créés sur cet appareil. Ils ne font pas partie de tes listes et ne sont jamais synchronisés.");demo.addView(button("Quitter la découverte",()->{exitDemo();showTab(2);}));}
        LinearLayout identity=settingsCard("Rhythmbox LeMegaGeek",installedIdentity());
        buildVolumeSettings();buildMusicAccountSettings();buildOfflineSettings();
        LinearLayout services=settingsCard("Comptes musicaux","");
        services.addView(button("Changer de compte Suno",()->openSunoBrowser(SunoBrowserProtocol.Destination.SIGN_IN)));
        services.addView(button("Déconnecter Spotify",()->{clearSpotifySelection();spotifyLibrary.disconnect();spotify.disconnect();toast("Spotify déconnecté");}));
        services.addView(button("Options avancées Spotify",this::configureSpotify));
        LinearLayout local=settingsCard("Ta musique sur cet appareil","Aucun compte n’est nécessaire pour écouter un dossier musical. Android limite l’accès au dossier que tu choisis.");addFolderChoice(local,"Dossier musique",config.optString("media_tree",""),PICK_MEDIA);local.addView(button("Importer la musique du dossier",this::importLocalMusic));
        LinearLayout shared=settingsCard("Les listes de ton PC","Les listes chiffrées Rhythmbox et Android sont distinctes des collections du lecteur pCloud officiel.");TextView paired=text(config.optString("key","").isEmpty()?"PC non associé":"Clé d’association enregistrée",13,config.optString("key","").isEmpty()?MUTED:ACCENT);shared.addView(paired);shared.addView(button("Associer avec le PC…",this::chooseDocument));addFolderChoice(shared,"Dossier des listes chiffrées",config.optString("playlist_tree",""),PICK_PLAYLISTS);shared.addView(button("Vérifier et enregistrer les dossiers",()->{if(busy)return;try{JSONObject next=new JSONObject(config.toString()).put("sync_mode","folder");new SyncConnection(this,next).validateConfig();new SecretStore(this).save(next);config=next;PCloudSyncController.cancelJob(this);updateSyncStatus();toast("Dossiers et association vérifiés");}catch(Exception failure){error(failure);}}));TextView note=text("Sur le PC, utilise « Associer Android ». Transfère le fichier d’association par un canal privé, puis sélectionne-le ici.",12,MUTED);note.setPadding(0,dp(8),0,dp(8));shared.addView(note);shared.addView(button("Connexion par liens de partage…",this::advancedSettings));
        LinearLayout privacy=settingsCard("Confidentialité","Aucun accès global aux fichiers, contacts ou microphone. La musique pCloud choisie est copiée dans Music/Rhythmbox ; les dossiers locaux restent accessibles après ton choix. Aucune publicité ni notification promotionnelle.");privacy.addView(button("Politique de confidentialité",()->publicationLink(R.string.privacy_policy_url,true)));privacy.addView(button("Comprendre les accès aux dossiers",this::privacyInfo));privacy.addView(button("Réafficher les titres mis à l’écart",()->new AlertDialog.Builder(this).setTitle("Réafficher les titres ?").setMessage("Les titres masqués seront à nouveau visibles sur ce téléphone. Aucun fichier ne sera déplacé.").setNegativeButton("Annuler",null).setPositiveButton("Réafficher",(d,w)->{try{library.state.put("hidden",new JSONArray());library.save();render();toast("Titres réaffichés");}catch(Exception failure){error(failure);}}).show()));
        LinearLayout discovery=settingsCard("Découvrir Rhythmbox","Deux extraits musicaux originaux permettent d’essayer le lecteur sans dossier, compte ou connexion.");discovery.addView(button("Essayer la démo",()->{enterDemo();showTab(0);}));TextView legal=text("Rhythmbox pour Android · logiciel libre GPL-2.0-or-later\nComposants Spotify App Remote et Gson : notices et licences tierces.\nProjet indépendant, sans affiliation avec GNOME, pCloud ou Spotify.",11,MUTED);legal.setPadding(dp(8),dp(4),dp(8),0);settingsScreen.addView(legal);settingsScreen.addView(button("Sources de l’application",()->publicationLink(R.string.source_code_url,false)),margin(-1,-2,8,0));settingsScreen.addView(button("Licence du logiciel libre",this::showLicense),margin(-1,-2,8,0));settingsScreen.addView(button("Licences Spotify SDK et Gson",this::showSpotifyNotices),margin(-1,-2,8,0));
    }
    private String installedIdentity(){
        try{android.content.pm.PackageInfo app=getPackageManager().getPackageInfo(getPackageName(),0);long code=Build.VERSION.SDK_INT>=28?app.getLongVersionCode():app.versionCode;return "Version "+(app.versionName==null?"inconnue":app.versionName)+" · code "+code+"\n"+getPackageName();}
        catch(android.content.pm.PackageManager.NameNotFoundException unavailable){return "Version indisponible\n"+getPackageName();}
    }
    private void buildOfflineSettings(){
        if(musicAccount==null||!musicAccount.hasMusicFolder())return;
        LinearLayout card=settingsCard("Musique pCloud sur ce téléphone",PCloudOfflineAudio.folderDescription()+". Les originaux des listes choisies restent disponibles hors connexion. Les autres fichiers de ce téléphone sont conservés.");
        card.addView(text("Cache automatique : jusqu’à 512 Mio, avec préparation du morceau suivant.",12,MUTED));
        try{JSONObject settings=PCloudOfflineAudio.settings(this);JSONArray ids=settings.optJSONArray("playlist_ids");String message=offlineMessage.isEmpty()?offlineStatusLabel(settings.optJSONObject("last_status")):offlineMessage;
            offlineSummary=text(message.isEmpty()?settings.optBoolean("enabled")?(ids==null?0:ids.length())+" liste(s) conservée(s) sur le téléphone":"Choisis les listes à télécharger":message,13,ACCENT);card.addView(offlineSummary);
        }catch(Exception failure){offlineSummary=text("Les réglages hors ligne sont indisponibles ; les données existantes sont conservées.",12,MUTED);card.addView(offlineSummary);}
        offlineProgress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);offlineProgress.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));offlineProgress.setVisibility(offlineCancellation==null?View.GONE:View.VISIBLE);card.addView(offlineProgress,margin(-1,dp(4),8,8));
        card.addView(button("Choisir les listes à conserver…",this::chooseOfflinePlaylists));
        card.addView(button("Synchroniser les morceaux maintenant",()->startOfflineSync(false)));
        if(offlineCancellation!=null)card.addView(button("Annuler le téléchargement",()->{if(offlineCancellation!=null)offlineCancellation.cancel();offlineMessage="Téléchargement annulé · les copies terminées sont conservées";if(offlineSummary!=null)offlineSummary.setText(offlineMessage);}));
        card.addView(text("Les copies suivent les changements des listes en Wi-Fi. Les fichiers déjà présents ne sont pas écrasés. Le dossier est conservé si tu désactives cette synchronisation.",12,MUTED));
    }
    private String offlineStatusLabel(JSONObject saved){
        if(saved==null)return "";
        if("completed".equals(saved.optString("phase"))&&saved.has("copied")){int ready=Math.max(0,saved.optInt("copied"))+Math.max(0,saved.optInt("reused")),skipped=Math.max(0,saved.optInt("skipped"));return ready+" morceau(x) disponible(s) hors connexion"+(skipped>0?" · "+skipped+" format(s) non copié(s)":"");}
        return offlineProgressLabel(saved.optString("phase"),saved.optInt("completed"),saved.optInt("total"),saved.optLong("bytes"),saved.optLong("total_bytes"));
    }
    private String offlineProgressLabel(String phase,int done,int total,long bytes,long totalBytes){
        done=Math.max(0,done);total=Math.max(0,total);if(total>0)done=Math.min(done,total);
        String count=total>0?" · "+done+"/"+total:"";
        if("connecting".equals(phase))return "Connexion au compte musical…";
        if("planning".equals(phase))return total+" morceau(x) à conserver"+(totalBytes>0?String.format(java.util.Locale.FRANCE," · %.1f Mio",totalBytes/1048576.0):"");
        if("copying".equals(phase)||"downloading".equals(phase))return ("copying".equals(phase)?"Copie vers Music/Rhythmbox":"Téléchargement pCloud")+(total>0?" · "+Math.min(total,done+1)+"/"+total:"")+(totalBytes>0?" · "+Math.min(100,Math.max(0,Math.round(100.0*bytes/totalBytes)))+" %":"");
        if("completed".equals(phase))return "Vérification terminée"+count;
        if("interrupted".equals(phase))return "Copie interrompue · les morceaux terminés sont conservés"+count;
        return "Vérification des morceaux"+count;
    }
    private void chooseOfflinePlaylists(){
        if(busy)return;
        try{
            JSONArray choices=PCloudOfflineAudio.availablePlaylists(this);if(choices.length()==0){toast("Choisis d’abord tes listes pCloud dans le compte musical");return;}
            JSONArray saved=PCloudOfflineAudio.settings(this).optJSONArray("playlist_ids");java.util.Set<String> selectedIds=new java.util.HashSet<>();if(saved!=null)for(int i=0;i<saved.length();i++)selectedIds.add(saved.getString(i));
            String[] labels=new String[choices.length()];boolean[] checked=new boolean[choices.length()];
            for(int i=0;i<labels.length;i++){JSONObject item=choices.getJSONObject(i);labels[i]=item.getString("name")+" · "+item.optInt("count")+" titres";checked[i]=selectedIds.contains(item.getString("id"));}
            new AlertDialog.Builder(this).setTitle("À conserver dans Music/Rhythmbox").setMultiChoiceItems(labels,checked,(dialog,index,on)->checked[index]=on).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer et télécharger",(dialog,which)->{
                try{java.util.Set<String> wanted=new java.util.HashSet<>();for(int i=0;i<checked.length;i++)if(checked[i])wanted.add(choices.getJSONObject(i).getString("id"));
                    if(wanted.isEmpty()){PCloudOfflineAudio.disable(this);offlineMessage="Synchronisation des morceaux désactivée · copies conservées";buildSettings();return;}
                    PCloudOfflineAudio.configure(this,wanted);offlineFingerprint="";startOfflineSync(false);
                }catch(Exception failure){error(failure);}
            }).show();
        }catch(Exception failure){error(failure);}
    }
    private void maybeOfflineSync(){
        if(busy||!uiVisible||SystemClock.elapsedRealtime()<nextOfflineCheck)return;
        nextOfflineCheck=SystemClock.elapsedRealtime()+60000;
        try{
            if(!PCloudOfflineAudio.settings(this).optBoolean("enabled"))return;
            android.net.ConnectivityManager network=(android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            if(network==null||network.getActiveNetwork()==null||network.isActiveNetworkMetered())return;
            if(!library.fingerprint().equals(offlineFingerprint))startOfflineSync(true);
        }catch(Exception ignored){/* Existing copies and playback remain usable. */}
    }
    private void startOfflineSync(boolean automatic){
        if(busy)return;
        final PCloudOfflineAudio.Cancellation cancel=new PCloudOfflineAudio.Cancellation(()->!isDestroyed());offlineCancellation=cancel;nextOfflineCheck=SystemClock.elapsedRealtime()+60000;
        if(activeTab==2)buildSettings();
        task("Synchronisation des morceaux vers Music/Rhythmbox…",()->{
            try{
                PCloudOfflineAudio.Report result=new PCloudOfflineAudio(this).sync(cancel,(phase,done,total,bytes,totalBytes)->postUi(()->{
                    String label=offlineProgressLabel(phase,done,total,bytes,totalBytes);
                    offlineMessage=label;if(offlineSummary!=null)offlineSummary.setText(label);if(offlineProgress!=null){offlineProgress.setVisibility(View.VISIBLE);offlineProgress.setIndeterminate(total<=0);if(total>0){offlineProgress.setMax(total);offlineProgress.setProgress(done);}}
                }));
                final String finished=result.copied+" morceau(x) copié(s), "+result.reused+" déjà présent(s)"+(result.skipped>0?" · "+result.skipped+" format(s) non copié(s)":"")+" · Music/Rhythmbox";
                postUi(()->{offlineMessage=finished;offlineFingerprint=library.fingerprint();if(!automatic)toast(finished);});
            }catch(Exception failure){
                if(cancel.isCancelled())postUi(()->offlineMessage="Téléchargement annulé · copies terminées conservées");
                else if(automatic)postUi(()->offlineMessage="Synchronisation des morceaux en attente · vérifie la connexion et l’espace disponible");
                else throw failure;
            }finally{postUi(()->{if(offlineCancellation==cancel)offlineCancellation=null;});}
        });
    }
    private void buildVolumeSettings(){
        LinearLayout card=settingsCard("Lecture","Un niveau plus régulier entre les morceaux, sans modifier leurs fichiers. Une première analyse peut précéder la lecture. Bibliothèque, pCloud et Suno sont pris en charge ; Spotify conserve son propre réglage de volume.");
        Switch uniform=new Switch(this);uniform.setText("Uniformiser le volume");uniform.setTextColor(TEXT);
        uniform.setChecked(VolumePreferences.enabled(this));uniform.setPadding(0,dp(10),0,dp(10));
        uniform.setOnCheckedChangeListener((button,on)->{VolumePreferences.setEnabled(this,on);if(player!=null)player.setUniformVolumeEnabled(on);updatePlayback();});
        card.addView(uniform);volumeSummary=text(player!=null?player.volumeStatus:VolumePreferences.enabled(this)?"Activée pour les prochaines écoutes":"Désactivée",12,MUTED);card.addView(volumeSummary);
    }
    private void refreshMusicAccount(){
        try{musicAccount=new PCloudAccountStore(this).load();}
        catch(Exception failure){musicAccount=null;cloudStatus="L’autorisation du compte musical est illisible. Reconnecte ce compte.";}
    }
    private boolean accountMode(){return "account".equals(config.optString("sync_mode"));}
    private void buildMusicAccountSettings(){
        LinearLayout card=settingsCard("Compte musical pCloud","Connecte un compte réservé à la musique, indépendamment du compte de l’application pCloud du téléphone. Choisis ensuite son dossier musical et les listes à synchroniser.");
        if(musicAccount==null){
            String clientId=PCloudOAuth.configuredClientId(this);
            card.addView(text("Aucun compte musical connecté",13,MUTED));
            Button connect=button("Connecter mon compte musical…",this::connectMusicAccount);enabled(connect,!busy);card.addView(connect);
            if(!clientId.isEmpty()){Button oauth=button("Autre autorisation pCloud…",this::connectOAuthAccount);enabled(oauth,!busy);card.addView(oauth);}
        }else{
            card.addView(text(musicAccount.email,14,ACCENT));
            try{if(!new PCloudAccountStore(this).isPersistent(musicAccount))card.addView(text("Connexion temporaire : elle prendra fin si Android arrête Rhythmbox. Pour la conserver, reconnecte-toi et choisis cette option sur la page pCloud.",12,MUTED));}catch(Exception ignored){}
            card.addView(button("Reconnecter ce compte…",this::connectMusicAccount));
            card.addView(text(musicAccount.hasMusicFolder()?"Dossier : "+config.optString("pcloud_music_folder_name","dossier musical choisi"):"Choisis le dossier qui contient ta musique",13,MUTED));
            card.addView(button(musicAccount.hasMusicFolder()?"Changer le dossier musical…":"Choisir le dossier musical…",()->chooseCloudFolder(0,"Mon espace pCloud")));
            if(musicAccount.hasMusicFolder()){
                card.addView(button("Voir mes listes pCloud…",()->chooseCloudCollection(null)));
                card.addView(button("Partager une liste de ce téléphone…",this::chooseLocalCloudPlaylist));
                card.addView(button("Importer les morceaux du dossier",this::importCloudMusic));
                card.addView(button("Synchroniser maintenant",()->syncCloud(false)));
                try{JSONObject state=new PCloudSyncController(this).state(library);if(state.has("pending"))card.addView(button("Vérifier la synchronisation interrompue…",this::recoverCloudPending));Switch automatic=new Switch(this);automatic.setText("Synchronisation automatique en Wi-Fi");automatic.setTextColor(TEXT);automatic.setChecked(state.optBoolean("auto_sync"));automatic.setPadding(0,dp(12),0,dp(12));automatic.setEnabled(!busy);automatic.setOnCheckedChangeListener((v,on)->{if(busy)return;acknowledgeCloud(()->{try{new PCloudSyncController(this).configure(library,true,on);config.put("pcloud_auto_sync_chosen",true);new SecretStore(this).save(config);nextCloudSync=0;toast(on?"Synchronisation automatique activée":"Synchronisation automatique désactivée");}catch(Exception failure){error(failure);}});});card.addView(automatic);}catch(Exception failure){card.addView(text("Réglages de synchronisation indisponibles",12,MUTED));}
            }
            card.addView(button("Déconnecter ce compte de Rhythmbox",()->{if(busy)return;new AlertDialog.Builder(this).setTitle("Déconnecter le compte musical ?").setMessage("L’autorisation enregistrée par Rhythmbox sera effacée sur ce téléphone. Les morceaux et listes pCloud seront conservés.").setNegativeButton("Annuler",null).setPositiveButton("Déconnecter",(d,w)->{PCloudOAuth.disconnect(this);PCloudSyncController.cancelJob(this);musicAccount=null;try{config.put("sync_mode","folder");new SecretStore(this).save(config);}catch(Exception failure){error(failure);}render();}).show();}));
        }
        if(browserSession!=null){
            card.addView(text("Termine la connexion sur la page officielle pCloud, puis reviens dans Rhythmbox.",13,ACCENT));
            card.addView(button("Rouvrir la page pCloud",()->openBrowserLogin(browserSession)));
            card.addView(button("Vérifier la connexion",()->{nextBrowserPoll=0;maybeBrowserLogin();}));
            card.addView(button("Annuler la connexion",()->{PCloudDeviceLogin.cancel(this,browserSession);browserSession=null;refreshMusicAccount();cloudStatus="La tentative de connexion a été fermée.";buildSettings();}));
        }
        if(!cloudStatus.isEmpty())card.addView(text(cloudStatus,12,MUTED));
    }
    private void connectMusicAccount(){
        if(busy||browserPolling)return;
        LinearLayout form=column();form.setPadding(dp(16),0,dp(16),0);
        EditText email=field(form,"Adresse du compte réservé à la musique",musicAccount!=null?musicAccount.email:config.optString("pcloud_expected_email",""),false);
        email.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);email.setSaveEnabled(false);
        new AlertDialog.Builder(this).setTitle("Connecter le compte musical")
            .setMessage("La connexion et les éventuels contrôles de sécurité se font sur la page officielle pCloud. Choisis ton compte réservé à la musique, puis reviens dans Rhythmbox après confirmation. Rhythmbox vérifiera son adresse avant tout accès. Cette autorisation donne techniquement accès au compte ; seuls le dossier musical et les listes que tu choisiras seront utilisés.")
            .setView(form).setNegativeButton("Annuler",null).setPositiveButton("Ouvrir pCloud",(d,w)->{
                final String entered=email.getText().toString().trim();try{PCloudAccount.normalizedEmail(entered);}catch(Exception failure){error(failure);return;}
                PCloudDeviceLogin.cancel(this,browserSession);browserSession=null;browserNetworkRetries=0;browserFailure=null;
                task("Préparation de la connexion pCloud…",()->{
                    PCloudDeviceLogin.Session session=PCloudDeviceLogin.begin(this,entered);
                    if(isFinishing()||isDestroyed()){PCloudDeviceLogin.cancel(this,session);return;}
                    postUi(()->{browserSession=session;nextBrowserPoll=0;cloudStatus="Connecte-toi sur la page pCloud, puis reviens ici.";openBrowserLogin(session);buildSettings();});
                });
            }).show();
    }
    private void openBrowserLogin(PCloudDeviceLogin.Session session){
        if(session==null)return;
        try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(session.browserUrl())));}
        catch(ActivityNotFoundException unavailable){PCloudDeviceLogin.cancel(this,session);if(browserSession==session)browserSession=null;toast("Active un navigateur pour ouvrir la page officielle pCloud.");}
    }
    private void maybeBrowserLogin(){
        if(browserSession==null||browserPolling||busy||!uiVisible||!browserResumed||SystemClock.elapsedRealtime()<nextBrowserPoll)return;
        final PCloudDeviceLogin.Session session=browserSession;browserPolling=true;
        worker.execute(()->{
            try{PCloudDeviceLoginProtocol.Poll result=PCloudDeviceLogin.poll(this,session);
                postUi(()->{if(browserSession!=session)return;browserNetworkRetries=0;if(!result.pending){browserSession=null;directConnected(result.account);if(activeTab==2)buildSettings();}else if(cloudStatus.contains("réseau")){cloudStatus="Connexion en attente de confirmation sur la page pCloud.";if(activeTab==2)buildSettings();}});
            }catch(PCloudDeviceLoginProtocol.NetworkFailure retry){postUi(()->{if(browserSession==session){browserNetworkRetries++;cloudStatus=retry.getMessage();if(activeTab==2)buildSettings();}});}
            catch(Exception failure){PCloudDeviceLogin.cancel(this,session);postUi(()->{if(browserSession==session){browserSession=null;cloudStatus=failure.getMessage()==null?"Connexion pCloud interrompue. Recommence dans Rhythmbox.":failure.getMessage();buildSettings();if(browserResumed)error(failure);else browserFailure=failure;}});}
            finally{postUi(()->{browserPolling=false;nextBrowserPoll=SystemClock.elapsedRealtime()+Math.min(30000L,2500L<<Math.min(browserNetworkRetries,4));});}
        });
    }
    /** Kept for compatibility/testing; normal account connection uses the official browser page. */
    private void connectPasswordAccount(){
        if(busy)return;
        LinearLayout form=column();form.setPadding(dp(16),0,dp(16),0);
        EditText email=field(form,"Adresse du compte réservé à la musique",musicAccount!=null?musicAccount.email:config.optString("pcloud_expected_email",""),false);
        email.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        EditText password=field(form,"Mot de passe pCloud","",true);password.setSaveEnabled(false);email.setSaveEnabled(false);
        form.addView(text("Région du compte pCloud",12,MUTED));Spinner region=new Spinner(this);
        region.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Europe","États-Unis"}));
        region.setSelection("us".equals(musicAccount!=null?musicAccount.region:config.optString("pcloud_region"))?1:0);form.addView(region);
        ScrollView scroll=new ScrollView(this);scroll.addView(form);
        directDialog=new AlertDialog.Builder(this).setTitle("Connecter le compte musical")
            .setMessage("Utilise exclusivement ton compte réservé à la musique. Cette connexion donne accès à ce compte pCloud ; Rhythmbox utilisera le dossier musical et les listes choisis. Le mot de passe est envoyé à pCloud par HTTPS puis oublié. Seul un jeton de connexion, valable au plus 30 jours, sera conservé chiffré sur ce téléphone.")
            .setView(scroll).setNegativeButton("Annuler",(d,w)->password.setText(""))
            .setPositiveButton("Se connecter",(d,w)->{
                final String entered=email.getText().toString().trim(),selectedRegion=region.getSelectedItemPosition()==1?"us":"eu";
                final char[] secret=new char[password.length()];password.getText().getChars(0,password.length(),secret,0);password.setText("");
                try{PCloudAccount.normalizedEmail(entered);if(secret.length==0)throw new IllegalArgumentException("Saisis le mot de passe du compte musical pCloud.");
                    directSession=PCloudDirectLogin.begin(this);final PCloudDirectLogin.Session session=directSession;
                    task("Connexion au compte musical pCloud…",()->{
                        try{PCloudAccount verified=PCloudDirectLogin.login(this,session,entered,secret,selectedRegion);postUi(()->directConnected(verified));}
                        catch(PCloudDirectLoginProtocol.TwoFactorRequired required){postUi(()->directTwoFactor(session,required.challenge));}
                        catch(Exception failure){PCloudDirectLogin.cancel(this,session);throw failure;}
                        finally{java.util.Arrays.fill(secret,'\0');}
                    });
                }catch(Exception failure){java.util.Arrays.fill(secret,'\0');error(failure);}
            }).create();
        directDialog.setOnCancelListener(d->password.setText(""));directDialog.show();
        directDialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
    }
    private void directTwoFactor(PCloudDirectLogin.Session session,PCloudDirectLoginProtocol.Challenge challenge){
        LinearLayout form=column();form.setPadding(dp(16),0,dp(16),0);EditText code=field(form,"Code de sécurité pCloud","",true);code.setSaveEnabled(false);
        if(challenge.type==1)form.addView(button("Envoyer un code par SMS",()->task("Demande du code à pCloud…",()->{PCloudDirectLogin.sendCode(this,session,challenge,true);postUi(()->toast("Code demandé à pCloud"));})));
        if(challenge.hasDevices)form.addView(button("Envoyer un code à mes appareils pCloud",()->task("Demande du code à pCloud…",()->{PCloudDirectLogin.sendCode(this,session,challenge,false);postUi(()->toast("Code demandé à pCloud"));})));
        directDialog=new AlertDialog.Builder(this).setTitle("Vérification pCloud")
            .setMessage("Saisis le code de ton application d’authentification ou reçu sur tes appareils pCloud. Aucun appareil ne sera déclaré de confiance. Le code ne sera pas conservé.")
            .setView(form).setNegativeButton("Annuler",(d,w)->{code.setText("");PCloudDirectLogin.cancel(this,session);directSession=null;})
            .setPositiveButton("Vérifier",(d,w)->{
                final char[] entered=new char[code.length()];code.getText().getChars(0,code.length(),entered,0);code.setText("");
                task("Vérification du code de sécurité…",()->{
                    try{PCloudAccount verified=PCloudDirectLogin.twoFactor(this,session,challenge,entered);postUi(()->directConnected(verified));}
                    catch(PCloudDirectLoginProtocol.TwoFactorRequired required){postUi(()->{if(required.retry)toast(required.getMessage());directTwoFactor(session,required.challenge);});}
                    catch(Exception failure){PCloudDirectLogin.cancel(this,session);throw failure;}
                    finally{java.util.Arrays.fill(entered,'\0');}
                });
            }).create();
        directDialog.setOnCancelListener(d->{code.setText("");PCloudDirectLogin.cancel(this,session);directSession=null;});directDialog.show();
        directDialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
    }
    private void directConnected(PCloudAccount verified){
        try{directSession=null;musicAccount=verified;config.put("sync_mode","account").put("pcloud_expected_email",verified.email).put("pcloud_region",verified.region);new SecretStore(this).save(config);
            cloudStatus=verified.hasMusicFolder()?"Compte musical reconnecté. Tes listes et le dossier choisi sont conservés.":"Compte musical connecté. Choisis son dossier musique, puis les listes à synchroniser.";nextCloudSync=0;render();
        }catch(Exception failure){error(failure);}
    }
    private void connectOAuthAccount(){
        if(busy)return;
        if(!PCloudOAuth.canStart(this)){new AlertDialog.Builder(this).setTitle("Liens sécurisés de Rhythmbox").setMessage("Android doit vérifier que le retour de connexion appartient à cette application. Active l’ouverture des liens compatibles de Rhythmbox, puis réessaie. La connexion reste indisponible si le domaine n’est pas vérifié.").setNegativeButton("Fermer",null).setPositiveButton("Réglages Android",(d,w)->{Intent settings=new Intent(android.provider.Settings.ACTION_APP_OPEN_BY_DEFAULT_SETTINGS,android.net.Uri.parse("package:"+getPackageName()));try{startActivity(settings);}catch(ActivityNotFoundException unavailable){startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:"+getPackageName())));}}).show();return;}
        LinearLayout form=column();EditText email=field(form,"Adresse du compte réservé à la musique",config.optString("pcloud_expected_email",""),false);email.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        new AlertDialog.Builder(this).setTitle("Connecter le compte musical").setMessage("Choisis ce même compte sur la page officielle pCloud. Rhythmbox vérifiera l’adresse avant d’accéder au dossier choisi.").setView(form).setNegativeButton("Annuler",null).setPositiveButton("Continuer dans le navigateur",(d,w)->{final String enteredEmail=email.getText().toString().trim();task("Préparation de la connexion sécurisée…",()->{
            String expected=PCloudAccount.normalizedEmail(enteredEmail);
            android.net.Uri uri=PCloudOAuth.begin(this,PCloudOAuth.configuredClientId(this),expected,0);
            JSONObject next=new JSONObject(config.toString()).put("pcloud_expected_email",expected);new SecretStore(this).save(next);
            postUi(()->{config=next;try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(ActivityNotFoundException unavailable){PCloudOAuth.cancel(this);toast("Installe ou active un navigateur pour te connecter à pCloud");}});
        });}).show();
    }
    private PCloudCollections cloudClient(PCloudAccount account) throws Exception {
        PCloudCollections client=new PCloudCollections(account,java.util.Collections.emptySet(),java.util.Collections.emptySet());
        client.setRequestGuard(()->{try{PCloudAccount current=new PCloudAccountStore(this).load();return current!=null&&PCloudAccount.sameAuthorization(current,account);}catch(Exception unavailable){return false;}});
        client.setIndexObserver(index->new PCloudAudioCache(new java.io.File(getNoBackupFilesDir(),"pcloud-audio-v1")).observeIndex(account,index));client.verifyAccount();return client;
    }
    private void chooseCloudFolder(long folderId,String name){
        if(busy||musicAccount==null)return;final PCloudAccount account=musicAccount;
        task("Lecture des dossiers du compte musical…",()->{
            JSONArray folders=cloudClient(account).listMusicFolders(folderId);String[] labels=new String[folders.length()];for(int i=0;i<labels.length;i++)labels[i]=folders.getJSONObject(i).getString("name");
            postUi(()->{AlertDialog.Builder dialog=new AlertDialog.Builder(this).setTitle(name).setItems(labels,(d,index)->{JSONObject chosen=folders.optJSONObject(index);chooseCloudFolder(chosen.optLong("folderid"),chosen.optString("name"));}).setNegativeButton("Annuler",null);if(folderId>0)dialog.setPositiveButton("Choisir ce dossier",(d,w)->task("Vérification du dossier musical…",()->{
                // Verify the candidate folder with the original authorization
                // still pinned in storage. Saving the folder remains the final CAS.
                PCloudFolderSelection selection=new PCloudFolderSelection(account,folderId);
                PCloudAccount selectedAccount=selection.candidate;
                PCloudCollections selectedClient=new PCloudCollections(selectedAccount,java.util.Collections.emptySet(),java.util.Collections.emptySet());
                selectedClient.setRequestGuard(()->{try{return selection.valid(new PCloudAccountStore(this).load());}catch(Exception unavailable){return false;}});
                selectedClient.verifyAccount();selectedClient.indexMusic();
                if(!new PCloudAccountStore(this).selectMusicFolder(account,folderId))throw new IllegalStateException("L’autorisation du compte musical a changé. Recommence le choix du dossier.");
                postUi(()->{try{musicAccount=selectedAccount;config.put("sync_mode","account").put("pcloud_music_folder_name",name);new SecretStore(this).save(config);new PCloudSyncController(this).configure(library,false,false);cloudStatus="Dossier vérifié. Choisis les listes pCloud à synchroniser.";render();}catch(Exception failure){error(failure);}});
            }));dialog.show();});
        });
    }
    private void acknowledgeCloud(Runnable action){
        if(busy)return;
        try{if(new PCloudSyncController(this).state(library).optBoolean("ack_pruning")){action.run();return;}}catch(Exception failure){error(failure);return;}
        new AlertDialog.Builder(this).setTitle("Lire les listes pCloud").setMessage("Le lecteur pCloud peut retirer de ses listes les références à des fichiers devenus indisponibles, même lors d’une lecture. Rhythmbox ne supprime aucun fichier audio. Seules les listes que tu choisiras seront synchronisées ; les titres mis à l’écart restent exclus.").setNegativeButton("Annuler",(d,w)->{if(activeTab==2)buildSettings();}).setPositiveButton("J’ai compris, continuer",(d,w)->{try{new PCloudSyncController(this).configure(library,true,false);action.run();}catch(Exception failure){error(failure);}}).show();
    }
    private void recoverCloudPending(){
        acknowledgeCloud(()->{try{JSONObject pending=new PCloudSyncController(this).state(library).optJSONObject("pending");if(pending==null)return;
            if("create".equals(pending.optString("operation"))&&pending.optLong("collection_id")==0){
                new AlertDialog.Builder(this).setTitle("Retrouver la liste créée").setMessage("La réponse de pCloud a été interrompue. Choisis la liste créée lors de cet essai. Rhythmbox la relira et conservera une copie de récupération sans modifier son contenu.").setNegativeButton("Annuler",null).setPositiveButton("Choisir dans pCloud",(d,w)->task("Recherche de la liste créée…",()->{JSONArray lists=cloudClient(musicAccount).browseCollections(true);String[] names=new String[lists.length()];for(int i=0;i<names.length;i++)names[i]=lists.getJSONObject(i).optString("name");postUi(()->new AlertDialog.Builder(this).setTitle("Liste créée lors du dernier essai").setItems(names,(dialog,index)->recoverCloudPending(lists.optJSONObject(index).optLong("id"))).setNegativeButton("Annuler",null).show());})).show();
            }else recoverCloudPending(0);
        }catch(Exception failure){error(failure);}});
    }
    private void recoverCloudPending(long createdId){task("Vérification des listes interrompues…",()->{PCloudSyncController controller=new PCloudSyncController(this);PCloudSyncController.Result result=createdId>0?controller.recoverPending(library,createdId,true):controller.recoverPending(library,true);postUi(()->commitCloudResult(controller,result,false));});}
    private void chooseCloudCollection(String localId){
        acknowledgeCloud(()->{if(musicAccount==null||!musicAccount.hasMusicFolder())return;final PCloudAccount account=musicAccount;task("Lecture de tes listes pCloud…",()->{
            JSONArray lists=cloudClient(account).browseCollections(true);String[] names=new String[lists.length()];for(int i=0;i<names.length;i++)names[i]=lists.getJSONObject(i).optString("name");postUi(()->{if(names.length==0){toast("Aucune liste musicale personnelle disponible sur ce compte pCloud");return;}new AlertDialog.Builder(this).setTitle("Choisir la liste pCloud").setItems(names,(d,index)->task("Association de la liste…",()->{long cid=lists.getJSONObject(index).getLong("id");PCloudSyncController controller=new PCloudSyncController(this);PCloudSyncController.Result result=localId==null?controller.importCollection(library,cid,true):controller.bindCollection(library,localId,cid,true);postUi(()->commitCloudResult(controller,result,false));})).setNegativeButton("Annuler",null).show();});
        });});
    }
    private void chooseLocalCloudPlaylist(){
        if(busy)return;JSONArray lists=library.playlists();String[] names=new String[lists.length()];for(int i=0;i<names.length;i++)names[i]=lists.optJSONObject(i).optString("name");if(names.length==0){toast("Crée d’abord une liste sur ce téléphone");return;}
        new AlertDialog.Builder(this).setTitle("Partager une liste").setItems(names,(d,index)->{JSONObject list=lists.optJSONObject(index);String localId=list.optString("id");new AlertDialog.Builder(this).setTitle(names[index]).setItems(new String[]{"Associer à une liste pCloud existante","Créer sa liste sur pCloud"},(dialog,choice)->{if(choice==0)chooseCloudCollection(localId);else acknowledgeCloud(()->task("Création de la liste pCloud…",()->{PCloudSyncController controller=new PCloudSyncController(this);PCloudSyncController.Result result=controller.createCollection(library,localId,names[index],true);postUi(()->commitCloudResult(controller,result,false));}));}).setNegativeButton("Annuler",null).show();}).setNegativeButton("Annuler",null).show();
    }
    private void commitCloudResult(PCloudSyncController controller,PCloudSyncController.Result result,boolean automatic){
        try{if(!controller.commit(library,result)){cloudStatus="Les listes ont changé pendant la synchronisation. Elles sont conservées ; une nouvelle vérification est nécessaire.";if(!automatic)toast(cloudStatus);}else{cloudStatus=result.message;JSONObject state=controller.state(library);JSONArray bindings=state.optJSONArray("bindings");if(!config.optBoolean("pcloud_auto_sync_chosen")&&bindings!=null&&bindings.length()>0){config.put("sync_mode","account").put("pcloud_auto_sync_chosen",true);new SecretStore(this).save(config);controller.configure(library,true,true);cloudStatus+=" Synchronisation automatique activée en Wi-Fi.";}if(!automatic)toast(cloudStatus);}lastCloudFingerprint=library.fingerprint();nextCloudSync=SystemClock.elapsedRealtime()+60000;render();}catch(Exception failure){if(!automatic)error(failure);else cloudStatus="Synchronisation interrompue · "+PCloudCollections.safeDiagnostic(failure);}
    }
    private void syncCloud(boolean automatic){
        if(busy||demoMode||musicAccount==null||!musicAccount.hasMusicFolder())return;
        if(!automatic){acknowledgeCloud(()->runCloudSync(false));return;}runCloudSync(true);
    }
    private void runCloudSync(boolean automatic){
        if(busy)return;nextCloudSync=SystemClock.elapsedRealtime()+60000;
        task("Synchronisation des listes pCloud…",()->{try{PCloudSyncController controller=new PCloudSyncController(this);PCloudSyncController.Result result=controller.prepareSync(library);postUi(()->commitCloudResult(controller,result,automatic));}catch(Exception failure){if(!automatic)throw failure;final String diagnostic=PCloudCollections.safeDiagnostic(failure);postUi(()->{cloudStatus="Synchronisation en attente · "+diagnostic;if(activeTab==2)buildSettings();});}});
    }
    private void maybeCloudSync(){
        if(busy||browserSession!=null||!hasWindowFocus()||demoMode||!accountMode()||musicAccount==null||!musicAccount.hasMusicFolder()||library==null)return;
        android.net.ConnectivityManager network=getSystemService(android.net.ConnectivityManager.class);android.net.NetworkCapabilities capabilities=network==null?null:network.getNetworkCapabilities(network.getActiveNetwork());if(capabilities==null||!capabilities.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_METERED)||!capabilities.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED))return;
        try{JSONObject state=new PCloudSyncController(this).state(library);if(state.has("pending")||!state.optBoolean("auto_sync")||!state.optBoolean("ack_pruning"))return;String fingerprint=library.fingerprint();long now=SystemClock.elapsedRealtime();if(!fingerprint.equals(lastCloudFingerprint)){lastCloudFingerprint=fingerprint;nextCloudSync=Math.min(nextCloudSync,now+3000);}if(now>=nextCloudSync)syncCloud(true);}catch(Exception ignored){/* Show actionable failures through explicit sync; no repeating dialogs. */}
    }
    private void importCloudMusic(){
        if(musicAccount==null||!musicAccount.hasMusicFolder()){settings();return;}final PCloudAccount account=musicAccount;
        task("Lecture du dossier musical pCloud…",()->{JSONArray tracks=cloudClient(account).importedMusic();postUi(()->{if(tracks.length()==0){toast("Aucun morceau dans le dossier choisi");return;}askText("Importer "+tracks.length()+" titres","Nom de la liste","Ma musique pCloud",name->{try{library.playlists().put(new JSONObject().put("id",UUID.randomUUID().toString()).put("name",name).put("tracks",tracks));selected=library.playlists().length()-1;library.save();render();showTab(0);}catch(Exception failure){error(failure);}});});});
    }
    private void publicationLink(int resource,boolean privacy){
        String address=getString(resource).trim();
        if(address.isEmpty()){
            if(privacy)privacyInfo();
            else new AlertDialog.Builder(this).setTitle("Sources de cette version").setMessage("Cette application est un logiciel libre sous licence GPL-2.0-or-later. Le lien public vers les sources n’a pas encore été renseigné dans cette version de préparation.").setPositiveButton("Voir la licence",(d,w)->showLicense()).setNegativeButton("Fermer",null).show();
            return;
        }
        android.net.Uri uri=android.net.Uri.parse(address);
        if(!"https".equals(uri.getScheme()) || uri.getHost()==null || uri.getUserInfo()!=null){toast("Lien de publication indisponible");return;}
        try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(ActivityNotFoundException unavailable){toast("Aucun navigateur n’est disponible sur cet appareil");}
    }
    private void showLicense(){
        try(java.io.InputStream input=getResources().openRawResource(R.raw.gpl_2_0);java.io.ByteArrayOutputStream output=new java.io.ByteArrayOutputStream()){
            byte[] block=new byte[4096];int count;while((count=input.read(block))!=-1)output.write(block,0,count);
            ScrollView scroll=new ScrollView(this);TextView license=text("Code original du client Android Rhythmbox : GPL-2.0-or-later.\n\n"+new String(output.toByteArray(),java.nio.charset.StandardCharsets.UTF_8),13,TEXT);license.setTextIsSelectable(true);license.setPadding(dp(18),dp(14),dp(18),dp(18));scroll.addView(license);new AlertDialog.Builder(this).setTitle("Licence du logiciel libre").setView(scroll).setPositiveButton("Fermer",null).show();
        }catch(Exception failure){error(failure);}
    }
    private void updateSyncStatus(){
        if(subtitle==null||busy)return;
        String status=demoMode?"Mode démo":"";
        subtitle.setText(status);
        subtitle.setVisibility(status.isEmpty()?View.GONE:View.VISIBLE);
    }
    private void privacyInfo(){new AlertDialog.Builder(this).setTitle("Un accès limité à tes choix").setMessage("La connexion au compte musical utilise une autorisation pCloud chiffrée avec une clé Android propre à Rhythmbox. Le compte est vérifié avant tout accès. Seuls le dossier musical choisi et les listes associées sont utilisés. Le compte de l’application pCloud du téléphone reste indépendant. La portée imposée par pCloud est indiquée lors de la connexion.\n\nSans connexion de compte, le sélecteur Android donne accès aux dossiers choisis. Les listes échangées par le mode PC sont chiffrées. La mise à l’écart masque des titres sur ce téléphone ; elle ne déplace pas les fichiers distants.\n\nLa seule notification est la commande système du lecteur pendant son utilisation. Retirer l’application des tâches récentes arrête le lecteur Rhythmbox. La lecture Spotify reste gérée par son application indépendante.").setPositiveButton("Compris",null).show();}
    private void createPlaylist(){if(busy)return;if(demoMode)exitDemo();askText("Nouvelle playlist","Nom de la playlist","",name->{try{library.playlists().put(new JSONObject().put("id",UUID.randomUUID().toString()).put("name",name).put("tracks",new JSONArray()));selected=library.playlists().length()-1;library.save();render();}catch(Exception e){error(e);}});}
    private void playlistOptions(int index){if(busy)return;JSONObject list=library.playlists().optJSONObject(index);new AlertDialog.Builder(this).setTitle(list.optString("name")).setItems(new String[]{"Renommer","Supprimer cette liste du téléphone"},(d,which)->{
        if(which==0)askText("Renommer","Nom",list.optString("name"),name->{try{list.put("name",name);library.save();render();}catch(Exception e){error(e);}});
        else new AlertDialog.Builder(this).setTitle("Retirer la liste de ce téléphone ?").setMessage("Les fichiers audio restent en place. La suppression d’une liste entière reste locale à ce téléphone. Elle peut réapparaître après récupération.").setNegativeButton("Annuler",null).setPositiveButton("Retirer localement",(dialog,w)->{try{library.playlists().remove(index);library.save();render();}catch(Exception e){error(e);}}).show();
    }).show();}
    private interface TextAction{void accept(String value);}
    private void askText(String title,String hint,String initial,TextAction action){EditText value=new EditText(this);value.setText(initial);value.setHint(hint);value.setSingleLine(true);new AlertDialog.Builder(this).setTitle(title).setView(value).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",(d,w)->{if(busy){toast("Attends la fin de la synchronisation");return;}String text=value.getText().toString().trim();if(text.isEmpty()||text.length()>1000){toast("Nom vide ou trop long");return;}action.accept(text);}).show();}
    private void trackOptions(JSONObject track){if(busy)return;if(DemoAudio.isDemo(track)){new AlertDialog.Builder(this).setTitle(UiPresentation.title(track)).setMessage("Extrait original de découverte, généré sur cet appareil. Aucun fichier personnel et aucune connexion ne sont utilisés. Ces extraits ne sont pas synchronisés.").setPositiveButton("Compris",null).show();return;}new AlertDialog.Builder(this).setTitle(track.optString("title")).setItems(new String[]{"Ajouter à une playlist","Modifier les métadonnées","Retirer de cette liste","Mettre le titre à l’écart","Mettre cet album à l’écart","Mettre cet artiste à l’écart"},(d,choice)->{
        if(choice==0){List<String> names=new ArrayList<>();for(int i=0;i<library.playlists().length();i++)names.add(library.playlists().optJSONObject(i).optString("name"));new AlertDialog.Builder(this).setTitle("Ajouter à…").setItems(names.toArray(new String[0]),(dialog,index)->{try{library.playlists().getJSONObject(index).getJSONArray("tracks").put(new JSONObject(track.toString()));library.save();render();}catch(Exception e){error(e);}}).show();}
        if(choice==1){LinearLayout form=column();EditText title=field(form,"Titre",track.optString("title"),false),artist=field(form,"Artiste",track.optString("artist"),false),album=field(form,"Album",track.optString("album"),false);new AlertDialog.Builder(this).setTitle("Métadonnées de la liste").setView(form).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",(dialog,w)->{try{track.put("title",title.getText().toString()).put("artist",artist.getText().toString()).put("album",album.getText().toString());library.save();render();}catch(Exception e){error(e);}}).show();}
        if(choice==2){try{JSONArray source=current().getJSONArray("tracks");for(int i=0;i<source.length();i++)if(source.getJSONObject(i)==track){source.remove(i);break;}library.save();render();}catch(Exception e){error(e);}}
        if(choice>=3){JSONArray matching=new JSONArray();String field=choice==4?"album":choice==5?"artist":"id";String value=track.optString(field);
            if(value.isEmpty()){toast("Métadonnée manquante : sélection ambiguë");return;}
            for(int i=0;i<library.playlists().length();i++){JSONArray tracks=library.playlists().optJSONObject(i).optJSONArray("tracks");for(int j=0;j<tracks.length();j++){JSONObject item=tracks.optJSONObject(j);boolean matches=field.equals("id")?item.optString(field).equals(value):UiPresentation.normalize(item.optString(field)).equals(UiPresentation.normalize(value));if(choice==4)matches=matches && UiPresentation.normalize(item.optString("artist")).equals(UiPresentation.normalize(track.optString("artist")));if(matches)matching.put(item);}}
            new AlertDialog.Builder(this).setTitle("Mise à l’écart locale").setMessage(matching.length()+" entrées seront masquées sur ce téléphone et exclues des prochains envois. Aucun fichier pCloud n’est déplacé. Le déplacement physique en quarantaine se fait sur le PC.")
                .setNegativeButton("Annuler",null).setPositiveButton("Mettre à l’écart",(dialog,w)->{try{library.hide(matching);if(player!=null)player.excludeTracks(matching);render();}catch(Exception e){error(e);}}).show();
        }
    }).show();}
    private EditText field(LinearLayout form,String label,String initial,boolean secret){TextView caption=text(label,12,MUTED);caption.setPadding(dp(12),dp(12),dp(12),0);form.addView(caption);EditText value=new EditText(this);value.setText(initial);value.setSingleLine(true);value.setTextSize(14);if(secret){value.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);value.setTransformationMethod(PasswordTransformationMethod.getInstance());value.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);value.setImeOptions(android.view.inputmethod.EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);}form.addView(value);return value;}
    private void settings(){if(activeTab!=2)settingsReturnTab=activeTab;showTab(2);}
    private void addFolderChoice(LinearLayout form,String title,String uri,int request){
        TextView caption=text(title,14,ACCENT);caption.setPadding(0,dp(18),0,dp(4));form.addView(caption);
        TextView value=text(uri.isEmpty()?"Aucun dossier choisi":folderName(uri),13,MUTED);value.setMaxLines(2);form.addView(value);
        form.addView(button(uri.isEmpty()?"Choisir un dossier…":"Changer de dossier…",()->chooseTree(request)));
    }
    private String folderName(String raw){try{String id=android.provider.DocumentsContract.getTreeDocumentId(android.net.Uri.parse(raw));int slash=id.lastIndexOf('/');int colon=id.lastIndexOf(':');return id.substring(Math.max(slash,colon)+1);}catch(Exception failure){return "Dossier sélectionné";}}
    private void chooseTree(int request){
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        if(request==PICK_PLAYLISTS)intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        String current=config.optString(request==PICK_PLAYLISTS?"playlist_tree":"media_tree","");
        if(!current.isEmpty())intent.putExtra(android.provider.DocumentsContract.EXTRA_INITIAL_URI,android.net.Uri.parse(current));
        try{startActivityForResult(intent,request);}catch(ActivityNotFoundException unavailable){toast("Aucun sélecteur de dossiers n’est disponible sur cet appareil");}
    }
    private void chooseDocument(){Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{startActivityForResult(intent,PICK_PAIRING);}catch(ActivityNotFoundException failure){toast("Aucun sélecteur de fichiers disponible");}}
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);if(result!=RESULT_OK || data==null || data.getData()==null){importAfterChoice=false;return;}
        try{
            if(request==PICK_PLAYLISTS || request==PICK_MEDIA){
                android.net.Uri uri=data.getData();if(!"content".equals(uri.getScheme()) || !android.provider.DocumentsContract.isTreeUri(uri))throw new IllegalArgumentException("Choisis un dossier Android");
                int flags=data.getFlags()&(request==PICK_PLAYLISTS?(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION):Intent.FLAG_GRANT_READ_URI_PERMISSION);
                if((flags&Intent.FLAG_GRANT_READ_URI_PERMISSION)==0 || request==PICK_PLAYLISTS && (flags&Intent.FLAG_GRANT_WRITE_URI_PERMISSION)==0)throw new IllegalArgumentException("Le dossier des playlists doit autoriser la lecture et l’écriture");
                getContentResolver().takePersistableUriPermission(uri,flags);
                JSONObject next=new JSONObject(config.toString()).put(request==PICK_PLAYLISTS?"playlist_tree":"media_tree",uri.toString()).put("sync_mode",request==PICK_MEDIA&&accountMode()?"account":"folder");
                new SecretStore(this).save(next);config=next;releaseUnusedFolderGrants();if(settingsDialog!=null)settingsDialog.dismiss();if(activeTab==1&&listenPage==ListenPage.PHONE)buildGuide();else settings();if(request==PICK_MEDIA && importAfterChoice){importAfterChoice=false;importLocalMusic();}
            }else if(request==PICK_PAIRING){
                if(!"content".equals(data.getData().getScheme()))throw new IllegalArgumentException("Choisis un fichier avec le sélecteur Android");
                byte[] bytes;try(java.io.InputStream in=getContentResolver().openInputStream(data.getData());java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){
                    if(in==null)throw new IllegalArgumentException("Fichier d’association indisponible");byte[] buffer=new byte[1024];int count;
                    while((count=in.read(buffer))!=-1){if(out.size()+count>4096)throw new IllegalArgumentException("Fichier d’association trop volumineux");out.write(buffer,0,count);}bytes=out.toByteArray();
                }
                JSONObject pairing=FolderProtocol.pairing(new JSONObject(new String(bytes,java.nio.charset.StandardCharsets.UTF_8)));
                boolean changed=!pairing.getString("library_id").equals(config.optString("library_id",""));
                config.put("key",pairing.getString("key")).put("library_id",pairing.getString("library_id")).put("sync_mode","folder");
                new SecretStore(this).save(config);if(changed){library.state.put("parents",new JSONArray());library.save();}
                if(settingsDialog!=null)settingsDialog.dismiss();settings();toast("PC associé. Le fichier d’association doit rester privé.");
            }
        }catch(Exception failure){error(failure);}
    }
    private void releaseUnusedFolderGrants(){
        for(android.content.UriPermission permission:getContentResolver().getPersistedUriPermissions()){
            String uri=permission.getUri().toString();
            if(!uri.equals(config.optString("playlist_tree","")) && !uri.equals(config.optString("media_tree",""))){
                int flags=(permission.isReadPermission()?Intent.FLAG_GRANT_READ_URI_PERMISSION:0)|(permission.isWritePermission()?Intent.FLAG_GRANT_WRITE_URI_PERMISSION:0);
                try{getContentResolver().releasePersistableUriPermission(permission.getUri(),flags);}catch(SecurityException ignored){}
            }else if(!uri.equals(config.optString("playlist_tree","")) && permission.isWritePermission()){
                // A music folder only needs read access, even if it used to
                // serve as the writable playlist folder before a settings change.
                try{getContentResolver().releasePersistableUriPermission(permission.getUri(),Intent.FLAG_GRANT_WRITE_URI_PERMISSION);}catch(SecurityException ignored){}
            }
        }
    }
    private void advancedSettings(){
        ScrollView scroll=new ScrollView(this);LinearLayout form=column();form.setPadding(dp(12),dp(8),dp(12),dp(8));scroll.addView(form);
        TextView intro=text("Aucun accès à ton compte entier. Utilise uniquement des liens limités aux dossiers musique et listes. Les liens restent des secrets à protéger.",14,MUTED);form.addView(intro);
        Spinner region=new Spinner(this);region.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Europe","États-Unis"}));region.setSelection(config.optString("region","eu").equals("eu")?0:1);form.addView(region);
        EditText read=field(form,"Lien/code de lecture des listes",config.optString("read_code"),true),upload=field(form,"Lien/code de dépôt des listes (même dossier)",config.optString("upload_code"),true),media=field(form,"Lien/code musique ou collection pCloud (facultatif)",config.optString("media_code"),true),key=field(form,"Clé partagée Base64 (32 octets, fournie par le PC)",config.optString("key"),true);
        TextView note=text("Le dossier des listes reçoit seulement des révisions chiffrées. Les médias partagés restent lisibles par toute personne possédant leur lien. Les playlists pCloud natives s’importent par leur lien ; leurs modifications restent dans les playlists Rhythmbox.",12,MUTED);note.setPadding(0,dp(16),0,dp(12));form.addView(note);
        Button restore=button("Réafficher tous les titres mis à l’écart",()->{try{library.state.put("hidden",new JSONArray());library.save();render();toast("Titres locaux réaffichés");}catch(Exception e){error(e);}});form.addView(restore);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Connexion pCloud privée").setView(scroll).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",null).create();dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{
            String mediaInput=media.getText().toString().trim();
            JSONObject next=new JSONObject().put("sync_mode","links").put("region",region.getSelectedItemPosition()==0?"eu":"us").put("read_code",SyncEngine.code(read.getText().toString())).put("upload_code",SyncEngine.code(upload.getText().toString())).put("media_code",mediaInput.isEmpty()?"":SyncEngine.code(mediaInput)).put("key",key.getText().toString().trim());
            new SyncEngine(next).validateConfig();new SecretStore(this).save(next);config=next;releaseUnusedFolderGrants();dialog.dismiss();render();toast("Connexion enregistrée sur ce téléphone");
        }catch(Exception failure){error(failure);}}));dialog.show();
    }
    private void syncMenu(){if(busy)return;if(accountMode()){syncCloud(false);return;}if(demoMode){toast("La découverte est hors ligne. Quitte ce mode pour synchroniser tes listes.");return;}if(config.optString("key","").isEmpty()){settings();toast("Associe d’abord ton PC pour synchroniser les listes");return;}new AlertDialog.Builder(this).setTitle("Synchroniser les playlists").setItems(new String[]{"Récupérer les playlists","Envoyer mes playlists","Confidentialité"},(d,choice)->{if(choice==0)pull();if(choice==1)push();if(choice==2)new AlertDialog.Builder(this).setTitle("Accès limité aux dossiers choisis").setMessage("L’application ne possède aucun jeton de compte pCloud. En mode dossiers, Android lui donne accès uniquement aux dossiers sélectionnés et à leurs descendants. Le fournisseur de fichiers assure la synchronisation. En mode avancé, seuls les liens de partage choisis sont utilisés. Les playlists sont chiffrées ; les fichiers musicaux restent dans le dossier musique. Ne choisis jamais un dossier regroupant tes autres documents.").setPositiveButton("Compris",null).show();}).show();}
    private interface Work{void run() throws Exception;}
    private void task(String message,Work work){if(busy){toast("Une opération est déjà en cours");return;}busy=true;subtitle.setText(message);subtitle.setVisibility(View.VISIBLE);activityProgress.setVisibility(View.VISIBLE);for(View action:busyActions)enabled(action,false);worker.execute(()->{try{work.run();}catch(Exception failure){postUi(()->error(failure));}finally{postUi(()->{busy=false;activityProgress.setVisibility(View.GONE);for(View action:busyActions)enabled(action,true);updateSyncStatus();if(activeTab==2)buildSettings();});}});}
    private void pull(){task("Lecture des révisions chiffrées…",()->{
        SyncConnection engine=new SyncConnection(this,config);engine.validateConfig();List<JSONObject> heads=engine.heads();postUi(()->{
            if(heads.isEmpty()){toast("Aucune révision partagée");return;}
            String[] labels=new String[heads.size()];for(int i=0;i<heads.size();i++){JSONObject s=heads.get(i);labels[i]=s.optString("created")+" · "+s.optJSONArray("playlists").length()+" listes · "+s.optString("device").substring(0,8);}
            new AlertDialog.Builder(this).setTitle(heads.size()>1?"Conflits : choisir une variante":"Révision disponible").setItems(labels,(d,index)->new AlertDialog.Builder(this).setTitle("Charger cette révision ?").setMessage("Les listes de ce téléphone seront remplacées par cette variante. Les révisions pCloud restent conservées. Les titres mis à l’écart restent masqués localement.").setNegativeButton("Annuler",null).setPositiveButton("Charger",(dialog,w)->{try{library.importSnapshot(heads.get(index));render();toast("Révision chargée");}catch(Exception e){error(e);}}).show()).setNegativeButton("Annuler",null).show();
        });
    });}
    private void push(){
        final JSONObject snapshot;try{snapshot=library.snapshot();Library.validate(snapshot);}catch(Exception e){error(e);return;}
        task("Vérification des variantes distantes…",()->{
            SyncConnection engine=new SyncConnection(this,config);engine.validateConfig();List<JSONObject> remote=engine.heads();
            java.util.Set<String> parents=new java.util.HashSet<>();JSONArray known=snapshot.getJSONArray("parents");for(int i=0;i<known.length();i++)parents.add(known.getString(i));
            boolean concurrent=false;for(JSONObject head:remote)if(!parents.contains(head.getString("id")))concurrent=true;final boolean conflicts=concurrent;
            postUi(()->new AlertDialog.Builder(this).setTitle(conflicts?"Publier une variante ?":"Envoyer les playlists ?").setMessage(conflicts?"Des révisions distantes ne sont pas présentes sur ce téléphone. Cet envoi créera une variante conservée à côté des autres. Récupère d’abord une révision pour repartir de celle-ci.":snapshot.optJSONArray("playlists").length()+" listes seront ajoutées sous forme chiffrée. Aucun fichier audio ou fichier en quarantaine ne sera envoyé.")
                .setNegativeButton("Annuler",null).setPositiveButton(conflicts?"Publier ma variante":"Envoyer",(d,w)->task("Envoi chiffré…",()->{engine.upload(snapshot);postUi(()->{try{library.state.put("parents",new JSONArray().put(snapshot.getString("id")));library.save();toast("Révision envoyée");}catch(Exception e){error(e);}});})).show());
        });
    }
    private void importLocalMusic(){
        if(busy)return;if(demoMode)exitDemo();if(config.optString("media_tree","").isEmpty()){chooseLocalMusic();return;}
        final JSONObject localConfig;try{localConfig=new JSONObject(config.toString()).put("sync_mode","folder");}catch(Exception failure){error(failure);return;}
        task("Lecture du dossier musique de cet appareil…",()->{JSONArray tracks=new SyncConnection(this,localConfig).importMedia();postUi(()->{
            if(tracks.length()==0){toast("Aucun fichier audio dans le dossier sélectionné");return;}
            if(activeTab==1&&listenPage==ListenPage.PHONE){
                try{
                    String id=UUID.randomUUID().toString();
                    String name=folderName(localConfig.optString("media_tree",""));
                    library.playlists().put(new JSONObject().put("id",id).put("name",name.isEmpty()?"Musique du téléphone":name).put("tracks",tracks));
                    selected=library.playlists().length()-1;library.save();collectionId=id;saveListenPage();render();
                }catch(Exception failure){error(failure);}
            }else askText("Importer "+tracks.length()+" titres","Nom de la nouvelle liste","Ma musique locale",name->{try{library.playlists().put(new JSONObject().put("id",UUID.randomUUID().toString()).put("name",name).put("tracks",tracks));selected=library.playlists().length()-1;library.save();render();showTab(0);}catch(Exception failure){error(failure);}});
        });});
    }
    private void importMedia(){if(busy)return;if(accountMode()){importCloudMusic();return;}if(demoMode)exitDemo();if(!"links".equals(config.optString("sync_mode","folder")) && config.optString("media_tree","").isEmpty()){chooseLocalMusic();return;}task("Lecture du dossier musique choisi…",()->{JSONArray tracks=new SyncConnection(this,config).importMedia();postUi(()->{
        if(tracks.length()==0){toast("Aucun fichier audio dans le dossier sélectionné");return;}
        askText("Importer "+tracks.length()+" titres","Nom de la nouvelle liste","Ma musique",name->{try{library.playlists().put(new JSONObject().put("id",UUID.randomUUID().toString()).put("name",name).put("tracks",tracks));selected=library.playlists().length()-1;library.save();render();showTab(0);}catch(Exception e){error(e);}});
    });});}
    private void postUi(Runnable action){handler.post(()->{if(!isFinishing()&&!isDestroyed())action.run();});}
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
    private void error(Exception failure){if(isFinishing()||isDestroyed())return;String message=failure instanceof IllegalArgumentException||failure instanceof IllegalStateException||failure instanceof PCloudCollections.CloudException||failure instanceof SunoCatalog.CatalogException||failure instanceof SunoAudio.Failure||failure instanceof java.util.ConcurrentModificationException?failure.getMessage():accountMode()?"Opération impossible. Vérifie le compte musical pCloud, le dossier choisi et la connexion réseau.":"Opération impossible. Vérifie les dossiers choisis, l’association avec le PC et la connexion du fournisseur.";new AlertDialog.Builder(this).setTitle("Opération interrompue").setMessage(message).setPositiveButton("Fermer",null).show();}
    @Override protected void onDestroy(){cancelCapabilityTimeout();if(spotifyLibrary!=null)spotifyLibrary.close();sunoWorker.shutdownNow();if(offlineCancellation!=null)offlineCancellation.cancel();deactivateSpectra();playbackOwnership.clear();pauseWaitArmed=false;pauseWaitSerial++;pendingNativePlayback=null;nativeResumePlayback=null;if(spotify!=null)spotify.stop();PCloudDeviceLogin.cancel(this,browserSession);browserSession=null;if(directDialog!=null){directDialog.dismiss();directDialog=null;}PCloudDirectLogin.cancel(this,directSession);directSession=null;handler.removeCallbacks(ticker);worker.shutdownNow();if(bound){unbindService(connection);bound=false;}super.onDestroy();}
}
