package fr.lemegageek.rhythmbox;

import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Wire format used only for reading the user's Spotify library. */
final class SpotifyLibraryProtocol {
    static final String REDIRECT = "https://lemegageek.github.io/rhythmbox/spotify/oauth/android-callback.html";
    static final String SCOPES = "playlist-read-private playlist-read-collaborative user-library-read";
    static final String AUTHORIZE = "https://accounts.spotify.com/authorize";
    static final String TOKEN = "https://accounts.spotify.com/api/token";
    static final String API = "https://api.spotify.com/v1";
    private static final long PENDING_TTL = 10 * 60_000L;
    private static final SecureRandom RANDOM = new SecureRandom();

    static final class Problem extends Exception {
        Problem(String text) { super(text); }
    }
    static Problem invalid() { return new Problem("Réponse Spotify invalide. Réessayez."); }
    static String nonce() {
        byte[] bytes = new byte[32];
        RANDOM.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }
    static String challenge(String verifier) throws Exception {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(
            MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)));
    }
    static String form(String... fields) throws Exception {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < fields.length; i += 2) {
            if (result.length() > 0) result.append('&');
            result.append(URLEncoder.encode(fields[i], "UTF-8")).append('=')
                .append(URLEncoder.encode(fields[i+1], "UTF-8"));
        }
        return result.toString();
    }
    static JSONObject pending(long now) throws Exception {
        return new JSONObject().put("verifier", nonce()).put("state", nonce()).put("created", now);
    }
    static String authUrl(String client, JSONObject pending) throws Exception {
        if (!client.matches("[A-Fa-f0-9]{32}")) throw new Problem("La connexion Spotify est indisponible dans cette version.");
        return AUTHORIZE + "?" + form("client_id", client, "response_type","code",
            "redirect_uri",REDIRECT, "scope",SCOPES, "state",pending.getString("state"),
            "code_challenge_method","S256", "code_challenge",challenge(pending.getString("verifier")));
    }
    static Map<String,String> parameters(String raw) throws Exception {
        Map<String,String> out = new HashMap<>();
        if (raw == null || raw.length() > 16_384) throw invalid();
        for (String pair : raw.split("&", -1)) {
            int split = pair.indexOf('=');
            if (split < 1 || out.size() >= 12) throw invalid();
            String name = URLDecoder.decode(pair.substring(0,split), "UTF-8");
            String value = URLDecoder.decode(pair.substring(split+1), "UTF-8");
            if (out.put(name,value) != null) throw invalid();
        }
        return out;
    }
    /** Returns an empty code for a verified refusal. Unmatched callbacks never consume a legitimate attempt. */
    static String code(String value, JSONObject pending, long now) throws Exception {
        if (value == null || value.length() > 20_000 || pending == null) throw invalid();
        URI uri = new URI(value);
        if (!"https".equals(uri.getScheme()) || !"lemegageek.github.io".equals(uri.getRawAuthority()) ||
            !"/rhythmbox/spotify/oauth/android-callback.html".equals(uri.getRawPath()) || uri.getRawFragment() != null) throw invalid();
        long created = pending.getLong("created");
        if (now < created || now - created > PENDING_TTL) throw new Problem("Connexion expirée. Réessayez.");
        Map<String,String> params = parameters(uri.getRawQuery());
        String state = params.get("state");
        if (state == null || !state.matches("[a-zA-Z0-9_-]{43}") || !MessageDigest.isEqual(
            state.getBytes(StandardCharsets.US_ASCII), pending.getString("state").getBytes(StandardCharsets.US_ASCII))) throw invalid();
        if (params.containsKey("error") == params.containsKey("code")) throw invalid();
        return params.containsKey("error") ? "" : token(params.get("code"));
    }
    static String token(String value) throws Problem {
        if (value == null || !value.matches("[!-~]{1,8192}")) throw invalid();
        return value;
    }
    static JSONObject session(JSONObject result, JSONObject previous, long now) throws Exception {
        String scopes = result.has("scope") ? result.getString("scope") : previous == null ? SCOPES : previous.getString("scope");
        Set<String> actual = new HashSet<>(Arrays.asList(scopes.split(" +")));
        if (!actual.containsAll(Arrays.asList(SCOPES.split(" ")))) throw new Problem("Autorisez la lecture de la bibliothèque Spotify pour afficher vos listes.");
        long lifetime = result.getLong("expires_in");
        if (lifetime < 1 || lifetime > 86_400 || !"Bearer".equalsIgnoreCase(result.getString("token_type"))) throw invalid();
        String refresh = result.has("refresh_token") ? result.getString("refresh_token") :
            previous == null ? null : previous.getString("refresh");
        return new JSONObject().put("access",token(result.getString("access_token"))).put("refresh",token(refresh))
            .put("scope",scopes).put("expires",now + lifetime*1000);
    }

    enum Section { LIKED, PLAYLISTS, ALBUMS, SEARCH, PLAYLIST, ALBUM }
    static final class Query {
        final Section section;
        final String key;
        final String title;
        Query(Section section, String key, String title) {
            this.section=section; this.key=key; this.title=title;
        }
        String path() throws Problem {
            switch(section) {
                case LIKED: return "/me/tracks";
                case PLAYLISTS: return "/me/playlists";
                case ALBUMS: return "/me/albums";
                case SEARCH: return "/search";
                case PLAYLIST: return "/playlists/" + id(key) + "/items";
                case ALBUM: return "/albums/" + id(key) + "/tracks";
                default: throw invalid();
            }
        }
        String context() {
            if(section==Section.PLAYLIST) return "spotify:playlist:" + key;
            if(section==Section.ALBUM) return "spotify:album:" + key;
            return "";
        }
        int limit() { return section==Section.SEARCH ? 10 : 30; }
        String url(int offset) throws Exception {
            if(offset < 0 || offset > (section == Section.SEARCH ? 1000 : 10_000_000)) throw invalid();
            String query = form("limit",Integer.toString(limit()),"offset",Integer.toString(offset));
            if(section == Section.SEARCH) {
                if(key.trim().isEmpty() || key.length()>256 || key.matches("(?s).*[\\p{Cntrl}].*")) throw invalid();
                query += "&" + form("type","track","q",key);
            }
            return API + path() + "?" + query;
        }
    }
    static String id(String id) throws Problem {
        if(id==null || !id.matches("[A-Za-z0-9]{22}")) throw invalid();
        return id;
    }
    static final class Item {
        final String type, id, name, detail;
        final boolean playable;
        final int sourceIndex;
        Item(String type, String id, String name, String detail, boolean playable, int sourceIndex) {
            this.type=type; this.id=id; this.name=name; this.detail=detail; this.playable=playable; this.sourceIndex=sourceIndex;
        }
        String uri() { return "spotify:" + type + ":" + id; }
    }
    static final class Page {
        final List<Item> items = new ArrayList<>();
        int next = -1;
    }
    static String label(JSONObject object, String field) {
        if(object==null || !(object.opt(field) instanceof String)) return "";
        String text=object.optString(field);
        return text.substring(0,Math.min(text.length(),512)).replaceAll("[\\p{Cntrl}]"," ").trim();
    }
    static Page page(Query query, int offset, JSONObject data) throws Exception {
        if(query.section==Section.SEARCH) data=data.getJSONObject("tracks");
        JSONArray rows=data.getJSONArray("items");
        if(rows.length()>query.limit() || data.optInt("offset",offset)!=offset) throw invalid();
        Page page=new Page();
        for(int i=0;i<rows.length();i++){
            JSONObject row=rows.optJSONObject(i);
            if(row==null) continue;
            String type="track";
            switch(query.section) {
                case LIKED: row=row.optJSONObject("track"); break;
                case PLAYLIST: row=row.has("item")?row.optJSONObject("item"):row.optJSONObject("track"); break;
                case ALBUMS: type="album"; row=row.optJSONObject("album"); break;
                case PLAYLISTS: type="playlist"; break;
                default: break;
            }
            if(row==null || !type.equals(row.optString("type",type))) continue;
            String id=row.optString("id","");
            String title=label(row,"name");
            if(!id.matches("[a-zA-Z0-9]{22}") || title.isEmpty() || row.optBoolean("is_local")) continue;
            JSONArray artists=row.optJSONArray("artists");
            List<String> names=new ArrayList<>();
            if(artists!=null) for(int j=0;j<Math.min(8,artists.length());j++){
                String name=label(artists.optJSONObject(j),"name");
                if(!name.isEmpty()) names.add(name);
            }
            String detail=type.equals("playlist") ? label(row.optJSONObject("owner"),"display_name") : String.join(", ",names);
            boolean playable=row.optBoolean("is_playable",true) && label(row.optJSONObject("restrictions"),"reason").isEmpty();
            page.items.add(new Item(type,id,title,detail,playable,offset+i));
        }
        if(!data.isNull("next")) {
            URI next=new URI(data.getString("next"));
            if(!"https".equals(next.getScheme()) || !"api.spotify.com".equals(next.getRawAuthority()) ||
                    !("/v1"+query.path()).equals(next.getRawPath()) || next.getRawFragment()!=null) throw invalid();
            int n=Integer.parseInt(parameters(next.getRawQuery()).get("offset"));
            if(n<=offset) throw invalid();
            query.url(n); // Never forward the server's URL or bearer token to another endpoint.
            page.next=n;
        }
        return page;
    }
    private SpotifyLibraryProtocol() {}
}
