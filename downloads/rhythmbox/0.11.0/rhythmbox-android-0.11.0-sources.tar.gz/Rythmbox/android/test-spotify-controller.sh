#!/usr/bin/env bash
set -euo pipefail
rbx_android_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$rbx_android_dir"
rbx_platform="${RBX_ANDROID_PLATFORM:-$rbx_android_dir/.toolchain/android-36/android.jar}"
rbx_sdk_classpath="$(python3 ../scripts/android_spotify_dependencies.py --classpath)"
rbx_output="build/spotify-controller-host-tests"
mkdir -p "$rbx_output"
javac --release 8 -Xlint:-options -encoding UTF-8 -classpath "$rbx_platform:$rbx_sdk_classpath" -d "$rbx_output" \
  app/src/main/java/fr/lemegageek/rhythmbox/SpotifyUri.java \
  app/src/main/java/fr/lemegageek/rhythmbox/SpotifyLoginReturn.java \
  app/src/main/java/fr/lemegageek/rhythmbox/SpotifyController.java \
  app/src/main/java/fr/lemegageek/rhythmbox/PlaybackOwnership.java \
  app/src/test/java/fr/lemegageek/rhythmbox/SpotifyControllerTest.java \
  app/src/test/java/fr/lemegageek/rhythmbox/SpotifyOwnershipTest.java
java -cp "$rbx_output:$rbx_platform:$rbx_sdk_classpath" fr.lemegageek.rhythmbox.SpotifyControllerTest

java -cp "$rbx_output:$rbx_platform:$rbx_sdk_classpath" fr.lemegageek.rhythmbox.SpotifyOwnershipTest
