package fr.lemegageek.rhythmbox;

import android.app.*;
import android.content.*;
import android.media.*;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Background playback with audio focus, headset handling and a media notification. */
public final class PlaybackService extends Service {
    public final class LocalBinder extends Binder { public PlaybackService service() { return PlaybackService.this; } }
    private final LocalBinder binder=new LocalBinder();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ExecutorService volumeWorker=Executors.newSingleThreadExecutor();
    private final ExecutorService prefetchWorker=Executors.newSingleThreadExecutor();
    private volatile PCloudAudioCache.Cancellation mediaCancellation,prefetchCancellation;
    private volatile TrackLoudnessAnalyzer.Cancellation prefetchAnalysis;
    private volatile long prefetchEpoch;
    private String prefetchedId="";private int prefetchedNext=-1;
    private String mediaOrigin="";
    private final Object volumeLock=new Object();
    private final TrackVolumeEffect volumeEffect=new TrackVolumeEffect();
    private volatile TrackLoudnessAnalyzer.Cancellation volumeAnalysis;
    private volatile boolean uniformVolume;
    private volatile long volumeEpoch;
    private TrackLoudness.Result trackLoudness;
    private File volumeFile;
    private JSONObject volumeSuno;
    private boolean volumeAttempted;
    public String volumeStatus="Uniformisation désactivée";
    private NativeAudioPlayer player; private MediaSession session; private AudioManager audio; private AudioFocusRequest focus;
    private SunoMediaDataSource sunoSource;
    private volatile SunoAudio.Cancellation sunoCancellation;
    private JSONArray queue=new JSONArray(); private int index=-1;private volatile int generation=0; private boolean shuffle=false,autoplay=true;
    public String title="À vous de choisir", artist="", status="Prêt"; public boolean loading=false;
    public Bitmap artwork; private String currentTrackId="";
    public String currentTrackId(){return currentTrackId;}
    public boolean hasCurrentTrack(){return index>=0 && index<queue.length();}
    public boolean canPrevious(){return hasCurrentTrack() && (index>0 || shuffle && queue.length()>1);}
    public boolean canNext(){return hasCurrentTrack() && (index<queue.length()-1 || shuffle && queue.length()>1);}
    public boolean isShuffle(){return shuffle;}
    private final BroadcastReceiver noisy=new BroadcastReceiver(){public void onReceive(Context c,Intent i){ pause(); }};
    @Override public void onCreate() {
        super.onCreate(); audio=(AudioManager)getSystemService(AUDIO_SERVICE);uniformVolume=VolumePreferences.enabled(this);
        volumeStatus=uniformVolume?"Uniformisation activée · choisis un morceau":"Uniformisation désactivée";
        focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setOnAudioFocusChangeListener(change->{ if(change<0) suspendForExternal(); }).build();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(new NotificationChannel("playback","Lecture musicale",NotificationManager.IMPORTANCE_LOW));
        session=new MediaSession(this,"Rhythmbox");
        session.setCallback(new MediaSession.Callback(){
            public void onPlay(){if(loading)autoplay=true;else if(!isPlaying())toggle();} public void onPause(){pause();} public void onSkipToNext(){next(1);} public void onSkipToPrevious(){next(-1);} public void onSeekTo(long pos){seek((int)pos);} public void onStop(){stopPlayback();}
        }); session.setActive(true);
        if(Build.VERSION.SDK_INT>=33) registerReceiver(noisy,new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(noisy,new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
    }
    @Override public IBinder onBind(Intent intent){return binder;}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        String action=intent==null?null:intent.getAction();
        if("previous".equals(action))next(-1);else if("next".equals(action))next(1);else if("toggle".equals(action))toggle();else if("stop".equals(action)){stopPlayback();return START_NOT_STICKY;}
        notification();return START_NOT_STICKY;
    }
    public void play(JSONArray tracks,int selected){ cancelPrefetch();queue=tracks;load(selected); }
    public void excludeTracks(JSONArray tracks){
        java.util.Set<String> ids=new java.util.HashSet<>();for(int i=0;i<tracks.length();i++){JSONObject item=tracks.optJSONObject(i);if(item!=null)ids.add(item.optString("id"));}
        PlaybackQueue.Selection kept=PlaybackQueue.excluding(queue,index,ids);
        if(kept.currentRemoved){stopPlayback();currentTrackId="";title="À toi de choisir";artist="";artwork=null;}
        queue=kept.tracks;index=kept.selected;
        if(!kept.currentRemoved){if(loading)cancelPrefetch();else scheduleNextCache();}
    }
    public void setShuffle(boolean value){shuffle=value;if(hasCurrentTrack()&&!loading)scheduleNextCache();}
    public boolean isPlaying(){try{return player!=null && !loading && player.isPlaying();}catch(Exception invalidState){return false;}}
    // MediaPlayer reports asynchronous ERROR(-38) for reads/seeks while
    // prepareAsync is pending; catching Java exceptions does not prevent it.
    public int position(){try{return player==null || loading?0:player.getCurrentPosition();}catch(Exception e){return 0;}}
    public int duration(){try{return player==null || loading?0:player.getDuration();}catch(Exception e){return 0;}}
    public void seek(int position){if(player!=null && !loading)try{player.seekTo(position);}catch(Exception ignored){}}
    public void toggle(){if(player==null && !loading && hasCurrentTrack()){load(index);return;}if(player!=null && !loading){if(isPlaying())pause();else if(audio.requestAudioFocus(focus)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED){session.setActive(true);player.start();status="Lecture";notification();}}}
    public void pause(){autoplay=false;if(isPlaying()){try{player.pause();}catch(Exception ignored){}}status="En pause";notification();}
    public void suspendForExternal(){pause();if(session!=null)session.setActive(false);if(audio!=null)audio.abandonAudioFocusRequest(focus);}
    /** Resume the selected native queue after a verified external pause.
     * Preserve pending downloads and position; toggle alone is a no-op while loading.
     */
    public void resumeAfterExternal(){if(loading)autoplay=true;else if(!isPlaying())toggle();}
    public boolean isUniformVolumeEnabled(){return uniformVolume;}
    public void setUniformVolumeEnabled(boolean enabled){
        VolumePreferences.setEnabled(this,enabled);if(uniformVolume==enabled)return;
        uniformVolume=enabled;cancelVolumeAnalysis();
        if(!enabled){volumeStatus="Uniformisation désactivée";volumeEffect.close();if(player!=null&&!loading)try{player.setVolume(1,1);}catch(RuntimeException ignored){}return;}
        if(trackLoudness!=null&&player!=null&&!loading){applyTrackVolume();return;}
        volumeStatus="Uniformisation activée · analyse du morceau…";
        if(player!=null&&!loading)analyzeCurrentVolume();
    }
    private void cancelVolumeAnalysis(){TrackLoudnessAnalyzer.Cancellation old;synchronized(volumeLock){volumeEpoch++;old=volumeAnalysis;volumeAnalysis=null;}if(old!=null)old.close();}
    private TrackLoudnessAnalyzer.Cancellation volumeTask(int request,long epoch){
        synchronized(volumeLock){if(request!=generation||epoch!=volumeEpoch||!uniformVolume)return null;
            TrackLoudnessAnalyzer.Cancellation task=new TrackLoudnessAnalyzer.Cancellation(()->request==generation&&epoch==volumeEpoch&&uniformVolume);
            TrackLoudnessAnalyzer.Cancellation old=volumeAnalysis;volumeAnalysis=task;if(old!=null)old.close();return task;}
    }
    private void endVolumeTask(TrackLoudnessAnalyzer.Cancellation task){synchronized(volumeLock){if(volumeAnalysis==task)volumeAnalysis=null;}task.close();}
    private TrackLoudness.Result measureVolume(File file,JSONObject suno,TrackLoudnessAnalyzer.Cancellation task,int request,long epoch) throws Exception {
        task.check();TrackLoudnessAnalyzer.Progress progress=(position,duration)->handler.post(()->{if(request==generation&&epoch==volumeEpoch&&uniformVolume)
            volumeStatus=duration>0?"Analyse du volume · "+Math.min(100,Math.round(position*100.0/duration))+" %":"Analyse du volume…";});
        if(file!=null){
            TrackLoudnessCache cache=new TrackLoudnessCache(getNoBackupFilesDir());String key=TrackLoudnessCache.fileKey(file);
            TrackLoudness.Result saved=cache.get(key);if(saved!=null){task.check();return saved;}
            TrackLoudness.Result measured=TrackLoudnessAnalyzer.measure(file,task,progress);task.check();
            if(!key.equals(TrackLoudnessCache.fileKey(file)))throw new java.io.IOException("Le fichier a changé pendant sa mesure");
            try{cache.put(key,measured);}catch(Exception optionalCache){}return measured;
        }
        if(suno!=null){
            // This independent source can be cancelled without stopping the
            // source already used by MediaPlayer. No Suno audio is cached.
            SunoAudio.Cancellation network=new SunoAudio.Cancellation();
            try(java.io.Closeable registration=task.register(network::close)){
                task.check();try(SunoMediaDataSource source=SunoMediaDataSource.open(suno,network)){
                    return TrackLoudnessAnalyzer.measure(source,task,progress);
                }
            }finally{network.close();}
        }
        throw new java.io.IOException("Source du morceau indisponible pour la mesure");
    }
    private void applyTrackVolume(){
        if(player==null||loading)return;
        try{volumeStatus=volumeEffect.applySession(player.getAudioSessionId(),player::setVolume,trackLoudness,uniformVolume);}
        catch(RuntimeException unavailable){volumeEffect.close();volumeStatus="Volume d’origine · uniformisation indisponible";}
    }
    private void analyzeCurrentVolume(){
        final int request=generation;final long epoch=volumeEpoch;final File file=volumeFile;final JSONObject suno=volumeSuno;
        final TrackLoudnessAnalyzer.Cancellation task=volumeTask(request,epoch);if(task==null)return;volumeAttempted=true;volumeStatus="Analyse du volume…";
        volumeWorker.execute(()->{TrackLoudness.Result measured=null;String issue=null;
            try{measured=measureVolume(file,suno,task,request,epoch);}catch(TrackLoudnessAnalyzer.Cancelled cancelled){}catch(Exception unavailable){issue="Volume d’origine · mesure indisponible";}
            finally{endVolumeTask(task);}
            final TrackLoudness.Result result=measured;final String failure=issue;
            handler.post(()->{if(request!=generation||epoch!=volumeEpoch||!uniformVolume)return;trackLoudness=result;if(result!=null)applyTrackVolume();else if(failure!=null)volumeStatus=failure;});
        });
    }
    private void closeSuno(){SunoAudio.Cancellation cancelled=sunoCancellation;sunoCancellation=null;if(cancelled!=null)cancelled.close();SunoMediaDataSource source=sunoSource;sunoSource=null;if(source!=null)source.close();}
    public void stopPlayback(){generation++;cancelMedia();cancelPrefetch();autoplay=false;loading=false;cancelVolumeAnalysis();volumeEffect.close();if(player!=null){player.release();player=null;}closeSuno();audio.abandonAudioFocusRequest(focus);status="Arrêté";session.setPlaybackState(new PlaybackState.Builder().setState(PlaybackState.STATE_STOPPED,0,0).build());session.setActive(false);stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}
    public void next(int direction){if(queue.length()==0)return; int next=shuffle && queue.length()>1?(direction>0&&prefetchedNext>=0?prefetchedNext:(index+1+new java.util.Random().nextInt(queue.length()-1))%queue.length()):index+direction;if(next>=queue.length()){stopPlayback();return;}load(Math.max(0,next));}
    private void load(int selected){
        if(selected<0 || selected>=queue.length())return;
        final JSONObject track=queue.optJSONObject(selected); if(track==null)return;
        index=selected;final int request=++generation;cancelMedia();
        if(!track.optString("id","").equals(prefetchedId))cancelPrefetch();
        final PCloudAudioCache.Cancellation download=new PCloudAudioCache.Cancellation(()->request==generation);mediaCancellation=download;mediaOrigin="";
        cancelVolumeAnalysis();volumeEffect.close();trackLoudness=null;volumeFile=null;volumeSuno=null;volumeAttempted=false;
        volumeStatus=uniformVolume?"Préparation de l’analyse du volume…":"Uniformisation désactivée";
        if(player!=null){player.release();player=null;}
        closeSuno();
        title=UiPresentation.title(track); artist=track.optString("artist","");currentTrackId=track.optString("id","");artwork=null;
        final boolean isSuno=SunoCatalog.isSunoTrack(track);
        if(isSuno&&(track.has("pcloud_account_userid")||track.has("pcloud_fileid")||track.has("media_path")||track.has("local_uri"))){fail(request,"La provenance de ce morceau Suno est contradictoire");return;}
        if(!isSuno && !DemoAudio.isDemo(track) && track.optLong("pcloud_fileid",0)<=0 && !track.has("media_path")){fail(request,"Ce morceau n’est pas associé à un dossier musical");return;}
        final SunoAudio.Cancellation cancellation=isSuno?new SunoAudio.Cancellation():null;sunoCancellation=cancellation;
        loading=true;autoplay=true;session.setActive(true);status="Préparation du morceau…";startForegroundService(new Intent(this,PlaybackService.class));notification();
        worker.execute(()->{
            try{
                File file=null;SunoMediaDataSource streaming=null;Bitmap selectedCover=null;JSONObject suno=null;
                if(isSuno){suno=new SunoLibrary(this).registeredTrack(track.getString("id"));selectedCover=sunoArtwork(suno,cancellation);}
                else if(DemoAudio.isDemo(track))file=DemoAudio.materialize(this,track);
                else{SyncConnection engine=new SyncConnection(this,new SecretStore(this).load(),()->request==generation);file=engine.mediaFile(track,getCacheDir(),download,(done,total)->handler.post(()->{if(request==generation)status=total>0?"Préparation audio · "+Math.min(100,done*100/total)+" %":"Préparation audio…";}));mediaOrigin=engine.lastMediaSource;}
                TrackLoudness.Result measured=null;boolean attempted=false;
                long epoch=volumeEpoch;TrackLoudnessAnalyzer.Cancellation task=volumeTask(request,epoch);
                if(task!=null){attempted=true;try{measured=measureVolume(file,suno,task,request,epoch);}
                    catch(TrackLoudnessAnalyzer.Cancelled cancelled){}catch(Exception unavailable){/* Original playback remains available. */}finally{endVolumeTask(task);}}
                if(request!=generation){if(cancellation!=null)cancellation.close();return;}
                if(isSuno)streaming=SunoMediaDataSource.open(suno,cancellation);
                final File localFile=file;final SunoMediaDataSource stream=streaming;
                final TrackLoudness.Result measurement=measured;final boolean analyzed=attempted;final long analyzedEpoch=epoch;final JSONObject registeredSuno=suno;
                final Bitmap cover=isSuno?selectedCover:embeddedArtwork(file);
                handler.post(()->{
                    if(request!=generation){if(stream!=null)stream.close();return;}
                    sunoSource=stream;
                    volumeFile=localFile;volumeSuno=registeredSuno;volumeAttempted=analyzed&&analyzedEpoch==volumeEpoch;
                    trackLoudness=analyzedEpoch==volumeEpoch?measurement:null;
                    artwork=cover;
                    try{
                        player=new NativeAudioPlayer(this); player.setWakeMode(this,PowerManager.PARTIAL_WAKE_LOCK);player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
                        // This music client never supplies a rendering surface,
                        // including when the selected file is a video container.
                        player.setSurface(null);
                        if(stream!=null)player.setDataSource(stream);else player.setDataSource(localFile.getAbsolutePath());
                        player.setOnPreparedListener(p->{
                            if(request!=generation)return;
                            loading=false;
                            boolean hasAudio=p.hasAudio();
                            if(!hasAudio){fail(request,"Ce fichier ne contient pas de piste audio lisible");return;}
                            applyTrackVolume();
                            if(uniformVolume&&!volumeAttempted)analyzeCurrentVolume();
                            if(!autoplay)status="En pause";
                            else if(audio.requestAudioFocus(focus)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED){p.start();status=mediaOrigin.isEmpty()?"Lecture":"Lecture · "+mediaOrigin;}
                            else status="Sortie audio occupée";
                            scheduleNextCache();
                            // PCM starts after this prepared callback finishes so
                            // the measured gain is attached before the first frame.
                            handler.post(()->{if(request==generation&&p==player)notification();});
                        });
                        player.setOnCompletionListener(p->{if(request==generation)next(1);});
                        player.setOnSeekCompleteListener(p->{if(request==generation && p==player)notification();});
                        player.setOnErrorListener((p,what,extra)->{fail(request,"Ce format audio ne peut pas être lu");return true;});
                        player.prepareAsync();
                    }catch(Exception failure){fail(request,"Échec de préparation audio");}
                });
            }catch(Exception failure){if(cancellation!=null)cancellation.close();handler.post(()->{if(request!=generation)return;fail(request,isSuno?(failure instanceof SunoAudio.Failure?failure.getMessage():"Lecture Suno indisponible : vérifie le lien et la connexion"):
                "Audio indisponible : vérifie le dossier et la connexion");});}
        });
    }
    public StereoSpectrum.Snapshot spectrum(){return player==null?StereoSpectrum.Snapshot.unavailable():player.getSpectrum();}
    public String spectrumStatus(){return player==null?"En attente de lecture":player.spectrumStatus();}
    private void cancelMedia(){PCloudAudioCache.Cancellation old=mediaCancellation;mediaCancellation=null;if(old!=null)old.cancel();}
    private void cancelPrefetch(){prefetchEpoch++;PCloudAudioCache.Cancellation old=prefetchCancellation;prefetchCancellation=null;if(old!=null)old.cancel();TrackLoudnessAnalyzer.Cancellation analysis=prefetchAnalysis;prefetchAnalysis=null;if(analysis!=null)analysis.close();prefetchedId="";prefetchedNext=-1;}
    private void scheduleNextCache(){
        cancelPrefetch();if(!hasCurrentTrack()||queue.length()<2)return;
        final int target=shuffle?(index+1+new java.util.Random().nextInt(queue.length()-1))%queue.length():index+1;
        if(target>=queue.length())return;
        JSONObject raw=queue.optJSONObject(target);if(raw==null||SunoCatalog.isSunoTrack(raw)||DemoAudio.isDemo(raw))return;
        final JSONObject next;try{next=new JSONObject(raw.toString());}catch(Exception invalid){return;}
        final long epoch=prefetchEpoch;prefetchedNext=target;prefetchedId=next.optString("id","");
        final PCloudAudioCache.Cancellation token=new PCloudAudioCache.Cancellation(()->epoch==prefetchEpoch);prefetchCancellation=token;
        prefetchWorker.execute(()->{try{
            SyncConnection engine=new SyncConnection(this,new SecretStore(this).load(),()->epoch==prefetchEpoch);
            File file=engine.prefetchMedia(next,token,null);token.check();
            if(uniformVolume){
                TrackLoudnessAnalyzer.Cancellation analysis=new TrackLoudnessAnalyzer.Cancellation(()->epoch==prefetchEpoch&&uniformVolume);prefetchAnalysis=analysis;
                try{TrackLoudnessCache cache=new TrackLoudnessCache(getNoBackupFilesDir());String key=TrackLoudnessCache.fileKey(file);if(cache.get(key)==null){TrackLoudness.Result result=TrackLoudnessAnalyzer.measure(file,analysis,null);analysis.check();if(key.equals(TrackLoudnessCache.fileKey(file)))cache.put(key,result);}}
                finally{if(prefetchAnalysis==analysis)prefetchAnalysis=null;analysis.close();}
            }
        }catch(Exception optionalPreparation){/* Current playback and the next explicit request remain available. */}});
    }
    private void fail(int request,String message){
        if(request!=generation)return;
        generation++;cancelMedia();cancelPrefetch();loading=false;autoplay=false;
        cancelVolumeAnalysis();volumeEffect.close();
        if(player!=null){try{player.release();}catch(Exception ignored){}player=null;}
        closeSuno();
        audio.abandonAudioFocusRequest(focus);status=message;
        session.setPlaybackState(new PlaybackState.Builder().setState(PlaybackState.STATE_ERROR,0,0).setErrorMessage(message).build());session.setActive(false);
        stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
    }
    private void notification(){
        if(session==null)return;
        MediaMetadata.Builder metadata=new MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE,title).putString(MediaMetadata.METADATA_KEY_ARTIST,artist).putLong(MediaMetadata.METADATA_KEY_DURATION,duration());
        if(artwork!=null)metadata.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART,artwork);session.setMetadata(metadata.build());
        session.setPlaybackState(new PlaybackState.Builder().setActions(PlaybackState.ACTION_PLAY_PAUSE|PlaybackState.ACTION_PLAY|PlaybackState.ACTION_PAUSE|PlaybackState.ACTION_SKIP_TO_NEXT|PlaybackState.ACTION_SKIP_TO_PREVIOUS|PlaybackState.ACTION_SEEK_TO)
            .setState(loading?PlaybackState.STATE_BUFFERING:isPlaying()?PlaybackState.STATE_PLAYING:PlaybackState.STATE_PAUSED,position(),isPlaying()?1:0).build());
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class).putExtra("open_player",true),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification=new Notification.Builder(this,"playback").setSmallIcon(R.drawable.ic_stat_music).setContentTitle(title).setContentText(artist+" · "+status).setContentIntent(open).setLargeIcon(artwork)
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_previous,"Précédent",command("previous",1)).build())
            .addAction(new Notification.Action.Builder(isPlaying()?android.R.drawable.ic_media_pause:android.R.drawable.ic_media_play,isPlaying()?"Pause":"Lecture",command("toggle",2)).build())
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_next,"Suivant",command("next",3)).build())
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"Arrêter",command("stop",4)).build())
            .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0,1,2)).setVisibility(Notification.VISIBILITY_PRIVATE).setOngoing(isPlaying()||loading).build();
        if(loading||player!=null)startForeground(1,notification);
    }
    private Bitmap embeddedArtwork(File file){
        MediaMetadataRetriever retriever=new MediaMetadataRetriever();
        try{retriever.setDataSource(file.getAbsolutePath());byte[] bytes=retriever.getEmbeddedPicture();if(bytes==null || bytes.length>4*1024*1024)return null;BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(bytes,0,bytes.length,options);if(options.outWidth<=0 || options.outHeight<=0 || options.outWidth>8192 || options.outHeight>8192 || (long)options.outWidth*options.outHeight>32L*1024*1024)return null;options.inJustDecodeBounds=false;options.inSampleSize=1;while(Math.max(options.outWidth,options.outHeight)/options.inSampleSize>512)options.inSampleSize*=2;return BitmapFactory.decodeByteArray(bytes,0,bytes.length,options);}
        catch(Exception unreadable){return null;}finally{try{retriever.release();}catch(Exception ignored){}}
    }
    private Bitmap sunoArtwork(JSONObject track,SunoAudio.Cancellation cancellation){
        String uri=track.optString("cover_uri","");if(!SunoCatalog.validCoverUri(uri)||java.net.CookieHandler.getDefault()!=null)return null;
        javax.net.ssl.HttpsURLConnection connection=null;java.io.Closeable registration=null;
        try{
            cancellation.check();connection=(javax.net.ssl.HttpsURLConnection)new java.net.URL(uri).openConnection();final javax.net.ssl.HttpsURLConnection active=connection;registration=cancellation.register(active::disconnect);
            connection.setConnectTimeout(5000);connection.setReadTimeout(5000);connection.setInstanceFollowRedirects(false);connection.setUseCaches(false);connection.setRequestProperty("Accept-Encoding","identity");
            if(connection.getResponseCode()!=200)return null;String type=connection.getContentType();if(type==null||!type.split(";",2)[0].trim().matches("image/(jpeg|png|webp)"))return null;
            String encoding=connection.getHeaderField("Content-Encoding");if(encoding!=null&&!"identity".equals(encoding))return null;
            java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();try(java.io.InputStream input=connection.getInputStream()){byte[] buffer=new byte[16384];int count;while((count=input.read(buffer))!=-1){cancellation.check();if(bytes.size()+count>4*1024*1024)return null;bytes.write(buffer,0,count);}}
            byte[] data=bytes.toByteArray();BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(data,0,data.length,options);
            if(options.outWidth<=0||options.outHeight<=0||options.outWidth>8192||options.outHeight>8192||(long)options.outWidth*options.outHeight>32L*1024*1024)return null;
            options.inJustDecodeBounds=false;options.inSampleSize=1;while(Math.max(options.outWidth,options.outHeight)/options.inSampleSize>512)options.inSampleSize*=2;cancellation.check();return BitmapFactory.decodeByteArray(data,0,data.length,options);
        }catch(Exception unavailable){return null;}finally{if(registration!=null)try{registration.close();}catch(Exception ignored){}if(connection!=null)connection.disconnect();}
    }
    @Override public void onTaskRemoved(Intent intent){stopPlayback();super.onTaskRemoved(intent);}
    private PendingIntent command(String action,int request){return PendingIntent.getService(this,request,new Intent(this,PlaybackService.class).setAction(action),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);}
    @Override public void onDestroy(){generation++;cancelMedia();cancelPrefetch();prefetchWorker.shutdownNow();cancelVolumeAnalysis();volumeEffect.close();if(player!=null){player.release();player=null;}closeSuno();worker.shutdownNow();volumeWorker.shutdownNow();if(session!=null)session.release();audio.abandonAudioFocusRequest(focus);unregisterReceiver(noisy);super.onDestroy();}
}
