package fr.denis.rhythmbox;

import android.app.job.JobParameters;
import android.app.job.JobService;
import java.util.concurrent.atomic.AtomicBoolean;

/** Periodic unmetered work; no foreground service or notification. */
public final class PCloudSyncJobService extends JobService {
    private AtomicBoolean cancelled;
    @Override public boolean onStartJob(JobParameters parameters){
        if(PCloudSyncController.isUiActive())return false;
        final AtomicBoolean stop=new AtomicBoolean();cancelled=stop;
        new Thread(()->{
            boolean retry=false;
            try{
                if(!"account".equals(new SecretStore(this).load().optString("sync_mode")))return;
                Library library=new Library(this);PCloudSyncController controller=new PCloudSyncController(this);
                PCloudSyncController.Result result=controller.prepareSync(library,true,stop::get);
                if(!stop.get()&&!PCloudSyncController.isUiActive())retry=!controller.commit(library,result);
            }catch(Exception error){
                // A pending journal remains private and blocks a blind retry.
                // Failures contain no tokens, paths or provider response dump.
                try{Library latest=new Library(this);org.json.JSONObject state=latest.state.optJSONObject("pcloud_native");retry=state!=null&&!state.has("pending")&&!PCloudSyncController.isUiActive();}catch(Exception ignored){retry=false;}
            }finally{if(!stop.get())jobFinished(parameters,retry);}
        },"rhythmbox-pcloud-sync").start();
        return true;
    }
    @Override public boolean onStopJob(JobParameters parameters){if(cancelled!=null)cancelled.set(true);return false;}
}
