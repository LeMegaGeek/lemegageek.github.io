package fr.denis.rhythmbox;

import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;

/** Pure three-way native-collection plans plus an explicit guarded executor.
 * A plan never writes Library, configuration, credentials or a remote account.
 * apply() writes collection references only and returns a candidate base; the
 * caller must save the local Library before acknowledging that base. A partial
 * remote failure has no automatic retry or destructive rollback.
 */
public final class PCloudNativeSync {
    private PCloudNativeSync(){}
    private static final int MAX=50000;
    private static IllegalArgumentException invalid(String text){return new IllegalArgumentException(text);}
    private static long id(Object value) throws Exception{return PCloudCollections.integer(value,false);}
    private static String text(Object value,int maximum) {
        if(!(value instanceof String))throw invalid("Métadonnée musicale invalide.");String s=(String)value;
        if(s.codePointCount(0,s.length())>maximum||s.indexOf(0)>=0)throw invalid("Métadonnée musicale trop longue ou invalide.");return s;
    }
    private static String identity(Object value,int maximum){String out=text(value,maximum);if(out.isEmpty())throw invalid("Identifiant musical vide.");return out;}
    private static JSONObject copy(JSONObject value) throws Exception{return new JSONObject(value.toString());}
    private static JSONArray array(List<Long> values){return new JSONArray(values);}
    private static List<Long> ids(JSONArray values) throws Exception{return PCloudCollections.ids(values);}
    private static Set<String> strings(Set<String> input,boolean paths) {
        Set<String> out=new HashSet<>();if(input==null)return out;if(input.size()>MAX)throw invalid("Trop d’exclusions.");
        for(String value:input)out.add(paths?FolderProtocol.mediaPath(value):identity(value,2048));return out;
    }
    /** Stable across Linux and Android without depending on a display name. */
    public static String playlistId(long userid,long collectionId) throws Exception {id(userid);id(collectionId);return "pcloud:"+userid+":collection:"+collectionId;}
    private static JSONObject portableTrack(JSONObject raw) throws Exception {
        JSONObject out=new JSONObject().put("id",identity(raw.get("id"),2048));
        for(String key:new String[]{"title","artist","album"})out.put(key,text(raw.opt(key)==null?"":raw.get(key),2048));
        if(raw.has("media_path"))out.put("media_path",FolderProtocol.mediaPath(raw.getString("media_path")));
        if(raw.has("pcloud_fileid"))out.put("pcloud_fileid",id(raw.get("pcloud_fileid")));return out;
    }
    private static JSONObject playlist(JSONObject raw,String expectedId) throws Exception {
        String identifier=identity(raw.get("id"),128);if(expectedId!=null&&!expectedId.equals(identifier))throw invalid("La liste ne correspond pas à sa liaison pCloud.");
        JSONArray source=raw.getJSONArray("tracks"),tracks=new JSONArray();if(source.length()>MAX)throw invalid("Trop de morceaux dans la liste.");
        for(int i=0;i<source.length();i++)tracks.put(portableTrack(source.getJSONObject(i)));
        return new JSONObject().put("id",identifier).put("name",text(raw.get("name"),1024)).put("tracks",tracks);
    }
    private static final class Mapping {
        final long fid;final String path;final JSONObject track;final boolean available,localAvailable;
        Mapping(long fid,String path,JSONObject track,boolean available,boolean localAvailable){this.fid=fid;this.path=path;this.track=track;this.available=available;this.localAvailable=localAvailable;}
    }
    private static final class Index {
        final Map<Long,Mapping> files=new LinkedHashMap<>();final Map<String,Mapping> paths=new HashMap<>(),tracks=new HashMap<>();
        final Set<String> quarantinedTracks=new HashSet<>(),quarantinedPaths=new HashSet<>();
    }
    private static boolean booleanField(JSONObject row,String key,boolean fallback) throws Exception {
        if(!row.has(key))return fallback;Object raw=row.get(key);if(!(raw instanceof Boolean))throw invalid("Disponibilité musicale invalide.");return (Boolean)raw;
    }
    private static Index index(JSONObject raw,long account) throws Exception {
        if(id(raw.get("account_userid"))!=account)throw invalid("Correspondance liée à un autre compte pCloud.");
        JSONArray files=raw.getJSONArray("files");if(files.length()>MAX)throw invalid("Trop de références musicales.");Index out=new Index();
        for(int i=0;i<files.length();i++){
            JSONObject row=files.getJSONObject(i);long fid=id(row.get("fileid"));String path=FolderProtocol.mediaPath(row.getString("media_path"));
            JSONObject source=row.getJSONObject("track");if(source.has("media_path")&&!path.equals(source.getString("media_path")))throw invalid("Chemins musicaux incohérents.");
            JSONObject track=portableTrack(source);track.put("media_path",path).put("pcloud_fileid",fid);
            Mapping mapped=new Mapping(fid,path,track,booleanField(row,"available",true),booleanField(row,"local_available",false));
            if(out.files.put(fid,mapped)!=null||out.paths.put(path,mapped)!=null||out.tracks.put(track.getString("id"),mapped)!=null)throw invalid("Correspondance musicale ambiguë.");
            if(booleanField(source,"quarantined",false)){out.quarantinedTracks.add(track.getString("id"));out.quarantinedPaths.add(path);}
        }return out;
    }
    /** representablePaths must describe a complete editable projection, not an
     * incomplete import. Missing cloud-only members otherwise stay protected. */
    public static JSONObject mediaIndex(PCloudAccount account,Map<Long,JSONObject> files,Set<String> representablePaths) throws Exception {
        JSONArray rows=new JSONArray();Set<String> representable=strings(representablePaths,true);
        if(files.size()>MAX)throw invalid("Trop de références musicales.");
        for(JSONObject row:files.values()){
            String path=FolderProtocol.mediaPath(row.getString("media_path"));rows.put(new JSONObject().put("fileid",id(row.get("fileid"))).put("media_path",path)
                .put("track",PCloudCollections.track(row,account.userid)).put("available",true).put("local_available",representable.contains(path)));
        }return new JSONObject().put("account_userid",account.userid).put("files",rows);
    }
    public static JSONObject playlistFromCollection(PCloudAccount account,JSONObject remote,Map<Long,JSONObject> files) throws Exception {
        if(id(remote.get("account_userid"))!=account.userid||!Boolean.TRUE.equals(remote.get("complete"))||!Boolean.TRUE.equals(remote.get("ismine"))||!Boolean.FALSE.equals(remote.get("system"))||!"audio".equals(remote.get("type")))throw invalid("Lecture pCloud incomplète ou liée à un autre compte.");
        long collection=id(remote.get("id"));JSONArray tracks=new JSONArray();for(long fid:ids(remote.getJSONArray("fileids"))){JSONObject row=files.get(fid);if(row==null)throw invalid("Morceau hors du dossier musical choisi.");tracks.put(PCloudCollections.track(row,account.userid));}
        return new JSONObject().put("id",playlistId(account.userid,collection)).put("name",text(remote.get("name"),1024)).put("tracks",tracks);
    }
    private static Mapping resolve(JSONObject track,Index index) throws Exception {
        Mapping same=index.tracks.get(track.getString("id"));
        if(track.has("media_path")){Mapping path=index.paths.get(FolderProtocol.mediaPath(track.getString("media_path")));if(path!=null&&same!=null&&path.fid!=same.fid)throw invalid("Identité et chemin musicaux contradictoires.");return path;}
        return same;
    }
    private static final class Mapped {
        JSONObject playlist;final List<Long> ids=new ArrayList<>();final Set<String> unknown=new TreeSet<>();
        Mapped(JSONObject value){playlist=value;}
    }
    private static Mapped map(JSONObject source,Index index,Set<String> excludedIds,Set<String> excludedPaths,Set<Long> excludedFiles) throws Exception {
        Mapped out=new Mapped(new JSONObject().put("id",source.getString("id")).put("name",source.getString("name")));JSONArray tracks=new JSONArray(),input=source.getJSONArray("tracks");
        for(int i=0;i<input.length();i++){
            JSONObject track=input.getJSONObject(i);Mapping mapped=resolve(track,index);
            if(excludedIds.contains(track.getString("id"))||(track.has("media_path")&&excludedPaths.contains(track.getString("media_path")))||(mapped!=null&&excludedFiles.contains(mapped.fid)))continue;
            JSONObject row=copy(track);if(mapped==null){out.unknown.add(track.getString("id"));out.ids.add(null);}else{row.put("media_path",mapped.path).put("pcloud_fileid",mapped.fid);out.ids.add(mapped.fid);}tracks.put(row);
        }out.playlist.put("tracks",tracks);return out;
    }
    private static void quarantine(JSONObject raw,Set<String> ids,Set<String> paths) throws Exception {
        if(raw==null)return;JSONArray tracks=raw.getJSONArray("tracks");for(int i=0;i<tracks.length();i++){JSONObject track=tracks.getJSONObject(i);if(booleanField(track,"quarantined",false)){ids.add(identity(track.get("id"),2048));if(track.has("media_path"))paths.add(FolderProtocol.mediaPath(track.getString("media_path")));}}
    }
    private static void issue(JSONObject result,String code,String field,JSONArray values) throws Exception {JSONObject issue=new JSONObject().put("code",code);if(field!=null)issue.put(field,values);result.getJSONArray("issues").put(issue);}
    private static List<Long> filtered(List<Long> values,Set<Long> removed){List<Long> out=new ArrayList<>();for(Long value:values)if(!removed.contains(value))out.add(value);return out;}
    private static JSONObject remotePlaylist(JSONObject local,List<Long> remote,Map<Long,JSONObject> preferences,Index index) throws Exception {
        JSONArray tracks=new JSONArray();for(long fid:remote)tracks.put(copy(preferences.containsKey(fid)?preferences.get(fid):index.files.get(fid).track));
        return new JSONObject().put("id",local.getString("id")).put("name",local.getString("name")).put("tracks",tracks);
    }
    private static JSONObject privateAccountMarker(JSONObject value,long account) throws Exception {
        JSONObject out=copy(value);JSONArray tracks=out.getJSONArray("tracks");for(int i=0;i<tracks.length();i++)tracks.getJSONObject(i).put("pcloud_account_userid",account);return out;
    }
    public static JSONObject plan(JSONObject binding,JSONObject base,JSONObject local,JSONObject remote,JSONObject mediaIndex,
                                  Set<String> excludedTrackIds,Set<String> excludedMediaPaths,Set<Long> excludedFileIds,Set<String> explicitLocalRemovals) throws Exception {
        long account=id(binding.get("account_userid")),collection=id(binding.get("collection_id"));String playlistId=identity(binding.get("playlist_id"),128);
        if(id(remote.get("account_userid"))!=account||id(remote.get("id"))!=collection)throw invalid("Collection liée à un autre compte ou une autre liste.");
        if(!Boolean.TRUE.equals(remote.get("ismine"))||!Boolean.FALSE.equals(remote.get("system"))||!"audio".equals(remote.get("type")))throw invalid("Seule une liste audio personnelle non système est autorisée.");
        List<Long> remoteIds=ids(remote.getJSONArray("fileids"));JSONObject original=playlist(local,playlistId),before=null;List<Long> beforeIds=new ArrayList<>();
        if(base!=null){if(id(base.get("account_userid"))!=account||id(base.get("collection_id"))!=collection||!playlistId.equals(base.getString("playlist_id")))throw invalid("Référence de synchronisation liée à un autre compte ou une autre liste.");before=playlist(base.getJSONObject("playlist"),playlistId);beforeIds=ids(base.getJSONArray("fileids"));}
        Index index=index(mediaIndex,account);Set<String> excludedIds=strings(excludedTrackIds,false),excludedPaths=strings(excludedMediaPaths,true),explicit=strings(explicitLocalRemovals,false);
        excludedIds.addAll(index.quarantinedTracks);excludedPaths.addAll(index.quarantinedPaths);quarantine(local,excludedIds,excludedPaths);if(base!=null)quarantine(base.getJSONObject("playlist"),excludedIds,excludedPaths);
        Set<Long> excludedFiles=new HashSet<>();if(excludedFileIds!=null)for(Long fid:excludedFileIds){if(fid==null||!index.files.containsKey(id(fid)))throw invalid("Exclusion hors du dossier musical du compte.");excludedFiles.add(fid);}
        for(Mapping row:index.files.values())if(excludedIds.contains(row.track.getString("id"))||excludedPaths.contains(row.path))excludedFiles.add(row.fid);
        for(JSONObject p:new JSONObject[]{original,before})if(p!=null){JSONArray tracks=p.getJSONArray("tracks");for(int i=0;i<tracks.length();i++){JSONObject t=tracks.getJSONObject(i);if(excludedIds.contains(t.getString("id"))||(t.has("media_path")&&excludedPaths.contains(t.getString("media_path")))){Mapping mapped=resolve(t,index);if(mapped!=null)excludedFiles.add(mapped.fid);}}}
        Mapped left=map(original,index,excludedIds,excludedPaths,excludedFiles),old=before==null?null:map(before,index,excludedIds,excludedPaths,excludedFiles);
        List<Long> effectiveRemote=filtered(remoteIds,excludedFiles),logicalBase=filtered(beforeIds,excludedFiles);
        JSONObject result=new JSONObject().put("schema",1).put("account_userid",account).put("collection_id",collection).put("playlist_id",playlistId).put("ready",false).put("direction","blocked")
            .put("local_playlist",privateAccountMarker(left.playlist,account)).put("conflicts",new JSONArray()).put("remote_before",array(remoteIds)).put("remote_target",JSONObject.NULL).put("operations",new JSONArray())
            .put("counts",new JSONObject().put("add",0).put("remove",0).put("reorder",0)).put("issues",new JSONArray()).put("proposed_base",JSONObject.NULL);
        if(!Boolean.TRUE.equals(remote.opt("complete")))issue(result,"incomplete_remote_read",null,null);
        if(!left.unknown.isEmpty())issue(result,"unmapped_local_tracks","track_ids",new JSONArray(left.unknown));
        if(old!=null&&!old.unknown.isEmpty())issue(result,"unmapped_base_tracks","track_ids",new JSONArray(old.unknown));
        if(old!=null&&old.unknown.isEmpty()&&!old.ids.equals(logicalBase))issue(result,"stale_base_mapping",null,null);
        Set<Long> missing=new TreeSet<>();for(long fid:effectiveRemote)if(!index.files.containsKey(fid))missing.add(fid);if(!missing.isEmpty())issue(result,"unmapped_remote_files","fileids",new JSONArray(missing));
        Set<Long> referenced=new HashSet<>(left.ids);referenced.addAll(logicalBase);referenced.addAll(effectiveRemote);Set<Long> unavailable=new TreeSet<>();for(Long fid:referenced)if(index.files.containsKey(fid)&&!index.files.get(fid).available)unavailable.add(fid);
        if(!unavailable.isEmpty())issue(result,"unavailable_files","fileids",new JSONArray(unavailable));
        Set<Long> seen=new HashSet<>(),duplicates=new TreeSet<>();for(Long fid:left.ids)if(fid!=null&&!seen.add(fid))duplicates.add(fid);if(!duplicates.isEmpty())issue(result,"unrepresentable_duplicates","fileids",new JSONArray(duplicates));
        if(result.getJSONArray("issues").length()>0)return result;
        if(old!=null){
            Set<Long> present=new HashSet<>(left.ids);JSONArray originalTracks=left.playlist.getJSONArray("tracks"),baseTracks=old.playlist.getJSONArray("tracks"),restored=new JSONArray();List<Long> restoredIds=new ArrayList<>();int consumed=0;
            for(int position=0;position<old.ids.size();position++){
                long fid=old.ids.get(position);JSONObject t=baseTracks.getJSONObject(position);
                if(!present.contains(fid)&&!index.files.get(fid).localAvailable&&!explicit.contains(t.getString("id"))){
                    int insertion=Math.min(position,left.ids.size()+restoredIds.size()-consumed),count=insertion-restoredIds.size();
                    while(count-->0&&consumed<left.ids.size()){restored.put(originalTracks.getJSONObject(consumed));restoredIds.add(left.ids.get(consumed++));}
                    restored.put(copy(t));restoredIds.add(fid);present.add(fid);
                }
            }
            if(restored.length()>0){while(consumed<left.ids.size()){restored.put(originalTracks.getJSONObject(consumed));restoredIds.add(left.ids.get(consumed++));}left.playlist.put("tracks",restored);left.ids.clear();left.ids.addAll(restoredIds);}
        }
        result.put("local_playlist",privateAccountMarker(left.playlist,account));Map<Long,JSONObject> preferences=new HashMap<>();
        for(Mapped mapped:new Mapped[]{old,left})if(mapped!=null){JSONArray tracks=mapped.playlist.getJSONArray("tracks");for(int i=0;i<mapped.ids.size();i++)preferences.put(mapped.ids.get(i),tracks.getJSONObject(i));}
        List<Long> target;JSONObject chosen;boolean conflict;
        if(old==null){conflict=!left.ids.isEmpty()&&!effectiveRemote.isEmpty()&&!left.ids.equals(effectiveRemote);target=left.ids.isEmpty()?effectiveRemote:left.ids;chosen=left.ids.isEmpty()?remotePlaylist(left.playlist,effectiveRemote,preferences,index):left.playlist;}
        else{boolean localChanged=!left.ids.equals(logicalBase),remoteChanged=!effectiveRemote.equals(logicalBase);conflict=localChanged&&remoteChanged&&!left.ids.equals(effectiveRemote);target=remoteChanged&&!localChanged?effectiveRemote:left.ids;chosen=remoteChanged&&!localChanged?remotePlaylist(left.playlist,effectiveRemote,preferences,index):left.playlist;}
        if(conflict){
            JSONObject variant=remotePlaylist(left.playlist,effectiveRemote,preferences,index);String material=canonical(new JSONArray().put(account).put(collection).put(variant));
            String conflictId=UUID.nameUUIDFromBytes(("pcloud-collection-conflict:"+material).getBytes(StandardCharsets.UTF_8)).toString();variant.put("id",conflictId);String label=left.playlist.getString("name");variant.put("name",label.substring(0,Math.min(label.length(),950))+" · conflit pCloud "+conflictId.substring(0,8));
            result.put("direction","conflict").getJSONArray("conflicts").put(privateAccountMarker(variant,account));issue(result,old==null?"initial_contents_differ":"concurrent_changes",null,null);return result;
        }
        JSONObject ops=operations(remoteIds,target);boolean localChanged=!canonical(chosen).equals(canonical(original));int count=ops.getJSONArray("operations").length();String direction=count>0?(localChanged?"reconcile":"push"):(localChanged?"pull":"unchanged");
        JSONObject nextBase=new JSONObject().put("account_userid",account).put("collection_id",collection).put("playlist_id",playlistId).put("playlist",copy(chosen)).put("fileids",array(target));
        return result.put("ready",true).put("direction",direction).put("local_playlist",privateAccountMarker(chosen,account)).put("remote_target",array(target)).put("operations",ops.getJSONArray("operations")).put("counts",ops.getJSONObject("counts")).put("proposed_base",nextBase);
    }
    private static JSONObject operations(List<Long> current,List<Long> target) throws Exception {
        Set<Long> currentSet=new HashSet<>(current),targetSet=new HashSet<>(target);List<Long> add=new ArrayList<>(),remove=new ArrayList<>(),working=new ArrayList<>();
        for(long fid:target)if(!currentSet.contains(fid))add.add(fid);for(long fid:current)if(!targetSet.contains(fid))remove.add(fid);else working.add(fid);working.addAll(add);
        JSONArray operations=new JSONArray();if(!add.isEmpty())operations.put(new JSONObject().put("action","link").put("fileids",array(add)));if(!remove.isEmpty())operations.put(new JSONObject().put("action","unlink").put("fileids",array(remove)));
        Map<Long,Long> previous=new HashMap<>(),next=new HashMap<>();for(int i=0;i<working.size();i++){previous.put(working.get(i),i==0?null:working.get(i-1));next.put(working.get(i),i+1==working.size()?null:working.get(i+1));}Long head=working.isEmpty()?null:working.get(0);int moves=0;
        for(int i=0;i<target.size();i++){
            Long fid=target.get(i),wanted=i==0?null:target.get(i-1),oldPrevious=previous.get(fid);if(java.util.Objects.equals(oldPrevious,wanted))continue;Long oldNext=next.get(fid);
            if(oldPrevious==null)head=oldNext;else next.put(oldPrevious,oldNext);if(oldNext!=null)previous.put(oldNext,oldPrevious);
            Long successor=wanted==null?head:next.get(wanted);previous.put(fid,wanted);next.put(fid,successor);if(wanted==null)head=fid;else next.put(wanted,fid);if(successor!=null)previous.put(successor,fid);
            operations.put(new JSONObject().put("action","move").put("fileid",fid).put("after_fileid",wanted==null?JSONObject.NULL:wanted).put("position",i+1));moves++;
        }
        List<Long> checked=new ArrayList<>();for(Long fid=head;fid!=null;fid=next.get(fid)){if(checked.size()>=MAX)throw invalid("Ordre de liste cyclique.");checked.add(fid);}if(!checked.equals(target))throw invalid("Plan d’ordre de liste incohérent.");
        return new JSONObject().put("operations",operations).put("counts",new JSONObject().put("add",add.size()).put("remove",remove.size()).put("reorder",moves));
    }
    /** Executes a ready plan but never saves the candidate base or local data. */
    public static JSONObject apply(PCloudCollections client,JSONObject plan,boolean acknowledgePruning) throws Exception {
        return apply(client,plan,acknowledgePruning,()->true);
    }
    public static JSONObject apply(PCloudCollections client,JSONObject plan,boolean acknowledgePruning,java.util.function.BooleanSupplier guard) throws Exception {
        if(guard==null||!guard.getAsBoolean())throw invalid("Synchronisation annulée avant toute modification.");
        if(!acknowledgePruning||!Boolean.TRUE.equals(plan.get("ready"))||id(plan.get("account_userid"))!=client.account().userid)throw invalid("Plan de synchronisation pCloud non confirmé.");
        long collection=id(plan.get("collection_id"));List<Long> before=ids(plan.getJSONArray("remote_before")),target=ids(plan.getJSONArray("remote_target"));
        JSONObject expectedOps=operations(before,target);if(!canonical(expectedOps.getJSONArray("operations")).equals(canonical(plan.getJSONArray("operations"))))throw invalid("Opérations du plan pCloud incohérentes.");
        client.indexMusic();JSONObject remote=client.readCollection(collection,true);List<Long> current=ids(remote.getJSONArray("fileids"));if(!current.equals(before))throw invalid("La liste pCloud a changé depuis la préparation.");
        JSONArray steps=plan.getJSONArray("operations");for(int i=0;i<steps.length();i++){
            if(!guard.getAsBoolean())throw invalid("Synchronisation annulée ; vérifier l’état distant avant de reprendre.");
            JSONObject step=steps.getJSONObject(i);String action=step.getString("action");
            if("link".equals(action)||"unlink".equals(action)){
                List<Long> values=ids(step.getJSONArray("fileids"));for(int start=0;start<values.size();start+=PCloudCollections.MAX_BATCH){List<Long> batch=new ArrayList<>(values.subList(start,Math.min(start+PCloudCollections.MAX_BATCH,values.size())));
                    remote="link".equals(action)?client.linkFiles(collection,batch,true,current):client.unlinkFiles(collection,batch,true,current,target.isEmpty());current=ids(remote.getJSONArray("fileids"));}
            }else if("move".equals(action)){remote=client.moveFile(collection,id(step.get("fileid")),step.getInt("position"),true,current);current=ids(remote.getJSONArray("fileids"));}
            else throw invalid("Opération du plan pCloud refusée.");
        }
        client.indexMusic();remote=client.readCollection(collection,true);if(!ids(remote.getJSONArray("fileids")).equals(target))throw new PCloudCollections.PartialException();
        return new JSONObject().put("local_playlist",copy(plan.getJSONObject("local_playlist"))).put("proposed_base",copy(plan.getJSONObject("proposed_base"))).put("remote_after",remote);
    }
    static String canonical(Object value) throws Exception {
        if(value instanceof JSONObject){JSONObject object=(JSONObject)value;TreeSet<String> keys=new TreeSet<>();Iterator<String> iterator=object.keys();while(iterator.hasNext())keys.add(iterator.next());StringBuilder out=new StringBuilder("{");for(String key:keys){if(out.length()>1)out.append(',');out.append(JSONObject.quote(key)).append(':').append(canonical(object.get(key)));}return out.append('}').toString();}
        if(value instanceof JSONArray){JSONArray array=(JSONArray)value;StringBuilder out=new StringBuilder("[");for(int i=0;i<array.length();i++){if(i>0)out.append(',');out.append(canonical(array.get(i)));}return out.append(']').toString();}
        return value instanceof String?JSONObject.quote((String)value):String.valueOf(value);
    }
}
