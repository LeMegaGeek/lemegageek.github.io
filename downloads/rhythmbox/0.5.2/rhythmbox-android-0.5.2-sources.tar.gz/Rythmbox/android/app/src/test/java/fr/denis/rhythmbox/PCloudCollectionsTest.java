package fr.denis.rhythmbox;

import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Executable account-boundary and reconciliation tests, without Android,
 * network, browser sessions, a real keyring or user media. */
public final class PCloudCollectionsTest {
    interface Check {void run() throws Exception;}
    static int checks=0;
    static void yes(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
    static void reject(Check check,String label) throws Exception {checks++;try{check.run();}catch(Exception expected){return;}throw new AssertionError("Accepted: "+label);}
    static JSONObject copyJson(JSONObject object) throws Exception{return new JSONObject(object.toString());}
    static PCloudAccount account(long folder){return new PCloudAccount("fixture-bearer","music@example.test","eu","fixture-client",7,folder);}
    static final class HttpFixture extends java.net.HttpURLConnection {
        final java.io.ByteArrayOutputStream body=new java.io.ByteArrayOutputStream();
        HttpFixture(java.net.URL url){super(url);}
        public void disconnect(){}public boolean usingProxy(){return false;}public void connect(){}
        public java.io.OutputStream getOutputStream(){return body;}
        public java.io.InputStream getInputStream(){return new java.io.ByteArrayInputStream("{\"result\":0}".getBytes(StandardCharsets.UTF_8));}
        public int getResponseCode(){return 200;}
        public long getContentLengthLong(){return 12;}
    }
    static Set<Long> selected(){return new HashSet<>(Collections.singletonList(20L));}
    static List<Long> list(long...values){List<Long> out=new ArrayList<>();for(long value:values)out.add(value);return out;}
    static List<Long> ids(JSONObject value) throws Exception{return PCloudCollections.ids(value.getJSONArray("fileids"));}
    static JSONObject file(long id,long parent,String name) throws Exception{return new JSONObject().put("fileid",id).put("parentfolderid",parent).put("ismine",true).put("isfolder",false).put("name",name).put("size",100).put("title",name).put("artist","Fixture").put("album","Fixture");}
    static final class Fake implements PCloudCollections.Transport {
        final Map<Long,JSONObject> files=new LinkedHashMap<>();final List<Long> members=new ArrayList<>();final List<String> calls=new ArrayList<>();
        final List<Map<String,String>> parameters=new ArrayList<>();
        boolean wrongAccount=false,system=false,foreign=false,incomplete=false,duplicatePosition=false,badItem=false,race=false,badHost=false,rootOwned=true,ancestorMoved=false,badJson=false;
        int mutations=0;
        Fake() throws Exception {files.put(101L,file(101,10,"A.mp3"));files.put(102L,file(102,10,"B.flac"));files.put(103L,file(103,11,"C.m4v"));members.add(101L);}
        JSONObject folder(long id) throws Exception {
            JSONObject value=new JSONObject().put("folderid",id).put("isfolder",true).put("ismine",rootOwned).put("name",id==10?"My Music":"Album").put("contents",new JSONArray());
            if(id==11)value.put("parentfolderid",10);JSONArray children=value.getJSONArray("contents");
            for(JSONObject row:files.values())if(row.getLong("parentfolderid")==id)children.put(copyJson(row));
            if(id==10&&!ancestorMoved)children.put(folder(11));return value;
        }
        JSONObject collection(long id,String name) throws Exception {
            JSONArray contents=new JSONArray();int position=0;for(long fid:members){JSONObject item=copyJson(files.get(fid));item.put("position",duplicatePosition?1:++position);contents.put(item);}
            return new JSONObject().put("id",id).put("name",name).put("ismine",!foreign).put("system",system).put("type","audio").put("items",members.size()+(incomplete?1:0)).put("contents",contents);
        }
        public byte[] request(String host,String method,Map<String,String> params,String token) throws Exception {
            if(!"eapi.pcloud.com".equals(host)||!"fixture-bearer".equals(token))throw new AssertionError("Wrong API identity");
            calls.add(method);parameters.add(new LinkedHashMap<>(params));if(params.containsKey("access_token")||params.containsKey("auth"))throw new AssertionError("Token in parameters");
            JSONObject response=new JSONObject().put("result",0);
            if(badJson)return "{\"result\":\"0\"}".getBytes(StandardCharsets.UTF_8);
            if(method.equals("userinfo"))response.put("userid",7).put("email",wrongAccount?"other@example.test":"music@example.test");
            else if(method.equals("listfolder")){
                long id=Long.parseLong(params.get("folderid"));
                if("1".equals(params.get("nofiles")))response.put("metadata",new JSONObject().put("folderid",id).put("isfolder",true).put("ismine",true).put("name","/").put("contents",new JSONArray().put(new JSONObject().put("folderid",10).put("parentfolderid",id).put("isfolder",true).put("ismine",true).put("name","My Music"))));
                else{if(id!=10||!"1".equals(params.get("recursive")))throw new AssertionError("Broad root listing");response.put("metadata",folder(10));}
            }else if(method.equals("collection_details"))response.put("collection",collection(Long.parseLong(params.get("collectionid")),"Mon top"));
            else if(method.equals("collection_list"))response.put("collections",new JSONArray().put(collection(20,"Mon top")).put(new JSONObject().put("id",21).put("name","Système").put("ismine",true).put("system",true).put("type","audio").put("items",1)).put(new JSONObject().put("id",22).put("name","Partagée").put("ismine",false).put("system",false).put("type","audio").put("items",1)));
            else if(method.equals("collection_create")){mutations++;response.put("collection",new JSONArray().put(new JSONObject().put("id",30).put("name",params.get("name")).put("ismine",true).put("system",false).put("type","audio").put("items",0).put("contents",new JSONArray())));}
            else if(method.equals("collection_linkfiles")){
                mutations++;JSONArray links=new JSONArray();for(String value:params.get("fileids").split(",")){long fid=Long.parseLong(value);members.add(fid);links.put(new JSONObject().put("fileid",value).put("result",badItem?2003:0).put("metadata",copyJson(files.get(fid))));}
                response.put("linkresult",links);if(race)files.get(102L).put("parentfolderid",99);
            }else if(method.equals("collection_unlinkfiles")){mutations++;for(String value:params.get("fileids").split(","))members.remove(Long.valueOf(value));}
            else if(method.equals("collection_move")){
                mutations++;long fid=Long.parseLong(params.get("fileid"));int from=Integer.parseInt(params.get("item"))-1;if(members.get(from)!=fid)throw new AssertionError("Bad source position");members.remove(from);members.add(Integer.parseInt(params.get("position"))-1,fid);
            }else if(method.equals("getfilelink")){response.put("hosts",new JSONArray().put(badHost?"evil.example":"c123.pcloud.com")).put("path","/opaque/original?download=1");}
            else if(method.equals("checksumfile"))response.put("metadata",copyJson(files.get(Long.parseLong(params.get("fileid"))))).put("sha1",String.join("",Collections.nCopies(40,"a")));
            else throw new AssertionError("Forbidden API: "+method);
            return response.toString().getBytes(StandardCharsets.UTF_8);
        }
    }
    static PCloudCollections client(Fake fake) throws Exception {PCloudCollections c=new PCloudCollections(account(10),selected(),new HashSet<>(Collections.singletonList("Test")),fake);c.verifyAccount();c.indexMusic();return c;}
    static JSONObject local(Map<Long,JSONObject> files,long...ids) throws Exception {JSONArray tracks=new JSONArray();for(long fid:ids)tracks.put(PCloudCollections.track(files.get(fid),7));return new JSONObject().put("id",PCloudNativeSync.playlistId(7,20)).put("name","Mon top").put("tracks",tracks);}
    static JSONObject binding() throws Exception{return new JSONObject().put("account_userid",7).put("collection_id",20).put("playlist_id",PCloudNativeSync.playlistId(7,20));}
    static JSONObject plan(JSONObject base,JSONObject local,JSONObject remote,JSONObject index) throws Exception{return PCloudNativeSync.plan(binding(),base,local,remote,index,Collections.emptySet(),Collections.emptySet(),Collections.emptySet(),Collections.emptySet());}
    static Set<String> paths(Map<Long,JSONObject> files) throws Exception {Set<String> out=new HashSet<>();for(JSONObject row:files.values())out.add(row.getString("media_path"));return out;}
    public static void main(String[] ignored) throws Exception {
        Fake f=new Fake();PCloudCollections unverified=new PCloudCollections(account(10),selected(),Collections.emptySet(),f);
        reject(()->unverified.indexMusic(),"unverified music account");yes(f.calls.isEmpty(),"no request before identity");
        f.wrongAccount=true;reject(()->unverified.verifyAccount(),"wrong account");yes(f.calls.equals(Collections.singletonList("userinfo")),"wrong account never reaches files");
        Fake pickerFake=new Fake();PCloudCollections picker=new PCloudCollections(account(0),selected(),Collections.emptySet(),pickerFake);picker.verifyAccount();
        reject(()->picker.indexMusic(),"global root cannot be music");reject(()->picker.listFolders(0,false),"implicit folder discovery");JSONArray choices=picker.listMusicFolders(0);yes(choices.length()==1&&choices.getJSONObject(0).getLong("folderid")==10,"explicit folder picker");yes(pickerFake.parameters.get(1).equals(new LinkedHashMap<String,String>(){{put("folderid","0");put("nofiles","1");put("noshares","1");}}),"picker requests folders only");
        Fake a=new Fake();PCloudCollections c=client(a);Map<Long,JSONObject> index=c.indexMusic();yes(index.size()==3,"music/video-audio index");
        reject(()->c.browseCollections(false),"chooser pruning acknowledgement required");JSONArray browsed=c.browseCollections(true);yes(browsed.length()==1&&browsed.getJSONObject(0).getLong("id")==20,"explicit chooser owned audio only");yes(a.parameters.get(a.parameters.size()-1).equals(Collections.singletonMap("type","1")),"chooser requests no file details");yes(c.allowedCollectionIds().equals(selected()),"chooser does not authorize extra collections");
        reject(()->c.readCollection(20,false),"pruning acknowledgement required");reject(()->c.readCollection(21,true),"unselected collection");yes(ids(c.readCollection(20,true)).equals(list(101)),"ordered native collection");
        a.system=true;reject(()->c.readCollection(20,true),"system collection");a.system=false;a.foreign=true;reject(()->c.readCollection(20,true),"foreign collection");a.foreign=false;
        a.incomplete=true;reject(()->c.readCollection(20,true),"partial collection");a.incomplete=false;a.members.add(102L);a.duplicatePosition=true;reject(()->c.readCollection(20,true),"duplicate positions");a.duplicatePosition=false;a.members.remove(102L);
        reject(()->c.linkFiles(20,list(999),true,list(101)),"outside music ID");reject(()->c.linkFiles(20,list(102),true,list(103)),"stale expected order");yes(a.mutations==0,"rejected requests never mutate");
        a.files.get(102L).put("parentfolderid",99);reject(()->c.linkFiles(20,list(102),true,list(101)),"stale file moved outside root");yes(a.mutations==0,"fresh root check before link");a.files.get(102L).put("parentfolderid",10);
        c.indexMusic();a.ancestorMoved=true;reject(()->c.linkFiles(20,list(103),true,list(101)),"stale ancestor moved outside root");yes(a.mutations==0,"moved ancestor does not leak ID");a.ancestorMoved=false;
        c.indexMusic();yes(ids(c.linkFiles(20,list(102),true,list(101))).equals(list(101,102)),"link verified");yes(ids(c.moveFile(20,102,1,true,list(101,102))).equals(list(102,101)),"reorder verified");
        reject(()->c.unlinkFiles(20,list(102,101),true,list(102,101),false),"implicit collection clear");yes(ids(c.unlinkFiles(20,list(102),true,list(102,101),false)).equals(list(101)),"targeted unlink");
        a.badItem=true;checks++;try{c.linkFiles(20,list(102),true,list(101));throw new AssertionError("Per-item failure accepted");}catch(PCloudCollections.PartialException expected){yes(expected.partial,"partial mutation classified");}a.badItem=false;
        Fake race=new Fake();PCloudCollections raceClient=client(race);race.race=true;checks++;try{raceClient.linkFiles(20,list(102),true,list(101));throw new AssertionError("Race accepted");}catch(PCloudCollections.PartialException expected){yes(race.members.equals(list(101,102)),"uncertain write preserved without destructive rollback");}
        Fake corrupt=new Fake();PCloudCollections malformed=client(corrupt);corrupt.files.get(102L).put("name","../outside.mp3");reject(()->malformed.indexMusic(),"traversal in metadata");corrupt.files.get(102L).put("name","B.flac").put("size",2.5);reject(()->malformed.indexMusic(),"fractional size");
        Fake owned=new Fake();PCloudCollections creator=client(owned);yes(creator.createCollection("Test").getLong("id")==30,"selected collection name creation");reject(()->creator.createCollection("Other"),"unselected creation name");owned.rootOwned=false;reject(()->creator.createCollection("Test"),"root ownership changed before creation");
        Fake media=new Fake();PCloudCollections player=client(media);JSONObject stale=new JSONObject().put("id","old").put("media_path","A.mp3").put("pcloud_fileid",999);
        yes(player.fileIdForTrack(stale)==101,"literal path rebinds old file IDs");reject(()->player.fileIdForTrack(new JSONObject().put("pcloud_fileid",101)),"unbound account ID cannot play");reject(()->player.fileIdForTrack(new JSONObject().put("pcloud_account_userid",8).put("media_path","A.mp3")),"foreign account marker");
        yes(player.mediaUrl(101).toString().equals("https://c123.pcloud.com/opaque/original?download=1"),"original music link only");yes(!media.calls.contains("getaudiolink"),"no lossy audio conversion");media.badHost=true;reject(()->player.mediaUrl(101),"untrusted CDN");
        JSONObject cached=file(101,10,"A.mp3").put("hash","v1");String oldCache=PCloudCollections.cacheName(cached,7);cached.put("hash","v2");yes(!oldCache.equals(PCloudCollections.cacheName(cached,7)),"same ID modified media has distinct cache version");
        for(String host:new String[]{"evil.example","pcloud.com.evil.test","localhost","127.0.0.1","c1.pcloud.com:443","c1.pcloud.com@evil.test"})reject(()->PCloudCollections.validatedMediaUrl(host,"/audio"),"invalid CDN host");
        for(String path:new String[]{"//evil.test/a","/x#fragment","/x\\escape","/x\r\ny"})reject(()->PCloudCollections.validatedMediaUrl("c1.pcloud.com",path),"invalid CDN path");
        PCloudCollections.HttpTransport http=new PCloudCollections.HttpTransport();reject(()->http.request("evil.test","userinfo",Collections.emptyMap(),"secret"),"API host blocks before network");reject(()->http.request("api.pcloud.com","deletefile",Collections.emptyMap(),"secret"),"file deletion endpoint forbidden");
        final HttpFixture[] transportCapture={null};
        PCloudCollections.HttpTransport directHttp=new PCloudCollections.HttpTransport("direct",url->{transportCapture[0]=new HttpFixture(url);return transportCapture[0];});
        directHttp.request("eapi.pcloud.com","getfilelink",Collections.singletonMap("fileid","101"),"direct+token");
        HttpFixture directRequest=transportCapture[0];String directBody=new String(directRequest.body.toByteArray(),StandardCharsets.UTF_8);
        yes(directRequest.getURL().toString().equals("https://eapi.pcloud.com/getfilelink")&&directRequest.getRequestMethod().equals("POST"),"direct media authorization uses HTTPS POST without token in URL");
        yes(directBody.equals("auth=direct%2Btoken&fileid=101")&&directRequest.getRequestProperty("Authorization")==null,"direct token uses auth POST parameter even for original audio links");
        yes(!directRequest.getInstanceFollowRedirects()&&!directRequest.getUseCaches(),"direct media API blocks redirects and caches");
        PCloudCollections.HttpTransport oauthHttp=new PCloudCollections.HttpTransport("oauth",url->{transportCapture[0]=new HttpFixture(url);return transportCapture[0];});
        oauthHttp.request("eapi.pcloud.com","collection_details",Collections.singletonMap("collectionid","20"),"oauth-token");
        yes("Bearer oauth-token".equals(transportCapture[0].getRequestProperty("Authorization"))&&!new String(transportCapture[0].body.toByteArray(),StandardCharsets.UTF_8).contains("oauth-token"),"OAuth keeps Bearer and cannot become direct auth");
        reject(()->directHttp.request("eapi.pcloud.com","userinfo",Collections.singletonMap("auth","foreign-token"),"direct-token"),"supplied auth parameters cannot override chosen direct account");
        reject(()->new PCloudAccount("token","music@example.test","eu","fake-client",7,10,"direct"),"direct account refuses fabricated OAuth client ID");
        Fake p=new Fake();PCloudCollections pc=client(p);Map<Long,JSONObject> files=pc.indexMusic();JSONObject idx=PCloudNativeSync.mediaIndex(account(10),files,paths(files)),remote=pc.readCollection(20,true),one=local(files,101);
        JSONObject unchanged=plan(null,one,remote,idx);yes(unchanged.getBoolean("ready")&&unchanged.getString("direction").equals("unchanged"),"matching first synchronization");JSONObject base=unchanged.getJSONObject("proposed_base");String baseOriginal=base.toString();
        JSONObject pull=plan(null,local(files),remote,idx);yes(pull.getBoolean("ready")&&pull.getString("direction").equals("pull")&&pull.getJSONObject("local_playlist").getJSONArray("tracks").length()==1,"first import");
        JSONObject conflict=plan(null,local(files,102),remote,idx);yes(!conflict.getBoolean("ready")&&conflict.getString("direction").equals("conflict")&&conflict.getJSONArray("operations").length()==0,"first divergent contents preserved");
        JSONObject push=plan(base,local(files,101,102),remote,idx);yes(push.getBoolean("ready")&&push.getString("direction").equals("push"),"one-sided local edit");JSONObject applied=PCloudNativeSync.apply(pc,push,true);yes(p.members.equals(list(101,102))&&applied.has("proposed_base"),"guarded plan executes");yes(base.toString().equals(baseOriginal),"base is never mutated/persisted implicitly");
        JSONObject after=pc.readCollection(20,true);JSONObject newBase=applied.getJSONObject("proposed_base");p.members.clear();p.members.addAll(list(102,101));JSONObject reorderedRemote=pc.readCollection(20,true);
        JSONObject remotePull=plan(newBase,local(files,101,102),reorderedRemote,idx);yes(remotePull.getString("direction").equals("pull")&&remotePull.getJSONObject("local_playlist").getJSONArray("tracks").getJSONObject(0).getLong("pcloud_fileid")==102,"remote reorder pulls");
        JSONObject both=plan(newBase,local(files,101,103),reorderedRemote,idx);JSONObject retry=plan(newBase,local(files,101,103),reorderedRemote,idx);yes(!both.getBoolean("ready")&&both.getJSONArray("conflicts").getJSONObject(0).getString("id").equals(retry.getJSONArray("conflicts").getJSONObject(0).getString("id")),"stable concurrent conflict copy");
        JSONObject repeated=plan(null,local(files,101,101),remote,idx);yes(!repeated.getBoolean("ready")&&repeated.getJSONArray("issues").toString().contains("unrepresentable_duplicates"),"duplicates never silently collapse");
        JSONObject missing=copyJson(idx);missing.getJSONArray("files").getJSONObject(0).put("available",false);yes(!plan(base,one,remote,missing).getBoolean("ready"),"unavailable media blocks writes");
        JSONObject oldIDs=local(files,101);oldIDs.getJSONArray("tracks").getJSONObject(0).put("pcloud_fileid",999);yes(plan(null,oldIDs,remote,idx).getJSONObject("local_playlist").getJSONArray("tracks").getJSONObject(0).getLong("pcloud_fileid")==101,"fresh mapping replaces stale account file ID");
        JSONObject unknown=local(files);unknown.getJSONArray("tracks").put(new JSONObject().put("id","unknown").put("title","A.mp3").put("artist","Fixture").put("album","Fixture").put("pcloud_fileid",101));yes(!plan(null,unknown,remote,idx).getBoolean("ready"),"no match by old ID or tags");
        reject(()->plan(base,one,remote,copyJson(idx).put("account_userid",8)),"index bound to another account");reject(()->plan(base,one,copyJson(remote).put("account_userid",8),idx),"remote bound to another account");
        JSONObject partial=copyJson(remote).put("complete",false);yes(!plan(base,one,partial,idx).getBoolean("ready"),"partial reads never mutate");
        JSONObject cloudOnly=PCloudNativeSync.mediaIndex(account(10),files,Collections.emptySet());JSONObject protectedPlan=plan(base,local(files),remote,cloudOnly);yes(protectedPlan.getJSONArray("remote_target").getLong(0)==101,"missing cloud-only projection protected");
        String trackId=one.getJSONArray("tracks").getJSONObject(0).getString("id");JSONObject clear=PCloudNativeSync.plan(binding(),base,local(files),remote,cloudOnly,Collections.emptySet(),Collections.emptySet(),Collections.emptySet(),new HashSet<>(Collections.singletonList(trackId)));
        yes(clear.getBoolean("ready")&&clear.getJSONArray("remote_target").length()==0,"intentional cloud-only removal");
        JSONObject hidden=PCloudNativeSync.plan(binding(),base,one,remote,idx,new HashSet<>(Collections.singletonList(trackId)),Collections.emptySet(),Collections.emptySet(),Collections.emptySet());yes(hidden.getJSONArray("remote_target").length()==0,"quarantine removes references only");
        JSONObject blockedOp=copyJson(push);blockedOp.getJSONArray("operations").put(new JSONObject().put("action","deletefile").put("fileid",101));int beforeCalls=p.calls.size();reject(()->PCloudNativeSync.apply(pc,blockedOp,true),"tampered operation plan");yes(p.calls.size()==beforeCalls,"tampered plan rejected before network");
        Fake empty=new Fake();PCloudCollections emptyClient=client(empty);PCloudNativeSync.apply(emptyClient,clear,true);yes(empty.members.isEmpty()&&empty.files.size()==3,"explicit clear leaves all audio files intact");
        System.out.println("PASS : "+checks+" dedicated pCloud account/collection/reconciliation assertions; no live network or user media");
    }
}
