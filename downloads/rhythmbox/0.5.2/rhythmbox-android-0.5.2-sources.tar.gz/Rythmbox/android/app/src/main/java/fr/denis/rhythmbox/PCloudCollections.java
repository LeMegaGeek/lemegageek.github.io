package fr.denis.rhythmbox;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Account-bound access to selected music and native audio collections.
 *
 * This client never consults the installed pCloud application's account. The
 * OAuth token goes only to the exact regional API host, never a media server.
 * Folder discovery is a separate, explicit folder-picker operation with
 * nofiles=1; background work only visits the selected non-root music subtree.
 *
 * pCloud collection_details may itself prune unavailable references. Existing
 * collection reads therefore require an explicit acknowledgement. There is no
 * conditional/transactional remote update: fresh scope/order checks and a
 * post-write read detect observable races, but cannot prevent an intervening
 * server-side move. PartialException must not be blindly retried.
 */
public final class PCloudCollections {
    public static final int MAX_RESPONSE=32*1024*1024,MAX_NODES=50000,MAX_BATCH=1000;
    private static final Set<String> METHODS=new HashSet<>(Arrays.asList("userinfo","listfolder","checksumfile","getfilelink","collection_list","collection_details","collection_create","collection_linkfiles","collection_unlinkfiles","collection_move"));
    public static class CloudException extends Exception {public CloudException(String message){super(message);}}
    public static final class PartialException extends CloudException {public final boolean partial=true;public PartialException(){super("Modification pCloud partielle ou non confirmée : actualise les listes avant de réessayer.");}}
    public interface Transport {byte[] request(String host,String method,Map<String,String> parameters,String token) throws Exception;}
    /** Bearer headers are documented at docs.pcloud.com/methods/oauth_2.0/. */
    public static final class HttpTransport implements Transport {
        interface ConnectionFactory {HttpURLConnection open(URL url) throws Exception;}
        private final boolean direct;
        private final ConnectionFactory connections;
        public HttpTransport(){this("oauth");}
        public HttpTransport(String authType){this(authType,url->(HttpURLConnection)url.openConnection());}
        HttpTransport(String authType,ConnectionFactory connections){
            if(!"direct".equals(authType)&&!"oauth".equals(authType))throw new IllegalArgumentException("Type d’autorisation pCloud invalide.");
            direct="direct".equals(authType);
            this.connections=connections;
        }
        @Override public byte[] request(String host,String method,Map<String,String> parameters,String token) throws Exception {
            if(!("api.pcloud.com".equals(host)||"eapi.pcloud.com".equals(host))||!METHODS.contains(method))throw failure("Destination pCloud refusée.");
            if(token==null||token.isEmpty()||!token.matches("[\\x21-\\x7e]+")||parameters.containsKey("auth")||parameters.containsKey("access_token")||parameters.containsKey("username")||parameters.containsKey("password"))throw failure("Autorisation pCloud invalide.");
            HttpURLConnection connection=null;
            try{
                connection=connections.open(new URL("https://"+host+"/"+method));
                connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(15000);connection.setReadTimeout(30000);
                connection.setRequestMethod("POST");connection.setDoOutput(true);
                connection.setUseCaches(false);
                if(!direct)connection.setRequestProperty("Authorization","Bearer "+token);
                connection.setRequestProperty("Content-Type","application/x-www-form-urlencoded");connection.setRequestProperty("Accept","application/json");
                StringBuilder form=new StringBuilder();
                if(direct)form.append("auth=").append(URLEncoder.encode(token,"UTF-8"));
                for(Map.Entry<String,String> e:parameters.entrySet()){if(form.length()>0)form.append('&');form.append(URLEncoder.encode(e.getKey(),"UTF-8")).append('=').append(URLEncoder.encode(e.getValue(),"UTF-8"));}
                byte[] body=form.toString().getBytes(StandardCharsets.UTF_8);connection.setFixedLengthStreamingMode(body.length);
                try(java.io.OutputStream out=connection.getOutputStream()){out.write(body);}
                if(connection.getResponseCode()!=200)throw failure("Connexion au compte musical pCloud refusée.");
                if(connection.getContentLengthLong()>MAX_RESPONSE)throw failure("Réponse pCloud trop volumineuse.");
                try(InputStream in=connection.getInputStream()){return bounded(in,MAX_RESPONSE);}
            }catch(CloudException error){throw error;}catch(Exception error){throw failure("Connexion au compte musical pCloud impossible.");}
            finally{if(connection!=null)connection.disconnect();}
        }
    }
    private final PCloudAccount account;
    private final Transport transport;
    private final Set<Long> allowed=new LinkedHashSet<>();
    private final Set<String> createNames=new LinkedHashSet<>();
    private Map<Long,JSONObject> index;
    private String rootPath;
    private boolean verified=false;
    private java.util.function.BooleanSupplier requestGuard=()->true;

    public PCloudCollections(PCloudAccount account,Set<Long> selected,Set<String> newNames) throws CloudException {this(account,selected,newNames,new HttpTransport(account==null?"oauth":account.authType));}
    public PCloudCollections(PCloudAccount account,Set<Long> selected,Set<String> newNames,Transport transport) throws CloudException {
        if(account==null||transport==null)throw failure("Connexion pCloud requise.");
        this.account=account;this.transport=transport;
        if(selected!=null)for(Long value:selected){if(value==null)throw failure("Collection pCloud invalide.");allowed.add(positive(value));}
        if(newNames!=null)for(String value:newNames)createNames.add(name(value));
    }
    public PCloudAccount account(){return account;}
    /** Checked immediately before every API request, including subrequests of
     * a mutation, so a foreground transition can stop a background job. */
    public void setRequestGuard(java.util.function.BooleanSupplier guard){if(guard==null)throw new IllegalArgumentException("Contrôle de synchronisation requis");requestGuard=guard;}
    public Set<Long> allowedCollectionIds(){return Collections.unmodifiableSet(new LinkedHashSet<>(allowed));}
    private static CloudException failure(String value){return new CloudException(value);}
    static long integer(Object value,boolean zero) throws CloudException {
        if(!(value instanceof Integer||value instanceof Long))throw failure("Identifiant ou nombre pCloud invalide.");
        long result=((Number)value).longValue();if(result<0||(!zero&&result==0))throw failure("Identifiant ou nombre pCloud invalide.");return result;
    }
    private static long positive(long value) throws CloudException {if(value<=0)throw failure("Identifiant pCloud invalide.");return value;}
    private static String name(String value) throws CloudException {
        if(value==null||value.trim().isEmpty()||value.codePointCount(0,value.length())>1024)throw failure("Nom de collection invalide.");
        for(int i=0;i<value.length();i++)if(value.charAt(i)<32||value.charAt(i)==127)throw failure("Nom de collection invalide.");return value.trim();
    }
    private static boolean bool(JSONObject value,String key) throws Exception {Object raw=value.get(key);if(!(raw instanceof Boolean))throw failure("Métadonnées pCloud incomplètes.");return (Boolean)raw;}
    private static Map<String,String> parameters(String... values){Map<String,String> out=new LinkedHashMap<>();for(int i=0;i<values.length;i+=2)out.put(values[i],values[i+1]);return out;}
    private String host(){return "eu".equals(account.region)?"eapi.pcloud.com":"api.pcloud.com";}
    private void requireAccount() throws CloudException {if(!verified)throw failure("Vérifie le compte musical avant tout accès.");}
    private void requireMusic() throws CloudException {requireAccount();if(account.musicFolderId<=0)throw failure("Choisis un dossier musical distinct de la racine pCloud.");}
    private void requireIndex() throws CloudException {requireMusic();if(index==null)throw failure("Actualise le dossier musical avant les listes.");}
    private long selected(long id) throws CloudException {positive(id);if(!allowed.contains(id))throw failure("Collection hors de la sélection autorisée.");return id;}
    private JSONObject api(String method,Map<String,String> parameters) throws CloudException {
        if(!requestGuard.getAsBoolean())throw failure("Synchronisation interrompue par une modification locale.");
        if(!METHODS.contains(method))throw failure("Méthode pCloud refusée.");
        if(!"userinfo".equals(method))requireAccount();
        try{
            byte[] body=transport.request(host(),method,Collections.unmodifiableMap(parameters),account.token);
            if(body==null||body.length>MAX_RESPONSE)throw failure("Réponse pCloud invalide ou trop volumineuse.");
            JSONObject result=new JSONObject(new String(body,StandardCharsets.UTF_8));
            long code=integer(result.get("result"),true);if(code!=0)throw failure("pCloud a refusé l’opération (code "+code+").");return result;
        }catch(CloudException error){throw error;}catch(Exception error){throw failure("Réponse du compte musical pCloud illisible.");}
    }
    public JSONObject verifyAccount() throws CloudException {
        verified=false;index=null;rootPath=null;
        try{
            JSONObject info=api("userinfo",parameters());long id=integer(info.get("userid"),false);
            Object raw=info.get("email");if(!(raw instanceof String)||!((String)raw).equalsIgnoreCase(account.email)||id!=account.userid)throw failure("Le compte pCloud ne correspond pas au compte musical attendu.");
            verified=true;return new JSONObject().put("userid",id).put("email",account.email);
        }catch(CloudException error){throw error;}catch(Exception error){throw failure("Vérification du compte musical impossible.");}
    }
    /** Call only in response to the user opening/browsing the folder picker. */
    public JSONArray listMusicFolders(long folderId) throws CloudException {return listFolders(folderId,true);}
    /** The explicit flag protects callers that expose generic browsing helpers. */
    public JSONArray listFolders(long folderId,boolean explicitFolderPicker) throws CloudException {
        requireAccount();if(!explicitFolderPicker||folderId<0)throw failure("Le choix explicite d’un dossier pCloud est requis.");
        try{
            JSONObject root=api("listfolder",parameters("folderid",Long.toString(folderId),"nofiles","1","noshares","1")).getJSONObject("metadata");
            if(!bool(root,"isfolder")||!bool(root,"ismine")||integer(root.get("folderid"),true)!=folderId)throw failure("Dossier pCloud inattendu.");
            JSONArray contents=root.getJSONArray("contents"),out=new JSONArray();if(contents.length()>MAX_NODES)throw failure("Trop de dossiers pCloud.");
            Set<Long> seen=new HashSet<>();for(int i=0;i<contents.length();i++){
                JSONObject child=contents.getJSONObject(i);
                if(!bool(child,"isfolder")||!bool(child,"ismine")||integer(child.get("parentfolderid"),true)!=folderId)throw failure("Dossier de sélection hors périmètre.");
                long id=integer(child.get("folderid"),false);if(!seen.add(id))throw failure("Dossier de sélection ambigu.");
                String component=FolderProtocol.mediaPath(child.getString("name"));if(component.indexOf('/')>=0)throw failure("Nom de dossier invalide.");
                out.put(new JSONObject().put("folderid",id).put("name",component).put("parentfolderid",folderId));
            }return out;
        }catch(CloudException error){throw error;}catch(Exception error){throw failure("Liste des dossiers pCloud invalide.");}
    }
    public Map<Long,JSONObject> indexMusic() throws CloudException {
        requireMusic();index=null;rootPath=null;
        try{
            JSONObject root=api("listfolder",parameters("folderid",Long.toString(account.musicFolderId),"recursive","1","noshares","1")).getJSONObject("metadata");
            Map<Long,JSONObject> found=new LinkedHashMap<>();Set<Long> folderIds=new HashSet<>(),fileIds=new HashSet<>();Set<String> paths=new HashSet<>();int[] count={0};
            walk(root,null,"",0,found,folderIds,fileIds,paths,count);
            index=found;return copyIndex(found);
        }catch(CloudException error){rootPath=null;throw error;}catch(Exception error){rootPath=null;throw failure("Arborescence musicale pCloud invalide.");}
    }
    private void walk(JSONObject node,Long parent,String relative,int depth,Map<Long,JSONObject> found,Set<Long> folderIds,Set<Long> fileIds,Set<String> paths,int[] count) throws Exception {
        if(++count[0]>MAX_NODES||depth>32||!bool(node,"ismine")||(node.has("isdeleted")&&bool(node,"isdeleted")))throw failure("Arbre musical hors périmètre ou trop volumineux.");
        if(parent!=null&&integer(node.get("parentfolderid"),false)!=parent)throw failure("Un élément a quitté son dossier musical.");
        boolean folder=bool(node,"isfolder");
        if(parent!=null){String component=FolderProtocol.mediaPath(node.getString("name"));if(component.indexOf('/')>=0)throw failure("Nom musical invalide.");relative=FolderProtocol.mediaPath(relative.isEmpty()?component:relative+"/"+component);if(!paths.add(relative))throw failure("Chemin musical ambigu.");}
        if(node.has("path")){
            String path=node.getString("path");if(!path.startsWith("/"))throw failure("Chemin de serveur invalide.");FolderProtocol.mediaPath(path.substring(1));
            if(parent==null){String component=FolderProtocol.mediaPath(node.getString("name"));if(component.indexOf('/')>=0||!path.substring(path.lastIndexOf('/')+1).equals(component))throw failure("Racine musicale incohérente.");rootPath=path;}
            else if(rootPath==null||!path.equals(rootPath+"/"+relative))throw failure("Chemin de serveur hors du dossier musical.");
        }
        if(folder){
            long id=integer(node.get("folderid"),false);if(!folderIds.add(id)||(parent==null&&id!=account.musicFolderId))throw failure("Racine ou dossier musical ambigu.");
            JSONArray children=node.getJSONArray("contents");for(int i=0;i<children.length();i++)walk(children.getJSONObject(i),id,relative,depth+1,found,folderIds,fileIds,paths,count);
        }else{
            if(parent==null||node.has("contents"))throw failure("Fichier musical hors de la racine choisie.");
            long id=integer(node.get("fileid"),false);if(!fileIds.add(id))throw failure("Identifiant musical ambigu.");long size=integer(node.get("size"),true);
            if(!FolderProtocol.isSupportedMedia(node.getString("name"),null))return;
            JSONObject row=new JSONObject().put("fileid",id).put("media_path",relative).put("name",node.getString("name")).put("size",size).put("parentfolderid",parent);
            for(String key:new String[]{"title","artist","album","contenttype"})if(node.opt(key) instanceof String)row.put(key,node.getString(key));found.put(id,row);
            for(String key:new String[]{"hash","modified"})if(node.has(key)){Object raw=node.get(key);String value=String.valueOf(raw);if((raw instanceof String||raw instanceof Integer||raw instanceof Long)&&value.length()<=128&&value.indexOf(0)<0)row.put(key,value);}
        }
    }
    private static Map<Long,JSONObject> copyIndex(Map<Long,JSONObject> input) throws Exception {Map<Long,JSONObject> out=new LinkedHashMap<>();for(Map.Entry<Long,JSONObject> e:input.entrySet())out.put(e.getKey(),new JSONObject(e.getValue().toString()));return out;}
    public JSONArray importedMusic() throws CloudException {
        Map<Long,JSONObject> files=indexMusic();JSONArray result=new JSONArray();
        try{for(Map.Entry<Long,JSONObject> entry:files.entrySet())result.put(track(entry.getValue(),account.userid));return result;}catch(Exception error){throw failure("Métadonnées musicales invalides.");}
    }
    public static JSONObject track(JSONObject row,long userid) throws Exception {
        long fileid=integer(row.get("fileid"),false);positive(userid);String path=FolderProtocol.mediaPath(row.getString("media_path"));
        String id=UUID.nameUUIDFromBytes(("pcloud-account:"+userid+":"+path).getBytes(StandardCharsets.UTF_8)).toString();
        return new JSONObject().put("id",id).put("title",row.optString("title",row.optString("name","Sans titre"))).put("artist",row.optString("artist","")).put("album",row.optString("album","")).put("media_path",path).put("pcloud_fileid",fileid).put("pcloud_account_userid",userid);
    }
    public static String collectionPlaylistId(long userid,long collectionId) throws Exception {positive(userid);positive(collectionId);return "pcloud:"+userid+":collection:"+collectionId;}
    private List<Long> fileIds(List<Long> values) throws CloudException {
        requireIndex();if(values==null||values.isEmpty()||values.size()>MAX_BATCH)throw failure("Sélection musicale vide ou trop volumineuse.");Set<Long> seen=new HashSet<>();List<Long> out=new ArrayList<>();
        for(Long id:values){if(id==null||!seen.add(positive(id))||!index.containsKey(id))throw failure("Fichier hors du dossier musical ou présent deux fois.");out.add(id);}return out;
    }
    private List<Long> freshIds(List<Long> values) throws CloudException {List<Long> copy=fileIds(values);indexMusic();return fileIds(copy);}
    public JSONObject checksumFile(long fileId) throws CloudException {
        freshIds(Collections.singletonList(fileId));JSONObject result=api("checksumfile",parameters("fileid",Long.toString(fileId)));
        try{
            JSONObject metadata=result.getJSONObject("metadata"),known=index.get(fileId),sums=new JSONObject();
            if(integer(metadata.get("fileid"),false)!=fileId||integer(metadata.get("parentfolderid"),false)!=known.getLong("parentfolderid")||integer(metadata.get("size"),true)!=known.getLong("size"))throw failure("Le fichier musical a changé.");
            for(String key:new String[]{"sha1","sha256","md5"})if(result.has(key)){Object raw=result.get(key);int size="sha1".equals(key)?40:"sha256".equals(key)?64:32;if(!(raw instanceof String)||!((String)raw).matches("[0-9A-Fa-f]{"+size+"}"))throw failure("Empreinte pCloud invalide.");sums.put(key,((String)raw).toLowerCase(Locale.ROOT));}
            if(!sums.has("sha1"))throw failure("Empreinte pCloud absente.");return sums;
        }catch(CloudException error){throw error;}catch(Exception error){throw failure("Empreinte musicale invalide.");}
    }
    private JSONObject header(JSONObject response,Long expected) throws Exception {
        Object raw=response.get("collection");if(raw instanceof JSONArray&&((JSONArray)raw).length()==1)raw=((JSONArray)raw).get(0);
        if(!(raw instanceof JSONObject))throw failure("Collection pCloud invalide.");JSONObject value=(JSONObject)raw;long id=integer(value.get("id"),false);
        if((expected!=null&&id!=expected)||!bool(value,"ismine")||bool(value,"system")||!"audio".equals(value.get("type")))throw failure("Seule une liste audio personnelle non système est autorisée.");name(value.getString("name"));return value;
    }
    public JSONObject readCollection(long collectionId,boolean acknowledgePruning) throws CloudException {
        requireIndex();selected(collectionId);if(!acknowledgePruning)throw failure("Confirme la lecture pCloud qui peut retirer des références indisponibles.");
        try{
            JSONObject value=header(api("collection_details",parameters("collectionid",Long.toString(collectionId),"page","0")),collectionId);
            JSONArray contents=value.getJSONArray("contents");long total=integer(value.get("items"),true);if(total!=contents.length()||total>MAX_NODES)throw failure("Liste pCloud incomplète.");
            List<long[]> ordered=new ArrayList<>();Set<Long> ids=new HashSet<>(),positions=new HashSet<>();
            for(int i=0;i<contents.length();i++){
                JSONObject item=contents.getJSONObject(i);long id=integer(item.get("fileid"),false),position=integer(item.get("position"),false);JSONObject known=index.get(id);
                if(known==null||!ids.add(id)||!positions.add(position)||position>total||integer(item.get("parentfolderid"),false)!=known.getLong("parentfolderid"))throw failure("Membre de liste hors du dossier musical ou ambigu.");
                if(item.has("path")&&(rootPath==null||!item.getString("path").equals(rootPath+"/"+known.getString("media_path"))))throw failure("Membre de liste hors du dossier musical.");ordered.add(new long[]{position,id});
            }
            ordered.sort(Comparator.comparingLong(item->item[0]));JSONArray fileids=new JSONArray(),tracks=new JSONArray();for(long[] item:ordered){fileids.put(item[1]);tracks.put(track(index.get(item[1]),account.userid));}
            return new JSONObject().put("account_userid",account.userid).put("id",collectionId).put("name",value.getString("name")).put("fileids",fileids).put("tracks",tracks).put("modified",value.opt("modified")).put("ismine",true).put("system",false).put("type","audio").put("complete",true);
        }catch(CloudException error){throw error;}catch(Exception error){throw failure("Liste pCloud invalide.");}
    }
    /** Explicit playlist-chooser action only. The provider may prune unavailable
     * references while listing; background sync must never call this method. */
    public JSONArray browseCollections(boolean acknowledgePruning) throws CloudException {
        requireMusic();if(!acknowledgePruning)throw failure("Confirme la lecture pCloud qui peut retirer des références indisponibles.");indexMusic();
        try{
            // Omit showfiles altogether: only collection headers are requested.
            JSONArray source=api("collection_list",parameters("type","1")).getJSONArray("collections"),out=new JSONArray();if(source.length()>1000)throw failure("Trop de listes pCloud.");Set<Long> seen=new HashSet<>();
            for(int i=0;i<source.length();i++){JSONObject value=source.getJSONObject(i);if(!Boolean.TRUE.equals(value.opt("ismine"))||!Boolean.FALSE.equals(value.opt("system"))||!"audio".equals(value.opt("type")))continue;
                long cid=integer(value.get("id"),false);if(!seen.add(cid))throw failure("Identifiant de liste pCloud ambigu.");long count=integer(value.get("items"),true);if(count>MAX_NODES)throw failure("Liste pCloud trop volumineuse.");
                out.put(new JSONObject().put("id",cid).put("name",name(value.getString("name"))).put("items",count).put("ismine",true).put("system",false).put("type","audio"));
            }return out;
        }catch(CloudException error){throw error;}catch(Exception error){throw failure("Liste des playlists pCloud invalide.");}
    }
    public JSONObject createCollection(String requestedName) throws CloudException {
        requireIndex();String label=name(requestedName);if(!createNames.contains(label))throw failure("Ce nom de liste n’a pas été sélectionné.");indexMusic();
        try{
            JSONObject value=header(api("collection_create",parameters("name",label,"type","1")),null);long id=integer(value.get("id"),false);
            if(allowed.contains(id)||!label.equals(value.getString("name"))||integer(value.get("items"),true)!=0||value.getJSONArray("contents").length()!=0)throw new PartialException();allowed.add(id);
            return new JSONObject().put("account_userid",account.userid).put("id",id).put("name",label).put("fileids",new JSONArray()).put("modified",value.opt("modified")).put("ismine",true).put("system",false).put("type","audio").put("complete",true);
        }catch(Exception error){throw new PartialException();}
    }
    static List<Long> ids(JSONArray array) throws Exception {if(array.length()>MAX_NODES)throw failure("Liste trop volumineuse.");List<Long> out=new ArrayList<>();Set<Long> seen=new HashSet<>();for(int i=0;i<array.length();i++){long id=integer(array.get(i),false);if(!seen.add(id))throw failure("Les listes pCloud ne permettent pas les répétitions.");out.add(id);}return out;}
    private static String csv(List<Long> values){StringBuilder out=new StringBuilder();for(long id:values){if(out.length()>0)out.append(',');out.append(id);}return out.toString();}
    private JSONObject before(long collectionId,boolean acknowledgePruning,List<Long> expected) throws Exception {JSONObject result=readCollection(collectionId,acknowledgePruning);if(expected!=null&&!ids(result.getJSONArray("fileids")).equals(expected))throw failure("La liste distante a changé ; actualise avant de la modifier.");return result;}
    private JSONObject mutate(String method,Map<String,String> parameters,List<Long> expected,boolean acknowledgePruning) throws PartialException {
        try{
            long collectionId=Long.parseLong(parameters.get("collectionid"));JSONObject response=api(method,parameters);
            if("collection_linkfiles".equals(method)){
                String[] requested=parameters.get("fileids").split(",");JSONArray results=response.getJSONArray("linkresult");if(results.length()!=requested.length)throw failure("Résultats individuels d’ajout absents.");
                for(int i=0;i<requested.length;i++){
                    long id=Long.parseLong(requested[i]);JSONObject item=results.getJSONObject(i);if(integer(item.get("result"),true)!=0)throw failure("Un ajout a échoué.");Object raw=item.get("fileid");long returned=raw instanceof String&&((String)raw).matches("[1-9][0-9]*")?Long.parseLong((String)raw):integer(raw,false);
                    JSONObject metadata=item.getJSONObject("metadata");if(returned!=id||integer(metadata.get("fileid"),false)!=id||integer(metadata.get("parentfolderid"),false)!=index.get(id).getLong("parentfolderid"))throw failure("Ajout individuel incohérent.");
                }
            }
            if(response.has("collection"))header(response,collectionId);indexMusic();JSONObject after=readCollection(collectionId,acknowledgePruning);
            if(!ids(after.getJSONArray("fileids")).equals(expected))throw failure("La liste a changé pendant l’opération.");return after;
        }catch(Exception error){throw new PartialException();}
    }
    public JSONObject linkFiles(long collectionId,List<Long> values,boolean acknowledgePruning,List<Long> expectedOrder) throws Exception {
        selected(collectionId);if(!acknowledgePruning)throw failure("Lecture pCloud non confirmée.");List<Long> additions=freshIds(values);JSONObject current=before(collectionId,true,expectedOrder);List<Long> target=ids(current.getJSONArray("fileids"));
        Set<Long> existing=new HashSet<>(target);for(long id:additions)if(existing.contains(id))throw failure("Ce morceau figure déjà dans la liste.");target.addAll(additions);
        return mutate("collection_linkfiles",parameters("collectionid",Long.toString(collectionId),"fileids",csv(additions)),target,true);
    }
    public JSONObject unlinkFiles(long collectionId,List<Long> values,boolean acknowledgePruning,List<Long> expectedOrder,boolean allowEmpty) throws Exception {
        selected(collectionId);if(!acknowledgePruning)throw failure("Lecture pCloud non confirmée.");List<Long> removals=freshIds(values);JSONObject current=before(collectionId,true,expectedOrder);List<Long> target=ids(current.getJSONArray("fileids"));
        Set<Long> removed=new HashSet<>(removals);if(!new HashSet<>(target).containsAll(removed))throw failure("Un retrait ne correspond plus à la liste distante.");target.removeIf(removed::contains);if(target.isEmpty()&&!allowEmpty)throw failure("Le vidage de cette liste n’est pas confirmé.");
        return mutate("collection_unlinkfiles",parameters("collectionid",Long.toString(collectionId),"fileids",csv(removals)),target,true);
    }
    public JSONObject moveFile(long collectionId,long fileId,int position,boolean acknowledgePruning,List<Long> expectedOrder) throws Exception {
        selected(collectionId);if(!acknowledgePruning)throw failure("Lecture pCloud non confirmée.");freshIds(Collections.singletonList(fileId));JSONObject current=before(collectionId,true,expectedOrder);List<Long> target=ids(current.getJSONArray("fileids"));int item=target.indexOf(fileId)+1;
        if(item==0||position<1||position>target.size())throw failure("Position hors de la liste choisie.");if(item==position)return current;target.remove(fileId);target.add(position-1,fileId);
        return mutate("collection_move",parameters("collectionid",Long.toString(collectionId),"item",Integer.toString(item),"fileid",Long.toString(fileId),"position",Integer.toString(position)),target,true);
    }
    public long fileIdForTrack(JSONObject track) throws CloudException {
        indexMusic();try{
            if(track.has("pcloud_account_userid")&&integer(track.get("pcloud_account_userid"),false)!=account.userid)throw failure("Ce morceau appartient à une autre connexion pCloud.");
            if(track.has("media_path")){String path=FolderProtocol.mediaPath(track.getString("media_path"));for(Map.Entry<Long,JSONObject> e:index.entrySet())if(path.equals(e.getValue().getString("media_path")))return e.getKey();throw failure("Morceau absent du dossier musical choisi.");}
            if(!track.has("pcloud_account_userid"))throw failure("Associe ce morceau au compte musical avant l’écoute.");long id=integer(track.get("pcloud_fileid"),false);fileIds(Collections.singletonList(id));return id;
        }catch(CloudException error){throw error;}catch(Exception error){throw failure("Référence musicale invalide.");}
    }
    public URL mediaUrl(long fileId) throws CloudException {
        freshIds(Collections.singletonList(fileId));JSONObject result=api("getfilelink",parameters("fileid",Long.toString(fileId),"skipfilename","1"));
        try{return validatedMediaUrl(result.getJSONArray("hosts").getString(0),result.getString("path"));}catch(Exception error){throw failure("Adresse du média pCloud refusée.");}
    }
    public static URL validatedMediaUrl(String host,String path) throws Exception {
        if(host==null||!host.matches("(?i)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+pcloud\\.com")||path==null||!path.startsWith("/")||path.startsWith("//")||path.indexOf('\\')>=0||path.indexOf('#')>=0)throw failure("Serveur du média refusé.");
        for(int i=0;i<path.length();i++)if(path.charAt(i)<32||path.charAt(i)==127)throw failure("Adresse du média refusée.");
        URL url=new URL("https://"+host+path);if(!host.equalsIgnoreCase(url.getHost())||url.getUserInfo()!=null||url.getPort()!=-1)throw failure("Adresse du média refusée.");return url;
    }
    public File mediaFile(JSONObject track,File cacheDirectory) throws Exception {
        long id=fileIdForTrack(track);URL url=mediaUrl(id);JSONObject metadata=index.get(id);String prefix="account-"+account.userid+"-audio-";File output=new File(cacheDirectory,cacheName(metadata,account.userid));
        if(!requestGuard.getAsBoolean())throw failure("Lecture annulée : le compte musical a changé.");
        if(!cacheDirectory.isDirectory())throw failure("Cache audio indisponible.");if((metadata.has("hash")||metadata.has("modified"))&&output.isFile()&&output.length()==metadata.getLong("size"))return output;
        HttpURLConnection connection=null;File temp=new File(cacheDirectory,output.getName()+".partial");boolean success=false;
        try{
            connection=(HttpURLConnection)url.openConnection();connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(15000);connection.setReadTimeout(30000);
            if(connection.getResponseCode()!=200||connection.getContentLengthLong()>256L*1024*1024)throw failure("Téléchargement audio refusé ou trop volumineux.");
            try(InputStream in=connection.getInputStream();FileOutputStream out=new FileOutputStream(temp)){byte[] buffer=new byte[65536];long total=0;int n;while((n=in.read(buffer))!=-1){if(!requestGuard.getAsBoolean())throw failure("Lecture annulée : le compte musical a changé.");total+=n;if(total>256L*1024*1024)throw failure("Morceau trop volumineux.");out.write(buffer,0,n);}if(total!=metadata.getLong("size"))throw failure("Le média pCloud est incomplet ; réessaie la lecture.");out.getFD().sync();}
            if(!temp.renameTo(output))throw failure("Cache audio indisponible.");success=true;
            File[] old=cacheDirectory.listFiles();if(old!=null)for(File file:old)if(file.getName().startsWith(prefix)&&file.getName().endsWith(".cache")&&!file.equals(output))file.delete();return output;
        }catch(CloudException error){throw error;}catch(Exception error){throw failure("Lecture du média pCloud impossible.");}
        finally{if(connection!=null)connection.disconnect();if(!success)temp.delete();}
    }
    static String cacheName(JSONObject metadata,long userid) throws Exception {
        long fileid=integer(metadata.get("fileid"),false),size=integer(metadata.get("size"),true);positive(userid);
        String version=fileid+":"+size+":"+metadata.optString("hash","")+":"+metadata.optString("modified","");byte[] hash=java.security.MessageDigest.getInstance("SHA-256").digest(version.getBytes(StandardCharsets.UTF_8));StringBuilder suffix=new StringBuilder();for(int i=0;i<16;i++)suffix.append(String.format(Locale.ROOT,"%02x",hash[i]&255));
        return "account-"+userid+"-audio-"+fileid+"-"+suffix+".cache";
    }
    private static byte[] bounded(InputStream in,int limit) throws Exception {try(ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] block=new byte[16384];int n;while((n=in.read(block))!=-1){if(out.size()+n>limit)throw failure("Réponse pCloud trop volumineuse.");out.write(block,0,n);}return out.toByteArray();}}
}
