package fr.denis.rhythmbox;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.util.List;

/** Human-facing folder setup by default; legacy scoped links stay available. */
public final class SyncConnection {
    private final Context context;
    private final JSONObject config;
    private final String mode;
    public SyncConnection(Context context,JSONObject config) throws Exception {
        this.context=context;this.config=new JSONObject(config.toString());this.mode=MediaOrigin.mode(this.config);
    }
    private FolderSync folder(){return new FolderSync(context,config);}
    private SyncEngine links() throws Exception{return new SyncEngine(config);}
    private PCloudCollections account(PCloudAccount selected) throws Exception {
        final PCloudAccount saved=selected==null?new PCloudAccountStore(context).load():selected;
        if(saved==null||saved.musicFolderId<=0)throw new IllegalStateException("Connecte le compte musical pCloud et sélectionne son dossier musique.");
        PCloudCollections client=new PCloudCollections(saved,java.util.Collections.emptySet(),java.util.Collections.emptySet());
        client.setRequestGuard(()->{try{PCloudAccount latest=new PCloudAccountStore(context).load();return latest!=null&&saved.userid==latest.userid&&saved.musicFolderId==latest.musicFolderId&&saved.token.equals(latest.token)&&saved.email.equalsIgnoreCase(latest.email)&&saved.region.equals(latest.region)&&saved.clientId.equals(latest.clientId);}catch(Exception error){return false;}});
        client.verifyAccount();return client;
    }
    public void validateConfig() throws Exception {if("account".equals(mode))account(null).indexMusic();else if("links".equals(mode))links().validateConfig();else folder().validateConfig();}
    public List<JSONObject> heads() throws Exception {if("account".equals(mode))throw new IllegalStateException("Utilise la synchronisation des listes du compte musical pCloud.");return "links".equals(mode)?links().heads():folder().heads();}
    public void upload(JSONObject value) throws Exception {if("account".equals(mode))throw new IllegalStateException("Utilise la synchronisation des listes du compte musical pCloud.");if("links".equals(mode))links().upload(value);else folder().upload(value);}
    public JSONArray importMedia() throws Exception {if("account".equals(mode))return account(null).importedMusic();return "links".equals(mode)?links().importMedia():folder().importMedia();}
    public File mediaFile(JSONObject track,File cache) throws Exception {
        PCloudAccount connected=track.has("pcloud_account_userid")?new PCloudAccountStore(context).load():null;
        MediaOrigin.Kind origin=MediaOrigin.route(track,config,connected);
        if(origin==MediaOrigin.Kind.ACCOUNT)return account(connected).mediaFile(track,cache);
        if(origin==MediaOrigin.Kind.FOLDER)return folder().mediaFile(track.getString("media_path"),cache);
        return links().mediaFile(track.getLong("pcloud_fileid"),cache);
    }
}
