# Client Android Rhythmbox

Application Android native en Java, sans WebView ni bibliothèque embarquée. Android 8 (API 26) minimum, cible Android 16 (API 36). Le code original de ce client est distribué sous GPL-2.0-or-later, comme le projet Rhythmbox.

État du 31 octobre 2026 : les sources préparent **0.5.2 (code 7), non publiée**, pour corriger l’échec de retour du navigateur observé avec 0.5.1 (code 6), après le remplacement du parcours mot de passe de 0.5.0 (code 5). Le parcours principal ouvre maintenant la page officielle pCloud et récupère uniquement l’autorisation de cette tentative. Les essais isolés ne prouvent pas encore une connexion ou une synchronisation avec le compte musical réel. Les artefacts et preuves des candidats précédents restent identifiés séparément.

L’APK de développement est dans `../dist/rhythmbox-android-debug.apk`. Il conserve sa clé locale et les signatures Android v2 et v3. La chaîne de production fournit un AAB et un APK universel signés avec une clé d’upload distincte ; voir [la construction Google Play](RELEASE.md). Les essais d’émulateur et d’appareil sont consignés séparément des contrôles de compilation et de protocole.

## Compte musical indépendant : préparation 0.5.2

Dans les réglages, **Connecter mon compte musical…** demande seulement l’adresse attendue du compte réservé à la musique. La connexion, la validation de mot de passe, le CAPTCHA éventuel et le second facteur se déroulent sur **la page officielle pCloud dans le navigateur habituel**. Après la confirmation affichée par pCloud, revenir dans Rhythmbox. L’application vérifie à nouveau l’adresse et l’identifiant utilisateur avec le nouveau jeton avant de l’enregistrer. Elle n’emprunte ni les autorisations de l’application pCloud du téléphone, ni ses cookies, ni son compte par défaut. Une connexion au mauvais compte est refusée et son nouveau jeton est révoqué au mieux, sans remplacer l’autorisation précédente.

Le protocole suit le [client officiel Console 3.x](https://github.com/pCloud/console-client/blob/92b0ec353710537e20149ff4f5cb366ee697c443/src/wrapper/weblogin.rs) et [pclsync](https://github.com/pCloud/pclsync/blob/31c17faea8bd6fe0cd67d2bf58adafdc7e00f4bf/ptools.c) : création anonyme `getrequestid`, page `/webview/authentication`, puis courts appels `pcloud_oauth2_token(typelogin=1, request_id, timeout=1)`. Le code 6002 signifie seulement « encore en attente ». Les refus API, erreurs HTTP, réponses invalides et discordances de compte arrêtent la tentative avec une étape et un code numériques utiles au diagnostic. Les interruptions réseau pendant la vérification restent transitoires : la même tentative reprend lorsque l’activité revient au premier plan, avec un délai progressif limité à trente secondes. Aucun nouvel identifiant de tentative ni nouvelle autorisation n’est créé automatiquement. Si le jeton est déjà arrivé, il reste uniquement en mémoire et la reprise vérifie ce même jeton avec userinfo, sans interroger de nouveau un identifiant déjà consommé. La validation TLS reste obligatoire ; ses échecs ne déclenchent aucun repli. L’identité d’application est **rhythmbox-musique**, le nom de dispositif **Rhythmbox Musique Android** et la version de système indique réellement Android. `os=10` sélectionne le mode de confirmation Console de l’interface pCloud ; cette valeur désigne ce parcours du fournisseur, pas une version Android ni une identité pcloud-cli empruntée. L’acceptation complète de ce parcours avec notre propre identifiant reste à vérifier sur le service réel.

L’identifiant temporaire `request_id` est une capacité permettant de récupérer le nouveau jeton : Rhythmbox le garde uniquement en mémoire, ne l’inscrit pas dans ses journaux ou exports, et l’envoie uniquement à pCloud. Seul un nonce de validation local est conservé chiffré pendant la tentative. La durée de tentative est limitée au plus court de l’expiration renvoyée par pCloud et de quinze minutes. Fermer complètement l’activité annule sa tentative ; une reprise après destruction du processus doit recommencer. Le contrôle commence uniquement lorsque l’activité est reprise (onResume) et se suspend pour les nouveaux appels dès onPause. Il reprend avec le même identifiant lorsque l’utilisateur revient du navigateur, sans App Link ni retour personnalisé contenant un jeton.

**Le choix de mémorisation fait sur la page pCloud est respecté.** Si `rememberme=true`, le jeton est conservé chiffré avec Android Keystore dans le stockage privé exclu des sauvegardes. Sinon il reste uniquement en mémoire et l’ancienne autorisation locale persistante est retirée : arrêter le processus met fin à la connexion de Rhythmbox, sans réutiliser automatiquement un ancien compte. Le choix d’un dossier ne transforme jamais une connexion temporaire en connexion persistante. La durée effective du jeton web dépend de pCloud ; aucune expiration de trente jours n’est promise pour ce parcours.

Une session locale à usage unique et une comparaison de l’autorisation précédente, y compris son mode temporaire/persistant, empêchent une réponse ancienne de remplacer une connexion plus récente. En cas de refus d’identité, d’expiration ou d’annulation après réception, seul le nouveau jeton rejeté est révoqué au mieux. Le transfert de propriété du jeton et la validation du compte sont synchronisés : une annulation arrivée après validation ne révoque jamais un jeton déjà enregistré. **Reconnecter ce compte…** conserve le dossier et les listes lorsque le même compte est retrouvé.

**Cette connexion donne techniquement accès au compte pCloud.** Les contrôles de Rhythmbox limitent ses opérations au dossier musical et aux listes choisis, mais ne réduisent pas les droits du jeton côté serveur. Le compte doit donc rester exclusivement musical. Voir [la configuration pCloud](../docs/PCLOUD-SETUP.md) et [l’analyse de confidentialité](../docs/SECURITY.md).

L’ancien parcours de mot de passe demeure dans les sources et les tests de compatibilité, sans point d’entrée dans l’interface principale. L’erreur réelle 1022 indiquant un paramètre `code` requis ne déclenche aucun envoi de code ni contournement automatique. Le parcours OAuth d’application enregistrée reste également distinct ; sa demande **Rhythmbox Musique LeMegaGeek**, mode **Private**, attend toujours la validation du fournisseur. Le nouveau parcours navigateur avec identifiant de tentative n’utilise pas cet identifiant OAuth vide.

Le retour HTTPS vérifié `https://lemegageek.github.io/rhythmbox/pcloud/oauth/callback.html` reste réservé à l’ancien parcours OAuth. Ses App Links et sa page de secours restent conservés, sans intervenir dans le nouveau parcours principal.

### Choisir la musique et les listes

Après connexion, **Choisir le dossier musical…** affiche uniquement les noms de dossiers du compte dédié, à la demande de l’utilisateur (`listfolder`, `nofiles=1`, `noshares=1`). La racine n’est pas une bibliothèque sélectionnable. Après validation d’un dossier non racine, l’index musical se limite à son sous-arbre et les identifiants des fichiers sont contrôlés avant utilisation.

**Voir mes listes pCloud…** permet de sélectionner les collections à importer ou à lier aux listes locales ; **Partager une liste de ce téléphone…** peut créer une collection. L’affichage des en-têtes de listes exige une action explicite et un accord préalable : [collection_list](https://docs.pcloud.com/methods/collection/collection_list.html), comme [collection_details](https://docs.pcloud.com/methods/collection/collection_details.html), peut faire retirer par pCloud des références devenues indisponibles. L’automatisation ne lance pas cet inventaire général ; elle ne traite que les identifiants de collections déjà sélectionnés. Aucun fichier musical n’est envoyé ou supprimé par ces opérations de playlists.

Les ajouts, retraits de références et changements d’ordre sont réconciliés avec la dernière base connue. Les conflits restent dans des copies visibles. Un journal privé est écrit avant les mutations distantes ; la validation locale utilise une comparaison de version (CAS) pour préserver une modification arrivée entre-temps. Une interruption suspend les nouveaux envois : **Vérifier la synchronisation interrompue…** relit les collections concernées et conserve leur état dans des copies de récupération, sans rejouer aveuglément les écritures.

### Synchronisation automatique et écoute

Après association d’une première liste et accord de lecture, la synchronisation automatique est activée si aucun choix préalable ne l’a désactivée. Son interrupteur reste dans les réglages. Avec l’application au premier plan, elle vérifie les changements environ chaque minute et attend environ trois secondes après une modification locale. En arrière-plan, un travail Android périodique demande un passage au plus tôt toutes les quinze minutes, sur réseau non facturé et avec batterie suffisante ; Android décide de l’heure effective. L’interface désigne cette option par **Synchronisation automatique en Wi-Fi**. Les travaux ne créent aucune nouvelle notification et ne présentent pas de dialogues répétés. La notification multimédia de lecture reste distincte.

Android récupère le fichier musical original avec `getfilelink`, vérifie sa taille reçue et le garde dans un cache privé limité à 256 Mio par fichier. Il ne demande pas de conversion audio et ne transmet pas le lien temporaire au lecteur. L’écoute commence après téléchargement. Seuls les titres identifiés comme issus du compte musical passent par ce compte ; les titres locaux continuent à utiliser le dossier Android choisi, même avec le compte connecté. Un fichier local manquant ne déclenche pas de recherche cloud par son nom. Sous Linux, l’écoute reste celle des fichiers locaux ; les membres uniquement cloud d’une collection sont conservés sans téléchargement ni lecture distante automatique.

## Modes compatibles avec la version 0.4 publiée

Les modes dossiers et liens ci-dessous restent disponibles en 0.5. Ils échangent des manifestes chiffrés `.rbx` ; ils ne synchronisent pas les collections du lecteur pCloud officiel. Ils ne nécessitent aucun jeton OAuth.

### Choisir les dossiers, sans saisir de code

Les réglages proposent maintenant **Choisir le dossier des playlists**, **Choisir le dossier musique** et **Associer avec le PC**. Les boutons ouvrent le sélecteur de dossiers Android ; les chemins et les clés ne sont pas à recopier.

Sur le PC, choisir les dossiers synchronisés et utiliser **Associer Android**. Transférer le fichier d’association par un canal privé, puis le sélectionner sur Android. Ce fichier contient la clé de chiffrement et doit rester hors du dossier pCloud des playlists. La clé importée est ensuite conservée dans les paramètres privés chiffrés avec Android Keystore. Le fichier de transfert n’est pas effacé automatiquement.

Le dossier des playlists doit être accessible en lecture/écriture et autoriser la création et le renommage de documents ; le dossier musique reçoit une autorisation de lecture uniquement. Les autorisations sont persistées et les anciens dossiers inutilisés sont révoqués lorsque le choix change. L’application n’obtient aucune permission générale d’accès aux fichiers. Les fichiers de playlists sont toujours les révisions chiffrées `rb-sync-UUID.rbx`, compatibles avec le PC.

La disponibilité du dossier pCloud dépend du **fournisseur de documents Android** installé : il doit apparaître dans le sélecteur et permettre de choisir un dossier entier. La présence de l’application pCloud ne prouve pas qu’elle expose cette fonction. Si aucun fournisseur compatible ne présente ce dossier, ce mode ne réalise pas à lui seul la synchronisation pCloud ; la connexion avancée ci-dessous reste disponible. Ce point doit être essayé sur le téléphone cible.

Les références musicales utilisent `media_path`, un chemin relatif au seul dossier musique choisi. Les chemins absolus, URL, composants `..`, `.`, vides, antislash, deux-points, séquences encodées `%HH` et caractères de contrôle sont refusés. Les noms contenant un `%` littéral, par exemple `11 100%.mp3`, sont conservés. Aucun chemin du PC n’est utilisable comme chemin Android. Le contenu est résolu par noms exacts sous le dossier autorisé, sans décodage d’URL, puis copié dans le cache privé pour lecture. Le PC et le téléphone doivent tous deux utiliser cette correction : un ancien client qui refusait tout `%` rejettera les révisions contenant ces noms.

### Connexion avancée par liens — mode historique

Dans **Réglages**, saisir la région pCloud, le lien de lecture et le lien de dépôt du même dossier dédié aux listes, puis la clé Base64 générée sur le PC. Le lien musique/collection est facultatif : les listes peuvent être synchronisées sans donner accès à des médias. Aucun identifiant ou jeton de compte pCloud n’est demandé.

Le bouton **↓ pCloud** importe les titres du dossier ou de la collection explicitement partagé par le lien musique. Créer et renommer des listes, rechercher un artiste/album/titre, toucher un titre pour écouter. Le menu `⋮` permet d’ajouter un titre à une liste, modifier ses métadonnées ou le retirer. Un appui long sur une liste ouvre son menu. La barre de lecture fournit lecture/pause, précédent/suivant, mode aléatoire et position. La lecture utilise un service de premier plan avec notification multimédia, gestion de la sortie casque et du focus audio.

**↻ Synchro** propose récupération ou envoi explicites. Les fichiers échangés sont des snapshots AES-256-GCM, compatibles avec le cœur Python. Chaque envoi crée une révision immuable. Plusieurs révisions terminales sont affichées comme variantes ; le choix de celle qui remplace les listes locales exige une confirmation. L’envoi depuis une base ancienne conserve une variante supplémentaire. Les révisions pCloud restent disponibles. La suppression d’une liste entière est locale en V1 et peut être annulée par une récupération ; le cœur bureau conserve aussi les listes absentes d’un export partiel.

La **mise à l’écart Android** masque un titre, un album ou un artiste sur ce téléphone et exclut ses entrées des prochains envois. Les fichiers pCloud restent en place. Le déplacement physique vers le dossier de quarantaine se fait dans l’application Rhythmbox sur le PC. Les identifiants des titres masqués restent exclusivement dans le stockage privé Android ; les réglages permettent de les réafficher.

### Piste audio des vidéos

Les conteneurs M4V, MP4, MPG/MPEG, MOV, MKV, AVI et WebM sont proposés avec les fichiers musicaux. L’application exige une piste audio lisible après préparation et ne fournit aucune surface vidéo : ces fichiers sont écoutés sans image. Leur extension ne garantit pas que le téléphone possède le codec audio requis. La lecture effective dépend encore d’un essai sur le téléphone cible ; la compilation et les tests JVM ne prouvent pas les codecs de l’appareil.

## Confidentialité et limites

- En mode historique par liens, seuls `showpublink`, `getpublinkdownload` et `uploadtolink` sont appelés ; aucune API de compte n’y est utilisée. Le mode compte dédié préparé en 0.5.1 utilise les API authentifiées décrites ci-dessus, avec méthodes et objets autorisés explicitement contrôlés.
- Un `fileid` audio n’est utilisé qu’après vérification de son appartenance au partage musique en mode liens, ou à l’index du dossier sélectionné en mode compte. Une playlist reçue ne peut pas imposer d’URL ni de chemin local. Le serveur CDN doit appartenir à `.pcloud.com`, le transport est HTTPS et les redirections HTTP sont refusées.
- Les liens sont des capacités d’accès : toute personne possédant un lien musique peut lire les médias de ce partage. Le chiffrement protège les métadonnées des listes, pas les médias. Tout contenu futur du dossier partagé devient accessible par ce lien. Voir `../docs/SECURITY.md` et `../docs/PCLOUD-SETUP.md`.
- Les paramètres sont chiffrés avec une clé Android Keystore non exportable. Le jeton de compte et l’état temporaire de connexion utilisent des fichiers chiffrés distincts dans `noBackupFilesDir`, sans repli en clair. Le jeton n’est jamais inclus dans l’association PC, une playlist `.rbx` ou l’export de bibliothèque. Bibliothèque et paramètres restent privés et exclus des sauvegardes ; le cache audio reste privé. Les champs secrets n’activent ni suggestions, ni apprentissage personnalisé du clavier, ni remplissage automatique.
- Aucun accès général aux fichiers, photos, contacts, microphone ou compte Android n’est demandé. La 0.5 ajoute l’observation de l’état réseau et le rétablissement des travaux après démarrage aux permissions réseau et de lecture multimédia existantes. La notification MediaSession est exemptée de la permission de notifications ; aucun dialogue général de notifications n’est demandé au lancement.
- L’audio est téléchargé dans un cache privé avant lecture, avec une limite de 256 Mio par fichier et un seul morceau conservé. Les liens temporaires ne sont pas confiés au moteur multimédia, ce qui permet de refuser les redirections réseau. Il ne s’agit donc pas encore d’un lecteur à démarrage instantané par streaming. Pas de téléchargement hors connexion de bibliothèque complète.
- La 0.4 publiée importe les liens de collections en lecture seule. La 0.5.1 prépare leur synchronisation native avec un compte musical distinct ; l’autorisation pCloud et l’essai réel restent nécessaires avant publication.

## Compilation Linux

Prérequis : Python 3.11 ou ultérieur, JDK 17 ou 21 et outils Unix usuels. Les téléchargements restent dans `.toolchain/` et sont vérifiés par SHA-256. Les plateformes/outils Android officiels sont soumis à leurs licences respectives. `org.json` est utilisé uniquement par les tests JVM et n’est pas inclus dans l’APK.

```sh
./prepare-toolchain.sh
./build.sh
./test.sh
./build-release.sh
```

Pour utiliser des outils déjà installés, définir `RBX_ANDROID_PLATFORM=/chemin/platforms/android-36/android.jar` et `RBX_ANDROID_BUILD_TOOLS=/chemin/build-tools/36.0.0`. AAPT2 Maven et bundletool restent épinglés localement ; leurs chemins peuvent être fournis par `RBX_ANDROID_AAPT2` et `RBX_ANDROID_BUNDLETOOL`. Les tests acceptent `RBX_JSON_TEST_JAR=/chemin/org.json.jar`.

Le build compile les ressources et les classes Java, produit le DEX avec D8, construit le manifeste avec AAPT2, aligne puis signe l’APK. La clé de développement reste sous `.signing/`, exclue du versionnement ; conserver cette clé permet de mettre à jour la même installation de développement. La clé d’upload de production est gérée séparément, hors du projet et du dossier musical synchronisé. Les scripts de release vérifient aussi l’AAB, son certificat et l’APK universel généré par bundletool.

## Vérification de la préparation 0.5

Les contrôles du 30 octobre séparent les preuves suivantes :

- Python pCloud dédié : 152 tests exécutés, 150 réussis et deux optatifs ignorés ; interface GTK vérifiée dans une session isolée.
- Android : 142 assertions natives sur JVM (80 transport, 23 routage selon l’origine, 39 contrôleur), plus 57 assertions OAuth hors réseau ; les suites historiques de protocole restent séparées.
- Android API 36 : 296 assertions dans onze scénarios d’instrumentation, avec le véritable AndroidKeyStore de l’émulateur et des identités fictives. L’APK `fr.denis.rhythmbox.authtest` a son propre UID, aucun droit réseau et aucun accès aux données de l’application principale. Voir [le test isolé](app/src/androidTest/README.md).
- Application Android principale signée : installation et démarrage vérifiés ; quatre contrôles UI ont couvert notamment l’attente de validation pCloud et le refus d’un simple signal de retour d’authentification falsifié comme preuve de connexion.
- App Links : trois tests de page/CSP/association ; publication HTTPS et domaine vérifié sous API 36 avec le certificat release.

Ces essais n’utilisent ni vrai compte pCloud, ni jeton réel, ni média personnel. Il n’y a pas encore eu de synchronisation réelle dans les deux sens, de parcours OAuth pCloud complet, de test sur téléphone physique ou sous API 26. Le périmètre serveur **Private** doit encore être confirmé. La politique publique et les déclarations Google Play de la 0.4 n’ont pas été modifiées pour cette préparation non publiée.

## Historique de validation de la version 0.4

`./test.sh` vérifie le chiffrement Python→Java et Java→Python sur une fixture commune, l’authentification GCM, la mauvaise clé, les limites du protocole, les types des identifiants, l’exclusion des URI locales, les codes de liens, les serveurs CDN, les conflits et les cycles de révisions. Il teste aussi les chemins relatifs, l’import d’association, la sélection des formats musicaux/vidéo, la présentation, la file de lecture et la séparation de la démo lors des exports. Il vérifie les permissions, l’absence de sauvegarde/HTTP clair, la version et l’absence de surface vidéo dans les sources. `./build.sh` compile et vérifie les signatures de l’APK, en conservant la clé de développement existante pour permettre sa mise à jour.

La QA réelle utilise un émulateur Android 16 (API 36) isolé, sans compte pCloud ni musique personnelle. Le candidat corrigé de la course PREPARING a passé douze contrôles directs : régression de préparation audio, import local SAF, seek MediaSession, rotation, menus de confidentialité et de sources HTTPS, pochette du MP3, police agrandie, commandes multimédias en arrière-plan, écran éteint, fermeture par retrait des tâches et recherche d’appels natifs invalides ou d’exceptions fatales. La régression exécute six cycles MP3 avec pause/reprise/relecture et douze paires suivant/précédent rapides ; les états de chargement ont été observés sans erreur native -38. Les erreurs de fichier sans audio et de codec ont été vérifiées séparément sur la debug.

Le détail figure dans `dist/android-emulator-validation.json` et `dist/android-qa/920582e3/revalidation.json`, livrés séparément du rapport de compilation et de cette archive de sources. Deux captures RGB et une vidéo réelle muette de 44,83 secondes proviennent du candidat corrigé ; les preuves des candidats retirés restent identifiées par leur empreinte. Les menus ouvrent bien les deux pages publiques HTTPS ; la publication du paquet GPL final est vérifiée séparément avant le téléversement. La présence d’une signature valide ne prouve pas à elle seule ces essais. Aucun test sur téléphone physique/API 26 ni connexion à des données pCloud réelles n’a été effectué. Les fournisseurs de documents pCloud et les codecs du téléphone cible restent à vérifier sur cet appareil.

Références : [API publique pCloud](https://docs.pcloud.com/methods/public_links/showpublink.html), [dépôt par lien](https://docs.pcloud.com/methods/upload_links/uploadtolink.html), [service multimédia Android](https://developer.android.com/develop/background-work/services/fgs/service-types#media).

Le périmètre des autorisations du sélecteur et la disponibilité des fournisseurs sont décrits dans la [documentation officielle du Storage Access Framework](https://developer.android.com/training/data-storage/shared/documents-files#grant-access-directory).
