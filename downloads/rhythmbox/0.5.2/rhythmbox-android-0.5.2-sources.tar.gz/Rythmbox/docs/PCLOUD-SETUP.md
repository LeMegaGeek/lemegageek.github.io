# Préparer pCloud pour Rhythmbox et Android

État du 31 octobre 2026 : **Android 0.4.0, code 4, reste diffusé en test fermé**. Les préparations 0.5.0/code 5 et 0.5.1/code 6 ont été conservées en brouillon Play et installées sur le Motorola : la connexion par mot de passe, puis le retour de la page pCloud, n’ont pas établi la connexion dans l’application Android. La préparation **0.5.2, code 7**, corrige le réseau et la reprise sans constituer encore une preuve de connexion réelle. Sur Linux, le compte musical et le dossier My Music sont vérifiés. La synchronisation complète dans les deux sens reste à valider. Ne fournir aucun mot de passe, code, jeton ou adresse privée de retour dans une conversation.

## Compte musical indépendant : connexion sur la page pCloud

Le parcours suit le [client Console officiel 3.x](https://github.com/pCloud/console-client/blob/92b0ec353710537e20149ff4f5cb366ee697c443/src/wrapper/weblogin.rs) et [pclsync](https://github.com/pCloud/pclsync/blob/31c17faea8bd6fe0cd67d2bf58adafdc7e00f4bf/ptools.c). Rhythmbox demande un identifiant temporaire avec `getrequestid`, ouvre `/webview/authentication`, puis récupère uniquement l’autorisation de cette tentative avec `pcloud_oauth2_token`. La page officielle gère le mot de passe, les éventuels CAPTCHA et les vérifications du compte. Aucun mot de passe ni code n’est saisi dans le nouveau formulaire principal de Rhythmbox.

L’application se présente comme **rhythmbox-musique**, avec un nom de dispositif Rhythmbox et un identifiant aléatoire. Elle n’emprunte ni identifiant pcloud-cli, ni secret d’application, ni cookie de pCloud Drive ou du navigateur. Le paramètre fournisseur `os=10` choisit l’écran de confirmation du parcours Console utilisé avec un navigateur autonome ; la plateforme réelle est indiquée séparément. Le `request_id` est une capacité privée gardée en mémoire, au plus quinze minutes et au plus jusqu’à son expiration serveur. Les erreurs et journaux ne le recopient pas.

La réponse n’établit une connexion que si `userinfo` confirme l’adresse attendue et le même identifiant utilisateur. Les hôtes restent limités aux API officielles Europe / États-Unis. Le jeton de session est envoyé dans le corps POST `auth` des demandes. Il n’est exporté ni avec la bibliothèque, ni dans une association, ni dans les playlists.

**Le choix de mémorisation sur la page pCloud est respecté.** Avec `rememberme=true`, Linux garde le jeton dans Secret Service et Android dans AndroidKeyStore. Sinon, seul le processus en cours le conserve en mémoire et l’ancienne autorisation persistante du même compte est retirée. Après fermeture complète, il faut se reconnecter. La durée effective du jeton web dépend de pCloud ; aucune expiration de trente jours n’est promise pour ce parcours.

Le compte doit rester exclusivement musical, y compris les partages auxquels il accède. **Le jeton donne les droits du compte entier.** Les contrôles locaux de dossier et de playlists limitent le comportement de Rhythmbox sans créer une permission limitée à un dossier côté serveur. La quarantaine reste locale, hors du dossier de musique et des dossiers synchronisés.

### Parcours à essayer

1. Dans **pCloud / Compte musical**, vérifier l’adresse du compte musical puis choisir **Connecter ce compte sur pCloud…** (Android : **Connecter mon compte musical…**).
2. Sur la page officielle, utiliser ce même compte et terminer ses vérifications. Choisir de rester connecté si la connexion doit survivre à un redémarrage. Revenir dans Rhythmbox après la confirmation de pCloud. Une identité différente est refusée ; l’autorisation précédente est préservée. Une tentative peut être annulée depuis l’application.
3. Choisir explicitement **My Music**, distinct de la racine. Le sélecteur lit seulement les noms de dossiers appartenant au compte avec `nofiles=1`, `noshares=1`. Après sélection, l’index est borné à ce sous-arbre.
4. Autoriser la lecture des playlists puis choisir celles à importer ou à associer. [`collection_list`](https://docs.pcloud.com/methods/collection/collection_list.html) et [`collection_details`](https://docs.pcloud.com/methods/collection/collection_details.html) peuvent retirer des références indisponibles, même pendant une lecture ; les fichiers audio ne sont pas supprimés.
5. Commencer par une petite collection de test pour vérifier les ajouts, retraits de références, ordre et conflits dans les deux sens. L’arrière-plan n’utilise ensuite que les identifiants de listes sélectionnés. Aucun fichier musical n’est téléversé ou supprimé par la synchronisation de listes.

### Méthodes précédentes

La connexion par mot de passe de 0.5.0 a été refusée : code 1022 sur Linux et refus signalé sur Android. Aucun code de sécurité n’a été reçu. L’analyse du JavaScript public pCloud montre un parcours de préparation et de connexion plus complet que cet ancien appel `userinfo`. Elle ne prouve pas précisément la cause du refus ; le code 1022 ne doit pas être transformé arbitrairement en code e-mail ou CAPTCHA.

La demande d’application OAuth **Rhythmbox Musique LeMegaGeek**, mode **Private** avec écriture, reste en attente. Son identifiant public reste vide. Le nouveau parcours par identifiant temporaire n’en dépend pas. Les App Links et la page `https://lemegageek.github.io/rhythmbox/pcloud/oauth/callback.html` restent réservés à l’ancien parcours OAuth ; ils ne sont pas requis pour cette connexion principale.

### Automatisation, conflits et récupération

La 0.5 prépare la synchronisation bidirectionnelle des références et de leur ordre, avec une base de comparaison et des copies de conflit. Sur Linux ouvert, les changements locaux attendent un bref délai et les changements distants sont recherchés chaque minute. Sur Android au premier plan, les délais préparés sont environ une minute et trois secondes après une modification locale. Après liaison initiale d’une liste et consentement, l’automatisation Android s’active si aucun choix préalable ne l’a désactivée ; son interrupteur reste disponible.

Android programme aussi un travail persistant d’au moins quinze minutes, sur réseau non facturé avec batterie suffisante ; l’OS peut le retarder. L’interface l’appelle « en Wi-Fi ». Seules les collections choisies sont concernées. Ces passages n’ajoutent aucune notification ; la notification multimédia éventuelle concerne la lecture.

Un journal privé précède les écritures distantes ; les états locaux ne sont validés que si leur base n’a pas changé (CAS). Une interruption bloque les nouvelles écritures. La récupération explicite relit les collections journalisées et en garde des copies à vérifier, sans rejouer automatiquement les opérations. Si une création a perdu sa réponse avant d’enregistrer son identifiant, l’utilisateur choisit explicitement la collection à rattacher.

Les références uniquement cloud sont conservées. Linux continue à lire sa musique locale. Sur Android, seuls les titres marqués comme issus du compte musical utilisent cette autorisation pour télécharger le fichier original, dans un cache privé de 256 Mio maximum par fichier avec contrôle de taille. Les titres locaux restent lus depuis le dossier Android choisi, même lorsque le compte est connecté ; un échec local ne déclenche pas de recherche cloud par nom. Choisir ce dossier local ne désactive pas la synchronisation du compte.

### Validation disponible et essais restants

La suite Linux ciblée actuelle compte 255 exécutions : 239 réussites et seize optatives ignorées. Douze tests GTK de configuration ont réussi séparément sans réseau ni trousseau réel. La préparation Android 0.5.2 a passé 183 assertions hôtes ciblant le réseau, 383 assertions dans seize scénarios d’instrumentation API 36 et dix contrôles UI sur son APK debug exact. Les preuves sont conservées séparément par candidat dans `dist/pcloud-native-qa/` ; les anciens résultats OAuth et App Links ne prouvent pas le nouveau retour navigateur.

Le compte musical Linux est réellement connecté avec une autorisation persistante. My Music a été vérifié comme dossier possédé et 4 642 médias ont été indexés. Une collection Mon top native a été créée ; elle était encore vide au dernier contrôle du rapport `dist/pcloud-device-login-validation.json`. Ce constat ne valide pas la propagation complète de ses morceaux. Android 0.5.1 a été installé et essayé sur le Motorola, mais le retour de sa page pCloud n’a pas confirmé la connexion dans l’application. La 0.5.2 reste à compiler puis à essayer réellement sur ce téléphone. La connexion Android, les échanges complets des listes dans les deux sens et l’exécution sous API 26 restent non démontrés. La politique publique et les déclarations doivent correspondre au candidat avant son déploiement en test fermé.


## Où apparaissent les listes ?

| Mode | Objet partagé | Visible dans le lecteur officiel pCloud ? |
|---|---|---|
| Dossiers ou liens historiques, disponibles dans Android 0.4 | Révisions de playlists chiffrées `.rbx` entre Rhythmbox et Android | Non ; le lecteur officiel ne lit pas ce format |
| Compte musical, préparé dans les sources 0.5.2 non publiées | Collections natives explicitement liées | Prévu dans les deux sens, à confirmer par un essai réel |
| Import historique d’un lien de collection | Copie en lecture seule puis échanges `.rbx` | La copie locale ne met pas à jour la collection officielle |

Une collection créée sur le site pCloud n’est synchronisée automatiquement avec Rhythmbox que si elle est explicitement liée dans le nouveau mode compte, autorisé et activé. La seule présence de fichiers `.rbx` ne crée pas cette liaison.

## Mode historique : choisir les dossiers sur le PC

Le greffon **pCloud** se configure par le bouton **pCloud** du Rhythmbox
modifié, ou dans **Greffons → pCloud → Configurer**. L'interface, les pochettes,
l'analyseur et la quarantaine appartiennent à l'application et restent
utilisables sans ce greffon.

Deux dossiers ont des rôles distincts :

| Champ | Choix préparé sur ce poste | Usage |
|---|---|---|
| **Dossier musique utilisé par Rhythmbox** | `/home/denis/Musique/Bibliothèque` | Morceaux utilisés pour l'écoute et références relatives des listes |
| **Dossier des listes chiffrées** | `/home/denis/pCloudDrive/Playlists-Rhythmbox` | Échange Rhythmbox et Android ; un dossier existant déjà choisi est conservé |

La liaison historique de la copie locale de musique utilisait **`/Ma musique`** dans le compte,
visible dans `/home/denis/pCloudDrive/Ma musique`. Il n'y a pas de sous-dossier
`Bibliothèque` dans ce chemin distant. Cette liaison a été vérifiée dans le
client officiel avant le transfert vers le compte musical dédié. Elle ne prouve pas les chemins ou identifiants du nouveau compte **My Music** : il faut sélectionner ce dernier dans la connexion directe et reconstruire les correspondances. Le montage du client pCloud peut continuer à utiliser un autre compte.

On peut choisir la **copie locale synchronisée par pCloud**, ou le dossier
musique du lecteur pCloudDrive. La copie locale permet d'écouter sans dépendre
du montage. Le dossier des playlists est distinct de la musique et doit être
accessible par les appareils associés. Un autre dossier local convient aussi
si sa réplication pCloud a déjà été configurée séparément.

Les options repliées d'emplacements indiquent le lecteur pCloud et les autres
racines synchronisées pour protéger les exports privés et la quarantaine. Ce
chemin de protection n'est pas un deuxième choix de bibliothèque. Les valeurs
du greffon ne créent ni ne changent les liaisons du client pCloud.

Cocher les playlists voulues, puis enregistrer ou synchroniser. La clé est
générée automatiquement ; région et liens de partage restent facultatifs
dans ce mode. Rhythmbox écrit les manifestes chiffrés dans le dossier choisi.
Le client pCloud officiel assure leur transfert ; vérifier son état pour
confirmer que les fichiers ont atteint le cloud. Le greffon n'envoie aucun
fichier audio et ne parcourt pas les autres dossiers du compte.

La quarantaine se règle dans **Quarantaine → Choisir le dossier de
quarantaine…**, dans l'application. Sa destination doit rester hors de toutes
les racines synchronisées, y compris les copies locales. Si une source est
retirée d'une copie locale répliquée, le client pCloud peut propager ce retrait
vers le cloud ; le dialogue de confirmation le précise. Les déplacements
faits directement depuis le montage pCloudDrive sont refusés.

Après un déplacement ou un ajout de morceaux, utiliser **Actualiser la
bibliothèque**. Cette commande réanalyse le dossier musical ; elle est
distincte de la synchronisation des playlists.

## Mode historique : une seule liste Mon top

**Mon top** reste la liste automatique de Rhythmbox : elle regroupe les
morceaux notés au moins quatre étoiles. Si elle est cochée dans le greffon,
un changement de note déclenche la synchronisation après un bref délai.
Le greffon réutilise cette liste et ne crée pas de copie « pCloud · Mon top ».

Lors d'une synchronisation, un favori ajouté sur un autre appareil devient
un favori local. Un morceau déjà noté quatre étoiles garde cette note. Le
retrait d'un favori précédemment partagé retire sa note de favori ; les
favoris locaux jamais partagés restent conservés. Une référence distante
sans fichier local accessible ne provoque aucun retrait de note. Les notes
modifiées sont sauvegardées avant application ; l'historique d'écoute et les
commentaires restent conservés.

## Mode historique : associer Android sans recopier une clé

Cliquer **Associer Android…**, choisir un emplacement privé hors de pCloud pour le fichier d'association, puis le transférer au téléphone par un canal privé. Dans les réglages Android, sélectionner ce fichier avec **Associer avec le PC**, puis choisir le dossier playlists et le dossier musique avec les sélecteurs système.

Le fournisseur de fichiers Android doit rendre les dossiers disponibles au sélecteur et autoriser les opérations demandées. Si pCloud ne propose pas de dossier sélectionnable sur le téléphone, ce mode nécessite un dossier synchronisé exposé par un fournisseur compatible ; la connexion avancée par liens reste disponible. Cette limite est affichée dans l'application. Aucun essai sur téléphone n'a encore confirmé la compatibilité du fournisseur pCloud.

Le fichier d'association contient une clé privée et n'appartient pas aux playlists synchronisées. Ne pas le placer dans pCloud. Les appareils associés lisent les mêmes révisions et conservent les modifications concurrentes.

## Mode historique : connexion avancée par liens

Les sections suivantes concernent uniquement cette option, repliée dans les paramètres.

## Préparer le dossier d'échange

Créer un nouveau dossier vide, par exemple `Rhythmbox-Echanges`, dédié uniquement aux manifestes chiffrés. Il est distinct des dossiers de documents et des répertoires contenant la musique en clair.

Créer un lien de lecture de ce dossier et un lien de dépôt vers ce même dossier. Les interfaces pCloud et les offres disponibles peuvent différer ; la documentation API décrit la création d'un [lien de dépôt](https://docs.pcloud.com/methods/upload_links/createuploadlink.html) vers un dossier possédé par le compte, avec limites optionnelles de taille, de nombre de fichiers et de durée.

Vérifier que les deux liens concernent le dossier vide choisi. Ne pas partager une racine, un dossier de sauvegarde ou un dossier déjà rempli de documents personnels. Ne pas rendre ce lien public dans un message ou un dépôt de sources : il donne accès à l'objet partagé à toute personne qui le possède.

Pour vérifier le périmètre, placer uniquement un objet témoin sans donnée privée dans ce dossier et confirmer sa visibilité via le lien. Les autres dossiers du compte ne doivent pas apparaître dans ce partage. Le client ne doit pas proposer une navigation vers le reste du compte.

## Appairer le bureau et Android

Choisir la région API du compte : `api.pcloud.com` pour les États-Unis ou `eapi.pcloud.com` pour l'Europe. Fournir les deux capacités dans la configuration privée prévue par le client.

Créer une clé aléatoire de 32 octets avec la fonction d'appairage du projet, puis transférer cette même clé au second appareil par un canal privé. Ne pas inventer une phrase courte comme clé et ne pas déposer la clé dans le dossier synchronisé. Le format exact de configuration et la commande d'appairage de la version livrée sont décrits par son README et son interface.

Une clé incorrecte doit produire une erreur de déchiffrement visible et ne jamais écraser une liste locale. Les deux liens ne suffisent pas à déchiffrer les playlists sans cette clé. Inversement, la clé ne donne aucun accès au compte pCloud en dehors des objets obtenus via les liens.

## Importer une liste pCloud existante

Une playlist du lecteur musical officiel pCloud est une collection native, différente d'un fichier M3U ou d'un manifeste du projet. Créer volontairement un lien vers la seule collection à importer, puis le fournir à la fonction d'import. Le [lien de collection](https://docs.pcloud.com/methods/public_links/getcollectionpublink.html) est une image à jour de cette collection et n'exige pas de jeton global pour sa consultation.

Ce partage expose les métadonnées et fichiers désignés aux détenteurs du lien. Une collection contenant des éléments qui ne doivent pas être partagés ne convient pas. Le chiffrement du dossier d'échange ne chiffre pas le contenu rendu public par un autre lien de collection.

Dans ce mode historique, l’import est en lecture seule pour la collection pCloud. Les modifications faites dans Rhythmbox ou Android sont échangées sous forme de manifestes chiffrés du projet ; elles ne modifient pas automatiquement la collection officielle et ne demandent aucun jeton de compte. La connexion au compte musical décrite en tête de document est un mode distinct de la préparation 0.5.

Les collections système doivent rester intactes. Tout import incomplet ou référence devenue inaccessible doit être signalé, sans considérer silencieusement une liste partielle comme une réussite.

## Premier essai

Commencer avec une petite playlist de test, sans données sensibles. Vérifier le nombre de pistes et leur ordre sur le bureau puis sur Android. Modifier la liste sur un appareil et confirmer que l'autre récupère la nouvelle révision. Créer ensuite deux modifications concurrentes et confirmer que les deux variantes sont conservées jusqu'à résolution.

Tester une mauvaise clé et un fichier chiffré altéré : les clients doivent refuser les données. Révoquer un lien et confirmer que les prochaines requêtes échouent explicitement. Les données déjà téléchargées restent présentes sur l'appareil ; elles ne sont pas effacées par une révocation distante.

Les liens réels et un appareil Android sont nécessaires pour valider la synchronisation de bout en bout. La simple compilation ou un essai d'API simulée ne suffit pas. Voir [les garanties et limites de confidentialité](SECURITY.md) et le compte rendu de validation du projet.
