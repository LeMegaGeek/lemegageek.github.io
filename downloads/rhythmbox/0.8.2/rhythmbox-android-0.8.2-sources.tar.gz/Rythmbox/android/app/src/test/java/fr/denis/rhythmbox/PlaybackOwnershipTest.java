package fr.denis.rhythmbox;

/** Deterministic callback-order tests: no Android stubs, device or SDK involved. */
public final class PlaybackOwnershipTest {
    private static int checks;
    private static void yes(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
    private static void quiet(PlaybackOwnership.Decision decision,String label){
        yes(!decision.pauseSpotify&&!decision.suspendNative&&!decision.startNative
            &&!decision.resumeNative&&!decision.spotifySelected,label);
    }

    private static void playThenNativeThenLatePlaying(){
        PlaybackOwnership owner=new PlaybackOwnership();
        PlaybackOwnership.Decision spotify=owner.spotifyIntent();
        yes(spotify.suspendNative&&spotify.spotifySelected,"Spotify intent suspends native before dispatch");
        // The pending Play has not yet produced Playing: cached state is Paused.
        PlaybackOwnership.Decision nativeChoice=owner.nativeIntent(7,10,true,false,false);
        long request=nativeChoice.generation;
        yes(request>spotify.generation&&nativeChoice.pauseSpotify&&nativeChoice.suspendNative
            &&!nativeChoice.startNative&&owner.awaitingPause(),"new native intent waits despite cached Paused");
        quiet(owner.onSpotifyState(7,10,true,false,false),"Pause-dispatched/status-only Paused cannot confirm anything");
        PlaybackOwnership.Decision late=owner.onSpotifyState(7,11,true,true,false);
        yes(late.pauseSpotify&&late.suspendNative&&!late.spotifySelected&&!late.startNative,
            "late old Spotify Playing is paused instead of stealing playback");
        quiet(owner.onSpotifyState(7,11,true,true,false),"artwork/status republish does not repeatedly send Pause");
        quiet(owner.onSpotifyState(7,11,true,false,false),"same revision cannot confirm pause");
        PlaybackOwnership.Decision paused=owner.onSpotifyState(7,12,true,false,false);
        yes(paused.generation==request&&paused.startNative&&!paused.resumeNative&&!owner.awaitingPause(),
            "fresh same-session Paused starts only newest native selection");
        quiet(owner.onSpotifyState(7,13,true,false,false),"later Paused does not start queue twice");
    }

    private static void latePlayingAfterNativeAlreadyStarted(){
        PlaybackOwnership owner=new PlaybackOwnership();
        owner.spotifyIntent();
        PlaybackOwnership.Decision nativeChoice=owner.nativeIntent(1,3,true,false,false);
        yes(nativeChoice.pauseSpotify,"in-flight start requires pause");
        yes(owner.onSpotifyState(1,4,true,false,false).startNative,"new Paused can confirm initial pause");
        PlaybackOwnership.Decision later=owner.onSpotifyState(1,5,true,true,false);
        yes(later.pauseSpotify&&later.suspendNative&&!later.spotifySelected,"even later Playing preserves native owner");
        PlaybackOwnership.Decision resumed=owner.onSpotifyState(1,6,true,false,false);
        yes(resumed.resumeNative&&!resumed.startNative,"existing native queue resumes at preserved position");
        quiet(owner.onSpotifyState(1,6,true,false,false),"resume runs once");
        quiet(owner.onSpotifyState(1,5,true,true,false),"older PlayerState cannot supersede newer confirmed pause");
    }

    private static void newestSpotifyCancelsPendingNative(){
        PlaybackOwnership owner=new PlaybackOwnership();
        PlaybackOwnership.Decision waiting=owner.nativeIntent(8,20,true,true,false);
        yes(waiting.pauseSpotify&&!waiting.startNative,"native waits for already playing Spotify");
        PlaybackOwnership.Decision newest=owner.spotifyIntent();
        yes(newest.generation>waiting.generation&&newest.spotifySelected&&!owner.awaitingPause(),"newer Spotify intent cancels pending native");
        quiet(owner.onSpotifyState(8,21,true,false,false),"old requested Paused cannot release cancelled native queue");
        PlaybackOwnership.Decision playing=owner.onSpotifyState(8,22,true,true,false);
        yes(playing.spotifySelected&&playing.suspendNative&&!playing.pauseSpotify,"newest explicit Spotify play wins");
        yes(!owner.timeout(waiting.generation),"old timeout cannot touch newer Spotify intent");
    }

    private static void lifecyclePauseFailuresAndSessions(){
        PlaybackOwnership owner=new PlaybackOwnership();
        long old=owner.nativeIntent(5,9,true,true,false).generation;
        owner.nativePaused();
        quiet(owner.onSpotifyState(5,10,true,false,false),"user native pause cancels pending start");
        yes(!owner.timeout(old),"old timeout cannot cancel explicit native pause");
        PlaybackOwnership.Decision local=owner.nativeIntent(5,11,true,false,false);
        yes(local.startNative&&!local.pauseSpotify,"known idle Spotify permits immediate native playback");
        owner.onSpotifyState(5,12,true,true,false);
        owner.nativePaused();
        quiet(owner.onSpotifyState(5,13,true,false,false),"late Paused cannot undo native pause");
        PlaybackOwnership.Decision retry=owner.nativeIntent(5,14,true,true,false);
        yes(owner.timeout(retry.generation),"current pause wait can time out");
        quiet(owner.onSpotifyState(5,15,true,false,false),"timeout never permits delayed auto start");
        PlaybackOwnership.Decision replacement=owner.nativeIntent(5,16,true,true,false);
        quiet(owner.onSpotifyState(6,0,true,false,false),"new session without actual PlayerState revision cannot confirm pause");
        yes(owner.onSpotifyState(6,1,true,false,false).startNative,"fresh replacement-session Paused can restore current native choice");
        owner.clear();
        yes(owner.generation()>replacement.generation&&!owner.awaitingPause(),"leaving activity invalidates previous closures");
        PlaybackOwnership.Decision adopted=owner.onSpotifyState(9,1,true,true,false);
        yes(adopted.spotifySelected&&adopted.suspendNative,"without foreground intent, current external Spotify can be adopted");
    }

    private static void synchronousRefusalAndDisconnectedObservation(){
        PlaybackOwnership owner=new PlaybackOwnership();
        long denied=owner.spotifyIntent().generation;
        owner.spotifyRejected(denied);
        yes(owner.nativeIntent(1,2,true,false,false).startNative,"refused Play is not a phantom pending start");
        long waiting=owner.nativeIntent(1,3,true,true,false).generation;
        quiet(owner.onSpotifyState(1,4,false,false,false),"disconnect does not confirm that audio paused");
        yes(owner.awaitingPause()&&owner.generation()==waiting,"disconnect preserves wait until confirmation or timeout");
        PlaybackOwnership.Decision newer=owner.spotifyIntent();
        owner.spotifyRejected(denied);
        yes(owner.nativeIntent(1,4,true,false,false).pauseSpotify,"old refusal cannot clear newer in-flight Play");
        owner.spotifyPauseIntent();
        quiet(owner.onSpotifyState(1,5,true,false,false),"explicit Spotify Pause cancels native pending action");
        yes(owner.nativeIntent(1,5,true,false,false).pauseSpotify,"explicit Pause intent alone does not prove pending Play settled");
    }

    private static void newUriBeforeFirstTrack(){
        PlaybackOwnership owner=new PlaybackOwnership();
        owner.spotifyIntent();
        PlaybackOwnership.Decision nativeChoice=owner.nativeIntent(12,0,true,false,false);
        yes(nativeChoice.pauseSpotify&&owner.awaitingPause(),"initial URI Play is pending even before first track metadata");
        quiet(owner.onSpotifyState(12,0,true,false,false),"pre-track capability/status publication is not a pause confirmation");
        PlaybackOwnership.Decision firstTrack=owner.onSpotifyState(12,1,true,true,false);
        yes(firstTrack.pauseSpotify&&!firstTrack.spotifySelected,"first late playing track is paused for newer native selection");
        yes(owner.onSpotifyState(12,2,true,false,false).startNative,"first authoritative pause releases selected native queue");
    }

    public static void main(String[] args){
        playThenNativeThenLatePlaying();latePlayingAfterNativeAlreadyStarted();newestSpotifyCancelsPendingNative();
        lifecyclePauseFailuresAndSessions();synchronousRefusalAndDisconnectedObservation();newUriBeforeFirstTrack();
        System.out.println("PASS playback ownership: "+checks+" checks (deterministic intent/state ordering)");
    }
}
