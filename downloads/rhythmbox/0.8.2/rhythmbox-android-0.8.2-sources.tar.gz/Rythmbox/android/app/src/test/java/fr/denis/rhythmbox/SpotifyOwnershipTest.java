package fr.denis.rhythmbox;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** Actual Controller -> Ownership composition with controlled SDK result/read
 * callbacks. No Android, account, network or audio output is used.
 */
public final class SpotifyOwnershipTest {
    static int checks;
    static final String TRACK="spotify:track:2JRo0gjbX4GrCqBYdRohoo";
    static void yes(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    static final class Queue implements SpotifyController.Dispatcher {
        ArrayDeque<Runnable> jobs=new ArrayDeque<>();
        public void post(Runnable r){jobs.add(r);}
        void drain(){int n=0;while(!jobs.isEmpty()){if(++n>2000)throw new AssertionError("callback loop");jobs.remove().run();}}
    }
    static final class Call {
        SpotifyController.Command command;String uri;SpotifyController.Result result;
        Call(SpotifyController.Command c,String u,SpotifyController.Result r){command=c;uri=u;result=r;}
    }
    static final class Remote implements SpotifyController.Remote {
        boolean connected=true,throwAfterSend;SpotifyController.Observer observer;
        List<Call> calls=new ArrayList<>();List<SpotifyController.ReadResult> reads=new ArrayList<>();
        public boolean connected(){return connected;}
        public void observe(SpotifyController.Observer o){observer=o;}
        public void close(){connected=false;}
        public void perform(SpotifyController.Command c,long value,String uri,SpotifyController.Result cb){calls.add(new Call(c,uri,cb));if(throwAfterSend){throwAfterSend=false;throw new IllegalStateException("ambiguous after-send test failure");}}
        public void readState(SpotifyController.ReadResult cb){reads.add(cb);}
    }
    static final class Gateway implements SpotifyController.Gateway {
        boolean enabled;SpotifyController.Connection callback;
        public String clientId(){return "0123456789abcdef0123456789abcdef";}
        public void configure(String id){}
        public boolean enabled(){return enabled;}
        public void setEnabled(boolean v){enabled=v;}
        public boolean installed(){return true;}
        public void connect(boolean auth,SpotifyController.Connection cb){callback=cb;}
    }
    static SpotifyController.Readout state(boolean playing,long revision){return new SpotifyController.Readout(TRACK,"Fixture","Artist","Album",null,playing,100,1000,true,true,true,true,false,3,0,true,true,0,0,revision);}
    static final class Bridge {
        Queue queue=new Queue();Gateway gateway=new Gateway();Remote remote=new Remote();PlaybackOwnership owner=new PlaybackOwnership();
        List<Long> starts=new ArrayList<>();int resumes,suspends;
        SpotifyController controller=new SpotifyController(gateway,queue,this::observed);
        Bridge(){controller.start();controller.connect();gateway.callback.connected(remote);queue.drain();emit(false,1);}
        void observed(SpotifyController.State s){apply(owner.onSpotifyState(s.sessionGeneration,s.playerRevision,s.available,s.playing,s.loading));}
        void apply(PlaybackOwnership.Decision d){
            if(d.suspendNative)suspends++;
            if(d.pauseSpotify){final long pending=owner.pendingSpotifyStart();if(!controller.pause(()->{owner.spotifyPauseConfirmed(pending);observed(controller.state());})){owner.timeout(d.generation);return;}}
            if(d.startNative)starts.add(d.generation);
            if(d.resumeNative)resumes++;
        }
        void settled(long intent){owner.spotifyRejected(intent);observed(controller.state());}
        long uri(){PlaybackOwnership.Decision d=owner.spotifyIntent();apply(d);boolean sent=controller.playUri(TRACK,()->settled(d.generation));if(!sent)owner.spotifyRejected(d.generation);queue.drain();return d.generation;}
        long resume(){PlaybackOwnership.Decision d=owner.spotifyIntent();apply(d);boolean sent=controller.resume(()->settled(d.generation));if(!sent)owner.spotifyRejected(d.generation);queue.drain();return d.generation;}
        long nativeChoice(){SpotifyController.State s=controller.state();PlaybackOwnership.Decision d=owner.nativeIntent(s.sessionGeneration,s.playerRevision,s.available,s.playing,s.loading);apply(d);queue.drain();return d.generation;}
        void emit(boolean playing,long revision){remote.observer.changed(state(playing,revision));queue.drain();}
        void fail(int index){remote.calls.get(index).result.done(false);queue.drain();}
        void accepted(int index){remote.calls.get(index).result.done(true);queue.drain();}
        void read(int index,SpotifyController.Readout value){remote.reads.get(index).done(value);queue.drain();}
        void stop(){owner.clear();controller.stop();queue.drain();}
    }
    static void failedUriNeedsRealRead(){
        Bridge b=new Bridge();long intent=b.uri();yes(b.remote.calls.get(0).uri.equals(TRACK),"real URI normalizer feeds exact SDK transport");
        b.fail(0);yes(b.owner.pendingSpotifyStart()==intent&&b.remote.reads.size()==1,"false alone retains unknown start and requests real state");
        b.read(0,state(false,2));yes(b.owner.pendingSpotifyStart()==-1,"fresh Paused settles only rejected URI");
        b.nativeChoice();yes(b.starts.size()==1&&b.remote.calls.size()==1,"native after verified refusal starts without phantom Pause");
        Bridge nullRead=new Bridge();nullRead.uri();nullRead.fail(0);nullRead.read(0,null);nullRead.nativeChoice();
        yes(nullRead.starts.isEmpty()&&nullRead.owner.awaitingPause(),"query error cannot turn cached Paused into acknowledgement");
        Bridge stale=new Bridge();stale.uri();stale.fail(0);stale.read(0,state(false,1));stale.nativeChoice();
        yes(stale.starts.isEmpty(),"same cached revision cannot settle start");
    }
    static void modesDoNotSwallowStartFailure(){
        Bridge b=new Bridge();long intent=b.resume();yes(b.controller.setShuffle(true),"mode command accepted during pending resume");b.accepted(1);b.fail(0);
        yes(b.remote.reads.size()==1&&b.owner.pendingSpotifyStart()==intent,"later mode serial does not discard older start outcome");
        b.read(0,state(false,2));b.nativeChoice();yes(b.starts.size()==1,"verified failed resume cannot block next native choice");
    }
    static void staleQueriesCannotConfirmNewerCommands(){
        Bridge b=new Bridge();b.uri();b.fail(0);long newer=b.resume();long nativeIntent=b.nativeChoice();
        yes(b.remote.calls.get(2).command==SpotifyController.Command.PAUSE,"native waits for newer resume");
        b.read(0,state(false,2));yes(b.starts.isEmpty()&&b.owner.pendingSpotifyStart()==newer,"old query cannot publish Paused across newer transport command");
        yes(b.controller.state().playerRevision==1,"stale query does not manufacture a PlayerState revision");
        b.accepted(2);yes(b.remote.reads.size()==2,"successful handoff Pause verifies official state even if subscription emits nothing");
        b.read(1,state(false,3));yes(b.starts.size()==1&&b.starts.get(0)==nativeIntent,"fresh post-Pause read starts newest native action");
    }
    static void nativeAThenBAndLateEvents(){
        Bridge b=new Bridge();long start=b.uri();long a=b.nativeChoice(),c=b.nativeChoice();
        yes(c>a&&b.starts.isEmpty()&&b.owner.pendingSpotifyStart()==start,"successive native choices retain unresolved Spotify risk");
        b.fail(0);yes(b.starts.isEmpty(),"start failure is not a Pause acknowledgement");
        b.read(0,null);yes(b.starts.isEmpty(),"unknown read keeps both choices fenced");
        b.emit(true,2);yes(b.starts.isEmpty(),"late Playing cannot steal newest native intent");
        b.emit(false,3);yes(b.starts.size()==1&&b.starts.get(0)==c,"new authoritative Paused releases only native B");
        b.emit(true,4);b.emit(false,5);yes(b.resumes==1&&b.starts.size()==1,"late replay preserves queue and resumes once");
    }
    static void freshPlayingNeverMeansPaused(){
        Bridge b=new Bridge();b.uri();b.fail(0);b.read(0,state(true,2));b.nativeChoice();
        yes(b.starts.isEmpty()&&b.owner.awaitingPause(),"query confirms actual Playing so native still waits for real pause");
        b.emit(false,3);yes(b.starts.size()==1,"only actual Paused starts native");
    }
    static void stopAndNavigationInvalidateCallbacks(){
        Bridge b=new Bridge();b.uri();b.fail(0);b.nativeChoice();b.owner.nativePaused();b.read(0,state(false,2));
        yes(b.starts.isEmpty()&&b.resumes==0,"stale query cannot revive explicitly stopped native action");
        b.nativeChoice();yes(b.starts.isEmpty(),"native stop did not prove old in-flight Play settled");
        b.emit(false,3);yes(b.starts.size()==1,"fresh pause after retry restores only new action");
        Bridge stopped=new Bridge();stopped.uri();stopped.fail(0);stopped.stop();stopped.read(0,state(false,2));
        yes(stopped.starts.isEmpty()&&!stopped.controller.state().available,"navigation/stop drops old SDK reconciliation");
        Bridge replaced=new Bridge();replaced.uri();replaced.fail(0);replaced.controller.disconnect();replaced.read(0,state(false,2));
        yes(!replaced.controller.state().available&&replaced.starts.isEmpty(),"disconnect cannot be undone by delayed read");
    }
    static void lostConnectionRetainsUnknownRisk(){
        Bridge b=new Bridge();b.uri();b.remote.connected=false;b.controller.refresh();b.queue.drain();b.nativeChoice();
        yes(!b.controller.state().available&&b.starts.isEmpty(),"lost connection is not proof old Play did not execute");
        yes(b.owner.pendingSpotifyStart()!=-1,"unknown start remains fenced after failed handoff Pause");
    }
    static void rejectedNewAttemptPreservesOlderUnknown(){
        Bridge b=new Bridge();long a=b.uri();b.remote.observer.lost();b.queue.drain();long newer=b.resume();
        yes(newer>a&&b.owner.pendingSpotifyStart()==a,"preflight rejection of B preserves unknown sent A");
        b.nativeChoice();yes(b.starts.isEmpty(),"lost A cannot be erased by failed new intent before native selection");
    }
    static void newerReadWinsAndSubscriptionsCannotRollback(){
        Bridge b=new Bridge();b.uri();b.resume();b.fail(0);b.fail(1);
        yes(b.remote.reads.size()==2,"both rejected command outcomes are reconciled independently");
        b.read(0,state(false,2));yes(b.controller.state().playerRevision==1,"superseded read request cannot publish a fresh revision");
        b.read(1,state(false,3));b.nativeChoice();yes(b.starts.isEmpty(),"settling B alone does not erase unresolved A risk");
        b.accepted(2);b.read(2,state(false,4));yes(b.starts.size()==1,"verified latest Pause can settle all older risks");
        Bridge live=new Bridge();live.uri();live.fail(0);live.emit(true,3);live.read(0,state(false,2));
        yes(live.controller.state().playing&&live.controller.state().playerRevision==3,"older query response cannot replace newer subscribed Playing");
        live.nativeChoice();yes(live.starts.isEmpty(),"actual Playing still requires pause despite failed old request");
    }
    static void observedPlayingSurvivesControlLoss(){
        Bridge b=new Bridge();b.uri();b.emit(true,2);b.remote.observer.lost();b.queue.drain();
        b.nativeChoice();yes(b.starts.isEmpty(),"losing SDK control does not stop previously observed Playing");
        b.owner.nativePaused();b.nativeChoice();yes(b.starts.isEmpty(),"native stop/retry cannot erase last unrefuted Spotify Playing");
        b.controller.connect();Remote fresh=new Remote();b.remote=fresh;b.gateway.callback.connected(fresh);b.queue.drain();
        b.emit(false,1);b.nativeChoice();yes(b.starts.size()==1,"new authoritative session Paused releases known-playing risk on explicit retry");
    }
    static void thrownTransportRemainsUnknown(){
        Bridge b=new Bridge();b.remote.throwAfterSend=true;long intent=b.uri();
        yes(b.owner.pendingSpotifyStart()==intent&&b.remote.reads.size()==1,"exception after entering transport is unknown, not synchronous refusal");
        b.read(0,null);b.nativeChoice();yes(b.starts.isEmpty(),"ambiguous exception cannot authorize native from cached Paused");
    }
    public static void main(String[] args){failedUriNeedsRealRead();modesDoNotSwallowStartFailure();staleQueriesCannotConfirmNewerCommands();nativeAThenBAndLateEvents();freshPlayingNeverMeansPaused();stopAndNavigationInvalidateCallbacks();lostConnectionRetainsUnknownRisk();rejectedNewAttemptPreservesOlderUnknown();newerReadWinsAndSubscriptionsCannotRollback();observedPlayingSurvivesControlLoss();thrownTransportRemainsUnknown();System.out.println("PASS Controller->Ownership junction: "+checks+" checks (fresh SDK reads, correlated intents, no real account/audio)");}
}
