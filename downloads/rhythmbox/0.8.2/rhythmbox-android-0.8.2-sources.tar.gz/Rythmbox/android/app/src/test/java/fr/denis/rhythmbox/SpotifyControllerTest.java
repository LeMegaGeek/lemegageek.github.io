package fr.denis.rhythmbox;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** App Remote state-machine tests. The real official SDK is on the compile
 * classpath; test gateways replace only network/Android account boundaries.
 * No Android method, installed Spotify app, account or device is exercised here.
 */
public final class SpotifyControllerTest {
    static int checks;
    static final String ID="0123456789abcdef0123456789abcdef";
    static final String TRACK="spotify:track:2JRo0gjbX4GrCqBYdRohoo";
    static final String PLAYLIST="spotify:playlist:37i9dQZF1DXcBWIGoYBM5M";
    static void yes(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    static final class Queue implements SpotifyController.Dispatcher {
        final ArrayDeque<Runnable> jobs=new ArrayDeque<>();
        public void post(Runnable action){jobs.add(action);}
        void drain(){int bound=0;while(!jobs.isEmpty()){if(++bound>1000)throw new AssertionError("unbounded callback loop");jobs.remove().run();}}
    }
    static final class Gateway implements SpotifyController.Gateway {
        String id=ID;boolean enabled,installed=true;final List<Boolean> authorizations=new ArrayList<>();
        final List<SpotifyController.Connection> attempts=new ArrayList<>();
        public String clientId(){return id;}
        public void configure(String id){this.id=id;}
        public boolean enabled(){return enabled;}
        public void setEnabled(boolean value){enabled=value;}
        public boolean installed(){return installed;}
        public void connect(boolean authorize,SpotifyController.Connection callback){authorizations.add(authorize);attempts.add(callback);}
    }
    static final class Call {
        SpotifyController.Command command;long value;String uri;SpotifyController.Result result;
        Call(SpotifyController.Command command,long value,String uri,SpotifyController.Result result){this.command=command;this.value=value;this.uri=uri;this.result=result;}
    }
    static final class Remote implements SpotifyController.Remote {
        boolean connected=true;int closed,observations;SpotifyController.Observer observer;
        final List<Call> calls=new ArrayList<>();
        public boolean connected(){return connected;}
        public void observe(SpotifyController.Observer observer){observations++;this.observer=observer;}
        public void close(){closed++;connected=false;}
        public void perform(SpotifyController.Command command,long value,String uri,SpotifyController.Result result){calls.add(new Call(command,value,uri,result));}
        public void readState(SpotifyController.ReadResult result){result.done(null);}
    }
    static final class Fixture {
        final Gateway gateway=new Gateway();final Queue queue=new Queue();final List<SpotifyController.State> states=new ArrayList<>();
        final SpotifyController controller=new SpotifyController(gateway,queue,states::add);
        final Remote remote=new Remote();
        void start(){controller.start();queue.drain();}
        void connect(){start();yes(controller.connect(),"explicit SDK connection requested");gateway.attempts.get(gateway.attempts.size()-1).connected(remote);queue.drain();}
        void state(boolean playing,boolean allowed,boolean onDemand,boolean known){remote.observer.changed(readout(TRACK,playing,allowed,onDemand,known));queue.drain();}
    }
    static SpotifyController.Readout readout(String id,boolean playing,boolean allowed,boolean onDemand,boolean known){
        return new SpotifyController.Readout(id,"Synthetic title","Synthetic artist","Synthetic album",null,playing,150,1000,
            allowed,allowed,allowed,allowed,false,allowed?3:0,0,onDemand,known,0,0);
    }
    static void empty(SpotifyController.State s,String label){
        yes(!s.available&&!s.playing&&!s.hasAccess,label+" no playback/session");
        yes(s.id.isEmpty()&&s.title.isEmpty()&&s.artist.isEmpty()&&s.cover==null,label+" clears metadata");
        yes(!s.canPlay&&!s.canPause&&!s.canSeek&&!s.canNext&&!s.canPrevious&&!s.shufflePossible&&!s.repeatPossible,label+" no controls");
    }
    static void explicitConnectAndPersistence(){
        Fixture f=new Fixture();f.start();yes(f.gateway.attempts.isEmpty(),"first start never launches consent");
        yes(!f.controller.resume(),"no session cannot play");f.connect();
        yes(f.gateway.authorizations.size()==1&&f.gateway.authorizations.get(0),"only explicit connect requests auth view");
        yes(f.gateway.enabled&&f.remote.observations==1&&f.remote.calls.isEmpty(),"connection persists consent intent and only subscribes");
        yes(f.controller.state().available&&!f.controller.state().playing,"connected without track does not fake playback");
        f.state(false,true,true,true);yes(f.controller.state().title.equals("Synthetic title"),"subscribed metadata is displayed");
        yes(f.controller.state().positionNow()==150&&f.controller.state().duration==1000,"milliseconds preserved");
        long generation=f.controller.state().sessionGeneration;f.controller.stop();f.queue.drain();
        yes(f.remote.closed==1&&f.remote.calls.isEmpty(),"activity lifecycle disconnects without surprise playback command");
        yes(f.controller.state().sessionGeneration>generation,"stop changes session generation");empty(f.controller.state(),"stop");
        f.controller.start();f.queue.drain();yes(f.gateway.attempts.size()==2&&!f.gateway.authorizations.get(1),"reopen reconnects silently");
        f.controller.disconnect();f.queue.drain();yes(!f.gateway.enabled,"explicit disconnect disables future reconnection");
    }
    static void missingConfigurationAndApp(){
        Fixture f=new Fixture();f.gateway.id="";f.start();yes(!f.controller.connect()&&f.gateway.attempts.isEmpty(),"no invented client ID or fake connection");
        yes(f.controller.state().status.contains("Client ID"),"missing app registration explained");
        for(String id:new String[]{"spotify","not a client secret","0",ID+"1"}){boolean rejected=false;try{f.controller.configure(id);}catch(IllegalArgumentException e){rejected=true;}yes(rejected,"invalid public ID rejected");}
        f.controller.configure(" "+ID+" ");yes(f.controller.configured(),"valid public client ID accepted");
        f.gateway.installed=false;yes(!f.controller.connect()&&f.gateway.attempts.isEmpty(),"missing official app prevents connection");
        yes(f.controller.state().status.contains("Installe"),"missing app explained");
    }
    static void staleAndReplacedSessions(){
        Fixture f=new Fixture();f.start();f.controller.connect();SpotifyController.Connection first=f.gateway.attempts.get(0);
        f.controller.stop();Remote late=new Remote();first.connected(late);f.queue.drain();yes(late.closed==1&&late.observations==0,"late connection after stop is closed without observing");empty(f.controller.state(),"late connection");
        f.controller.start();f.queue.drain();Remote active=new Remote();f.gateway.attempts.get(1).connected(active);f.queue.drain();
        SpotifyController.Observer stale=active.observer;stale.changed(readout(TRACK,true,true,true,true));f.queue.drain();
        yes(f.controller.state().playing,"active SDK state is observed");f.controller.configure(ID);f.queue.drain();
        stale.changed(readout(TRACK,true,true,true,true));stale.lost();f.queue.drain();empty(f.controller.state(),"configuration switch rejects stale player events");
        yes(active.closed==1,"old connection disconnected on config switch");
        f.controller.connect();f.gateway.attempts.get(2).failed("secret=https://token/private");f.queue.drain();
        yes(f.controller.state().status.contains("AppRemoteError")&&!f.controller.state().status.contains("token"),"raw provider error text never exposed");
    }
    static void authoritativePlaybackAndFailures(){
        Fixture f=new Fixture();f.connect();f.state(false,true,true,true);
        yes(f.controller.resume(),"resume accepted for dispatch");yes(!f.controller.state().playing,"dispatch does not optimistically assert playback");
        Call play=f.remote.calls.get(0);yes(play.command==SpotifyController.Command.PLAY,"resume reaches official transport boundary");
        play.result.done(true);f.queue.drain();yes(!f.controller.state().playing,"RPC success alone is not proof of audible playback");
        f.state(true,true,true,true);yes(f.controller.state().playing,"only observed PlayerState confirms playback");
        yes(f.controller.pause(),"pause requested");Call pause=f.remote.calls.get(1);pause.result.done(false);f.queue.drain();
        yes(f.controller.state().playing&&f.controller.state().status.contains("confirmé"),"unknown failure preserves authoritative playback state");
        yes(f.controller.next(),"next accepted");Call next=f.remote.calls.get(2);
        f.controller.disconnect();next.result.done(false);f.queue.drain();empty(f.controller.state(),"late command error does not revive disconnected state");
    }
    static void capabilitiesAndMusicReferences(){
        Fixture f=new Fixture();f.connect();f.state(false,false,false,true);
        yes(!f.controller.next()&&!f.controller.previous()&&!f.controller.seekTo(50)&&!f.controller.setShuffle(true)&&!f.controller.setRepeat(1),"SDK restrictions disable unsupported commands");
        yes(!f.controller.playUri(TRACK),"on-demand track denied for restricted account");
        yes(f.controller.playUri(PLAYLIST),"playlist stays subject to Spotify own playback rules");
        f.state(false,true,true,false);yes(!f.controller.playUri(TRACK),"unknown account capabilities cannot imply on-demand access");
        f.state(false,true,true,true);int before=f.remote.calls.size();
        yes(f.controller.playUri("https://open.spotify.com/intl-fr/track/2JRo0gjbX4GrCqBYdRohoo?si=discarded"),"official link can be selected in Rhythmbox");
        yes(f.remote.calls.get(before).uri.equals(TRACK),"only normalized URI reaches SDK");
        yes(f.controller.seekTo(5000),"seek beyond duration clamped");yes(f.remote.calls.get(before+1).value==1000,"seek bounded to known duration");
        yes(!f.controller.seekTo(-1)&&!f.controller.setRepeat(3),"invalid seek/repeat values not dispatched");
        yes(f.controller.setShuffle(true)&&f.controller.setRepeat(2)&&f.controller.previous()&&f.controller.next(),"shuffle repeat previous next all use official SDK boundary");
        f.remote.connected=false;f.controller.refresh();f.queue.drain();empty(f.controller.state(),"lost SDK connection");
    }
    static void pauseBeforeFirstTrack(){
        Fixture f=new Fixture();f.connect();
        yes(f.controller.state().available&&f.controller.state().id.isEmpty()&&!f.controller.state().canPause,"connected before metadata keeps visible pause unavailable");
        yes(f.controller.pause(),"handoff may cancel pending SDK playback before first Track");
        yes(f.remote.calls.size()==1&&f.remote.calls.get(0).command==SpotifyController.Command.PAUSE,"no-track pause reaches only connected official SDK");
        f.controller.disconnect();yes(!f.controller.pause(),"disconnected no-track pause still fails closed");
    }
    static void strictUris(){
        yes(SpotifyUri.parse(TRACK).equals(TRACK),"canonical URI accepted");yes(SpotifyUri.link(TRACK).equals("https://open.spotify.com/track/2JRo0gjbX4GrCqBYdRohoo"),"attribution URL derived from validated URI");
        String[] invalid={"https://open.spotify.com.evil/track/2JRo0gjbX4GrCqBYdRohoo","http://open.spotify.com/track/2JRo0gjbX4GrCqBYdRohoo","https://name@open.spotify.com/track/2JRo0gjbX4GrCqBYdRohoo","https://open.spotify.com:443/track/2JRo0gjbX4GrCqBYdRohoo","spotify:track:short","spotify:track:2JRo0gjbX4GrCqBYdRohoo:extra","https://open.spotify.com/track/%32JRo0gjbX4GrCqBYdRohoo","file:///tmp/music","https://spotify.link/anything","https://open.spotify.com/track/2JRo0gjbX4GrCqBYdRohoo#extra"};
        for(String input:invalid){boolean rejected=false;try{SpotifyUri.parse(input);}catch(IllegalArgumentException e){rejected=true;}yes(rejected,"untrusted reference rejected: "+input);}
    }
    static void realSdkModels(){
        SpotifyController.Readout empty=SpotifyController.sdkReadout(null,null,true,true,123);
        yes(empty.id.isEmpty()&&empty.capabilitiesKnown&&empty.canPlayOnDemand,"capabilities survive before first track for initial URI playback");
        com.spotify.protocol.types.Artist artist=new com.spotify.protocol.types.Artist("Artist","spotify:artist:2JRo0gjbX4GrCqBYdRohoo");
        com.spotify.protocol.types.Album album=new com.spotify.protocol.types.Album("Album","spotify:album:2JRo0gjbX4GrCqBYdRohoo");
        com.spotify.protocol.types.Track track=new com.spotify.protocol.types.Track(artist,java.util.Collections.singletonList(artist),album,9000,"Track",TRACK,null,false,false);
        com.spotify.protocol.types.PlayerRestrictions restrictions=new com.spotify.protocol.types.PlayerRestrictions(true,false,true,false,true,true);
        com.spotify.protocol.types.PlayerState playing=new com.spotify.protocol.types.PlayerState(track,false,1,2600,new com.spotify.protocol.types.PlayerOptions(true,2),restrictions);
        SpotifyController.Readout result=SpotifyController.sdkReadout(playing,null,true,true,700);
        yes(result.id.equals(TRACK)&&result.title.equals("Track")&&result.artist.equals("Artist")&&result.album.equals("Album"),"real SDK track/artist/album map correctly");
        yes(result.playing&&result.position==2600&&result.duration==9000&&result.observedAt==700,"SDK playback anchor retained across artwork/capabilities events");
        SpotifyController.Readout revision=SpotifyController.sdkReadout(playing,null,true,true,700,9);
        SpotifyController.Readout capabilityRefresh=SpotifyController.sdkReadout(playing,null,false,true,700,9);
        yes(new SpotifyController.State(revision,true,false,"state",4).playerRevision==9,"real PlayerState revision reaches presentation");
        yes(new SpotifyController.State(capabilityRefresh,true,false,"capabilities",4).playerRevision==9&&capabilityRefresh.observedAt==700,"capability/art/status redraw cannot impersonate a new PlayerState confirmation");

        yes(result.canNext&&!result.canPrevious&&result.canSeek&&result.canShuffle&&result.shuffled&&result.repeatMode==2,"SDK restrictions/options map without inventing capabilities");
        SpotifyController.Readout unknown=SpotifyController.sdkReadout(new com.spotify.protocol.types.PlayerState(track,true,1,100,null,null),null,false,false,0);
        yes(!unknown.playing&&!unknown.canNext&&!unknown.canSeek&&!unknown.canShuffle&&!unknown.capabilitiesKnown,"missing restriction objects fail closed");
        Fixture f=new Fixture();f.connect();
        com.spotify.protocol.types.PlayerRestrictions contextOnly=new com.spotify.protocol.types.PlayerRestrictions(true,true,false,true,true,true);
        f.remote.observer.changed(SpotifyController.sdkReadout(new com.spotify.protocol.types.PlayerState(track,true,1,100,new com.spotify.protocol.types.PlayerOptions(false,0),contextOnly),null,true,true,0));f.queue.drain();
        yes(f.controller.state().canRepeatContext&&!f.controller.state().canRepeatTrack,"asymmetric SDK repeat capabilities preserved");
        yes(!f.controller.setRepeat(1),"track repetition cannot bypass context-only restriction");
        yes(f.controller.cycleRepeat(),"context-only repeat cycle can dispatch");
        yes(f.remote.calls.get(f.remote.calls.size()-1).command==SpotifyController.Command.REPEAT&&f.remote.calls.get(f.remote.calls.size()-1).value==2,"repeat cycle skips unsupported track mode");
        com.spotify.protocol.types.PlayerRestrictions trackOnly=new com.spotify.protocol.types.PlayerRestrictions(true,true,true,false,true,true);
        f.remote.observer.changed(SpotifyController.sdkReadout(new com.spotify.protocol.types.PlayerState(track,true,1,100,new com.spotify.protocol.types.PlayerOptions(false,1),trackOnly),null,true,true,0));f.queue.drain();
        yes(!f.controller.setRepeat(2)&&f.controller.cycleRepeat(),"track-only repeat rejects context and cycles to off");
        yes(f.remote.calls.get(f.remote.calls.size()-1).value==0,"unsupported repeat mode never blocks return to off");

    }
    public static void main(String[] arguments){explicitConnectAndPersistence();missingConfigurationAndApp();staleAndReplacedSessions();authoritativePlaybackAndFailures();capabilitiesAndMusicReferences();strictUris();realSdkModels();pauseBeforeFirstTrack();System.out.println("PASS Spotify App Remote controller: "+checks+" checks (host state machine, no real account/device)");}
}
