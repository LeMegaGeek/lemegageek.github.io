# Construire une version Google Play

L'identifiant stable est `fr.denis.rhythmbox`. Les sources préparent
**0.8.2 (code 17)**, Android 8 minimum
(API 26) et cible Android 16 (API 36). La politique de
[cible Android de Google Play](https://developer.android.com/google/play/requirements/target-sdk)
doit être vérifiée au moment de la livraison.

Le code 15 ajoute le SDK officiel Spotify App Remote 0.8.0 et Gson 2.11.0,
épinglés par SHA-256. Exécuter `bash android/prepare-spotify.sh` avant le build.
Le service d’accès aux notifications est retiré ; la connexion et la lecture
passent par Spotify installé. Aucun secret n’est incorporé. Le Client ID public
et les empreintes de signature doivent être enregistrés chez Spotify avant un
essai connecté. Voir [SPOTIFY-APP-REMOTE.md](SPOTIFY-APP-REMOTE.md) pour les limites,
les notices et la distinction entre compilation, tests hôtes et vrai compte.
La construction de ce candidat ne constitue ni une publication Google Play ni
une validation de l’accès public aux services Spotify.

Le code 17 corrige les bandes basses de l’analyseur stéréo natif : certaines
barres ne recevaient aucun point du calcul FFT et restaient au minimum,
même lorsqu’un signal était présent. Ce correctif concerne la bibliothèque,
pCloud et Suno. Il n’ajoute pas d’analyse de l’audio Spotify : App Remote
commande toujours le lecteur officiel sans fournir son signal PCM.

Le code 16 corrige les retours tardifs et les erreurs de commande App Remote.
Un refus ou une perte de connexion ne vaut pas confirmation de pause : Rhythmbox
vérifie un état frais dans Spotify avant de démarrer la bibliothèque ou Suno.
Un nouvel essai refusé conserve aussi les lancements précédents dont l'issue
reste inconnue. Les réponses d'une ancienne commande ou session ne peuvent
relancer une action native annulée ni remplacer un choix plus récent.

Les paragraphes suivants décrivent les preuves historiques du code 14.

Le code 14 ajoute un **cache privé pCloud de 512 Mio**, avec préchargement du
morceau suivant et réutilisation locale des originaux encore valides. Les reçus
du cache sont liés à la région, au compte, au dossier choisi, au fichier, à son
chemin et à sa version connue. Un nouvel index vérifié invalide les anciennes
copies lorsqu’un fichier a changé, a été déplacé ou a disparu. Un hit valide
n’exige pas d’appel API ou CDN. La limite par fichier reste de 256 Mio.

Les **copies hors connexion** concernent seulement les listes explicitement
choisies et liées au compte musical et à son dossier. Les morceaux masqués,
en quarantaine, Suno et de démonstration sont exclus. Sous API 29 et ultérieur,
MediaStore Audio publie les originaux dans **Music/Rhythmbox/** en conservant
l’arborescence des albums, sans sélecteur de dossier ni permission de stockage
générale. Sous API 26–28, le repli utilise le dossier externe Musique propre à
l’application. Les octets sont relus et vérifiés par SHA-256 avant publication ;
les fichiers existants ne sont pas remplacés et les collisions créent des noms
comme **Titre (2).flac**. Le journal privé permet de reprendre fichier par fichier
et l’annulation conserve les copies terminées. Les vidéos et conteneurs sans
attestation audio sont comptés comme non copiés, sans modifier leurs références
ou leur lecture habituelle.

Le lecteur natif de la 0.7.0 utilise le **PCM mono ou stéréo** des formats pris en
charge pour le gain de lecture et l’analyseur gauche/droite. Celui-ci représente
le signal source avant le traitement du niveau, sans microphone ni capture audio globale. Un format passant
par le lecteur Android de repli peut annoncer l’analyseur indisponible. Spotify
reste une application externe : Rhythmbox pilote sa session et affiche ses
métadonnées, sans analyser son audio, appliquer son gain ou le copier hors ligne.

La révision locale **r4 du code 14/0.7.0** est installée sur le Motorola
LineageOS. Son APK a pour SHA-256
`58ccb3acc9c9649646414a346c06417a3bbe74074ff7a1c5637c9e717f10d23f`.
La mise à jour de même signature a conservé les octets de la bibliothèque et la
date de première installation, sans désinstallation, effacement, nouvelle
permission ou modification de réglages système. La r4 ne change que le libellé
de l’analyseur par rapport à la r3. Voir
`dist/pcloud-resume-20261103/android-code14-r4-install.json`.

Les contrôles physiques de la r3 ont confirmé le cache persistant après mise
à jour en 1 538 ms, le morceau suivant préchargé en 1 446 ms, la recherche de
position, pause/reprise/arrêt et de vraies mesures PCM gauche/droite. Ces délais
restent propres aux morceaux et à l’appareil essayés. Voir
`dist/pcloud-resume-20261103/android-code14-r3-playback-ui.json`.

Sur la r4, Test a produit deux copies publiques dans
**Music/Rhythmbox/Muse/Showbiz/**, soit **17 861 086 octets**, relues avec les
SHA-256 des originaux. Une seconde synchronisation a réutilisé les mêmes deux
URI sans doublon ni sélecteur de dossier. Un contrôle séparé a écarté
temporairement le cache privé du premier morceau, puis confirmé sa restauration
identique depuis la copie publique, le libellé **Dossier musical hors ligne**
et l’analyse G/D. Les fichiers publics ont été préservés et la sauvegarde
technique temporaire a été nettoyée. Voir
`dist/pcloud-resume-20261103/android-code14-r4-offline-ui.json` et
`android-code14-r4-offline-playback.json`.

**Le réseau est resté activé pendant ce contrôle : le parcours local depuis
la copie publique est validé, pas une déconnexion globale en mode avion ni
l’absence de tout trafic de l’application.** Les contrôles hôtes de concurrence
et de journal simulé restent consignés séparément dans
`dist/pcloud-resume-20261103/android-cache-source.json`. Le pont observé le
3 novembre sur Test a inclus une intervention manuelle initiale : le bouton
public Linux **Vérifier après une synchronisation interrompue**, après un ajout
concurrent de C pendant un lot ayant capturé A/B. Les propagations A/B/C de
Linux vers pCloud puis Android et le retour A/B d’Android vers pCloud puis Linux
ont ensuite été automatiques, sans bouton de synchronisation manuelle. Test a
retrouvé ses deux références et Mon top ses 363 références audio partagées ;
voir `bridge-native-automatic.json` et `bridge-android-automatic.json` dans le
même dossier. Ce parcours ne constitue pas un cycle physique entièrement sans
intervention.

La cause de cette interruption Linux a ensuite été corrigée dans
`rb_adapter.py` : ordre variable d’un même ensemble de favoris et modification
concurrente de Test. Les **219 tests unitaires** et la revue indépendante sont
consignés dans `linux-outgoing-favorites-source.json`, l’installation dans
`linux-outgoing-favorites-install.json`. Aucun nouveau cycle physique complet
de cette correction n’est revendiqué. `final-state-validation.json` confirme
un redémarrage normal sans transaction en attente. Une ancienne liste de
conflit de 309 références a été sauvegardée en M3U puis retirée après vérification
que toutes ses références figuraient déjà dans Mon top natif ; ses 366 références
(363 audio partagées et 3 locales seules) et Test sont restées inchangées,
sans opération sur les fichiers audio ni mutation cloud. Voir
`legacy-top-conflict-cleanup.json`.

La **publication Google Play n’est pas effectuée**. Les essais physiques sous
API 26–28, les formats de repli non essayés et un intervalle Android périodique
complet sans intervention restent distincts des preuves ci-dessus. Avant
diffusion, publier la politique et les sources correspondant à l’artefact livré,
puis vérifier les déclarations du magasin. Les artefacts des codes précédents
restent des preuves historiques distinctes.

Le code 13 corrigeait la reprogrammation du travail périodique pCloud : un travail
identique déjà enregistré doit être conservé, y compris pendant son exécution.
Sur le Motorola LineageOS, le code 12 remplaçait ce travail après chaque commit
et provoquait une nouvelle exécution environ toutes les 22 secondes.
Le code 13 a passé les 387 assertions pCloud ciblées et la compilation des
42 sources contre le SDK 36. Il avait été installé sur le Motorola sans effacement,
avec connexion et listes conservées. Un travail réel, déclenché pour le test
en anticipant son délai, a committé en arrière-plan puis terminé normalement ;
75 secondes d’observation n’ont montré aucun redémarrage immédiat. Le réseau
et la batterie satisfaisaient les contraintes. Un intervalle périodique complet
sans intervention et l’exécution sous API 26 ne sont pas revendiqués.
Voir `dist/pcloud-resume-20261102/android-code13-background.json`.
Aucune publication Google Play n’a été effectuée pendant cette reprise.

Le code 12 ajoute un diagnostic pCloud limité à des étapes, catégories et
codes sûrs. Les contrôles d’identité, de dossier, de concurrence et les journaux
restent actifs. Aucun jeton, corps de réponse ou message réseau brut ne doit
être affiché. Ses 1 861 assertions hôtes et neuf comparaisons FFmpeg ont passé.
Installé par mise à jour de même signature sur le Motorola, il a permis de
vérifier la connexion persistante du compte musical, My Music, Mon top
(309 références) et Test (2 références). L’essai contrôlé a confirmé un retrait
Android transmis automatiquement et committé, puis le retour automatique du
contenu initial après réouverture. La liste Test a été restaurée dans son ordre
initial et aucune liste de récupération n’a été laissée. Ces preuves sont dans
`dist/pcloud-resume-20261102/android-code12-outbound-diagnostic.json` et
`android-code12-clean-final-state.json`. Ces preuves historiques sont distinctes
du pont avec l’application Linux ouverte vérifié le 3 novembre ci-dessus.

Le candidat 0.6.2 ajoute **Uniformiser le volume** dans **Réglages → Lecture**, désactivé par défaut : analyse préalable, cache privé de mesures et gain fixe par morceau, sans modification des originaux. L’atténuation reste disponible dès API 26 ; l’amplification positive nécessite DynamicsProcessing sous API 28 ou ultérieur et une session mono ou stéréo compatible. Un effet indisponible conserve le niveau d’origine et le signale. Aucune permission de microphone n’est ajoutée en production. Voir [la portée et les limites de l’option](../docs/VOLUME.md).

Le code 11 a passé **1 769 assertions hôtes et neuf comparaisons FFmpeg**. L’instrumentation audio API 36 a ensuite passé **71 assertions dans six scénarios, sans échec**. Les gains +5,9938, +12 et −12,0064 dB ont été mesurés à +5,98, +11,99 et −12,01 dB sur la sortie réelle de l’émulateur. La désactivation de l’effet restitue les RMS initiaux sans changer le volume système. Ces preuves emploient des médias synthétiques et un APK de test isolé, sans microphone ; elles sont consignées dans `dist/android-volume-native-validation.json`. Le build debug de l’application complète et l’AAB release signé ont été préparés et validés localement sous `android/build/`. L’APK debug exact a passé cinq contrôles UI : OFF par défaut, activation mémorisée après arrêt et relance du processus, lecture de la démo native avec gain annoncé de +6,2 dB, touche multimédia Pause et retour au statut désactivé après OFF. Voir `dist/android-volume-ui/validation.json` pour son empreinte et les résultats.

Le code 11 a été installé le 2 novembre sur le Motorola sous LineageOS par
mise à jour de même signature, sans désinstallation ni effacement. La connexion
au compte musical, My Music et les listes Mon top (309 références) et Test
(2 références) ont été vérifiées après une relance du processus. Un retrait
depuis Android a atteint pCloud automatiquement. Le retour complet n’est pas
encore validé : les essais ont laissé une opération non confirmée, conservée
dans le journal et relue par la récupération publique de l’application.
Les rapports restent dans `dist/pcloud-resume-20261102/` ; ils ne prouvent pas
encore la synchronisation native Linux ni l’achèvement du parcours dans les
deux sens.

Le candidat 0.6.1/code 10 corrigeait le contrôle du premier dossier musical pCloud. Ses 45 nouvelles assertions, les suites pCloud ciblées de 295 assertions et la suite complète de 1 739 assertions sont conservées avec ses builds sous `dist/pcloud-0.6.1-candidate/`. L’APK signé par Google a été installé par mise à jour sans désinstaller l’application avant l’incident. Les archives du code 10 restent distinctes des nouvelles sources ; cette installation ne prouve pas le bon état actuel des autorisations ou des données.

Le candidat précédent 0.6.0/code 9 reste conservé sous `dist/pcloud-0.6.0-candidate/`, sans publication ni installation sur le téléphone. Sa suite hôte a passé 1 694 assertions et son APK debug a pour SHA-256 `4b3f3fefb7826bf36adc0cce0f74c6e71be291a03977e82b5d989eb25f99fb34`. Ses preuves ne valident pas le correctif de dossier du code 10. Les archives immuables de la 0.5.2 restent sous `dist/pcloud-0.5.2-candidate/` ; le brouillon Play code 7 et les artefacts déjà publiés restent distincts des nouveaux candidats.

La 0.6.0 ajoute l’onglet **Services** : pilotage de l’application Spotify locale avec autorisation Android explicite d’accès aux notifications, et lecture native de morceaux ou playlists publics Suno ajoutés par lien. Les catalogues Suno restent séparés des listes pCloud. Le contrôleur Spotify filtre les sessions par application et utilisateur, ignore le contenu des notifications et demande un filtre système nul à partir d’API 31. L’écoute Suno n’emprunte pas de cookies ni de compte et utilise seulement les droits invité ordinaires, sans achat ni crédit ; son tampon audio reste en mémoire. Les commandes communes attendent la confirmation de pause Spotify avant un lancement natif. Le candidat reprend aussi la protection des vidéos préparée en 0.5.3 : références audio seules dans les collections pCloud, vidéos attestées conservées dans la liste locale complète, blocage des vidéos ambiguës ou déjà partagées avant mutation. Les flux externes non attestables dans une liste pCloud restent bloquants.

## Outils et commandes

Pour préparer le candidat sans remplacer les artefacts déjà diffusés, utiliser
`python3 scripts/android_build.py release --stage-only`. Le bundle, l'APK et
les sources correspondantes restent dans `android/build/release/`.
`debug --stage-only` conserve aussi ses fichiers sous `android/build/debug/`.
La connexion principale ouvre la page officielle pCloud avec un identifiant de
tentative privé, puis récupère son jeton via `pcloud_oauth2_token`. Elle emploie
notre propre identifiant **rhythmbox-musique**, sans identifiant ou secret emprunté
au client pCloud. Le choix temporaire/persistant fait chez pCloud est respecté.
Ce parcours ne dépend pas de l’enregistrement OAuth approuvé le 1er novembre
2026 : **Rhythmbox Musique LeMegaGeek**, identifiant public **HA4srpzRXF7**,
accès **Specific folder only** (Private dans le courriel), écriture autorisée
et parcours implicite activé. Le champ de retour était encore vide dans la
console au contrôle. Les connexions directes existantes sont conservées ;
aucune migration de jeton ni validation OAuth de My Music n’a eu lieu.
Les App Links existants restent propres au parcours OAuth enregistré.

Le compte doit rester exclusivement musical : les contrôles du client ne
réduisent pas les droits du jeton sur le serveur. Avant une livraison, consigner
les essais réels de connexion et de synchronisation dans les deux sens, puis
mettre à jour la politique de confidentialité, les notes de version et les
déclarations Google Play. L'ancienne version 0.5.0 a rencontré une erreur 1022
sur le service réel ; 0.5.1 a également rencontré un échec générique au retour du navigateur sur Android. La 0.5.2 conserve la tentative après interruption réseau, reprend userinfo avec le jeton déjà reçu et donne une étape/code diagnostiques pour les refus terminaux. La tentative principale reste en mémoire dans l’activité : sa destruction demande de recommencer la connexion. Un test simulé ne suffit pas à déclarer la connexion réelle résolue.

Les essais de modules restent identifiés séparément : Spotify a été vérifié avec le vrai framework multimédia API 36 et des sessions fictives ; Suno avec les codecs Android AAC/Opus et des données synthétiques. L’APK debug code 9 a également passé dix contrôles UI pCloud et huit contrôles Services sur émulateur, dont la lecture native réelle du lien public Suno fourni et ses commandes reprise/pause/arrêt. Ils ne constituent pas des tests du moteur PCM ou des copies hors connexion du code 14. Les essais pCloud des codes 12 et 13 décrits plus haut ne valident pas davantage ces nouvelles fonctions. L’autorisation Spotify et les commandes d’un vrai compte Spotify, ainsi que l’écoute Suno intégrale sur téléphone, restent à consigner avant de les annoncer comme acquises. Le fichier `android/play/site/confidentialite.html` est un brouillon local pour la 0.7.0/code 14 ; son édition ne modifie pas le site public. La politique, les sources et les déclarations du magasin doivent correspondre à l’artefact effectivement livré.

```sh
./android/prepare-toolchain.sh
./android/test.sh
./android/build.sh
./android/build-release.sh
```

Python 3.11 ou ultérieur, JDK 17 ou 21 et outils Unix doivent être installés. Les outils officiels Google sont
téléchargés dans `android/.toolchain/`, avec versions et SHA256 épinglés dans
`scripts/android_toolchain.py`. Aucune commande n'accepte automatiquement une
licence (`sdkmanager --licenses` n'est pas appelé). Les notices des distributions
SDK restent conservées dans le cache. Le build n'utilise pas de SDK global.

AAPT2 Maven compile les ressources et produit un manifeste protobuf ; javac et
D8 compilent le Java. Bundletool construit et valide l'AAB. Le bundle est signé
par jarsigner, puis un APK universel est généré et sa signature est vérifiée par
apksigner. Cette procédure suit le
[build en ligne de commande officiel](https://developer.android.com/build/building-cmdline).
L'application Java n'embarque pas de bibliothèque native.

Les variantes restent séparées : le manifeste de production est explicitement
non débogable ; seul le manifeste temporaire du build debug autorise le
débogage nécessaire aux essais d'émulateur.

## Signature privée

La première compilation release génère une clé d'upload RSA 4096 distincte de la
clé debug. Elle est conservée dans
`~/.local/share/rhythmbox-android/signing/` (dossier 0700, fichiers 0600), hors du
projet et du dossier musical pCloud. Le mot de passe aléatoire reste dans ce
dossier et n'est jamais affiché ni passé en clair sur la ligne de commande.
Le build refuse de remplacer une clé existante ou une signature incomplète.

Le chemin peut être fourni par `RBX_ANDROID_SIGNING_DIR` ou `--signing-dir`.
Il doit rester hors du projet, dans un emplacement privé non synchronisé.
Conserver une sauvegarde privée de cette signature pour les futures mises à jour.
Seul le certificat **public** est exporté. Les clés et profils privés ne figurent
ni dans les APK/AAB ni dans l'archive de sources.

Une APK release signée différemment ne remplace pas l'ancienne APK debug sur un
téléphone. Aucun désinstalleur ni effacement de données personnelles n'est lancé
par ces scripts ; les essais se font sur un émulateur isolé ou via une piste de
test Play. Avec Play App Signing, Google gère la clé de distribution et la clé
locale sert à l'upload.

## Fichiers produits

- `dist/rhythmbox-android-release.aab` : bundle à importer dans Play Console.
- `dist/rhythmbox-android-release.apk` : APK universel dérivé du bundle pour les essais.
- `dist/rhythmbox-upload-certificate.pem` : certificat public d'upload.
- `dist/rhythmbox-android-<version>-sources.tar.gz` : sources GPL, ressources et scripts de build/test correspondant à la version construite ; les archives 0.4.0 et 0.5.2 restent conservées séparément.
- `dist/android-play-release-validation.json` : versions, signatures et empreintes vérifiées.

Les artefacts ont chacun un SHA256. Le rapport de build ne signifie pas que
l'application est publiée ou qu'un téléphone a été testé : ces étapes sont
suivies séparément. Les exigences d'accès au compte Play, de fiche magasin,
de confidentialité et de piste de test restent à satisfaire dans la console.

Le champ `publication_readiness` distingue la validité du bundle de la préparation
du magasin : URL HTTPS de confidentialité et de sources renseignées dans
`publication.xml`, contact public dans `play/fr-FR.json`, fichiers de captures
et vidéo du service multimédia. Les URL vides sont signalées comme bloquantes.
Ces contrôles locaux ne prouvent pas que les pages sont publiques, que les
captures et la vidéo ont été examinées, ni que les déclarations et l'accès à la
production sont validés dans Play Console. Le build ne fait aucun contrôle
réseau caché et n'accepte aucune déclaration au nom du propriétaire.

## Piste de livraison

La préparation du 29 octobre 2026 vise un **test fermé** pour l'application
`fr.denis.rhythmbox`. Pour cette application, Play Console impose douze testeurs
inscrits pendant quatorze jours continus avant la demande d'accès à la production.
Un bundle signé et un test d'émulateur réussis ne remplissent pas cette condition.
Les candidats précédents sont conservés sous `dist/candidates/` avec leur scope
de validation ; seul le candidat corrigé et revérifié doit servir au téléversement.
