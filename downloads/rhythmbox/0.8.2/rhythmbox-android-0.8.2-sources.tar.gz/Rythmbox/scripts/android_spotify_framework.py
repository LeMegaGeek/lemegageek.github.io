#!/usr/bin/python3
"""Build/run historical 0.7 Spotify MediaSession fixtures on API36 QEMU.

No Internet permission, production package, real Spotify installation, account
or physical device is used. The Spotify package fixture is installed only when
absent and all packages created by this run are removed afterward.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile

from android_build import Tools, run, write_zip_entry

ROOT = Path(__file__).resolve().parents[1]
HARNESS = 'fr.denis.rhythmbox.spotifytest'
SPOTIFY = 'com.spotify.music'
FOREIGN = 'fr.denis.rhythmbox.foreignspotifyfixture'
COMPONENT = HARNESS + '/fr.denis.rhythmbox.SpotifyNotificationListener'
PERMISSION = HARNESS + '.CONTROL_FIXTURE'
FIXTURE_CLASS = 'fr.denis.rhythmbox.spotifyfixture.FixtureService'
TEST_ACTIVITY = 'fr.denis.rhythmbox.SpotifyFrameworkProbeActivity'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def manifest(package, harness):
    common = f'''<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="{package}" android:versionCode="1" android:versionName="isolated-framework-test">
<uses-sdk android:minSdkVersion="26" android:targetSdkVersion="36"/>
<uses-permission android:name="{PERMISSION}"/>
'''
    if harness:
        return common + f'''<permission android:name="{PERMISSION}" android:protectionLevel="signature"/>
<queries><package android:name="{SPOTIFY}"/><package android:name="{FOREIGN}"/></queries>
<application android:label="Rhythmbox isolated Spotify framework test" android:debuggable="true" android:testOnly="true" android:allowBackup="false" android:usesCleartextTraffic="false" android:theme="@android:style/Theme.Material.Light.NoActionBar">
<activity android:name="{TEST_ACTIVITY}" android:exported="true"/>
<service android:name="fr.denis.rhythmbox.SpotifyNotificationListener" android:label="Isolated Spotify MediaSession test" android:exported="false" android:permission="android.permission.BIND_NOTIFICATION_LISTENER_SERVICE">
<intent-filter><action android:name="android.service.notification.NotificationListenerService"/></intent-filter>
<meta-data android:name="android.service.notification.default_filter_types" android:value="@string/listener_filter_none"/>
<meta-data android:name="android.service.notification.disabled_filter_types" android:value="conversations|alerting|silent|ongoing"/>
</service></application></manifest>'''
    return common + f'''<application android:label="Synthetic offline {package} session fixture" android:debuggable="true" android:testOnly="true" android:allowBackup="false" android:usesCleartextTraffic="false">
<service android:name="{FIXTURE_CLASS}" android:exported="true" android:permission="{PERMISSION}"/>
</application></manifest>'''


def build(tools, stage, package, sources, key):
    destination = stage / package
    if destination.is_symlink():
        raise ValueError('Symbolic fixture stage refused')
    if destination.exists():
        shutil.rmtree(destination)
    destination.mkdir()
    for name in ('classes', 'generated', 'dex', 'res/values'):
        (destination / name).mkdir(parents=True, exist_ok=True)
    xml = destination / 'AndroidManifest.xml'
    xml.write_text(manifest(package, package == HARNESS))
    (destination / 'res/values/strings.xml').write_text('<resources><string name="listener_filter_none" translatable="false">0</string></resources>')
    run([tools.aapt2, 'compile', '--dir', destination / 'res', '-o', destination / 'compiled.zip'])
    run([tools.aapt2, 'link', '--manifest', xml, '-I', tools.platform,
         '--java', destination / 'generated', '--min-sdk-version', '26', '--target-sdk-version', '36',
         '--auto-add-overlay', '-R', destination / 'compiled.zip', '-o', destination / 'resources.apk'])
    java = [*sources, *sorted((destination / 'generated').rglob('*.java'))]
    run(['javac', '--release', '8', '-encoding', 'UTF-8', '-classpath', tools.platform,
         '-d', destination / 'classes', *java])
    run(['jar', '--create', '--file', destination / 'classes.jar', '-C', destination / 'classes', '.'])
    run([tools.directory / 'd8', '--release', '--min-api', '26', '--lib', tools.platform,
         '--output', destination / 'dex', destination / 'classes.jar'])
    unsigned = destination / 'unsigned.apk'
    shutil.copy2(destination / 'resources.apk', unsigned)
    with zipfile.ZipFile(unsigned, 'a') as output:
        for dex in sorted((destination / 'dex').glob('classes*.dex')):
            write_zip_entry(output, dex.name, dex.read_bytes())
    run([tools.directory / 'zipalign', '-f', '-p', '4', unsigned, destination / 'aligned.apk'])
    apk = destination / 'fixture.apk'
    run([tools.directory / 'apksigner', 'sign', '--ks', key, '--ks-key-alias', 'isolated-spotify-test',
         '--ks-pass', 'pass:android', '--key-pass', 'pass:android', '--out', apk, destination / 'aligned.apk'])
    run([tools.directory / 'apksigner', 'verify', apk])
    badging = run([tools.aapt2, 'dump', 'badging', apk])
    if 'android.permission.INTERNET' in badging:
        raise ValueError('Network permission is forbidden in the framework fixtures')
    return apk


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--serial', default='emulator-5582')
    parser.add_argument('--adb', default=str(Path.home() / 'Android/Sdk/platform-tools/adb'))
    parser.add_argument('--run', action='store_true', help='Install/run/clean only the three isolated fixtures on verified QEMU API36')
    parser.add_argument('--report', type=Path, default=ROOT / 'dist/android-spotify-framework-validation.json')
    args = parser.parse_args()
    if not re.fullmatch(r'emulator-[0-9]+', args.serial):
        raise ValueError('Only an explicitly identified emulator is accepted')
    tools = Tools.local()
    stage = ROOT / 'android/build/spotify-framework'
    if stage.is_symlink():
        raise ValueError('Symbolic build directory refused')
    stage.mkdir(parents=True, exist_ok=True)
    fixture_root = ROOT / 'android/app/src/spotifyFrameworkTest/java/fr/denis/rhythmbox'
    production = ROOT / 'android/app/src/main/java/fr/denis/rhythmbox'
    sources = [fixture_root / 'SpotifyController.java', fixture_root / 'SpotifyNotificationListener.java',
               fixture_root / 'SpotifyFrameworkProbeActivity.java', fixture_root / 'spotifyfixture/FixtureService.java']
    for path in sources:
        if not path.is_file():
            raise ValueError('Framework fixture source missing: ' + str(path))
    key = stage / 'test-only.p12'
    if not key.exists():
        run(['keytool', '-genkeypair', '-noprompt', '-storetype', 'PKCS12', '-keystore', key,
             '-storepass', 'android', '-keypass', 'android', '-alias', 'isolated-spotify-test',
             '-keyalg', 'RSA', '-keysize', '2048', '-validity', '7', '-dname', 'CN=Disposable isolated Spotify framework test'])
    apks = {HARNESS: build(tools, stage, HARNESS, sources[:3], key),
            SPOTIFY: build(tools, stage, SPOTIFY, sources[3:], key),
            FOREIGN: build(tools, stage, FOREIGN, sources[3:], key)}
    result = {'kind': 'isolated-android-spotify-framework-test',
              'source_sha256': {str(p.relative_to(ROOT)): digest(p) for p in sources},
              'apk_sha256': {name: digest(path) for name, path in apks.items()},
              'network_permission': False, 'production_package_touched': False,
              'physical_device_touched': False, 'real_spotify_package_replaced': False,
              'framework_run': False, 'fixtures_installed': [], 'fixtures_removed': [],
              'real_spotify_account_tested': False}
    args.report.parent.mkdir(parents=True, exist_ok=True)
    def record():
        args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    if not args.run:
        record();print(json.dumps(result, ensure_ascii=False, indent=2));return 0
    command = [args.adb, '-s', args.serial]
    def adb(*parts, timeout=20, check=True):
        value = subprocess.run([*command, *map(str, parts)], capture_output=True, text=True, errors='replace', timeout=timeout)
        if check and value.returncode:
            raise RuntimeError('Isolated adb command failed: ' + ' '.join(map(str, parts[:3])) + ': ' + (value.stdout + value.stderr)[-2000:])
        return value.stdout.strip()
    if adb('shell', 'getprop', 'ro.kernel.qemu') != '1' or adb('shell', 'getprop', 'ro.build.version.sdk') != '36':
        raise ValueError('The selected serial must be a live API36 QEMU emulator')
    if adb('shell', 'am', 'get-current-user') != '0':
        raise ValueError('Only the disposable primary emulator user is accepted')
    for package in apks:
        if adb('shell', 'pm', 'path', package, check=False).startswith('package:'):
            raise ValueError('Existing package preserved; fixture install refused: ' + package)
    installed = []
    try:
        for package, apk in apks.items():
            if 'Success' not in adb('install', '-t', '--no-streaming', apk, timeout=30):
                raise RuntimeError('Isolated fixture install was not confirmed')
            installed.append(package);result['fixtures_installed'].append(package);record()
        adb('shell', 'cmd', 'notification', 'allow_listener', COMPONENT, '0')
        result.update(framework_run=True, serial=args.serial, qemu_verified=True, api_level=36,
                      notification_grant_target=COMPONENT)
        # AOSP does not expose the filter in the ordinary notification dump.
        # Read existing policy metadata only on this verified virtual device,
        # using its pre-existing su; do not enable adb root or read messages.
        filter_types = None
        deadline = time.monotonic() + 8
        while time.monotonic() < deadline:
            policy = adb('shell', 'su', '0', 'cat', '/data/system/notification_policy.xml', check=False)
            if not policy.lstrip().startswith('<'):
                policy = adb('shell', 'su', '0', 'abx2xml', '/data/system/notification_policy.xml', '-', check=False)
            try:
                tree = ET.fromstring(policy)
                for listener in tree.iter('listener'):
                    if listener.get('component') != COMPONENT:
                        continue
                    allowed = listener.find('allowed')
                    if allowed is not None:
                        filter_types = int(allowed.get('types', '-1'))
                if filter_types == 0:
                    break
            except (ET.ParseError, ValueError):
                pass
            time.sleep(.2)
        result['os_listener_filter_types'] = filter_types
        result['os_filter_evidence'] = 'Own component only, read-only policy XML through pre-existing QEMU su; no notification content retained'
        adb('shell', 'am', 'start', '-W', '-n', HARNESS + '/' + TEST_ACTIVITY)
        deadline = time.monotonic() + 85
        revoked = False
        while time.monotonic() < deadline:
            final = adb('shell', 'run-as', HARNESS, 'cat', 'files/spotify-framework-result.json', check=False)
            if final.startswith('{'):
                result['framework'] = json.loads(final);break
            progress = adb('shell', 'run-as', HARNESS, 'cat', 'files/spotify-framework-progress.json', check=False)
            if not revoked and progress.startswith('{') and json.loads(progress).get('phase') == 'await-revoke':
                adb('shell', 'cmd', 'notification', 'disallow_listener', COMPONENT, '0')
                revoked=True;result['notification_revoke_target']=COMPONENT
            time.sleep(.2)
        else:
            raise RuntimeError('Bounded framework scenario did not return a result')
        if not result['framework'].get('passed'):
            raise RuntimeError('Framework fixture failed: ' + str(result['framework'].get('error', 'unknown')))
        if filter_types != 0:
            raise RuntimeError('Our notification filter was not attested as zero by the OS')
        if not revoked:
            raise RuntimeError('The revocation scenario was not executed')
        result['passed'] = True
    except BaseException as error:
        result.update(passed=False, error=str(error))
        pid = adb('shell', 'pidof', HARNESS, check=False)
        if re.fullmatch(r'\d+', pid):
            (stage / 'framework-logcat.txt').write_text(adb('logcat', '-d', '--pid=' + pid, check=False)[-16000:])
        raise
    finally:
        if installed:
            adb('shell', 'cmd', 'notification', 'disallow_listener', COMPONENT, '0', check=False)
        for package in reversed(installed):
            if 'Success' in adb('uninstall', package, timeout=30, check=False):
                result['fixtures_removed'].append(package)
        record()
    print(json.dumps(result, ensure_ascii=False, indent=2));return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as error:
        print(str(error), file=sys.stderr);sys.exit(1)
