#!/usr/bin/python3
"""Build a debug APK or a signed Google Play bundle with the pinned local tools.

Production upload signing is separate from debug, private outside this checkout,
and never exported into an archive. No Play account or release is changed here.
"""
import argparse
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import secrets
import shutil
import stat
import subprocess
import tarfile
import tempfile
import xml.etree.ElementTree as ET
import zipfile
from urllib.parse import urlsplit
if __package__:
    from .android_spotify_dependencies import dependencies as spotify_dependencies
else:
    from android_spotify_dependencies import dependencies as spotify_dependencies

ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / 'android'
NS = '{http://schemas.android.com/apk/res/android}'
UPLOAD_ALIAS = 'rhythmbox-upload'
ET.register_namespace('android', NS[1:-1])


def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def run(command, *, cwd=None):
    result = subprocess.run([str(v) for v in command], cwd=cwd or ROOT,
                            capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError('Échec de ' + str(command[0]) + ':\n' + (result.stdout + result.stderr)[-6000:])
    return result.stdout + result.stderr


def version(manifest):
    document = ET.parse(manifest).getroot()
    uses = document.find('uses-sdk')
    application = document.find('application')
    values = {'package': document.attrib['package'],
              'version_code': int(document.attrib[NS + 'versionCode']),
              'version_name': document.attrib[NS + 'versionName'],
              'min_sdk': int(uses.attrib[NS + 'minSdkVersion']),
              'target_sdk': int(uses.attrib[NS + 'targetSdkVersion'])}
    if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z][A-Za-z0-9_]*)+', values['package']):
        raise ValueError('Identifiant Android invalide')
    if values['version_code'] < 1 or not values['version_name']:
        raise ValueError('Version Android invalide')
    if values['target_sdk'] < 36 or values['min_sdk'] < 26:
        raise ValueError('Cette publication exige cible API36 et minimum API26')
    if application.attrib.get(NS + 'debuggable') != 'false':
        raise ValueError('Le manifeste de production doit désactiver debuggable explicitement')
    return values


def safe_private_directory(path):
    path = Path(path)
    if '..' in path.parts:
        raise ValueError('Traversée de dossier de signature refusée')
    path = path.absolute()
    for component in [path, *path.parents]:
        if component.is_symlink():
            raise ValueError('Chemin de signature symbolique refusé')
    if path.is_relative_to(ROOT):
        raise ValueError('Conserver la signature de production hors du projet et de ses archives')
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    info = path.stat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid():
        raise ValueError('Le dossier de signature doit appartenir au compte courant')
    path.chmod(0o700)
    return path


def upload_signing(directory):
    directory = safe_private_directory(directory)
    key, password = directory / 'upload-keystore.p12', directory / 'upload-keystore.pass'
    for path in (key, password):
        if path.is_symlink():
            raise ValueError('Fichier de signature symbolique refusé')
    if key.exists() != password.exists():
        raise ValueError('Signature incomplète : ne pas régénérer une clé existante')
    if not key.exists():
        fd = os.open(password, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, 'w') as output:
            output.write(secrets.token_urlsafe(48) + '\n')
        try:
            run(['keytool', '-genkeypair', '-noprompt', '-storetype', 'PKCS12', '-keystore', key,
                 '-storepass:file', password, '-keypass:file', password, '-alias', UPLOAD_ALIAS,
                 '-keyalg', 'RSA', '-keysize', '4096', '-sigalg', 'SHA256withRSA',
                 '-validity', '10000', '-dname', 'CN=Rhythmbox Upload, OU=Android Release, O=Denis, C=FR'])
        except BaseException:
            # Retain any partially created keystore for inspection; never replace one.
            if not key.exists():
                password.unlink()
            raise
    for path in (key, password):
        if (not stat.S_ISREG(path.stat().st_mode) or path.stat().st_uid != os.getuid() or
                path.stat().st_nlink != 1):
            raise ValueError('Signature privée non régulière ou appartenant à un autre compte')
        path.chmod(0o600)
    run(['keytool', '-list', '-keystore', key, '-storetype', 'PKCS12',
         '-storepass:file', password, '-alias', UPLOAD_ALIAS])
    return key, password


@dataclass
class Tools:
    platform: Path
    directory: Path
    aapt2: Path
    bundletool: Path

    @classmethod
    def local(cls):
        cache = ANDROID / '.toolchain'
        result = cls(Path(os.environ.get('RBX_ANDROID_PLATFORM', cache / 'android-36/android.jar')),
                     Path(os.environ.get('RBX_ANDROID_BUILD_TOOLS', cache / 'build-tools-36')),
                     Path(os.environ.get('RBX_ANDROID_AAPT2', cache / 'aapt2-9.5.0/aapt2')),
                     Path(os.environ.get('RBX_ANDROID_BUNDLETOOL', cache / 'bundletool-all-1.18.3.jar')))
        for path in (result.platform, result.aapt2, result.directory / 'd8', result.directory / 'zipalign', result.directory / 'apksigner'):
            if not path.is_file():
                raise ValueError('Outils Android absents ; exécuter android/prepare-toolchain.sh')
        return result


def write_zip_entry(output, name, value):
    path = PurePosixPath(name)
    if path.is_absolute() or '..' in path.parts or '\\' in name:
        raise ValueError('Chemin de module Android non sûr')
    info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o100644 << 16
    output.writestr(info, value)


def bundle_module(resources, dex_directory, destination):
    with zipfile.ZipFile(resources) as source, zipfile.ZipFile(destination, 'w') as output:
        names = source.namelist()
        if 'AndroidManifest.xml' not in names or 'resources.pb' not in names:
            raise ValueError('Manifeste et ressources protobuf requis pour le bundle')
        for name in sorted(names):
            if name.endswith('/'):
                continue
            target = 'manifest/AndroidManifest.xml' if name == 'AndroidManifest.xml' else name
            if target != 'manifest/AndroidManifest.xml' and target != 'resources.pb' and not target.startswith(('res/', 'assets/')):
                raise ValueError('Fichier de ressource inattendu dans le module : ' + name)
            write_zip_entry(output, target, source.read(name))
        dex_files = sorted(dex_directory.glob('classes*.dex'))
        if not dex_files or not (dex_directory / 'classes.dex').exists():
            raise ValueError('DEX principal absent')
        for dex in dex_files:
            write_zip_entry(output, 'dex/' + dex.name, dex.read_bytes())


def compile_app(kind, tools, metadata):
    stage = ANDROID / 'build' / kind
    if stage.is_symlink():
        raise ValueError('Dossier de build symbolique refusé')
    if stage.exists():
        shutil.rmtree(stage)
    stage.mkdir(parents=True)
    for name in ('classes', 'generated', 'dex'):
        (stage / name).mkdir()
    manifest = ANDROID / 'app/src/main/AndroidManifest.xml'
    if kind == 'debug':
        tree = ET.parse(manifest)
        tree.getroot().find('application').set(NS + 'debuggable', 'true')
        manifest = stage / 'AndroidManifest.xml'
        tree.write(manifest, encoding='utf-8', xml_declaration=True)
    command = [tools.aapt2, 'link', '--manifest', manifest, '-I', tools.platform,
               '--java', stage / 'generated', '--min-sdk-version', metadata['min_sdk'],
               '--target-sdk-version', metadata['target_sdk'], '--auto-add-overlay', '-o', stage / 'resources.apk']
    resources = ANDROID / 'app/src/main/res'
    if resources.is_dir():
        run([tools.aapt2, 'compile', '--dir', resources, '-o', stage / 'compiled-res.zip'])
        command += ['-R', stage / 'compiled-res.zip']
    assets = ANDROID / 'app/src/main/assets'
    if assets.is_dir():
        command += ['-A', assets]
    if kind == 'release':
        command += ['--proto-format']
    run(command)
    sources = sorted((ANDROID / 'app/src/main/java').rglob('*.java')) + sorted((stage / 'generated').rglob('*.java'))
    sdk_jars = spotify_dependencies()
    classpath = os.pathsep.join(map(str, [tools.platform, *sdk_jars]))
    run(['javac', '--release', '8', '-encoding', 'UTF-8', '-g:none' if kind == 'release' else '-g',
         '-classpath', classpath, '-d', stage / 'classes', *sources])
    run(['jar', '--create', '--file', stage / 'classes.jar', '-C', stage / 'classes', '.'])
    run([tools.directory / 'd8', '--release', '--min-api', metadata['min_sdk'], '--lib', tools.platform,
         '--output', stage / 'dex', stage / 'classes.jar', *sdk_jars])
    return stage


def publish_file(source, destination):
    if destination.is_symlink():
        raise ValueError('Destination de distribution symbolique refusée')
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.android-build-', dir=destination.parent)
    os.close(fd)
    try:
        shutil.copy2(source, temporary)
        os.replace(temporary, destination)
    finally:
        Path(temporary).unlink(missing_ok=True)
    destination.with_name(destination.name + '.sha256').write_text(sha(destination) + '  ' + destination.name + '\n')


def corresponding_sources(destination):
    """Corresponding Android source, resources and reproducible build/test tools."""
    selected = [ROOT / 'COPYING', ANDROID / 'README.md', ANDROID / 'RELEASE.md', ANDROID / 'SPOTIFY-APP-REMOTE.md',
                ANDROID / 'spotify-dependencies.json', ANDROID / 'prepare-spotify.sh']
    selected += sorted((ANDROID / 'app/src').rglob('*'))
    # Preserve the preferred editable forms and provenance of bundled artwork.
    selected += sorted((ANDROID / 'artwork').rglob('*'))
    selected += [ANDROID / name for name in ('build.sh', 'build-release.sh', 'prepare-toolchain.sh', 'test.sh', 'test-pcloud-native.sh',
                                           'test-suno-catalog.sh', 'test-suno-library.sh', 'test-suno-audio.sh', 'test-spotify-controller.sh', 'test-playback-ownership.sh', 'test-volume.sh', 'test-audio-cache.sh', 'test-pcm.sh')]
    selected += [ROOT / 'scripts' / name for name in ('android_build.py', 'android_toolchain.py', 'android_spotify_dependencies.py',
                                                     'android_auth_instrumentation.py', 'android_pcloud_smoke.py',
                                                     'generate_suno_audio_fixture.py', 'android_suno_instrumentation.py',
                                                     'android_spotify_framework.py', 'android_services_smoke.py',
                                                     'android_loudness_instrumentation.py', 'android_pcm_instrumentation.py',
                                                     'android_live_ui.py')]
    selected += sorted((ANDROID / 'play/app-links').rglob('*'))
    selected += sorted((ANDROID / 'play/site/pcloud').rglob('*'))
    selected += [ROOT / 'tests/fixtures' / name for name in ('protocol-v1.rbx', 'protocol-v1.plain.json')]
    selected += [ROOT / 'docs' / name for name in ('SECURITY.md', 'PCLOUD-SETUP.md', 'PROTOCOL.md', 'VOLUME.md', 'SPOTIFY-SETUP.md')]
    selected = sorted(set(path for path in selected if path.is_file()))
    private_parts = {'.signing', '.toolchain', 'build', '.private', '__pycache__'}
    private_names = {'sync.json', 'config.json', 'tokens.json', 'credentials.json', 'local.properties'}
    with tarfile.open(destination, 'w:gz') as output:
        for path in selected:
            relative = path.relative_to(ROOT)
            if (path.is_symlink() or any(part in private_parts for part in relative.parts) or
                    path.name in private_names or path.suffix in {'.p12', '.jks', '.keystore', '.pass', '.key'}):
                raise ValueError('Fichier privé refusé dans les sources Android')
            item = output.gettarinfo(str(path), arcname='Rythmbox/' + relative.as_posix())
            item.uid = item.gid = 0
            item.uname = item.gname = ''
            item.mtime = 0
            with path.open('rb') as source:
                output.addfile(item, source)
    return len(selected)


def publication_readiness():
    """Local evidence only: a successful signed build is not a store submission."""
    settings = ANDROID / 'app/src/main/res/values/publication.xml'
    values = {} if not settings.is_file() else {
        item.attrib.get('name'): (item.text or '').strip()
        for item in ET.parse(settings).getroot().findall('string')}
    listing_path = ANDROID / 'play/fr-FR.json'
    listing = json.loads(listing_path.read_text()) if listing_path.is_file() else {}

    def configured_url(name):
        parsed = urlsplit(values.get(name, ''))
        return parsed.scheme == 'https' and bool(parsed.hostname) and not parsed.username and not parsed.password

    screenshots = list((ANDROID / 'play/screenshots').glob('*.png'))
    videos = list((ANDROID / 'play').rglob('*.mp4')) + list((ANDROID / 'play').rglob('*.webm'))
    support = listing.get('public_support_email')
    checks = {'privacy_policy_https_configured': configured_url('privacy_policy_url'),
              'source_code_https_configured': configured_url('source_code_url'),
              'public_support_email_configured': isinstance(support, str) and bool(re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', support)),
              'at_least_two_screenshot_files_present': len(screenshots) >= 2,
              'foreground_service_video_file_present': bool(videos)}
    blockers = [name for name, configured in checks.items() if not configured]
    blockers += ['public_urls_and_support_not_verified_by_build',
                 'play_declarations_and_production_access_not_verified_by_build']
    return {'status': 'requires_external_play_review', 'ready_for_play_submission': False,
            'local_checks': checks, 'blocking_items': blockers,
            'screenshots_count': len(screenshots), 'video_files_count': len(videos),
            'network_checks_performed': False, 'play_declarations_accepted_by_build': False}


def debug_build(tools, metadata, publish=True):
    stage = compile_app('debug', tools, metadata)
    unsigned = stage / 'unsigned.apk'
    shutil.copy2(stage / 'resources.apk', unsigned)
    with zipfile.ZipFile(unsigned, 'a') as output:
        for dex in sorted((stage / 'dex').glob('classes*.dex')):
            write_zip_entry(output, dex.name, dex.read_bytes())
    run([tools.directory / 'zipalign', '-f', '-p', '4', unsigned, stage / 'aligned.apk'])
    directory = ANDROID / '.signing'
    if directory.is_symlink():
        raise ValueError('Dossier debug symbolique refusé')
    directory.mkdir(exist_ok=True, mode=0o700)
    directory.chmod(0o700)
    key = directory / 'debug.keystore'
    if key.is_symlink():
        raise ValueError('Clé debug symbolique refusée')
    if not key.exists():
        run(['keytool', '-genkeypair', '-noprompt', '-keystore', key, '-storepass', 'android',
             '-keypass', 'android', '-alias', 'androiddebugkey', '-dname',
             'CN=Rhythmbox local debug, O=Denis, C=FR', '-keyalg', 'RSA', '-keysize', '3072', '-validity', '10000'])
    key.chmod(0o600)
    apk = stage / 'rhythmbox-android-debug.apk'
    run([tools.directory / 'apksigner', 'sign', '--ks', key, '--ks-pass', 'pass:android',
         '--key-pass', 'pass:android', '--out', apk, stage / 'aligned.apk'])
    run([tools.directory / 'apksigner', 'verify', '--verbose', apk])
    if publish:
        publish_file(apk, ROOT / 'dist' / apk.name)
    return {'kind': 'debug', 'metadata': metadata, 'apk': apk.name, 'sha256': sha(apk), 'debug_signing': True}


def release_build(tools, metadata, signing_directory, publish=True):
    if not tools.bundletool.is_file():
        raise ValueError('Bundletool absent ; exécuter android/prepare-toolchain.sh')
    stage = compile_app('release', tools, metadata)
    module = stage / 'base.zip'
    bundle_module(stage / 'resources.apk', stage / 'dex', module)
    unsigned = stage / 'unsigned.aab'
    run(['java', '-jar', tools.bundletool, 'build-bundle', '--modules=' + str(module), '--output=' + str(unsigned)])
    key, password = upload_signing(signing_directory)
    aab = stage / 'rhythmbox-android-release.aab'
    run(['jarsigner', '-J-Duser.language=en', '-J-Duser.country=US', '-keystore', key, '-storetype', 'PKCS12',
         '-storepass:file', password, '-keypass:file', password, '-sigalg', 'SHA256withRSA',
         '-digestalg', 'SHA-256', '-signedjar', aab, unsigned, UPLOAD_ALIAS])
    signature = run(['jarsigner', '-J-Duser.language=en', '-J-Duser.country=US', '-verify', aab])
    if 'jar verified.' not in signature:
        raise ValueError('Signature JAR du bundle non vérifiée')
    run(['java', '-jar', tools.bundletool, 'validate', '--bundle=' + str(aab)])
    manifest = run(['java', '-jar', tools.bundletool, 'dump', 'manifest', '--bundle=' + str(aab)])
    actual = ET.fromstring(manifest)
    if (actual.attrib['package'] != metadata['package'] or int(actual.attrib[NS + 'versionCode']) != metadata['version_code'] or
            actual.find('application').attrib.get(NS + 'debuggable', 'false') != 'false' or
            int(actual.find('uses-sdk').attrib[NS + 'targetSdkVersion']) != metadata['target_sdk']):
        raise ValueError('Métadonnées du bundle différentes du manifeste approuvé')
    certificate = stage / 'rhythmbox-upload-certificate.pem'
    run(['keytool', '-exportcert', '-rfc', '-keystore', key, '-storetype', 'PKCS12',
         '-storepass:file', password, '-alias', UPLOAD_ALIAS, '-file', certificate])
    apks = stage / 'verification.apks'
    run(['java', '-jar', tools.bundletool, 'build-apks', '--bundle=' + str(aab), '--output=' + str(apks),
         '--mode=universal', '--ks=' + str(key), '--ks-pass=file:' + str(password),
         '--key-pass=file:' + str(password), '--ks-key-alias=' + UPLOAD_ALIAS])
    apk = stage / 'rhythmbox-android-release.apk'
    with zipfile.ZipFile(apks) as archive:
        apk.write_bytes(archive.read('universal.apk'))
    verified_apk = run([tools.directory / 'apksigner', 'verify', '--verbose', '--print-certs', apk])
    certificate_digest = re.search(r'Signer #1 certificate SHA-256 digest: ([0-9a-fA-F]+)', verified_apk)
    if certificate_digest is None:
        raise ValueError('Certificat de l’APK généré non vérifié')
    with zipfile.ZipFile(aab) as archive:
        names = archive.namelist()
        native = any(name.startswith('base/lib/') for name in names)
        if any(part in {'.signing', 'spotify-firefox', 'sync.json', 'config.json', 'tokens.json', 'credentials.json'}
               or PurePosixPath(part).suffix in {'.p12', '.jks', '.keystore', '.pass', '.key'}
               for name in names for part in PurePosixPath(name).parts):
            raise ValueError('Fichier privé interdit dans le bundle')
    source_archive = stage / ('rhythmbox-android-' + metadata['version_name'] + '-sources.tar.gz')
    source_files = corresponding_sources(source_archive)
    report = {'schema': 1, 'kind': 'google-play-release-build', 'ok': True, 'metadata': metadata,
              'aab': aab.name, 'aab_sha256': sha(aab), 'aab_bytes': aab.stat().st_size,
              'universal_apk': apk.name, 'universal_apk_sha256': sha(apk),
              'upload_certificate_sha256': certificate_digest.group(1).lower(),
              'debug_signing': False, 'jarsigner_verified': True, 'bundletool_validated': True,
              'universal_apk_signature_verified': True, 'native_libraries_present': native,
              'private_signing_material_packaged': False, 'play_console_uploaded': False,
              'physical_device_tested': False, 'emulator_tested': False,
              'corresponding_sources': source_archive.name, 'source_files': source_files,
              'corresponding_sources_sha256': sha(source_archive), 'published_to_dist': publish,
              'publication_readiness': publication_readiness()}
    if publish:
        for source in (aab, apk, certificate, source_archive):
            publish_file(source, ROOT / 'dist' / source.name)
        output = ROOT / 'dist/android-play-release-validation.json'
        output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('kind', choices=('debug', 'release'))
    parser.add_argument('--stage-only', action='store_true', help='Validate under android/build without replacing dist artifacts')
    parser.add_argument('--signing-dir', type=Path, default=Path(os.environ.get('RBX_ANDROID_SIGNING_DIR',
                        Path.home() / '.local/share/rhythmbox-android/signing')))
    args = parser.parse_args()
    metadata = version(ANDROID / 'app/src/main/AndroidManifest.xml')
    tools = Tools.local()
    report = debug_build(tools, metadata, not args.stage_only) if args.kind == 'debug' else release_build(tools, metadata, args.signing_dir, not args.stage_only)
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
