#!/usr/bin/env bash
set -euo pipefail
rbx_android_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$rbx_android_dir"
rbx_json_jar="${RBX_JSON_TEST_JAR:-$rbx_android_dir/.toolchain/json-test.jar}"
if [[ ! -f "$rbx_json_jar" ]]; then
  printf '%s\n' 'Préparer le JAR org.json avec prepare-toolchain.sh ou RBX_JSON_TEST_JAR.' >&2
  exit 1
fi
mkdir -p build/suno-catalog-host-tests
javac --release 8 -Xlint:-options -encoding UTF-8 -classpath "$rbx_json_jar" -d build/suno-catalog-host-tests \
  app/src/main/java/fr/denis/rhythmbox/SunoCatalog.java \
  app/src/test/java/fr/denis/rhythmbox/SunoCatalogTest.java
java -cp "build/suno-catalog-host-tests:$rbx_json_jar" fr.denis.rhythmbox.SunoCatalogTest
