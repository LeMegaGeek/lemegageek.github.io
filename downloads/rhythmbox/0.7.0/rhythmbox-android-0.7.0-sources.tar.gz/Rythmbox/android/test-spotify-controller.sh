#!/usr/bin/env bash
set -euo pipefail
rbx_android_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$rbx_android_dir"
rbx_platform="${RBX_ANDROID_PLATFORM:-$rbx_android_dir/.toolchain/android-36/android.jar}"
if [[ ! -f "$rbx_platform" ]]; then
  printf '%s\n' 'Préparer android.jar avec prepare-toolchain.sh ou RBX_ANDROID_PLATFORM.' >&2
  exit 1
fi
rbx_output="build/spotify-controller-host-tests"
mkdir -p "$rbx_output"
javac --release 8 -Xlint:-options -encoding UTF-8 -classpath "$rbx_platform" -d "$rbx_output" \
  app/src/main/java/fr/denis/rhythmbox/SpotifyController.java \
  app/src/main/java/fr/denis/rhythmbox/SpotifyNotificationListener.java \
  app/src/test/java/fr/denis/rhythmbox/SpotifyControllerTest.java
java -cp "$rbx_output:$rbx_platform" fr.denis.rhythmbox.SpotifyControllerTest
