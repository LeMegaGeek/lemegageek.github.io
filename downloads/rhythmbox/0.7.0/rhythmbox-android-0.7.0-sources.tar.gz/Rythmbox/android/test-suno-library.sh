#!/usr/bin/env bash
set -euo pipefail
rbx_suno_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$rbx_suno_dir"
rbx_suno_json="${RBX_JSON_TEST_JAR:-$rbx_suno_dir/.toolchain/json-test.jar}"
rbx_suno_platform="${RBX_ANDROID_PLATFORM:-$rbx_suno_dir/.toolchain/android-36/android.jar}"
mkdir -p build/suno-library-host-tests
javac --release 8 -Xlint:-options -encoding UTF-8 -classpath "$rbx_suno_json:$rbx_suno_platform" -d build/suno-library-host-tests \
  app/src/main/java/fr/denis/rhythmbox/SunoCatalog.java \
  app/src/main/java/fr/denis/rhythmbox/SunoShare.java \
  app/src/main/java/fr/denis/rhythmbox/SunoLibrary.java \
  app/src/test/java/fr/denis/rhythmbox/SunoLibraryTest.java \
  app/src/test/java/fr/denis/rhythmbox/SunoShareTest.java
java -cp "build/suno-library-host-tests:$rbx_suno_json:$rbx_suno_platform" fr.denis.rhythmbox.SunoLibraryTest
java -cp "build/suno-library-host-tests:$rbx_suno_json:$rbx_suno_platform" fr.denis.rhythmbox.SunoShareTest
