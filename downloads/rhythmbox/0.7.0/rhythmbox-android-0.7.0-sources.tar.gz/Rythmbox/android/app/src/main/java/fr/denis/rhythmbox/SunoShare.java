package fr.denis.rhythmbox;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Extract a single official link for review, never for automatic navigation. */
public final class SunoShare {
    private static final String UUID="[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}";
    private static final Pattern LINK=Pattern.compile("https://suno\\.com/(?:s/[A-Za-z0-9_-]{6,128}|(?:song|playlist)/"+UUID+")/?(?=$|[\\s<>()\\\"'?#])");
    private SunoShare(){}
    public static String extract(CharSequence input) throws Exception {
        if(input==null||input.length()>8192)throw new IllegalArgumentException("Partage Suno vide ou trop volumineux.");
        Matcher matches=LINK.matcher(input);String chosen=null;
        while(matches.find()){
            String link=SunoCatalog.canonicalLink(matches.group());
            if(chosen!=null&&!chosen.equals(link))throw new IllegalArgumentException("Partage plusieurs liens séparément pour choisir le bon catalogue Suno.");
            chosen=link;
        }
        if(chosen==null)throw new IllegalArgumentException("Ce partage ne contient pas de lien officiel Suno reconnu.");
        return chosen;
    }
}
