package fr.denis.rhythmbox;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Private Suno metadata, deliberately separate from pCloud playlists and credentials.
 * No guest grant, key, audio bytes or browser session is accepted or persisted.
 */
public final class SunoLibrary {
    private static final int MAX_BYTES=16*1024*1024, MAX_SOURCES=100, MAX_TRACKS=5000;
    private final File file;
    private JSONArray sources=new JSONArray();

    public SunoLibrary(Context context) throws Exception {this(new File(context.getFilesDir(),"suno-library.json"));}
    public SunoLibrary(File file) throws Exception {this.file=file;reload();}
    private static JSONObject copy(JSONObject value) throws Exception {return new JSONObject(value.toString());}
    private static String label(Object value,int limit) {
        if(!(value instanceof String))throw new IllegalArgumentException("Nom de liste Suno invalide.");
        String text=(String)value;
        if(text.isEmpty()||text.codePointCount(0,text.length())>limit||text.indexOf(0)>=0)throw new IllegalArgumentException("Nom de liste Suno invalide.");
        return text;
    }
    /** Validate one resolver manifest before it becomes an allowed playback source. */
    public static JSONObject manifest(JSONObject raw) throws Exception {
        Object version=raw.get("version");
        if(!(version instanceof Integer)||((Integer)version)!=1)throw new IllegalArgumentException("Version de catalogue Suno inconnue.");
        String link=SunoCatalog.canonicalLink(raw.getString("source_url"));
        String id=raw.getString("id"),name=label(raw.get("name"),1024);
        boolean song=link.startsWith("https://suno.com/song/"),playlist=link.startsWith("https://suno.com/playlist/");
        String expected=song?"suno:"+link.substring("https://suno.com/song/".length()):playlist?"suno-playlist:"+link.substring("https://suno.com/playlist/".length()):"";
        if(expected.isEmpty()||!expected.equals(id))throw new IllegalArgumentException("Le catalogue ne correspond pas à son lien Suno.");
        JSONArray input=raw.getJSONArray("tracks"),tracks=new JSONArray();
        if(input.length()>MAX_TRACKS)throw new IllegalArgumentException("Trop de morceaux Suno.");
        Set<String> ids=new HashSet<>();
        for(int i=0;i<input.length();i++){
            JSONObject source=input.getJSONObject(i);
            for(String forbidden:new String[]{"media_path","local_uri","pcloud_fileid","pcloud_account_userid","pcloud_music_folderid","key","iv","glt","access_token","cookie"})
                if(source.has(forbidden))throw new IllegalArgumentException("Une référence étrangère ne peut pas être importée comme morceau Suno.");
            JSONObject track=SunoCatalog.validateTrack(source);
            if(!ids.add(track.getString("id")))throw new IllegalArgumentException("Identité Suno répétée dans un catalogue.");
            tracks.put(track);
        }
        JSONArray lists=raw.getJSONArray("playlists"),normalized=new JSONArray();
        if(song){
            if(tracks.length()!=1||!ids.contains(id)||lists.length()!=0)throw new IllegalArgumentException("Catalogue de morceau Suno incohérent.");
        }else{
            if(lists.length()!=1)throw new IllegalArgumentException("Catalogue de playlist Suno incohérent.");
            JSONObject source=lists.getJSONObject(0);JSONArray order=source.getJSONArray("track_ids"),checked=new JSONArray();Set<String> ordered=new HashSet<>();
            if(!id.equals(source.getString("id"))||!name.equals(source.getString("name"))||order.length()>MAX_TRACKS)throw new IllegalArgumentException("Identité de playlist Suno incohérente.");
            for(int i=0;i<order.length();i++){
                Object member=order.get(i);if(!(member instanceof String)||!ids.contains(member))throw new IllegalArgumentException("Un membre de la playlist Suno manque.");
                checked.put(member);ordered.add((String)member);
            }
            if(!ordered.equals(ids))throw new IllegalArgumentException("La playlist Suno est incomplète.");
            normalized.put(new JSONObject().put("id",id).put("name",name).put("track_ids",checked));
        }
        return new JSONObject().put("version",1).put("id",id).put("name",name).put("source_url",link).put("tracks",tracks).put("playlists",normalized);
    }
    private static JSONArray validateSources(JSONArray input) throws Exception {
        if(input.length()>MAX_SOURCES)throw new IllegalArgumentException("Trop de catalogues Suno.");
        JSONArray output=new JSONArray();Set<String> ids=new HashSet<>();int count=0;
        for(int i=0;i<input.length();i++){
            JSONObject source=manifest(input.getJSONObject(i));
            if(!ids.add(source.getString("id")))throw new IllegalArgumentException("Catalogue Suno répété.");
            count+=source.getJSONArray("tracks").length();if(count>MAX_TRACKS)throw new IllegalArgumentException("Trop de morceaux Suno enregistrés.");
            output.put(source);
        }
        return output;
    }
    public synchronized void reload() throws Exception {
        if(!file.exists()){sources=new JSONArray();return;}
        if(Files.isSymbolicLink(file.toPath())||!file.isFile())throw new IllegalArgumentException("Le catalogue Suno privé est invalide.");
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        try(FileInputStream stream=new FileInputStream(file)){
            byte[] buffer=new byte[16384];int n;
            while((n=stream.read(buffer))!=-1){if(bytes.size()+n>MAX_BYTES)throw new IllegalArgumentException("Catalogue Suno trop volumineux.");bytes.write(buffer,0,n);}
        }
        String text=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes.toByteArray())).toString();
        JSONObject root=new JSONObject(text);
        if(!Integer.valueOf(1).equals(root.get("version"))||!"rhythmbox-suno".equals(root.optString("format")))throw new IllegalArgumentException("Catalogue Suno privé non reconnu.");
        sources=validateSources(root.getJSONArray("sources"));
    }
    public synchronized JSONArray sources() throws Exception {return new JSONArray(sources.toString());}
    private void save(JSONArray candidate) throws Exception {
        JSONArray checked=validateSources(candidate);
        byte[] bytes=new JSONObject().put("format","rhythmbox-suno").put("version",1).put("sources",checked).toString().getBytes(StandardCharsets.UTF_8);
        if(bytes.length>MAX_BYTES)throw new IllegalArgumentException("Catalogue Suno trop volumineux.");
        File parent=file.getAbsoluteFile().getParentFile();if(!parent.isDirectory()&&!parent.mkdirs())throw new java.io.IOException("Stockage Suno indisponible.");
        if(Files.isSymbolicLink(file.toPath()))throw new IllegalArgumentException("Le catalogue Suno privé est invalide.");
        File temporary=Files.createTempFile(parent.toPath(),".suno-library-",".json").toFile();
        try{
            temporary.setReadable(false,false);temporary.setWritable(false,false);temporary.setReadable(true,true);temporary.setWritable(true,true);
            try(FileOutputStream output=new FileOutputStream(temporary)){output.write(bytes);output.getFD().sync();}
            Files.move(temporary.toPath(),file.toPath(),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
            sources=checked;
        }finally{Files.deleteIfExists(temporary.toPath());}
    }
    public synchronized void put(JSONObject raw) throws Exception {
        JSONObject source=manifest(raw);JSONArray candidate=new JSONArray();boolean found=false;
        for(int i=0;i<sources.length();i++){
            JSONObject old=sources.getJSONObject(i);
            if(old.getString("id").equals(source.getString("id"))){candidate.put(source);found=true;}else candidate.put(copy(old));
        }
        if(!found)candidate.put(source);save(candidate);
    }
    public synchronized void remove(String sourceId) throws Exception {
        JSONArray candidate=new JSONArray();for(int i=0;i<sources.length();i++){JSONObject source=sources.getJSONObject(i);if(!source.getString("id").equals(sourceId))candidate.put(copy(source));}save(candidate);
    }
    public synchronized JSONArray queue(String sourceId) throws Exception {
        for(int i=0;i<sources.length();i++){
            JSONObject source=sources.getJSONObject(i);if(!sourceId.equals(source.getString("id")))continue;
            JSONArray tracks=source.getJSONArray("tracks"),playlists=source.getJSONArray("playlists"),result=new JSONArray();Map<String,JSONObject> byId=new HashMap<>();
            for(int n=0;n<tracks.length();n++)byId.put(tracks.getJSONObject(n).getString("id"),tracks.getJSONObject(n));
            if(playlists.length()==0)return new JSONArray(tracks.toString());
            JSONArray order=playlists.getJSONObject(0).getJSONArray("track_ids");for(int n=0;n<order.length();n++)result.put(copy(byId.get(order.getString(n))));return result;
        }
        throw new IllegalArgumentException("Catalogue Suno absent. Ajoute à nouveau son lien.");
    }
    /** Only a track previously registered by this phone may open a Suno stream. */
    public synchronized JSONObject registeredTrack(String id) throws Exception {
        for(int i=sources.length()-1;i>=0;i--){JSONArray tracks=sources.getJSONObject(i).getJSONArray("tracks");for(int n=0;n<tracks.length();n++)if(id.equals(tracks.getJSONObject(n).getString("id")))return copy(tracks.getJSONObject(n));}
        throw new IllegalArgumentException("Ce morceau Suno n’est pas enregistré sur ce téléphone.");
    }
}
