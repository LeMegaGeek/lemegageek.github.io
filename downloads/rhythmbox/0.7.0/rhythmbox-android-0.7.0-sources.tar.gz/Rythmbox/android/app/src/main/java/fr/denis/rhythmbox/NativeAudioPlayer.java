package fr.denis.rhythmbox;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaDataSource;
import android.media.MediaPlayer;
import android.os.PowerManager;
import android.view.Surface;
import java.io.File;

/** One native playback route, with a measured PCM route and an explicit format fallback. */
public final class NativeAudioPlayer {
    public interface Prepared { void onPrepared(NativeAudioPlayer player); }
    public interface Completed { void onCompletion(NativeAudioPlayer player); }
    public interface SeekComplete { void onSeekComplete(NativeAudioPlayer player); }
    public interface Error { boolean onError(NativeAudioPlayer player,int what,int extra); }
    private final Context context;
    private File file;
    private MediaDataSource source;
    private PcmAudioPlayer pcm;
    private MediaPlayer fallback;
    private Prepared preparedListener;
    private Completed completionListener;
    private SeekComplete seekListener;
    private Error errorListener;
    private boolean released,prepared,preparing,fallbackAttempted;
    private AudioAttributes attributes=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
    private int wakeMode=PowerManager.PARTIAL_WAKE_LOCK;

    public NativeAudioPlayer(Context context){this.context=context.getApplicationContext();}
    public void setWakeMode(Context ignored,int mode){wakeMode=mode;}
    public void setAudioAttributes(AudioAttributes value){attributes=value;}
    public void setSurface(Surface surface){if(surface!=null)throw new IllegalArgumentException("Lecture audio uniquement");}
    public void setDataSource(String path){if(preparing)throw new IllegalStateException();file=new File(path);source=null;}
    /** The service owns this source, so a decoder fallback must not close it. */
    public void setDataSource(MediaDataSource value){if(preparing)throw new IllegalStateException();source=value;file=null;}
    public void setOnPreparedListener(Prepared listener){preparedListener=listener;}
    public void setOnCompletionListener(Completed listener){completionListener=listener;}
    public void setOnSeekCompleteListener(SeekComplete listener){seekListener=listener;}
    public void setOnErrorListener(Error listener){errorListener=listener;}
    public void prepareAsync(){
        if(released||preparing||file==null&&source==null)throw new IllegalStateException();
        preparing=true;
        final PcmAudioPlayer candidate=new PcmAudioPlayer(source!=null?
            PcmAudioPlayer.borrowedMediaDataSource(source):PcmAudioPlayer.file(file));
        pcm=candidate;candidate.setAudioAttributes(attributes);candidate.setWakeMode(context,wakeMode);
        candidate.setOnPreparedListener(p->{if(released||pcm!=p)return;prepared=true;if(preparedListener!=null)preparedListener.onPrepared(this);});
        candidate.setOnCompletionListener(p->{if(!released&&pcm==p&&completionListener!=null)completionListener.onCompletion(this);});
        candidate.setOnSeekCompleteListener(p->{if(!released&&pcm==p&&seekListener!=null)seekListener.onSeekComplete(this);});
        candidate.setOnErrorListener((p,error)->{
            if(released||pcm!=p)return;
            if(!prepared&&!fallbackAttempted)useFallback();else signalError();
        });
        candidate.prepareAsync();
    }
    private void useFallback(){
        fallbackAttempted=true;PcmAudioPlayer old=pcm;pcm=null;if(old!=null)old.release();
        if(released)return;
        MediaPlayer candidate=new MediaPlayer();fallback=candidate;
        try{
            candidate.setWakeMode(context,wakeMode);candidate.setAudioAttributes(attributes);candidate.setSurface(null);
            if(source!=null)candidate.setDataSource(source);else candidate.setDataSource(file.getAbsolutePath());
            candidate.setOnPreparedListener(p->{
                if(released||fallback!=p)return;
                boolean audio=false;MediaPlayer.TrackInfo[] tracks=p.getTrackInfo();
                if(tracks!=null)for(MediaPlayer.TrackInfo track:tracks)if(track.getTrackType()==MediaPlayer.TrackInfo.MEDIA_TRACK_TYPE_AUDIO)audio=true;
                if(!audio){signalError();return;}
                prepared=true;if(preparedListener!=null)preparedListener.onPrepared(this);
            });
            candidate.setOnCompletionListener(p->{if(!released&&fallback==p&&completionListener!=null)completionListener.onCompletion(this);});
            candidate.setOnSeekCompleteListener(p->{if(!released&&fallback==p&&seekListener!=null)seekListener.onSeekComplete(this);});
            candidate.setOnErrorListener((p,what,extra)->{if(!released&&fallback==p)signalError();return true;});
            candidate.prepareAsync();
        }catch(Exception failure){signalError();}
    }
    private void signalError(){if(!released&&errorListener!=null)errorListener.onError(this,-1,0);}
    public boolean hasAudio(){return prepared;}
    public boolean isPlaying(){if(released||!prepared)return false;return pcm!=null?pcm.isPlaying():fallback!=null&&fallback.isPlaying();}
    public int getCurrentPosition(){if(released||!prepared)return 0;return pcm!=null?pcm.getCurrentPosition():fallback==null?0:fallback.getCurrentPosition();}
    public int getDuration(){if(released||!prepared)return 0;return pcm!=null?pcm.getDuration():fallback==null?0:fallback.getDuration();}
    public int getAudioSessionId(){if(released)return 0;return pcm!=null?pcm.getAudioSessionId():fallback==null?0:fallback.getAudioSessionId();}
    public void start(){if(released||!prepared)throw new IllegalStateException();if(pcm!=null)pcm.start();else fallback.start();}
    public void pause(){if(released||!prepared)return;if(pcm!=null)pcm.pause();else if(fallback!=null)fallback.pause();}
    public void seekTo(int position){if(released||!prepared)return;if(pcm!=null)pcm.seekTo(position);else if(fallback!=null)fallback.seekTo(position);}
    public void setVolume(float left,float right){if(released)return;if(pcm!=null)pcm.setVolume(left,right);else if(fallback!=null)fallback.setVolume(left,right);}
    public StereoSpectrum.Snapshot getSpectrum(){return !released&&pcm!=null?pcm.getSpectrum():StereoSpectrum.Snapshot.unavailable();}
    public String spectrumStatus(){return fallback!=null?"Analyseur indisponible pour ce format":prepared?isPlaying()?"G / D":"En pause":"En attente de lecture";}
    public void release(){
        if(released)return;released=true;prepared=false;
        PcmAudioPlayer nativePlayer=pcm;pcm=null;if(nativePlayer!=null)nativePlayer.release();
        MediaPlayer legacy=fallback;fallback=null;if(legacy!=null)try{legacy.release();}catch(RuntimeException ignored){}
    }
}
