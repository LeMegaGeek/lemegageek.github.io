package fr.denis.rhythmbox;

import org.json.JSONObject;

/** Playback identity only; no document provider, keyring, network or audio. */
public final class MediaOriginTest {
    static int checks;
    interface Checked {void run() throws Exception;}
    static void yes(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
    static void reject(Checked work,String label) throws Exception{checks++;try{work.run();}catch(Exception expected){return;}throw new AssertionError("Accepted: "+label);}
    public static void main(String[] args) throws Exception {
        PCloudAccount account=PCloudCollectionsTest.account(10);JSONObject local=new JSONObject().put("media_path","Artist/Song.flac").put("pcloud_fileid",999);
        JSONObject folder=new JSONObject().put("sync_mode","folder").put("media_tree","content://fixture/tree/music"),links=new JSONObject().put("sync_mode","links").put("media_code","fixture-share"),cloud=new JSONObject().put("sync_mode","account");
        yes(MediaOrigin.route(local,folder,null)==MediaOrigin.Kind.FOLDER,"existing document-tree track keeps local playback");
        yes(MediaOrigin.route(local,links,null)==MediaOrigin.Kind.LINKS,"unmarked public-share track keeps legacy playback");
        JSONObject marked=new JSONObject(local.toString()).put("pcloud_account_userid",7);
        for(JSONObject mode:new JSONObject[]{folder,links,cloud,new JSONObject().put("region","invalid-unused-legacy")})yes(MediaOrigin.route(marked,mode,account)==MediaOrigin.Kind.ACCOUNT,"private account track remains account-backed regardless global sync mode");
        for(JSONObject mode:new JSONObject[]{folder,links,cloud}){reject(()->MediaOrigin.route(marked,mode,null),"disconnected private account never falls back");reject(()->MediaOrigin.route(new JSONObject(marked.toString()).put("pcloud_account_userid",8),mode,account),"foreign private account never falls back");}
        reject(()->MediaOrigin.route(marked,folder,PCloudCollectionsTest.account(0)),"unselected music root cannot play account media");
        for(Object invalid:new Object[]{0,-1,true,"7",JSONObject.NULL,7.5})reject(()->MediaOrigin.route(new JSONObject(marked.toString()).put("pcloud_account_userid",invalid),folder,account),"malformed private marker cannot select local fallback");
        JSONObject hybrid=new JSONObject(cloud.toString()).put("media_tree","content://fixture/tree/music");yes(MediaOrigin.route(local,hybrid,null)==MediaOrigin.Kind.FOLDER,"connecting cloud preserves prior explicitly selected local music tree");
        reject(()->MediaOrigin.route(local,cloud,account),"unmarked media never guessed into cloud by matching name or stale ID");
        reject(()->MediaOrigin.route(new JSONObject().put("title","Song.flac"),hybrid,account),"filename display tags cannot select a local file");
        reject(()->MediaOrigin.route(new JSONObject().put("media_path","../other.flac"),hybrid,null),"local path stays within granted tree");
        System.out.println("PASS : "+checks+" private-origin/local playback routing assertions; no providers or live files");
    }
}
