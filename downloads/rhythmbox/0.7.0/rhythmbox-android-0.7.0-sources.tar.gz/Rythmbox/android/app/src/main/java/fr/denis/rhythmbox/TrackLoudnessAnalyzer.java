package fr.denis.rhythmbox;

import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaDataSource;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BooleanSupplier;

/** Silent complete-track decoder. It creates no AudioTrack, surface or file. */
public final class TrackLoudnessAnalyzer {
    private TrackLoudnessAnalyzer(){}
    public interface Progress {void onProgress(long positionUs,long durationUs);}
    public static final class Cancelled extends IOException {Cancelled(){super("Analyse de volume annulée");}}
    public static final class Cancellation implements AutoCloseable {
        private final AtomicBoolean closed=new AtomicBoolean();private final BooleanSupplier valid;
        private final long deadline=System.nanoTime()+60_000_000_000L;
        private final java.util.Set<Runnable> cleanup=java.util.concurrent.ConcurrentHashMap.newKeySet();
        public Cancellation(BooleanSupplier valid){if(valid==null)throw new NullPointerException();this.valid=valid;}
        public void check() throws IOException {
            if(closed.get()||!valid.getAsBoolean()||Thread.currentThread().isInterrupted()){close();throw new Cancelled();}
            if(System.nanoTime()>deadline){close();throw new IOException("Analyse trop longue ; volume d’origine conservé");}
        }
        public java.io.Closeable register(Runnable action){cleanup.add(action);if(closed.get()&&cleanup.remove(action))later(action);return ()->cleanup.remove(action);}
        private static void later(Runnable action){Thread t=new Thread(()->{try{action.run();}catch(Exception ignored){}},"volume-analysis-close");t.setDaemon(true);t.start();}
        @Override public void close(){if(closed.compareAndSet(false,true))for(Runnable action:cleanup)if(cleanup.remove(action))later(action);}
    }
    public static TrackLoudness.Result measure(File file,Cancellation cancellation,Progress progress) throws Exception {
        cancellation.check();MediaExtractor extractor=new MediaExtractor();
        try(FileInputStream input=new FileInputStream(file)){extractor.setDataSource(input.getFD());return decode(extractor,cancellation,progress);}
        finally{extractor.release();}
    }
    public static TrackLoudness.Result measure(MediaDataSource source,Cancellation cancellation,Progress progress) throws Exception {
        cancellation.check();MediaExtractor extractor=new MediaExtractor();
        // The caller owns its media source, including cancellation and keys.
        MediaDataSource borrowed=new MediaDataSource(){
            public int readAt(long at,byte[] bytes,int offset,int length) throws IOException{cancellation.check();return source.readAt(at,bytes,offset,length);}
            public long getSize() throws IOException{cancellation.check();return source.getSize();}
            public void close(){}
        };
        try{extractor.setDataSource(borrowed);return decode(extractor,cancellation,progress);}finally{extractor.release();}
    }
    private static TrackLoudness.Result decode(MediaExtractor extractor,Cancellation cancellation,Progress progress) throws Exception {
        int track=-1;MediaFormat inputFormat=null;
        for(int i=0;i<extractor.getTrackCount();i++){
            MediaFormat format=extractor.getTrackFormat(i);String mime=format.getString(MediaFormat.KEY_MIME);
            if(mime!=null&&mime.startsWith("audio/")){track=i;inputFormat=format;break;}
        }
        if(track<0)throw new IOException("Aucune piste audio à mesurer");
        if(inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)<1||inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)>2)
            throw new IOException("Analyse disponible pour les pistes mono et stéréo");
        long duration=inputFormat.containsKey(MediaFormat.KEY_DURATION)?inputFormat.getLong(MediaFormat.KEY_DURATION):0;
        if(duration>43_200_000_000L)throw new IOException("Piste trop longue pour l’analyse");
        extractor.selectTrack(track);String mime=inputFormat.getString(MediaFormat.KEY_MIME);
        MediaCodec codec=MediaCodec.createDecoderByType(mime);boolean started=false;
        TrackLoudness meter=null;int rate=0,channels=0,encoding=AudioFormat.ENCODING_PCM_16BIT;
        try{
            // Retain Android's default codec/DRC behavior, as MediaPlayer does.
            // Never add a second tag-based gain or silently guess PCM layout.
            codec.configure(inputFormat,null,null,0);codec.start();started=true;
            boolean inputEnded=false,outputEnded=false;MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();long reported=0;
            while(!outputEnded){
                cancellation.check();
                if(!inputEnded){int slot=codec.dequeueInputBuffer(10000);if(slot>=0){
                    ByteBuffer buffer=codec.getInputBuffer(slot);if(buffer==null)throw new IOException("Décodeur indisponible");
                    int length=extractor.readSampleData(buffer,0);
                    if(length<0){codec.queueInputBuffer(slot,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputEnded=true;}
                    else{if((extractor.getSampleFlags()&MediaExtractor.SAMPLE_FLAG_ENCRYPTED)!=0)throw new IOException("Piste protégée non analysable");
                        codec.queueInputBuffer(slot,0,length,Math.max(0,extractor.getSampleTime()),0);extractor.advance();}
                }}
                int slot=codec.dequeueOutputBuffer(info,10000);
                if(slot==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){
                    MediaFormat format=codec.getOutputFormat();int newRate=format.getInteger(MediaFormat.KEY_SAMPLE_RATE),newChannels=format.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    int newEncoding=format.containsKey(MediaFormat.KEY_PCM_ENCODING)?format.getInteger(MediaFormat.KEY_PCM_ENCODING):AudioFormat.ENCODING_PCM_16BIT;
                    if(meter!=null&&(rate!=newRate||channels!=newChannels||encoding!=newEncoding))throw new IOException("Le format audio change pendant la piste");
                    rate=newRate;channels=newChannels;encoding=newEncoding;
                    if(encoding!=AudioFormat.ENCODING_PCM_16BIT&&encoding!=AudioFormat.ENCODING_PCM_FLOAT)throw new IOException("Ce format PCM ne peut pas être mesuré");
                    if(meter==null)meter=new TrackLoudness(rate,channels);
                }else if(slot>=0){
                    try{if(info.size>0&&(info.flags&MediaCodec.BUFFER_FLAG_CODEC_CONFIG)==0){
                        if(meter==null)throw new IOException("Format PCM non annoncé par le décodeur");
                        ByteBuffer buffer=codec.getOutputBuffer(slot);if(buffer==null||info.offset<0||info.size<0||info.size>8*1024*1024||
                            info.offset+info.size>buffer.capacity())throw new IOException("Bloc PCM invalide");
                        int stride=channels*(encoding==AudioFormat.ENCODING_PCM_FLOAT?4:2);if(info.size%stride!=0)throw new IOException("Bloc PCM incomplet");
                        buffer.position(info.offset);buffer.limit(info.offset+info.size);buffer.order(ByteOrder.LITTLE_ENDIAN);
                        int frames=info.size/stride;
                        for(int frame=0;frame<frames;frame++){
                            if((frame&1023)==0)cancellation.check();
                            double left=encoding==AudioFormat.ENCODING_PCM_FLOAT?buffer.getFloat():buffer.getShort()/32768.0;
                            double right=channels==1?left:encoding==AudioFormat.ENCODING_PCM_FLOAT?buffer.getFloat():buffer.getShort()/32768.0;
                            meter.addFrame(left,right);
                        }
                        if(progress!=null&&info.presentationTimeUs-reported>=1_000_000){reported=info.presentationTimeUs;progress.onProgress(Math.max(0,reported),duration);}
                    }}finally{codec.releaseOutputBuffer(slot,false);}
                    outputEnded=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                }
            }
            cancellation.check();if(meter==null)throw new IOException("Aucune donnée audio mesurée");return meter.finish();
        }finally{if(started)try{codec.stop();}catch(Exception ignored){}codec.release();}
    }
}
