package fr.denis.rhythmbox;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;

/** Token-bearing verified app link is consumed here and never forwarded to MainActivity. */
public final class PCloudOAuthCallbackActivity extends Activity {
    private volatile boolean completed, cancelled;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        String callback = takeData(getIntent());
        if (state != null || callback == null) { complete(false); return; }
        TextView status = new TextView(this);
        status.setText("Vérification du compte musical pCloud…");
        status.setTextColor(0xfff3f7fd);
        status.setBackgroundColor(0xff10151e);
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);
        status.setPadding(24, 24, 24, 24);
        setContentView(status);
        new Thread(() -> {
            boolean ok = false;
            try { PCloudOAuth.consume(getApplicationContext(), callback); ok = true; }
            catch (Exception ignored) { /* Only a generic result leaves this activity. */ }
            final boolean success = ok;
            runOnUiThread(() -> { if (!cancelled && !isFinishing()) complete(success); });
        }, "rhythmbox-pcloud-identity").start();
    }

    private String takeData(Intent intent) {
        Uri uri = intent != null && Intent.ACTION_VIEW.equals(intent.getAction()) ? intent.getData() : null;
        if (intent != null) { intent.setData(null); intent.replaceExtras((Bundle) null); }
        setIntent(new Intent());
        return uri == null ? null : uri.toString();
    }

    @Override public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        takeData(intent); // Duplicate callbacks never start a second verifier.
    }

    private void complete(boolean ok) {
        completed = true;
        Intent result = new Intent().setClassName(getPackageName(), getPackageName() + ".MainActivity");
        result.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        result.putExtra(PCloudOAuth.EXTRA_AUTH_RESULT, ok);
        startActivity(result);
        finish();
    }

    @Override public void onBackPressed() {
        cancelled = true;
        PCloudOAuth.cancel(getApplicationContext());
        super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (!completed && isFinishing()) {
            cancelled = true;
            PCloudOAuth.cancel(getApplicationContext());
        }
        super.onDestroy();
    }
}
