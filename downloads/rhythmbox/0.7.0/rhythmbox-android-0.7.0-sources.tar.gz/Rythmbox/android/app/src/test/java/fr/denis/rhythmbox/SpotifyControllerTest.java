package fr.denis.rhythmbox;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Local session controller boundaries only. No Android method is executed,
 * no installed app/account/permission exists and no network is possible. */
public final class SpotifyControllerTest {
    private static int checks;
    private static void yes(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
    private static SpotifyController.Readout value(String id,boolean playing,boolean loading,
            long position,long duration,boolean play,boolean pause,boolean next,boolean previous,boolean seek){
        return new SpotifyController.Readout(id,"Title "+id,"Synthetic artist","Synthetic album",null,
            playing,loading,position,duration,play,pause,next,previous,seek);
    }
    private static SpotifyController.Readout full(String id){return value(id,false,false,150,1000,true,true,true,true,true);}

    private static final class Queue implements SpotifyController.Dispatcher {
        final ArrayDeque<Runnable> actions=new ArrayDeque<>();
        public void post(Runnable action){actions.add(action);}
        void drain(){int count=0;while(!actions.isEmpty()){if(++count>1000)throw new AssertionError("Unbounded dispatcher retry");actions.remove().run();}}
    }
    private static final class Call {
        final SpotifyController.Command command;final long position;
        Call(SpotifyController.Command command,long position){this.command=command;this.position=position;}
    }
    private static final class Session implements SpotifyController.Session {
        final String pkg;final Object identity=new Object();
        SpotifyController.Readout readout;SpotifyController.SessionCallback listener;
        final List<Call> calls=new ArrayList<>();
        int reads,listens,unlistens;boolean forbiddenRead,failRead,accept=true;Runnable duringPerform;
        Session(String pkg,String id){this.pkg=pkg;readout=full(id);}
        public String packageName(){return pkg;}
        public Object token(){return identity;}
        public SpotifyController.Readout read(){reads++;if(forbiddenRead)throw new AssertionError("Foreign metadata was read");if(failRead)throw new IllegalStateException("Synthetic session read failure");return readout;}
        public void listen(SpotifyController.SessionCallback listener){listens++;this.listener=listener;}
        public void unlisten(){unlistens++;listener=null;}
        public boolean perform(SpotifyController.Command command,long position){calls.add(new Call(command,position));if(duringPerform!=null)duringPerform.run();return accept;}
    }
    private static final class Gateway implements SpotifyController.Gateway {
        boolean access=true,securityFailure;int uid=12345,enumerations,listens,unlistens;
        List<SpotifyController.Session> available=new ArrayList<>();Runnable listener;
        public boolean hasAccess(){return access;}
        public int spotifyUid(){return uid;}
        public List<SpotifyController.Session> sessions(){enumerations++;if(securityFailure)throw new SecurityException("Synthetic revoked access");return new ArrayList<>(available);}
        public void listen(Runnable listener){listens++;this.listener=listener;}
        public void unlisten(){unlistens++;listener=null;}
        void changed(){if(listener!=null)listener.run();}
    }
    private static final class Fixture {
        final Gateway gateway=new Gateway();final Queue queue=new Queue();
        final Session spotify=new Session("com.spotify.music","A");
        final List<SpotifyController.State> observed=new ArrayList<>();
        final SpotifyController controller=new SpotifyController(gateway,queue,observed::add);
        Fixture(){gateway.available.add(spotify);}
        void start(){controller.start();queue.drain();}
        void close(){controller.stop();queue.drain();}
    }
    private static void unavailable(SpotifyController.State state,String label){
        yes(state!=null&&!state.available,label+" unavailable");
        yes(!state.playing&&!state.loading,label+" no active playback");
        yes(!state.canPlay&&!state.canPause&&!state.canNext&&!state.canPrevious&&!state.canSeek,label+" no controls");
        yes(state.id.isEmpty()&&state.title.isEmpty()&&state.artist.isEmpty()&&state.album.isEmpty()&&state.cover==null,label+" no stale metadata");
        yes(!state.shufflePossible,label+" shuffle unavailable");
    }

    private static void startAndStopAreObservationOnly(){
        Fixture f=new Fixture();
        unavailable(f.controller.state(),"initial state");
        yes(!f.controller.resume(),"command before start refused");
        yes(f.spotify.calls.isEmpty(),"inactive command cannot start a player");
        f.start();
        yes(f.controller.state().available&&f.controller.state().hasAccess,"single authorized Spotify selected");
        yes(f.controller.state().id.equals("A")&&f.controller.state().title.equals("Title A"),"Spotify metadata retained");
        yes(f.controller.state().artist.equals("Synthetic artist")&&f.controller.state().album.equals("Synthetic album"),"artist and album presented");
        yes(f.controller.state().position==150&&f.controller.state().duration==1000,"time unit remains milliseconds");
        yes(f.controller.state().positionNow()==150,"untimestamped synthetic snapshot has no clock or network dependency");
        yes(f.controller.state().cover==null&&!f.controller.state().shufflePossible,"host cover null and no guessed shuffle");
        yes(f.spotify.calls.isEmpty(),"start never plays or pauses Spotify");
        f.controller.start();f.queue.drain();
        yes(f.gateway.listens==1&&f.spotify.listens==1,"repeated start does not duplicate watchers");
        long generation=f.controller.state().sessionGeneration;
        f.controller.stop();f.queue.drain();
        yes(f.spotify.calls.isEmpty(),"stop never pauses Spotify");
        yes(f.spotify.unlistens==1&&f.gateway.unlistens==1,"stop unsubscribes exact local watchers");
        yes(f.controller.state().sessionGeneration>generation,"stop invalidates selected session generation");
        unavailable(f.controller.state(),"stopped state");
        yes(!f.controller.next()&&!f.controller.pause(),"stopped controls rejected");
        yes(f.spotify.calls.isEmpty(),"no stopped command fallback");
        f.controller.start();f.queue.drain();
        yes(f.controller.state().available,"observing can resume without destroying platform session");
        yes(f.spotify.calls.isEmpty(),"observing again still does not autoplay");
        f.close();
    }

    private static void accessAndPackageBoundaries(){
        Fixture denied=new Fixture();denied.gateway.access=false;denied.start();
        unavailable(denied.controller.state(),"access denied");
        yes(!denied.controller.state().hasAccess&&denied.gateway.enumerations==0&&denied.spotify.reads==0,"no access never enumerates or reads sessions");
        yes(!denied.controller.resume()&&!denied.controller.next()&&denied.spotify.calls.isEmpty(),"no permission has no transport fallback");denied.close();
        Fixture missing=new Fixture();missing.gateway.uid=-1;missing.start();
        unavailable(missing.controller.state(),"Spotify not installed");
        yes(missing.gateway.enumerations==0&&missing.spotify.reads==0,"absent Spotify UID stops before enumeration");missing.close();
        Fixture empty=new Fixture();empty.gateway.available.clear();empty.start();
        unavailable(empty.controller.state(),"no sessions");
        yes(!empty.controller.resume()&&empty.spotify.calls.isEmpty(),"no session cannot bootstrap Spotify playback");empty.close();
        Fixture filtered=new Fixture();Session other=new Session("fr.other.player","FOREIGN");other.forbiddenRead=true;
        Session fake=new Session("com.spotify.music.fake","SPOOF");fake.forbiddenRead=true;
        filtered.gateway.available=Arrays.asList(other,fake,filtered.spotify);filtered.start();
        yes(filtered.controller.state().available&&filtered.controller.state().id.equals("A"),"priority of foreign app does not redirect selection");
        yes(other.reads==0&&fake.reads==0,"only exact com.spotify.music metadata read");
        yes(filtered.controller.next(),"exact selected Spotify supports next");
        yes(filtered.spotify.calls.size()==1&&other.calls.isEmpty()&&fake.calls.isEmpty(),"transport reaches only exact Spotify");filtered.close();
        Fixture foreignOnly=new Fixture();Session foreign=new Session("fr.other.player","OTHER");foreign.forbiddenRead=true;
        foreignOnly.gateway.available=Collections.singletonList(foreign);foreignOnly.start();
        unavailable(foreignOnly.controller.state(),"foreign sessions only");
        yes(foreign.reads==0&&!foreignOnly.controller.next()&&foreign.calls.isEmpty(),"no global player or metadata fallback");foreignOnly.close();
        Fixture multiple=new Fixture();Session second=new Session("com.spotify.music","B");
        multiple.gateway.available=Arrays.asList(multiple.spotify,second);multiple.start();
        unavailable(multiple.controller.state(),"ambiguous sessions");
        yes(multiple.spotify.reads==0&&second.reads==0,"ambiguity resolved before reading any Spotify metadata");
        yes(!multiple.controller.resume()&&multiple.spotify.calls.isEmpty()&&second.calls.isEmpty(),"ambiguous transport refused");multiple.close();
    }

    private static void capabilitiesAndSeek(){
        Fixture f=new Fixture();f.start();
        f.spotify.readout=value("A",false,false,150,1000,false,false,false,false,false);
        yes(!f.controller.resume()&&!f.controller.pause()&&!f.controller.next()&&!f.controller.previous()&&!f.controller.seekTo(40),"every disabled capability refuses its command");
        yes(f.spotify.calls.isEmpty(),"disabled controls never invoke transport");
        f.spotify.readout=full("A");
        yes(f.controller.resume()&&f.controller.pause()&&f.controller.next()&&f.controller.previous(),"explicit supported controls dispatched");
        List<SpotifyController.Command> commands=new ArrayList<>();for(Call c:f.spotify.calls)commands.add(c.command);
        yes(commands.equals(Arrays.asList(SpotifyController.Command.PLAY,SpotifyController.Command.PAUSE,SpotifyController.Command.NEXT,SpotifyController.Command.PREVIOUS)),"commands remain explicit instead of guessed toggles");
        yes(!f.controller.state().playing,"accepted play request is not proof that Spotify started");
        int count=f.spotify.calls.size();yes(!f.controller.seekTo(-1)&&!f.controller.seekTo(Long.MIN_VALUE),"negative seek refused");
        yes(f.spotify.calls.size()==count,"negative seek has no transport effect");
        yes(f.controller.seekTo(0)&&f.spotify.calls.get(count).position==0,"seek to beginning");
        yes(f.controller.seekTo(500)&&f.spotify.calls.get(count+1).position==500,"seek within duration");
        yes(f.controller.seekTo(Long.MAX_VALUE)&&f.spotify.calls.get(count+2).position==1000,"seek above known duration clamps");
        f.spotify.readout=value("A",true,false,150,0,true,true,true,true,true);
        yes(f.controller.seekTo(5000)&&f.spotify.calls.get(count+3).position==5000,"unknown duration does not invent a bound");
        f.spotify.readout=value("A",true,true,-5,-2,true,true,true,true,true);f.controller.refresh();f.queue.drain();
        yes(f.controller.state().playing&&f.controller.state().loading,"Spotify announces its own playback and buffering");
        yes(f.controller.state().position==0&&f.controller.state().duration==0,"negative presentation times bounded");
        f.close();
        Fixture rejected=new Fixture();rejected.start();rejected.spotify.accept=false;
        yes(!rejected.controller.resume(),"provider rejection is not playback success");
        unavailable(rejected.controller.state(),"rejected transport");rejected.close();
    }

    private static void changesDestroyedSessionsAndUid(){
        Fixture f=new Fixture();f.start();SpotifyController.SessionCallback stale=f.spotify.listener;
        long first=f.controller.state().sessionGeneration;
        f.spotify.readout=value("A2",true,false,600,1000,true,true,true,false,true);stale.onChanged();f.queue.drain();
        yes(f.controller.state().id.equals("A2")&&f.controller.state().playing,"live session callback refreshes state");
        yes(f.controller.state().sessionGeneration==first,"ordinary metadata updates keep generation");
        stale.onDestroyed();f.queue.drain();long destroyed=f.controller.state().sessionGeneration;
        unavailable(f.controller.state(),"destroyed session");
        yes(destroyed>first,"destruction invalidates generation");int reads=f.spotify.reads;
        f.controller.refresh();f.queue.drain();
        unavailable(f.controller.state(),"destroyed token still listed");
        yes(f.spotify.reads==reads&&!f.controller.next(),"destroyed token tombstone blocks read and reuse");
        Session replacement=new Session("com.spotify.music","NEW");f.gateway.available=Collections.singletonList(replacement);f.controller.refresh();f.queue.drain();
        yes(f.controller.state().available&&f.controller.state().id.equals("NEW"),"new session token may be observed");
        long fresh=f.controller.state().sessionGeneration;int replacementReads=replacement.reads;
        stale.onChanged();stale.onDestroyed();f.queue.drain();
        yes(f.controller.state().id.equals("NEW")&&f.controller.state().sessionGeneration==fresh,"late old callbacks do not overwrite or destroy new session");
        yes(replacement.reads==replacementReads,"late callback cannot reread another generation");
        yes(f.controller.next()&&replacement.calls.size()==1&&f.spotify.calls.isEmpty(),"controls use replacement only");f.close();
        Fixture changedUid=new Fixture();changedUid.start();int before=changedUid.spotify.reads;
        changedUid.gateway.uid++;
        yes(!changedUid.controller.next()&&changedUid.spotify.calls.isEmpty(),"reinstalled app UID rejects old controller transport");
        yes(changedUid.spotify.reads==before,"UID mismatch rejected before stale metadata read");
        unavailable(changedUid.controller.state(),"UID changed");
        Session newer=new Session("com.spotify.music","REINSTALLED");changedUid.gateway.available=Collections.singletonList(newer);changedUid.controller.refresh();changedUid.queue.drain();
        yes(changedUid.controller.state().available&&changedUid.controller.next()&&newer.calls.size()==1,"fresh token of current UID may be controlled");changedUid.close();
    }

    private static void queuedPublicationAndRevocation(){
        Fixture replaced=new Fixture();replaced.controller.start();Session next=new Session("com.spotify.music","NEXT");
        replaced.gateway.available=Collections.singletonList(next);replaced.controller.refresh();replaced.queue.drain();
        yes(!replaced.observed.isEmpty(),"current generation eventually published");
        for(SpotifyController.State state:replaced.observed)yes(!state.available||state.id.equals("NEXT"),"queued old generation metadata suppressed");
        replaced.close();
        Fixture stopped=new Fixture();stopped.controller.start();stopped.controller.stop();stopped.queue.drain();
        for(SpotifyController.State state:stopped.observed)yes(!state.available,"queued state cannot revive stopped controller");
        yes(stopped.spotify.calls.isEmpty(),"stale publication never dispatches playback");
        Fixture revoked=new Fixture();revoked.controller.start();revoked.gateway.access=false;
        revoked.queue.drain();
        for(SpotifyController.State state:revoked.observed)yes(!state.available,"revoked access checked when queued listener executes");
        unavailable(revoked.controller.state(),"revoked before queued listener delivery");
        yes(!revoked.controller.pause()&&!revoked.controller.next()&&revoked.spotify.calls.isEmpty(),"revocation cannot control another or previous player");revoked.close();
        Fixture notified=new Fixture();notified.start();notified.observed.clear();
        SpotifyController.SessionCallback old=notified.spotify.listener;notified.gateway.access=false;notified.gateway.changed();old.onChanged();notified.queue.drain();
        unavailable(notified.controller.state(),"notified access revocation");
        yes(notified.gateway.unlistens==1&&notified.spotify.unlistens==1,"revocation releases local watchers");
        for(SpotifyController.State state:notified.observed)yes(!state.available,"revocation notification never republishes old metadata");notified.close();
    }

    private static void transportCallbacksDoNotRestoreAnOlderSnapshot(){
        Fixture immediate=new Fixture();immediate.start();
        immediate.spotify.duringPerform=()->{
            immediate.spotify.readout=value("CONFIRMED",true,false,180,1000,true,true,true,true,true);
            immediate.spotify.listener.onChanged();
        };
        yes(immediate.controller.resume(),"explicit play request accepted during immediate state callback");immediate.queue.drain();
        yes(immediate.controller.state().id.equals("CONFIRMED")&&immediate.controller.state().playing,"newer Spotify acknowledgement survives command return");
        yes(immediate.observed.get(immediate.observed.size()-1).id.equals("CONFIRMED"),"queued delivery also keeps the newer acknowledgement");immediate.close();
        Fixture destroyed=new Fixture();destroyed.start();SpotifyController.SessionCallback callback=destroyed.spotify.listener;
        destroyed.spotify.duringPerform=callback::onDestroyed;
        yes(destroyed.controller.next(),"transport request can finish as the session is destroyed");destroyed.queue.drain();
        unavailable(destroyed.controller.state(),"destruction during command");
        yes(!destroyed.controller.previous()&&destroyed.spotify.calls.size()==1,"destroyed session cannot be resurrected by the completed request");destroyed.close();
        Fixture revoked=new Fixture();revoked.start();
        revoked.spotify.duringPerform=()->{revoked.gateway.access=false;revoked.gateway.changed();};
        yes(revoked.controller.pause(),"explicit request can return after permission revocation callback");revoked.queue.drain();
        unavailable(revoked.controller.state(),"revocation during command");
        yes(!revoked.controller.next()&&revoked.spotify.calls.size()==1,"revoked session stays disconnected after request return");revoked.close();
    }

    private static void activeSelectionNeverFallsBackWhenItDisappearsOrBecomesAmbiguous(){
        Fixture gone=new Fixture();gone.start();Session foreign=new Session("fr.other.player","OTHER");foreign.forbiddenRead=true;
        gone.gateway.available=Collections.singletonList(foreign);
        yes(!gone.controller.next(),"disappearing Spotify cannot route command to another player");
        unavailable(gone.controller.state(),"selected Spotify disappeared");
        yes(gone.spotify.calls.isEmpty()&&foreign.calls.isEmpty()&&foreign.reads==0,"disappearance neither controls nor reads foreign session");gone.close();
        Fixture many=new Fixture();many.start();int reads=many.spotify.reads;Session added=new Session("com.spotify.music","NEW");
        many.gateway.available=Arrays.asList(many.spotify,added);
        yes(!many.controller.resume(),"new ambiguity invalidates existing transport selection");
        unavailable(many.controller.state(),"ambiguity after selection");
        yes(many.spotify.reads==reads&&added.reads==0&&many.spotify.calls.isEmpty()&&added.calls.isEmpty(),"live ambiguity rejected before any new metadata or transport");many.close();
    }

    private static void failuresStayLocalAndClosed(){
        Fixture broken=new Fixture();broken.spotify.failRead=true;broken.start();
        unavailable(broken.controller.state(),"session read failure");
        yes(!broken.controller.next()&&broken.spotify.calls.isEmpty(),"read failure has no player fallback");broken.close();
        Fixture security=new Fixture();security.gateway.securityFailure=true;security.start();
        unavailable(security.controller.state(),"platform security failure");
        yes(!security.controller.state().hasAccess&&security.spotify.reads==0,"platform security failure does not read metadata");
        yes(!security.controller.resume()&&security.spotify.calls.isEmpty(),"platform failure never starts playback");security.close();
    }

    private static void removedApplicationUidCannotResurrectAnOldToken(){
        Fixture f=new Fixture();f.start();long generation=f.controller.state().sessionGeneration;
        f.gateway.uid=-1;f.controller.refresh();f.queue.drain();
        yes(!f.controller.state().available&&f.controller.state().sessionGeneration>generation,"uninstalled owner invalidates its selected token");
        f.gateway.uid=23456;f.controller.refresh();f.queue.drain();
        yes(!f.controller.state().available,"reinstalled owner cannot revive the previous UID token");
        yes(!f.controller.resume()&&f.spotify.calls.isEmpty(),"reinstall never dispatches to old owner");
        Session replacement=new Session("com.spotify.music","REINSTALLED");
        f.gateway.available=Collections.singletonList(replacement);f.controller.refresh();f.queue.drain();
        yes(f.controller.state().available&&f.controller.state().id.equals("REINSTALLED"),"new owner needs a fresh session token");
        yes(replacement.calls.isEmpty(),"fresh token adoption does not autoplay");f.close();
    }

    public static void main(String[] args){
        startAndStopAreObservationOnly();accessAndPackageBoundaries();capabilitiesAndSeek();
        changesDestroyedSessionsAndUid();queuedPublicationAndRevocation();transportCallbacksDoNotRestoreAnOlderSnapshot();
        activeSelectionNeverFallsBackWhenItDisappearsOrBecomesAmbiguous();failuresStayLocalAndClosed();
        removedApplicationUidCannotResurrectAnOldToken();
        System.out.println("PASS : "+checks+" Spotify local-session/privacy/generation/command assertions; fake sessions only, no Android API, account, device or network");
    }
}
