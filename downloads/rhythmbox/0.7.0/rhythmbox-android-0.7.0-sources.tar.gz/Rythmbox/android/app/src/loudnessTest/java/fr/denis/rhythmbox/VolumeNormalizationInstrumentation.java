package fr.denis.rhythmbox;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.media.MediaDataSource;
import android.media.MediaPlayer;
import android.media.AudioManager;
import android.media.audiofx.Visualizer;
import android.os.Bundle;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Real codecs and player effects measured on the isolated test AVD output. */
public final class VolumeNormalizationInstrumentation extends Instrumentation {
    private int assertions,failures;
    private final JSONArray scenarios=new JSONArray();
    private final JSONArray outputMeasurements=new JSONArray();
    private File directory;
    private JSONObject references;
    private interface Checked { void run() throws Exception; }
    private void check(boolean value,String label) {
        assertions++;
        if(!value)throw new AssertionError(label);
    }
    private void scenario(String name,Checked task) throws Exception {
        try {task.run();scenarios.put(new JSONObject().put("scenario",name).put("ok",true));}
        catch(Throwable failure){failures++;scenarios.put(new JSONObject().put("scenario",name).put("ok",false).put("error",failure.getClass().getSimpleName()+": "+failure.getMessage()));}
    }
    private byte[] asset(String name) throws Exception {
        try(InputStream in=getContext().getAssets().open("volume-fixtures/"+name)) {
            java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] block=new byte[8192];int n;
            while((n=in.read(block))!=-1)out.write(block,0,n);
            return out.toByteArray();
        }
    }
    private File file(String name) throws Exception {
        File out=new File(directory,name);
        try(FileOutputStream stream=new FileOutputStream(out)){stream.write(asset(name));}
        return out;
    }
    private TrackLoudness.Result measure(File file) throws Exception {
        TrackLoudnessAnalyzer.Cancellation cancel=new TrackLoudnessAnalyzer.Cancellation(()->true);
        try{return TrackLoudnessAnalyzer.measure(file,cancel,null);}finally{cancel.close();}
    }
    private void reference(String name,double tolerance) throws Exception {
        TrackLoudness.Result value=measure(file(name));JSONObject expected=references.getJSONObject(name);
        check(value.measured,"audible complete source is measurable: "+name);
        check(Math.abs(value.integratedLufs-expected.getDouble("input_i"))<=tolerance,"R128 agrees with FFmpeg: "+name+" actual="+value.integratedLufs);
        check(value.gainDb()<=12.0001,"boost capped: "+name);
        check(value.peakDb()+value.gainDb()<=-0.999,"measured peak ceiling: "+name);
        check(value.frames>0&&value.sampleRate>0,"decoded PCM measured: "+name);
    }
    private static final class MemorySource extends MediaDataSource {
        final byte[] bytes;boolean closed;
        MemorySource(byte[] bytes){this.bytes=bytes;}
        public int readAt(long position,byte[] target,int offset,int size){
            if(position>=bytes.length)return -1;
            int count=Math.min(size,bytes.length-(int)position);System.arraycopy(bytes,(int)position,target,offset,count);return count;
        }
        public long getSize(){return bytes.length;}
        public void close(){closed=true;}
    }
    private double rms(Visualizer visualizer,long milliseconds) throws Exception {
        List<Integer> values=new ArrayList<>();long until=android.os.SystemClock.elapsedRealtime()+milliseconds;
        while(android.os.SystemClock.elapsedRealtime()<until){
            Visualizer.MeasurementPeakRms value=new Visualizer.MeasurementPeakRms();
            if(visualizer.getMeasurementPeakRms(value)==Visualizer.SUCCESS&&value.mRms>-8500)values.add(value.mRms);
            Thread.sleep(40);
        }
        check(values.size()>=3,"isolated output real PCM measurements available");Collections.sort(values);return values.get(values.size()/2)/100.;
    }
    private Visualizer outputVisualizer() throws Exception {
        // Same-session Visualizer is INSERT_FIRST, before INSERT_LAST DP. Only
        // this empty, named emulator permits inspection of the final mix.
        Visualizer value=new Visualizer(0);value.setCaptureSize(1024);
        value.setScalingMode(Visualizer.SCALING_MODE_AS_PLAYED);
        value.setMeasurementMode(Visualizer.MEASUREMENT_MODE_PEAK_RMS);value.setEnabled(true);return value;
    }
    private double settledRms(Visualizer visualizer) throws Exception {
        // The native measurement includes the most recent 25 mixer buffers.
        // Flush those, the effect latency and the output device queue first.
        Thread.sleep(1000);return rms(visualizer,400);
    }
    private void staticGain(String name,int expectedSign) throws Exception {
        File source=file(name);TrackLoudness.Result measured=measure(source);
        check(measured.measured&&Math.signum(measured.gainDb())==expectedSign,"fixture correction has intended sign");
        if(name.equals("very-quiet.wav"))check(Math.abs(measured.gainDb()-12)<.0001,"quiet fixture reaches the maximum fixed boost");
        MediaPlayer player=new MediaPlayer();Visualizer visualizer=null;TrackVolumeEffect effect=new TrackVolumeEffect();
        AudioManager manager=(AudioManager)getContext().getSystemService(android.content.Context.AUDIO_SERVICE);
        int userVolume=manager.getStreamVolume(AudioManager.STREAM_MUSIC);
        try {
            player.setDataSource(source.getAbsolutePath());player.setLooping(true);player.prepare();
            check(player.getAudioSessionId()>0,"effect uses its player's nonzero session");
            visualizer=outputVisualizer();player.start();double before=settledRms(visualizer);
            String status=effect.apply(player,measured,true);
            String details=Math.signum(effect.appliedGainDb())==expectedSign?status:status+"; "+gainDiagnostic(player.getAudioSessionId(),(float)measured.gainDb());
            check(Math.signum(effect.appliedGainDb())==expectedSign,"device applies measured correction: "+details);
            check(Math.abs(effect.appliedGainDb()-measured.gainDb())<.05,"applied gain matches correction");
            double after=settledRms(visualizer);
            effect.apply(player,measured,false);double restored=settledRms(visualizer);
            JSONObject metrics=new JSONObject().put("fixture",name).put("requested_db",measured.gainDb())
                .put("before_rms_dbfs",before).put("after_rms_dbfs",after).put("restored_rms_dbfs",restored)
                .put("observed_db",after-before).put("music_volume_before",userVolume)
                .put("music_volume_after",manager.getStreamVolume(AudioManager.STREAM_MUSIC));outputMeasurements.put(metrics);
            check(Math.abs((after-before)-measured.gainDb())<1.2,"post-effect correction: "+metrics);
            check(Math.abs(effect.appliedGainDb())<.001,"off reports neutral gain");
            check(Math.abs(restored-before)<.7,"off restores original output: "+metrics);
            check(manager.getStreamVolume(AudioManager.STREAM_MUSIC)==userVolume,"system music volume is unchanged");
        } finally {effect.close();if(visualizer!=null)visualizer.release();player.release();}
    }
    private String gainDiagnostic(int session,float gain){
        android.media.audiofx.DynamicsProcessing probe=null;
        try{
            android.media.audiofx.DynamicsProcessing.Config config=new android.media.audiofx.DynamicsProcessing.Config.Builder(
                android.media.audiofx.DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,2,false,0,false,0,false,0,false).setInputGainAllChannelsTo(gain).build();
            probe=new android.media.audiofx.DynamicsProcessing(0,session,config);
            android.media.audiofx.DynamicsProcessing.Config actual=probe.getConfig();
            return "channels="+probe.getChannelCount()+", pre="+actual.isPreEqInUse()+", mbc="+actual.isMbcInUse()+", post="+actual.isPostEqInUse()+", limiter="+actual.isLimiterInUse()+", gain="+probe.getInputGainByChannelIndex(0)+", control="+probe.hasControl();
        }catch(RuntimeException failure){return failure.getClass().getSimpleName()+": "+failure.getMessage();}
        finally{if(probe!=null)probe.release();}
    }
    @Override public void onCreate(Bundle args){super.onCreate(args);start();}
    @Override public void onStart(){
        Activity activity=null;
        try {
            directory=new File(getContext().getCacheDir(),"normalization-fixtures");check(directory.mkdirs()||directory.isDirectory(),"private test fixture directory");
            references=new JSONObject(new String(asset("references.json"),java.nio.charset.StandardCharsets.UTF_8));
            activity=startActivitySync(new Intent(getTargetContext(),VolumeProbeActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            scenario("real_codec_r128",()->{
                reference("quiet.wav",.35);reference("loud.wav",.35);reference("mono.wav",.35);reference("quiet-aac.m4a",.6);reference("quiet-opus.mp4",.6);
                TrackLoudness.Result quiet=measure(file("quiet.wav")),loud=measure(file("loud.wav"));
                check(Math.abs((quiet.integratedLufs+quiet.gainDb())-(loud.integratedLufs+loud.gainDb()))<.3,"different master levels converge without changing relative dynamics");
            });
            scenario("silence_peak_cache_and_cancel",()->{
                TrackLoudness.Result silent=measure(file("silence.wav"));check(!silent.measured||silent.gainDb()==0,"silence is not amplified");
                TrackLoudness.Result peak=measure(file("crest.wav"));check(peak.measured,"transient-rich fixture measurable");check(peak.peakDb()+peak.gainDb()<=-0.999,"transients limit the static correction");
                File original=file("quiet.wav");TrackLoudness.Result value=measure(original);File metrics=new File(directory,"metrics");check(metrics.mkdirs()||metrics.isDirectory(),"private cache base exists");TrackLoudnessCache cache=new TrackLoudnessCache(metrics);String key=TrackLoudnessCache.fileKey(original);cache.put(key,value);TrackLoudness.Result hit=cache.get(key);check(hit!=null&&Math.abs(hit.gainDb()-value.gainDb())<.0001,"private metadata cache roundtrip");
                check(original.setLastModified(original.lastModified()+2000),"change authored fixture identity");check(!key.equals(TrackLoudnessCache.fileKey(original)),"changed source invalidates cache key");
                TrackLoudnessAnalyzer.Cancellation cancel=new TrackLoudnessAnalyzer.Cancellation(()->false);boolean rejected=false;try{TrackLoudnessAnalyzer.measure(original,cancel,null);}catch(Exception expected){rejected=true;}finally{cancel.close();}check(rejected,"cancelled generation cannot publish a measurement");
            });
            scenario("borrowed_media_data_source",()->{
                MemorySource source=new MemorySource(asset("quiet-aac.m4a"));TrackLoudnessAnalyzer.Cancellation cancel=new TrackLoudnessAnalyzer.Cancellation(()->true);
                try {TrackLoudness.Result value=TrackLoudnessAnalyzer.measure(source,cancel,null);check(value.measured,"stream-like memory source is decoded");check(!source.closed,"borrowed source is not closed by the analyzer");}
                finally {cancel.close();source.close();}
            });
            scenario("real_output_static_gain",()->staticGain("quiet.wav",1));
            scenario("real_output_maximum_boost",()->staticGain("very-quiet.wav",1));
            scenario("real_output_attenuation",()->staticGain("loud.wav",-1));
        }catch(Throwable failure){failures++;try{scenarios.put(new JSONObject().put("scenario","runner").put("ok",false).put("error",failure.getClass().getSimpleName()+": "+failure.getMessage()));}catch(Exception ignored){}}
        finally{if(activity!=null){final Activity current=activity;runOnMainSync(current::finish);}}
        Bundle result=new Bundle();
        try{result.putString("report",new JSONObject().put("assertions",assertions).put("failures",failures).put("scenarios",scenarios).put("output_measurements",outputMeasurements).put("network_permission",false).put("microphone_opened",false).put("visualizer_targets_empty_test_emulator_output_mix",true).put("physical_device_tested",false).toString());}catch(Exception ignored){}
        finish(failures==0?Activity.RESULT_OK:Activity.RESULT_CANCELED,result);
    }
}
