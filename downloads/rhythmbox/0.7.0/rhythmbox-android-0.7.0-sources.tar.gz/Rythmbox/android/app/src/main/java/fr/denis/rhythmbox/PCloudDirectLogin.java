package fr.denis.rhythmbox;

import android.content.Context;
import org.json.JSONObject;
import java.security.SecureRandom;
import java.util.Base64;

/** Nonce/CAS protected direct authorization; passwords and 2FA challenges never enter storage. */
public final class PCloudDirectLogin {
    public static final class Session {
        private final JSONObject pending;
        private final PCloudAccount expected;
        private volatile boolean cancelled;
        private Session(JSONObject pending,PCloudAccount expected){this.pending=pending;this.expected=expected;}
        @Override public String toString(){return "PCloudDirectSession{state=<redacted>}";}
    }
    private PCloudDirectLogin(){}
    public static Session begin(Context context) throws Exception {
        byte[] bytes=new byte[32];new SecureRandom().nextBytes(bytes);
        JSONObject pending=new JSONObject().put("auth_type","direct").put("state",Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)).put("created_ms",System.currentTimeMillis());
        return new Session(pending,new PCloudAccountStore(context).beginDirect(pending));
    }
    public static void cancel(Context context,Session session){if(session!=null){session.cancelled=true;new PCloudAccountStore(context).cancelDirect(session.pending);}}
    public static PCloudAccount login(Context context,Session session,String email,char[] password,String region) throws Exception {
        return login(context,session,email,password,region,new PCloudDirectLoginProtocol.HttpTransport());
    }
    static PCloudAccount login(Context context,Session session,String email,char[] password,String region,PCloudDirectLoginProtocol.Transport transport) throws Exception {
        try{
            if(!active(context,session))throw PCloudDirectLoginProtocol.failure();
            return commit(context,session,PCloudDirectLoginProtocol.login(email,password,region,session.expected,transport),transport);
        }finally{if(password!=null)java.util.Arrays.fill(password,'\0');}
    }
    public static PCloudAccount twoFactor(Context context,Session session,PCloudDirectLoginProtocol.Challenge challenge,char[] code) throws Exception {
        try{
            if(!active(context,session))throw PCloudDirectLoginProtocol.failure();
            PCloudDirectLoginProtocol.Transport transport=new PCloudDirectLoginProtocol.HttpTransport();
            return commit(context,session,PCloudDirectLoginProtocol.twoFactor(challenge,code,transport),transport);
        }finally{if(code!=null)java.util.Arrays.fill(code,'\0');}
    }
    public static void sendCode(Context context,Session session,PCloudDirectLoginProtocol.Challenge challenge,boolean sms) throws Exception {
        if(!active(context,session))throw PCloudDirectLoginProtocol.failure();
        PCloudDirectLoginProtocol.sendCode(challenge,sms,new PCloudDirectLoginProtocol.HttpTransport());
    }
    static PCloudAccount commit(Context context,Session session,PCloudAccount account,PCloudDirectLoginProtocol.Transport transport) throws Exception {
        return commit(context,session,account,transport,true);
    }
    static PCloudAccount commit(Context context,Session session,PCloudAccount account,PCloudDirectLoginProtocol.Transport transport,boolean persistent) throws Exception {
        return commit(context,session,account,transport,persistent,true);
    }
    static PCloudAccount commit(Context context,Session session,PCloudAccount account,PCloudDirectLoginProtocol.Transport transport,boolean persistent,boolean revokeOnFailure) throws Exception {
        try{
            if(session.cancelled||!new PCloudAccountStore(context).saveDirect(session.pending,session.expected,account,persistent))throw new IllegalStateException("La connexion a été annulée ou remplacée. Recommence dans Rhythmbox.");
            return account;
        }catch(Exception failure){if(revokeOnFailure)PCloudDirectLoginProtocol.revoke(account.region,account.token,session.expected,transport);throw failure;}
    }
    static boolean active(Context context,Session session) throws Exception{return session!=null&&!session.cancelled&&new PCloudAccountStore(context).directActive(session.pending,session.expected);}
    static PCloudAccount expectedAccount(Session session){return session==null?null:session.expected;}
}
