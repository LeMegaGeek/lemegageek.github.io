package fr.denis.rhythmbox;

import android.graphics.*;
import android.graphics.drawable.Drawable;

/** Small native vector glyphs: predictable rendering, including on offline devices. */
public final class UiIcons {
    private UiIcons() {}
    public static Drawable icon(String name,int color) { return new Glyph(name,color); }
    private static final class Glyph extends Drawable {
        private final String name; private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG); private int color;
        Glyph(String name,int color){this.name=name;this.color=color;}
        public int getIntrinsicWidth(){return -1;} public int getIntrinsicHeight(){return -1;}
        public void draw(Canvas canvas){
            canvas.save(); Rect b=getBounds();canvas.translate(b.left,b.top);canvas.scale(b.width()/24f,b.height()/24f);
            paint.setColor(color);paint.setStrokeWidth(1.85f);paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);paint.setStyle(Paint.Style.STROKE);
            Path p=new Path();
            switch(name){
                case "play": paint.setStyle(Paint.Style.FILL);p.moveTo(8,5);p.lineTo(20,12);p.lineTo(8,19);p.close();canvas.drawPath(p,paint);break;
                case "pause": paint.setStyle(Paint.Style.FILL);canvas.drawRoundRect(6,5,10,19,1,1,paint);canvas.drawRoundRect(14,5,18,19,1,1,paint);break;
                case "next": paint.setStyle(Paint.Style.FILL);p.moveTo(5,5);p.lineTo(16,12);p.lineTo(5,19);p.close();canvas.drawPath(p,paint);canvas.drawRoundRect(18,5,20,19,1,1,paint);break;
                case "previous":paint.setStyle(Paint.Style.FILL);p.moveTo(19,5);p.lineTo(8,12);p.lineTo(19,19);p.close();canvas.drawPath(p,paint);canvas.drawRoundRect(4,5,6,19,1,1,paint);break;
                case "stop":paint.setStyle(Paint.Style.FILL);canvas.drawRoundRect(6,6,18,18,3,3,paint);break;
                case "library":canvas.drawRoundRect(4,3,20,21,3,3,paint);canvas.drawLine(8,8,16,8,paint);canvas.drawLine(8,12,16,12,paint);canvas.drawLine(8,16,12,16,paint);break;
                case "music":canvas.drawLine(10,17,10,6,paint);canvas.drawLine(10,6,19,4,paint);canvas.drawLine(19,4,19,15,paint);paint.setStyle(Paint.Style.FILL);canvas.drawOval(4,15,10,20,paint);canvas.drawOval(13,13,19,18,paint);break;
                case "settings":canvas.drawCircle(12,12,3.25f,paint);canvas.drawCircle(12,12,8,paint);for(int i=0;i<8;i++){double a=i*Math.PI/4;canvas.drawLine(12+(float)Math.cos(a)*8,12+(float)Math.sin(a)*8,12+(float)Math.cos(a)*10,12+(float)Math.sin(a)*10,paint);}break;
                case "more":paint.setStyle(Paint.Style.FILL);for(int i=0;i<3;i++)canvas.drawCircle(12,5+7*i,1.65f,paint);break;
                case "shuffle":p.moveTo(4,6);p.lineTo(7,6);p.cubicTo(12,6,12,18,17,18);p.lineTo(21,18);canvas.drawPath(p,paint);p.reset();p.moveTo(4,18);p.lineTo(7,18);p.cubicTo(12,18,12,6,17,6);p.lineTo(21,6);canvas.drawPath(p,paint);canvas.drawLine(18,3,21,6,paint);canvas.drawLine(18,9,21,6,paint);canvas.drawLine(18,15,21,18,paint);canvas.drawLine(18,21,21,18,paint);break;
                case "sync":canvas.drawArc(4,4,20,20,215,260,false,paint);canvas.drawLine(3,4,3,10,paint);canvas.drawLine(3,10,9,10,paint);canvas.drawLine(21,14,15,14,paint);canvas.drawLine(21,14,21,20,paint);break;
                case "folder":p.moveTo(3,7);p.lineTo(9,7);p.lineTo(11,10);p.lineTo(21,10);p.lineTo(21,20);p.lineTo(3,20);p.close();canvas.drawPath(p,paint);canvas.drawLine(3,7,3,5,paint);canvas.drawLine(3,5,10,5,paint);canvas.drawLine(10,5,12,7,paint);canvas.drawLine(12,7,20,7,paint);break;
                case "add":canvas.drawLine(12,5,12,19,paint);canvas.drawLine(5,12,19,12,paint);break;
                case "chevron":canvas.drawLine(7,9,12,14,paint);canvas.drawLine(12,14,17,9,paint);break;
                case "search":canvas.drawCircle(10,10,6,paint);canvas.drawLine(15,15,21,21,paint);break;
                case "close":canvas.drawLine(6,6,18,18,paint);canvas.drawLine(6,18,18,6,paint);break;
                case "shield":p.moveTo(12,3);p.lineTo(20,6);p.lineTo(19,14);p.quadTo(17,19,12,22);p.quadTo(7,19,5,14);p.lineTo(4,6);p.close();canvas.drawPath(p,paint);canvas.drawLine(8,12,11,15,paint);canvas.drawLine(11,15,16,9,paint);break;
                default:paint.setStyle(Paint.Style.FILL);for(int i=0;i<5;i++){float h=new float[]{8,15,20,12,7}[i];canvas.drawRoundRect(3+i*4,12-h/2,5+i*4,12+h/2,1,1,paint);}
            }
            canvas.restore();
        }
        public void setAlpha(int alpha){paint.setAlpha(alpha);invalidateSelf();} public void setColorFilter(ColorFilter filter){paint.setColorFilter(filter);invalidateSelf();} public int getOpacity(){return PixelFormat.TRANSLUCENT;}
    }
    public static Drawable album(String seed){return new Album(seed);}
    private static final class Album extends Drawable {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private final int variant;
        Album(String seed){variant=Math.floorMod(seed==null?0:seed.hashCode(),3);}
        public void draw(Canvas c){Rect r=getBounds();float w=r.width(),h=r.height();c.save();c.translate(r.left,r.top);
            int[] left={0xff234f57,0xff433765,0xff3b4b6c},right={0xff122b42,0xff192b49,0xff183b38};
            p.setShader(new LinearGradient(0,0,w,h,left[variant],right[variant],Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,p);p.setShader(null);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(1,w*.005f));p.setColor(0x3072e1bb);c.drawCircle(w*.75f,h*.25f,w*.61f,p);c.drawCircle(w*.75f,h*.25f,w*.43f,p);c.drawCircle(w*.75f,h*.25f,w*.25f,p);
            p.setStyle(Paint.Style.FILL);p.setColor(0xffa1eed6);float[] heights={.19f,.38f,.57f,.32f,.19f};for(int i=0;i<5;i++){float x=w*(.28f+i*.095f),hh=h*heights[i];c.drawRoundRect(x,h*.5f-hh/2,x+w*.045f,h*.5f+hh/2,w*.022f,w*.022f,p);}c.restore();
        }
        public void setAlpha(int a){p.setAlpha(a);}public void setColorFilter(ColorFilter f){p.setColorFilter(f);}public int getOpacity(){return PixelFormat.OPAQUE;}
    }
}
