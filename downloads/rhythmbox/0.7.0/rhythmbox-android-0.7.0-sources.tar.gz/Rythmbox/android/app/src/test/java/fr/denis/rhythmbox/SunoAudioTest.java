package fr.denis.rhythmbox;

import org.json.JSONArray;
import org.json.JSONObject;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Synthetic rights/media transport only. No account, browser, phone or network. */
public final class SunoAudioTest {
    private static int checks;
    private static JSONObject fixture;
    private interface Action {void run() throws Exception;}
    private static void yes(boolean value,String why){checks++;if(!value)throw new AssertionError(why);}
    private static void reject(Action action,String why) throws Exception {
        try{action.run();throw new AssertionError("Unexpected acceptance: "+why);}
        catch(IOException|IllegalArgumentException expected){checks++;}
    }
    private static JSONObject copy(JSONObject object) throws Exception{return new JSONObject(object.toString());}
    private static JSONObject track() throws Exception{return copy(fixture.getJSONObject("track"));}
    private static byte[] data(String name) throws Exception{return Base64.getDecoder().decode(fixture.getString(name));}
    private static byte[] hex(String value){byte[] bytes=new byte[value.length()/2];for(int i=0;i<bytes.length;i++)bytes[i]=(byte)Integer.parseInt(value.substring(i*2,i*2+2),16);return bytes;}
    private static String hex(byte[] value){StringBuilder text=new StringBuilder();for(byte b:value)text.append(String.format("%02x",b&255));return text.toString();}
    private static byte[] read(SunoAudio audio,long position,int length) throws Exception {
        byte[] bytes=new byte[length];int done=0;
        while(done<length){int n=audio.readAt(position+done,bytes,done,length-done);if(n<0)break;yes(n>0,"read advances");done+=n;}
        return Arrays.copyOf(bytes,done);
    }
    private static final class Call {
        final String url,method;final Map<String,String> headers;final byte[] body;
        Call(SunoAudio.Request request){url=request.url;method=request.method;headers=new HashMap<>(request.headers);body=request.body==null?null:request.body.clone();}
    }
    private static class BytesResponse implements SunoAudio.Response {
        final int status;final Map<String,String> headers;final byte[] bytes;final String url;
        boolean closed;int bodyCalls;Closeable registration;
        BytesResponse(int status,Map<String,String> headers,byte[] bytes,String url){this.status=status;this.headers=headers;this.bytes=bytes;this.url=url;}
        public int status(){return status;}public String url(){return url;}
        public String header(String name){return headers.get(name);}
        public InputStream body() throws IOException {bodyCalls++;return new ByteArrayInputStream(bytes);}
        public void close() throws IOException {closed=true;if(registration!=null)registration.close();}
    }
    private static final class Fake implements SunoAudio.Transport {
        final List<Call> calls=new ArrayList<>();final List<BytesResponse> responses=new ArrayList<>();
        JSONObject licence;byte[] media;String mediaType="audio/mp4",encoding="identity",finalUrl;
        int rightsStatus=200,headStatus=200,rangeStatus=206;boolean shortBody,trailingBody,wrongRange,wrongTotal,missingLength,rightsChunked;
        long declaredSize=-1;boolean slowRead,slowOpen;
        final CountDownLatch entered=new CountDownLatch(1),released=new CountDownLatch(1);
        Fake() throws Exception {licence=copy(fixture.getJSONObject("licence"));media=data("ciphertext");}
        long count(String method){long count=0;for(Call call:calls)if(call.method.equals(method))count++;return count;}
        @Override public SunoAudio.Response open(SunoAudio.Request request,SunoAudio.Cancellation cancel) throws IOException {
            calls.add(new Call(request));Map<String,String> headers=new HashMap<>();int status;byte[] bytes;
            try{
                if(request.url.equals(SunoAudio.RIGHTS_URL)){
                    yes(request.method.equals("POST"),"licence is an ordinary POST");
                    JSONObject params=new JSONObject(new String(request.body,StandardCharsets.US_ASCII)).getJSONObject("content_params");
                    yes(params.getString("content_id").equals(fixture.getString("song"))&&params.getString("content_type").equals("clip"),"exact content identity in licence");
                    status=rightsStatus;bytes=licence.toString().getBytes(StandardCharsets.UTF_8);headers.put("Content-Type","application/json");if(!rightsChunked)headers.put("Content-Length",Integer.toString(bytes.length));
                }else{
                    yes(request.url.equals(fixture.getJSONObject("track").getString("stream_uri")),"only registered exact CDN URL requested");
                    headers.put("Content-Type",mediaType);headers.put("Content-Encoding",encoding);
                    if(request.method.equals("HEAD")){
                        status=headStatus;bytes=new byte[0];headers.put("Content-Length",Long.toString(declaredSize>=0?declaredSize:media.length));
                        if(slowOpen){Closeable hook=cancel.register(released::countDown);try{entered.countDown();released.await(5,TimeUnit.SECONDS);cancel.check();throw new IOException("Synthetic open was not cancelled");}finally{hook.close();}}
                    }else{
                        yes(request.method.equals("GET"),"media is only HEAD or ranged GET");String raw=request.headers.get("Range");Matcher range=Pattern.compile("bytes=([0-9]+)-([0-9]+)").matcher(raw==null?"":raw);yes(range.matches(),"one explicit bounded range");
                        int start=Integer.parseInt(range.group(1)),end=Integer.parseInt(range.group(2));yes(start>=0&&end>=start&&end<media.length,"range is inside synthetic source");
                        status=rangeStatus;bytes=Arrays.copyOfRange(media,start,end+1);headers.put("Content-Range","bytes "+(wrongRange?start+1:start)+"-"+end+"/"+(wrongTotal?media.length+1:media.length));headers.put("Content-Length",Integer.toString(bytes.length));
                        if(shortBody)bytes=Arrays.copyOf(bytes,bytes.length-1);if(trailingBody)bytes=Arrays.copyOf(bytes,bytes.length+1);
                        if(missingLength)headers.remove("Content-Length");
                    }
                }
                final byte[] body=bytes;
                BytesResponse response=slowRead&&!request.method.equals("HEAD")&&!request.url.equals(SunoAudio.RIGHTS_URL)?
                    new BytesResponse(status,headers,body,finalUrl==null?request.url:finalUrl){
                        @Override public InputStream body(){bodyCalls++;return new InputStream(){
                            private void waitForCancel() throws IOException {entered.countDown();try{released.await(5,TimeUnit.SECONDS);}catch(InterruptedException interrupted){Thread.currentThread().interrupt();throw new IOException("Interrupted synthetic read");}cancel.check();throw new IOException("Synthetic read was not cancelled");}
                            public int read() throws IOException {waitForCancel();return -1;}
                            public int read(byte[] out,int offset,int length) throws IOException {waitForCancel();return -1;}
                        };}
                    }:new BytesResponse(status,headers,body,finalUrl==null?request.url:finalUrl);
                if(slowRead)response.registration=cancel.register(released::countDown);responses.add(response);return response;
            }catch(IOException error){throw error;}
            catch(Exception error){throw new IOException("Invalid synthetic fixture",error);}
        }
    }
    private static void normalAndCrossLanguage() throws Exception {
        Fake f=new Fake();byte[] plain=data("plaintext");SunoAudio audio=SunoAudio.open(track(),f);
        yes(audio.size()==plain.length,"source size matches Python fixture");yes(f.count("POST")==1,"one licence for the request-scoped source");
        for(int i=0;i<fixture.getJSONArray("ranges").length();i++){
            JSONObject range=fixture.getJSONArray("ranges").getJSONObject(i);long position=range.getLong("position");int length=range.getInt("length");byte[] bytes=read(audio,position,length);
            yes(Arrays.equals(bytes,Arrays.copyOfRange(plain,(int)position,(int)position+length)),"Python CTR plaintext agrees across block/page boundaries");
            yes(hex(MessageDigest.getInstance("SHA-256").digest(bytes)).equals(range.getString("sha256")),"Linux/Python range digest agrees");
        }
        for(Call call:f.calls){yes(!call.headers.containsKey("Cookie")&&!call.headers.containsKey("Authorization"),"no account session sent");yes("identity".equals(call.headers.get("Accept-Encoding")),"compressed stream disabled");}
        long before=f.calls.size();read(audio,plain.length-17,17);yes(f.calls.size()==before,"same page is cached");
        yes(audio.readAt(plain.length,new byte[4],0,4)==-1,"EOF returns minus one");yes(audio.readAt(Long.MAX_VALUE,new byte[4],0,4)==-1,"far EOF cannot overflow arithmetic");yes(audio.readAt(0,new byte[0],0,0)==0,"zero-sized valid read");
        reject(()->audio.readAt(-1,new byte[4],0,4),"negative position");reject(()->audio.readAt(0,new byte[4],0,5),"buffer bounds");reject(()->audio.readAt(0,new byte[4],-1,1),"negative buffer offset");
        Field key=SunoAudio.class.getDeclaredField("key"),iv=SunoAudio.class.getDeclaredField("iv");key.setAccessible(true);iv.setAccessible(true);byte[] retainedKey=(byte[])key.get(audio),retainedIv=(byte[])iv.get(audio);audio.close();audio.close();
        yes(Arrays.equals(retainedKey,new byte[retainedKey.length])&&Arrays.equals(retainedIv,new byte[retainedIv.length]),"stored key and IV arrays erased");yes(audio.cachedBytes()==0,"cache erased at close");
        reject(audio::size,"closed size");reject(()->audio.readAt(0,new byte[10],0,10),"read after close");
        for(BytesResponse response:f.responses)yes(response.closed,"all completed responses closed");
    }
    private static void identityAndRefusals() throws Exception {
        String uri=track().getString("stream_uri"),song=fixture.getString("song");
        String[] urls={uri.replace("https:","http:"),uri.replace("d2lwuy8qc234o3.cloudfront.net","evil.example"),uri.replace("https://","https://name:secret@"),uri.replace(".net/",".net:444/"),uri+"#fragment",uri.replace(song,"00000000-0000-4000-8000-000000000002"),uri.replace(".m4a",".mp3"),uri.replace("/clip/","/clip%2f"),uri+"\n"};
        for(String url:urls){Fake f=new Fake();reject(()->SunoAudio.open(track().put("stream_uri",url),f),"unsafe or mismatched URI");yes(f.calls.isEmpty(),"invalid link never reaches transport");}
        for(Object encoding:new Object[]{"",true,1,"2.0.0"}){Fake f=new Fake();reject(()->SunoAudio.open(track().put("stream_encoding",encoding),f),"explicit unknown encoding");yes(f.calls.isEmpty(),"unknown encoding never falls back to plaintext");}
        Fake absent=new Fake();JSONObject missing=track();missing.remove("stream_encoding");reject(()->SunoAudio.open(missing,absent),"missing encoding");
        for(int status:new int[]{401,403}){
            Fake f=new Fake();f.rightsStatus=status;reject(()->SunoAudio.open(track(),f),"licence refusal");yes(f.calls.size()==1,"rights refusal is not retried or bypassed");yes(f.responses.get(0).bodyCalls==0,"refusal body is not read");
            Fake head=new Fake();head.headStatus=status;JSONObject plaintext=track().put("stream_encoding",JSONObject.NULL);reject(()->SunoAudio.open(plaintext,head),"media HEAD refusal");yes(head.calls.size()==1,"media auth refusal is terminal");
            Fake media=new Fake();media.rangeStatus=status;reject(()->SunoAudio.open(track(),media),"media GET refusal");yes(media.count("POST")==1&&media.count("GET")==1,"media auth refusal neither retries nor asks for more rights");
        }
        Fake redirect=new Fake();redirect.finalUrl="https://evil.example/audio";reject(()->SunoAudio.open(track(),redirect),"response redirected outside registered URL");yes(redirect.calls.size()==1,"redirect target is never requested");
        Fake redirectStatus=new Fake();redirectStatus.rightsStatus=302;reject(()->SunoAudio.open(track(),redirectStatus),"HTTP redirect status");yes(redirectStatus.calls.size()==1,"HTTP redirect not followed");
        for(String field:new String[]{"glt","key","iv"}){Fake f=new Fake();f.licence.put(field,"invalid");reject(()->SunoAudio.open(track(),f),"malformed licence "+field);yes(f.count("HEAD")==0,"invalid rights cannot reach media");}
        Fake aad=new Fake();String wrapped=aad.licence.getString("key");aad.licence.put("key",wrapped.substring(0,10)+(wrapped.charAt(10)=='A'?'B':'A')+wrapped.substring(11));reject(()->SunoAudio.open(track(),aad),"GCM integrity");
        Fake overflow=new Fake();overflow.licence=copy(fixture.getJSONObject("overflow_licence"));overflow.media=data("overflow_ciphertext");reject(()->SunoAudio.open(track(),overflow),"CTR counter overflow even when a wrapping cipher would produce valid plaintext");
    }
    private static void metadataAndPlaintext() throws Exception {
        Fake fallback=new Fake();fallback.headStatus=405;try(SunoAudio audio=SunoAudio.open(track(),fallback)){yes(audio.size()==fallback.media.length,"HEAD405 uses exact ranged byte metadata");yes(fallback.count("POST")==1&&fallback.count("GET")==2,"fallback requests one byte and MP4 prefix without another licence");}
        Fake chunked=new Fake();chunked.rightsChunked=true;try(SunoAudio audio=SunoAudio.open(track(),chunked)){yes(audio.size()>0,"bounded chunked licence needs no Content-Length");}
        for(int kind=0;kind<8;kind++){
            Fake f=new Fake();if(kind==0)f.mediaType="text/html";if(kind==1)f.encoding="gzip";if(kind==2)f.rangeStatus=200;if(kind==3)f.wrongRange=true;if(kind==4)f.wrongTotal=true;if(kind==5)f.shortBody=true;if(kind==6)f.trailingBody=true;if(kind==7)f.missingLength=true;
            reject(()->SunoAudio.open(track(),f),"invalid response type/range/length/body "+kind);
        }
        for(long size:new long[]{0,SunoAudio.MAX_AUDIO_BYTES+1,Long.MAX_VALUE}){Fake f=new Fake();f.declaredSize=size;reject(()->SunoAudio.open(track(),f),"declared source outside bounds");yes(f.count("GET")==0,"invalid total cannot allocate/read media");}
        Fake plain=new Fake();plain.media=data("plaintext");plain.mediaType="application/octet-stream";try(SunoAudio audio=SunoAudio.open(track().put("stream_encoding",JSONObject.NULL),plain)){yes(Arrays.equals(read(audio,17,90),Arrays.copyOfRange(plain.media,17,107)),"explicit plaintext can play without rights exchange");yes(plain.count("POST")==0,"plaintext did not request guest material");}
        Fake html=new Fake();html.media=new byte[500];html.mediaType="application/octet-stream";reject(()->SunoAudio.open(track().put("stream_encoding",JSONObject.NULL),html),"generic MIME without actual MP4 prefix");
    }
    private static void boundedCache() throws Exception {
        Fake f=new Fake();f.media=new byte[36*SunoAudio.PAGE_BYTES+17];for(int i=0;i<f.media.length;i++)f.media[i]=(byte)i;f.media[4]='f';f.media[5]='t';f.media[6]='y';f.media[7]='p';
        byte[] retainedPage;
        try(SunoAudio audio=SunoAudio.open(track().put("stream_encoding",JSONObject.NULL),f)){
            audio.readAt(0,new byte[1],0,1);Field pages=SunoAudio.class.getDeclaredField("pages");pages.setAccessible(true);retainedPage=(byte[])((Map<?,?>)pages.get(audio)).get(0L);
            for(int page=0;page<36;page++){long pos=(long)page*SunoAudio.PAGE_BYTES;yes(audio.readAt(pos,new byte[1],0,1)==1,"one page available");yes(audio.cachedBytes()<=SunoAudio.MAX_CACHE_BYTES,"LRU at most2MiB");}
            yes(Arrays.equals(retainedPage,new byte[retainedPage.length]),"evicted plaintext page erased");
            long before=f.count("GET");audio.readAt(0,new byte[1],0,1);yes(f.count("GET")==before+1,"oldest evicted page is fetched again");
            before=f.count("GET");audio.readAt(0,new byte[1],0,1);yes(f.count("GET")==before,"most recent page remains cached");
            retainedPage=(byte[])((Map<?,?>)pages.get(audio)).get(0L);
        }
        yes(Arrays.equals(retainedPage,new byte[retainedPage.length]),"cached plaintext page erased on close");
    }
    private static void largeOffsets() throws Exception {
        Fake base=new Fake();base.declaredSize=SunoAudio.MAX_AUDIO_BYTES;long position=fixture.getLong("virtual_page_start");byte[] cipher=data("virtual_page_ciphertext"),plain=data("virtual_page_plaintext");
        SunoAudio.Transport virtual=(request,cancel)->{
            String raw=request.headers.get("Range");
            if(raw!=null&&raw.startsWith("bytes="+position+"-")){
                yes(raw.equals("bytes="+position+"-"+(position+SunoAudio.PAGE_BYTES-1)),"64-bit exact aligned page range");
                Map<String,String> headers=new HashMap<>();headers.put("Content-Type","audio/mp4");headers.put("Content-Length",Integer.toString(cipher.length));headers.put("Content-Range","bytes "+position+"-"+(position+cipher.length-1)+"/"+SunoAudio.MAX_AUDIO_BYTES);
                return new BytesResponse(206,headers,cipher,request.url);
            }
            BytesResponse response=(BytesResponse)base.open(request,cancel);
            if(response.headers.containsKey("Content-Range"))response.headers.put("Content-Range",response.headers.get("Content-Range").replaceFirst("/[0-9]+$","/"+SunoAudio.MAX_AUDIO_BYTES));
            return response;
        };
        try(SunoAudio audio=SunoAudio.open(track(),virtual)){
            yes(audio.size()==SunoAudio.MAX_AUDIO_BYTES,"5GiB boundary accepted without full buffering");
            yes(Arrays.equals(read(audio,position+17,4099),Arrays.copyOfRange(plain,17,4116)),"Python CTR counter/offset above4GiB agrees");
            yes(audio.readAt(SunoAudio.MAX_AUDIO_BYTES,new byte[1],0,1)==-1,"5GiB EOF");
        }
    }
    private static void cancellation() throws Exception {
        ExecutorService worker=Executors.newSingleThreadExecutor();Fake f=new Fake();SunoAudio audio=SunoAudio.open(track(),f);f.slowRead=true;
        try{
            Future<?> pending=worker.submit(()->{try{audio.readAt(65536,new byte[32],0,32);throw new AssertionError("Cancelled read returned audio");}catch(IOException expected){}});
            yes(f.entered.await(2,TimeUnit.SECONDS),"synthetic media read is live");long start=System.nanoTime();audio.close();yes(TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-start)<250,"close does not block on network body");pending.get(2,TimeUnit.SECONDS);yes(audio.cachedBytes()==0,"cancelled read cannot repopulate cache");
        }finally{audio.close();f.released.countDown();worker.shutdownNow();}
        ExecutorService opener=Executors.newSingleThreadExecutor();Fake slow=new Fake();slow.slowOpen=true;SunoAudio.Cancellation token=new SunoAudio.Cancellation();
        try{
            Future<?> pending=opener.submit(()->{try{SunoAudio.open(track(),slow,token);throw new AssertionError("Cancelled open succeeded");}catch(Exception expected){}});
            yes(slow.entered.await(2,TimeUnit.SECONDS),"synthetic metadata request is live");long start=System.nanoTime();token.close();yes(TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-start)<250,"cancel during open does not wait for HTTP");pending.get(2,TimeUnit.SECONDS);
        }finally{token.close();slow.released.countDown();opener.shutdownNow();}
        Fake cached=new Fake();SunoAudio.Cancellation external=new SunoAudio.Cancellation();SunoAudio open=SunoAudio.open(track(),cached,external);open.readAt(0,new byte[1],0,1);external.close();reject(()->open.readAt(0,new byte[1],0,1),"external cancellation also rejects cache hits immediately");open.close();
    }
    public static void main(String[] args) throws Exception {
        fixture=new JSONObject(new String(Files.readAllBytes(Paths.get(args[0])),StandardCharsets.UTF_8));
        normalAndCrossLanguage();identityAndRefusals();metadataAndPlaintext();boundedCache();largeOffsets();cancellation();
        System.out.println("PASS : "+checks+" Suno audio protocol/range/crypto/cache/cancellation assertions; synthetic transport only, no account/network/audio output");
    }
}
