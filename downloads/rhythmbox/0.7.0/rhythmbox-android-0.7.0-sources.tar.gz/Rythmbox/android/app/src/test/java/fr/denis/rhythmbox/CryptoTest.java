package fr.denis.rhythmbox;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;

public final class CryptoTest {
    private static void check(boolean condition,String label){if(!condition)throw new AssertionError(label);}
    public static void main(String[] args) throws Exception {
        byte[] key=new byte[32],nonce=new byte[12];for(int i=0;i<key.length;i++)key[i]=(byte)i;for(int i=0;i<nonce.length;i++)nonce[i]=(byte)i;
        byte[] envelope=Files.readAllBytes(Paths.get(args[0])),plain=Files.readAllBytes(Paths.get(args[1]));
        check(Arrays.equals(plain,Crypto.open(key,envelope)),"Python encrypt -> Java decrypt");
        check(Arrays.equals(envelope,Crypto.sealWithNonce(key,plain,nonce)),"Java encrypt -> Python byte-identical fixture");
        byte[] modified=envelope.clone();modified[modified.length-1]^=1;boolean rejected=false;
        try{Crypto.open(key,modified);}catch(Exception expected){rejected=true;}check(rejected,"tampered ciphertext");
        key[0]^=1;rejected=false;try{Crypto.open(key,envelope);}catch(Exception expected){rejected=true;}check(rejected,"wrong key");
        rejected=false;try{Crypto.open(new byte[16],envelope);}catch(Exception expected){rejected=true;}check(rejected,"short key");
        System.out.println("PASS : AES-GCM interop Python/Java, authentication, key length");
    }
}
