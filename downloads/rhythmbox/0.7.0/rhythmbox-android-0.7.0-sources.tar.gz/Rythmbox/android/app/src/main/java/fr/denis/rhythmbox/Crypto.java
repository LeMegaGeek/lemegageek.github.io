package fr.denis.rhythmbox;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** Portable wire format shared with the Python desktop implementation. */
public final class Crypto {
    private static final byte[] AAD = "rhythmbox-playlists-v1".getBytes(StandardCharsets.US_ASCII);
    private Crypto() {}
    public static byte[] seal(byte[] key, byte[] plain) throws Exception {
        byte[] nonce = new byte[12]; new SecureRandom().nextBytes(nonce);
        return sealWithNonce(key, plain, nonce);
    }
    static byte[] sealWithNonce(byte[] key, byte[] plain, byte[] nonce) throws Exception {
        if (key.length != 32 || nonce.length != 12 || plain.length>8*1024*1024-32) throw new IllegalArgumentException("Clé, nonce ou taille invalide");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, nonce));
        cipher.updateAAD(AAD);
        byte[] encrypted = cipher.doFinal(plain);
        byte[] output = new byte[16 + encrypted.length];
        System.arraycopy(new byte[]{82,66,88,49}, 0, output, 0, 4);
        System.arraycopy(nonce, 0, output, 4, 12); System.arraycopy(encrypted, 0, output, 16, encrypted.length);
        return output;
    }
    public static byte[] open(byte[] key, byte[] envelope) throws Exception {
        if (key.length != 32 || envelope.length < 32 || envelope.length>8*1024*1024 || envelope[0] != 82 || envelope[1] != 66 || envelope[2] != 88 || envelope[3] != 49)
            throw new IllegalArgumentException("Format de synchronisation invalide");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, Arrays.copyOfRange(envelope, 4, 16)));
        cipher.updateAAD(AAD); return cipher.doFinal(envelope, 16, envelope.length - 16);
    }
}
