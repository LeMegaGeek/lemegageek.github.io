package fr.denis.rhythmbox;

import android.media.MediaPlayer;
import android.media.audiofx.AudioEffect;
import android.os.Build;

/** Applies only a measured fixed gain to this player's own audio session. */
public final class TrackVolumeEffect implements AutoCloseable {
    private AudioEffect enhancer;
    private double appliedGain;
    public interface VolumeSetter { void set(float left,float right); }
    public double appliedGainDb(){return appliedGain;}
    public String apply(MediaPlayer player,TrackLoudness.Result measurement,boolean enabled){
        return applySession(player.getAudioSessionId(),player::setVolume,measurement,enabled);
    }
    public String applySession(int session,VolumeSetter output,TrackLoudness.Result measurement,boolean enabled){
        close();output.set(1,1);
        if(!enabled)return "Uniformisation désactivée";
        if(measurement==null||!measurement.measured)return "Volume d’origine · mesure indisponible";
        double db=measurement.gainDb();
        if(db<=0){float scalar=(float)Math.pow(10,db/20);output.set(scalar,scalar);appliedGain=db;return description(db);}
        try{
            if(session<=0)throw new IllegalStateException();
            if(Build.VERSION.SDK_INT<28)throw new UnsupportedOperationException();
            enhancer=Api28.linearGain(session,(float)db);if(!enhancer.hasControl())throw new IllegalStateException();
            if(enhancer.setEnabled(true)!=AudioEffect.SUCCESS||!enhancer.getEnabled())throw new IllegalStateException();
            appliedGain=db;return description(db);
        }catch(RuntimeException unavailable){close();return "Volume d’origine · amplification indisponible sur cet appareil";}
    }
    private static String description(double db){return String.format(java.util.Locale.FRANCE,"Volume uniformisé · %+.1f dB",db);}
    private static final class Api28 {
        static AudioEffect linearGain(int session,float db){
            // LoudnessEnhancer contains a compressor. Use only the input-gain
            // stage here, with EQ, compressor and limiter all absent.
            android.media.audiofx.DynamicsProcessing.Config config=new android.media.audiofx.DynamicsProcessing.Config.Builder(
                android.media.audiofx.DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,2,false,0,false,0,false,0,false)
                .setInputGainAllChannelsTo(db).build();
            android.media.audiofx.DynamicsProcessing effect=new android.media.audiofx.DynamicsProcessing(0,session,config);
            try{
                android.media.audiofx.DynamicsProcessing.Config actual=effect.getConfig();
                if(actual.isLimiterInUse()||actual.isMbcInUse()||actual.isPreEqInUse()||actual.isPostEqInUse())
                    throw new IllegalStateException();
                if(effect.getChannelCount()!=2||Math.abs(effect.getInputGainByChannelIndex(0)-db)>.01||
                        Math.abs(effect.getInputGainByChannelIndex(1)-db)>.01)throw new IllegalStateException();
                return effect;
            }catch(RuntimeException failure){effect.release();throw failure;}
        }
    }
    @Override public void close(){AudioEffect old=enhancer;enhancer=null;appliedGain=0;if(old!=null){try{old.setEnabled(false);}catch(RuntimeException ignored){}try{old.release();}catch(RuntimeException ignored){}}}
}
