package fr.denis.rhythmbox;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayDeque;
import java.util.Arrays;

/** Bounded measurements of PCM frames actually accepted by the native renderer. */
public final class StereoSpectrum {
    public static final int BAND_COUNT = 32;
    public static final int FFT_SIZE = 2048;
    public static final float FLOOR_DB = -90f;
    private static final int HOP = FFT_SIZE / 2;
    private static final int MAX_SNAPSHOTS = 64;

    public static final class Snapshot {
        public final boolean available;
        public final int sampleRate, channels;
        public final long framePosition;
        public final float leftRmsDb, rightRmsDb, leftPeakDb, rightPeakDb;
        public final float leftDominantHz, rightDominantHz;
        private final float[] left, right, centers;

        private Snapshot(boolean available, int sampleRate, int channels, long framePosition,
                         float leftRmsDb, float rightRmsDb, float leftPeakDb, float rightPeakDb,
                         float leftDominantHz, float rightDominantHz,
                         float[] left, float[] right, float[] centers) {
            this.available = available;
            this.sampleRate = sampleRate;
            this.channels = channels;
            this.framePosition = framePosition;
            this.leftRmsDb = leftRmsDb;
            this.rightRmsDb = rightRmsDb;
            this.leftPeakDb = leftPeakDb;
            this.rightPeakDb = rightPeakDb;
            this.leftDominantHz = leftDominantHz;
            this.rightDominantHz = rightDominantHz;
            this.left = left.clone();
            this.right = right.clone();
            this.centers = centers.clone();
        }

        public float[] leftBands() { return left.clone(); }
        public float[] rightBands() { return right.clone(); }
        public float[] bandCentersHz() { return centers.clone(); }

        public static Snapshot unavailable() {
            float[] empty = new float[BAND_COUNT];
            Arrays.fill(empty, FLOOR_DB);
            return new Snapshot(false, 0, 0, 0, FLOOR_DB, FLOOR_DB, FLOOR_DB, FLOOR_DB,
                                0, 0, empty, empty, new float[BAND_COUNT]);
        }
    }

    private final int sampleRate, channels;
    private final double[] left = new double[FFT_SIZE], right = new double[FFT_SIZE];
    private final double[] window = new double[FFT_SIZE];
    private final float[] centers = new float[BAND_COUNT];
    private final int[] bandForBin = new int[FFT_SIZE / 2 + 1];
    private final ArrayDeque<Snapshot> snapshots = new ArrayDeque<>();
    private long frames;
    private int cursor;
    private final double windowSum;

    public StereoSpectrum(int sampleRate, int channels) {
        if (sampleRate < 8000 || sampleRate > 192000 || (channels != 1 && channels != 2))
            throw new IllegalArgumentException("Analyse PCM mono ou stéréo attendue");
        this.sampleRate = sampleRate;
        this.channels = channels;
        double sum = 0;
        for (int i = 0; i < FFT_SIZE; i++) {
            window[i] = .5 - .5 * Math.cos(2 * Math.PI * i / (FFT_SIZE - 1));
            sum += window[i];
        }
        windowSum = sum;
        double high = Math.min(20000, sampleRate / 2.0);
        double span = Math.log(high / 20);
        for (int i = 0; i < BAND_COUNT; i++)
            centers[i] = (float) (20 * Math.exp(span * (i + .5) / BAND_COUNT));
        Arrays.fill(bandForBin, -1);
        for (int i = 1; i < bandForBin.length; i++) {
            double frequency = i * (double) sampleRate / FFT_SIZE;
            if (frequency >= 20 && frequency <= high)
                bandForBin[i] = Math.min(BAND_COUNT - 1,
                    (int) (BAND_COUNT * Math.log(frequency / 20) / span));
        }
    }

    /** The caller passes only complete frames already accepted by AudioTrack.write. */
    public synchronized void acceptPcm16(ByteBuffer pcm) {
        if (pcm.remaining() % (channels * 2) != 0)
            throw new IllegalArgumentException("Bloc PCM incomplet");
        pcm.order(ByteOrder.LITTLE_ENDIAN);
        while (pcm.hasRemaining()) {
            double l = pcm.getShort() / 32768.0;
            double r = channels == 1 ? l : pcm.getShort() / 32768.0;
            add(l, r);
        }
    }

    public synchronized void acceptPcmFloat(ByteBuffer pcm) {
        if (pcm.remaining() % (channels * 4) != 0)
            throw new IllegalArgumentException("Bloc PCM incomplet");
        pcm.order(ByteOrder.LITTLE_ENDIAN);
        while (pcm.hasRemaining()) {
            double l = pcm.getFloat();
            double r = channels == 1 ? l : pcm.getFloat();
            if (!Double.isFinite(l) || !Double.isFinite(r))
                throw new IllegalArgumentException("Échantillon PCM invalide");
            add(l, r);
        }
    }

    private void add(double l, double r) {
        left[cursor] = l;
        right[cursor] = r;
        cursor = (cursor + 1) % FFT_SIZE;
        frames++;
        if (frames >= FFT_SIZE && (frames - FFT_SIZE) % HOP == 0) {
            Channel a = measure(left), b = channels == 1 ? a : measure(right);
            snapshots.addLast(new Snapshot(true, sampleRate, channels, frames,
                a.rms, b.rms, a.peak, b.peak, a.dominant, b.dominant,
                a.bands, b.bands, centers));
            while (snapshots.size() > MAX_SNAPSHOTS) snapshots.removeFirst();
        }
    }

    /** Never exposes measurements from queued frames that have not yet played. */
    public synchronized Snapshot atFrame(long playedFrames) {
        Snapshot result = null;
        for (Snapshot snapshot : snapshots) {
            if (snapshot.framePosition > playedFrames) break;
            result = snapshot;
        }
        return result == null ? Snapshot.unavailable() : result;
    }

    public synchronized void reset() {
        frames = 0;
        cursor = 0;
        Arrays.fill(left, 0);
        Arrays.fill(right, 0);
        snapshots.clear();
    }

    private static final class Channel {
        float rms, peak, dominant;
        final float[] bands = new float[BAND_COUNT];
    }

    private Channel measure(double[] ring) {
        Channel result = new Channel();
        double energy = 0, peak = 0, mean = 0;
        for (double value : ring) {
            mean += value;
            energy += value * value;
            peak = Math.max(peak, Math.abs(value));
        }
        mean /= FFT_SIZE;
        result.rms = db(Math.sqrt(energy / FFT_SIZE));
        result.peak = db(peak);
        double[] real = new double[FFT_SIZE], imaginary = new double[FFT_SIZE];
        for (int i = 0; i < FFT_SIZE; i++)
            real[i] = (ring[(cursor + i) % FFT_SIZE] - mean) * window[i];
        fft(real, imaginary);
        Arrays.fill(result.bands, FLOOR_DB);
        double largest = 0;
        int largestBin = 0;
        for (int i = 1; i <= FFT_SIZE / 2; i++) {
            double magnitude = Math.hypot(real[i], imaginary[i]) * 2 / windowSum;
            if (magnitude > largest) { largest = magnitude; largestBin = i; }
            int band = bandForBin[i];
            if (band >= 0)
                result.bands[band] = Math.max(result.bands[band], Math.min(0, db(magnitude)));
        }
        result.dominant = largest > 1e-7 ? largestBin * (float) sampleRate / FFT_SIZE : 0;
        return result;
    }

    private static float db(double amplitude) {
        return amplitude > 0 ? (float) Math.max(FLOOR_DB, 20 * Math.log10(amplitude)) : FLOOR_DB;
    }

    private static void fft(double[] real, double[] imaginary) {
        int n = real.length;
        for (int i = 1, j = 0; i < n; i++) {
            int bit = n >> 1;
            for (; (j & bit) != 0; bit >>= 1) j ^= bit;
            j ^= bit;
            if (i < j) {
                double value = real[i]; real[i] = real[j]; real[j] = value;
                value = imaginary[i]; imaginary[i] = imaginary[j]; imaginary[j] = value;
            }
        }
        for (int length = 2; length <= n; length <<= 1) {
            double angle = -2 * Math.PI / length;
            double stepReal = Math.cos(angle), stepImaginary = Math.sin(angle);
            for (int start = 0; start < n; start += length) {
                double wr = 1, wi = 0;
                for (int j = 0; j < length / 2; j++) {
                    int even = start + j, odd = even + length / 2;
                    double tr = wr * real[odd] - wi * imaginary[odd];
                    double ti = wr * imaginary[odd] + wi * real[odd];
                    real[odd] = real[even] - tr;
                    imaginary[odd] = imaginary[even] - ti;
                    real[even] += tr;
                    imaginary[even] += ti;
                    double nextReal = wr * stepReal - wi * stepImaginary;
                    wi = wr * stepImaginary + wi * stepReal;
                    wr = nextReal;
                }
            }
        }
    }
}
