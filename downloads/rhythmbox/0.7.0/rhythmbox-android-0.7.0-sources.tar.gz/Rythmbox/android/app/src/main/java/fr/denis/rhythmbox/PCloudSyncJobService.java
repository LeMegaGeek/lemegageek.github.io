package fr.denis.rhythmbox;

import android.app.job.JobParameters;
import android.app.job.JobService;
import java.util.concurrent.atomic.AtomicBoolean;

/** Periodic unmetered work; no foreground service or notification. */
public final class PCloudSyncJobService extends JobService {
    private AtomicBoolean cancelled;
    private volatile PCloudOfflineAudio.Cancellation audioCopies;
    private static final java.util.concurrent.atomic.AtomicReference<PCloudOfflineAudio.Cancellation> ACTIVE_COPIES=new java.util.concurrent.atomic.AtomicReference<>();
    public static void cancelCopiesForForeground(){PCloudOfflineAudio.Cancellation copies=ACTIVE_COPIES.get();if(copies!=null)copies.cancel();}
    @Override public boolean onStartJob(JobParameters parameters){
        if(PCloudSyncController.isUiActive())return false;
        final AtomicBoolean stop=new AtomicBoolean();cancelled=stop;
        new Thread(()->{
            boolean retry=false;
            try{
                if(!"account".equals(new SecretStore(this).load().optString("sync_mode")))return;
                Library library=new Library(this);PCloudSyncController controller=new PCloudSyncController(this);
                PCloudSyncController.Result result=controller.prepareSync(library,true,stop::get);
                if(!stop.get()&&!PCloudSyncController.isUiActive()){
                    boolean committed=controller.commit(library,result);retry=!committed;
                    if(committed&&!stop.get()&&!PCloudSyncController.isUiActive()){
                        try{
                            if(PCloudOfflineAudio.settings(this).optBoolean("enabled")){
                                PCloudOfflineAudio.Cancellation copies=new PCloudOfflineAudio.Cancellation(()->!stop.get()&&!PCloudSyncController.isUiActive());audioCopies=copies;ACTIVE_COPIES.set(copies);if(PCloudSyncController.isUiActive()||stop.get())copies.cancel();
                                try{new PCloudOfflineAudio(this).sync(copies,null);}finally{ACTIVE_COPIES.compareAndSet(copies,null);if(audioCopies==copies)audioCopies=null;}
                            }
                        }catch(Exception optionalCopies){/* Preserve completed copies and the committed lists; retry in the next normal window. */}
                    }
                }
            }catch(Exception error){
                // A pending journal remains private and blocks a blind retry.
                // Failures contain no tokens, paths or provider response dump.
                try{Library latest=new Library(this);org.json.JSONObject state=latest.state.optJSONObject("pcloud_native");retry=state!=null&&!state.has("pending")&&!PCloudSyncController.isUiActive();}catch(Exception ignored){retry=false;}
            }finally{if(!stop.get())jobFinished(parameters,retry);}
        },"rhythmbox-pcloud-sync").start();
        return true;
    }
    @Override public boolean onStopJob(JobParameters parameters){if(cancelled!=null)cancelled.set(true);PCloudOfflineAudio.Cancellation copies=audioCopies;if(copies!=null)copies.cancel();return false;}
}
