package fr.denis.rhythmbox;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Pure projection tests: synthetic account metadata only, no filesystem media,
 * device, network, credentials or codec/byte attestation. Controller tests own
 * the durable CAS/journal transaction; this class proves the video policy. */
public final class PCloudVideoSyncTest {
    private static final long USER = 7, FOLDER = 10, COLLECTION = 20;
    private static final long VIDEO_ONE = 2001, VIDEO_TWO = 2002;
    private static final int AUDIO_COUNT = 288;
    private static int checks;

    private interface Planned { JSONObject run() throws Exception; }
    private static void yes(boolean condition, String label) {
        checks++;
        if (!condition) throw new AssertionError(label);
    }
    private static JSONObject copy(JSONObject value) throws Exception {
        return new JSONObject(value.toString());
    }
    private static void failsClosed(Planned work, String label) throws Exception {
        checks++;
        try {
            JSONObject result = work.run();
            if (result.getBoolean("ready") || result.getJSONArray("operations").length() != 0 ||
                    !result.isNull("proposed_base")) throw new AssertionError("Accepted: " + label);
        } catch (Exception expected) { /* Invalid identities may fail before a plan exists. */ }
    }
    private static boolean issue(JSONObject result, String code) throws Exception {
        JSONArray issues = result.getJSONArray("issues");
        for (int i = 0; i < issues.length(); i++)
            if (code.equals(issues.getJSONObject(i).getString("code"))) return true;
        return false;
    }
    private static List<Long> ids(JSONObject result, String field) throws Exception {
        return PCloudCollections.ids(result.getJSONArray(field));
    }
    private static List<String> trackIds(JSONObject playlist) throws Exception {
        List<String> out = new ArrayList<>();
        JSONArray tracks = playlist.getJSONArray("tracks");
        for (int i = 0; i < tracks.length(); i++) out.add(tracks.getJSONObject(i).getString("id"));
        return out;
    }
    private static JSONObject byFile(JSONObject playlist, long fid) throws Exception {
        JSONArray tracks = playlist.getJSONArray("tracks");
        for (int i = 0; i < tracks.length(); i++) {
            JSONObject track = tracks.getJSONObject(i);
            if (track.optLong("pcloud_fileid", -1) == fid) return track;
        }
        throw new AssertionError("Missing synthetic file " + fid);
    }
    private static void blocked(JSONObject result, String code, String label) throws Exception {
        yes(!result.getBoolean("ready"), label + " is blocked");
        yes(result.getJSONArray("operations").length() == 0, label + " has no provider operations");
        yes(result.isNull("proposed_base"), label + " has no candidate base");
        if (code != null) yes(issue(result, code), label + " has explicit issue");
    }

    private static final class Fixture {
        final PCloudAccount account = new PCloudAccount("synthetic-video-test-token",
            "music@example.test", "eu", "fixture-client", USER, FOLDER);
        final Map<Long, JSONObject> files = new LinkedHashMap<>();
        final List<Long> audio = new ArrayList<>();
        final String pid = PCloudNativeSync.playlistId(USER, COLLECTION);
        Fixture() throws Exception {
            for (int i = 0; i < AUDIO_COUNT; i++) {
                long fid = 1000 + i;
                audio.add(fid);
                files.put(fid, file(fid, "Album/track-" + i + ".mp3", "audio/mpeg"));
            }
            files.put(VIDEO_ONE, file(VIDEO_ONE, "Clips/one.m4v", "video/mp4"));
            files.put(VIDEO_TWO, file(VIDEO_TWO, "Clips/two.m4v", "video/mp4"));
        }
        JSONObject file(long fid, String path, String mime) throws Exception {
            return new JSONObject().put("fileid", fid).put("music_folderid", FOLDER)
                .put("parentfolderid", FOLDER).put("ismine", true).put("isfolder", false)
                .put("size", 100).put("media_path", path)
                .put("name", path.substring(path.lastIndexOf('/') + 1))
                .put("title", "Synthetic " + fid).put("artist", "Fixture")
                .put("album", "Fixture").put("contenttype", mime);
        }
        JSONObject binding() throws Exception {
            return new JSONObject().put("account_userid", USER).put("collection_id", COLLECTION)
                .put("playlist_id", pid).put("music_folderid", FOLDER);
        }
        JSONObject index() throws Exception {
            Set<String> paths = new HashSet<>();
            for (JSONObject row : files.values()) paths.add(row.getString("media_path"));
            return PCloudNativeSync.mediaIndex(account, files, paths);
        }
        JSONObject track(long fid) throws Exception {
            JSONObject out = PCloudCollections.track(files.get(fid), USER);
            if (fid == VIDEO_ONE || fid == VIDEO_TWO)
                out.put("rating", 5).put("private_note", "Preserve synthetic local video")
                    .put("private_ui", new JSONObject().put("selected", true));
            return out;
        }
        JSONObject playlist(List<Long> order) throws Exception {
            JSONArray tracks = new JSONArray();
            for (long fid : order) tracks.put(track(fid));
            return new JSONObject().put("id", pid).put("name", "Synthetic Mon top").put("tracks", tracks);
        }
        JSONObject full() throws Exception {
            List<Long> order = new ArrayList<>();
            for (int i = 0; i < audio.size(); i++) {
                if (i == 1) order.add(VIDEO_ONE);
                if (i == 144) order.add(VIDEO_TWO);
                order.add(audio.get(i));
            }
            return playlist(order);
        }
        JSONObject remote(List<Long> order) throws Exception {
            return new JSONObject().put("id", COLLECTION).put("account_userid", USER)
                .put("ismine", true).put("system", false).put("type", "audio")
                .put("complete", true).put("fileids", new JSONArray(order));
        }
        JSONObject base(List<Long> order) throws Exception {
            return new JSONObject().put("account_userid", USER).put("collection_id", COLLECTION)
                .put("playlist_id", pid).put("playlist", playlist(order)).put("fileids", new JSONArray(order));
        }
        JSONObject plan(JSONObject base, JSONObject local, JSONObject remote, JSONObject index) throws Exception {
            return PCloudNativeSync.plan(binding(), base, local, remote, index,
                Collections.emptySet(), Collections.emptySet(), Collections.emptySet(), Collections.emptySet());
        }
    }

    private static void largeProjectionAndPrivateObjects() throws Exception {
        Fixture f = new Fixture();
        JSONObject local = f.full(), index = f.index();
        String original = PCloudNativeSync.canonical(local);
        JSONObject plan = f.plan(null, local, f.remote(f.audio), index);
        yes(plan.getBoolean("ready"), "288 audio plus two videos prepares a ready plan");
        yes(ids(plan, "remote_target").equals(f.audio), "all 288 audio references retained in original order");
        yes(plan.getJSONArray("operations").length() == 0, "matching 288 references needs no provider mutation");
        yes(plan.getInt("local_video_count") == 2 && plan.getInt("cloud_reference_count") == 288,
            "result distinguishes two local video references from 288 cloud references");
        JSONObject result = plan.getJSONObject("local_playlist");
        yes(result.getJSONArray("tracks").length() == 290, "all 290 local references preserved");
        yes(trackIds(result).equals(trackIds(local)), "local-only ordinal slots preserve full native order");
        for (long fid : new long[] {VIDEO_ONE, VIDEO_TWO}) {
            yes(PCloudNativeSync.canonical(byFile(result, fid)).equals(PCloudNativeSync.canonical(byFile(local, fid))),
                "full private video object and rating preserved for " + fid);
        }
        JSONObject base = plan.getJSONObject("proposed_base");
        yes(ids(base, "fileids").equals(f.audio), "candidate base contains audio references only");
        yes(base.getJSONObject("playlist").getJSONArray("tracks").length() == 288, "base has no local-only video objects");
        yes(original.equals(PCloudNativeSync.canonical(local)), "plan leaves full CAS source unchanged");
        yes(index.getLong("music_folderid") == FOLDER, "media index carries selected music root identity");
        boolean hasFreshVideoType = false;
        JSONArray rows = index.getJSONArray("files");
        for (int i = 0; i < rows.length(); i++)
            if (rows.getJSONObject(i).getLong("fileid") == VIDEO_ONE)
                hasFreshVideoType = "video/mp4".equals(rows.getJSONObject(i).getString("contenttype"));
        yes(hasFreshVideoType, "fresh provider video MIME is carried by the index");
    }

    private static void remotePullAndReorderPreserveVideos() throws Exception {
        Fixture f = new Fixture();
        JSONObject local = f.full(), index = f.index();
        List<Long> reversed = new ArrayList<>(f.audio);
        Collections.reverse(reversed);
        JSONObject reordered = f.plan(f.base(f.audio), local, f.remote(reversed), index);
        yes(reordered.getBoolean("ready") && ids(reordered, "remote_target").equals(reversed),
            "remote reorder pulls all 288 audio references");
        JSONObject result = reordered.getJSONObject("local_playlist");
        List<Long> restoredAudio = new ArrayList<>();
        JSONArray tracks = result.getJSONArray("tracks");
        for (int i = 0; i < tracks.length(); i++) {
            long fid = tracks.getJSONObject(i).getLong("pcloud_fileid");
            if (fid != VIDEO_ONE && fid != VIDEO_TWO) restoredAudio.add(fid);
        }
        yes(restoredAudio.equals(reversed), "local video slots do not disturb cloud audio order");
        yes(tracks.getJSONObject(1).getLong("pcloud_fileid") == VIDEO_ONE &&
            tracks.getJSONObject(145).getLong("pcloud_fileid") == VIDEO_TWO,
            "video ordinal slots survive remote reorder");
        JSONObject empty = f.plan(f.base(f.audio), local, f.remote(Collections.emptyList()), index);
        yes(empty.getBoolean("ready") && ids(empty, "remote_target").isEmpty(), "explicit remote audio removal pulls");
        yes(empty.getJSONObject("local_playlist").getJSONArray("tracks").length() == 2,
            "both local-only videos survive an empty remote list");
        yes(byFile(empty.getJSONObject("local_playlist"), VIDEO_ONE).getInt("rating") == 5 &&
            byFile(empty.getJSONObject("local_playlist"), VIDEO_TWO).getInt("rating") == 5,
            "remote audio removal preserves video likes");
    }

    private static void formerlySharedVideoBlocks() throws Exception {
        Fixture f = new Fixture();
        List<Long> withVideo = new ArrayList<>(f.audio);
        withVideo.add(VIDEO_ONE);
        blocked(f.plan(null, f.full(), f.remote(withVideo), f.index()), "video_reference_already_shared",
            "video already referenced remotely");
        blocked(f.plan(f.base(withVideo), f.full(), f.remote(f.audio), f.index()), "video_reference_already_shared",
            "video in acknowledged base even after provider omission");
    }

    private static void missingOrAmbiguousMimeNeverBecomesLocalOnly() throws Exception {
        for (String mime : new String[] {"", "application/octet-stream", "video/", "video/mp4\nprivate"}) {
            Fixture f = new Fixture();
            f.files.get(VIDEO_ONE).put("contenttype", mime);
            blocked(f.plan(null, f.full(), f.remote(f.audio), f.index()), "unverified_video_reference",
                "ambiguous video container MIME " + mime.replace('\n', '_'));
        }
        Fixture absent = new Fixture();
        absent.files.get(VIDEO_ONE).remove("contenttype");
        blocked(absent.plan(null, absent.full(), absent.remote(absent.audio), absent.index()),
            "unverified_video_reference", "video container without provider MIME");
        Fixture audio = new Fixture();
        audio.files.get(audio.audio.get(0)).remove("contenttype");
        JSONObject noAudioMime = audio.plan(null, audio.full(), audio.remote(audio.audio), audio.index());
        yes(noAudioMime.getBoolean("ready") && ids(noAudioMime, "remote_target").size() == 288,
            "missing audio MIME does not silently remove an ordinary musical reference");
    }

    private static void mimeAndNotExtensionDecidesCompatibility() throws Exception {
        Fixture f = new Fixture();
        JSONObject row = f.files.get(VIDEO_ONE);
        row.put("name", "one.mp3").put("media_path", "Clips/one.mp3");
        JSONObject typedVideoMp3 = f.plan(null, f.full(), f.remote(f.audio), f.index());
        yes(typedVideoMp3.getBoolean("ready") && typedVideoMp3.getInt("local_video_count") == 2,
            "fresh video MIME remains local-only even with an mp3 extension");
        Fixture explicitAudio = new Fixture();
        explicitAudio.files.get(VIDEO_ONE).put("contenttype", "audio/mp4");
        List<Long> represented = new ArrayList<>(explicitAudio.audio);
        represented.add(1, VIDEO_ONE);
        JSONObject audioM4v = explicitAudio.plan(null, explicitAudio.full(), explicitAudio.remote(represented), explicitAudio.index());
        yes(audioM4v.getBoolean("ready") && ids(audioM4v, "remote_target").equals(represented),
            "explicit audio MIME remains cloud-representable despite m4v extension");
        yes(audioM4v.getInt("local_video_count") == 1, "extension alone does not retain the explicitly audio reference");
    }

    private static void contradictingIdentityFailsClosed() throws Exception {
        for (String field : new String[] {"id", "media_path", "pcloud_fileid", "pcloud_account_userid", "pcloud_music_folderid"}) {
            Fixture f = new Fixture();
            JSONObject local = f.full();
            JSONObject video = byFile(local, VIDEO_ONE);
            if (field.equals("id")) video.put(field, "foreign-canonical-id");
            else if (field.equals("media_path")) video.put(field, "Missing/one.m4v");
            else if (field.equals("pcloud_fileid")) video.put(field, 9999);
            else if (field.equals("pcloud_account_userid")) video.put(field, 8);
            else video.put(field, 99);
            failsClosed(() -> f.plan(null, local, f.remote(f.audio), f.index()),
                "contradictory video identity " + field);
        }
        Fixture missingAccount = new Fixture();
        JSONObject source = missingAccount.full();
        byFile(source, VIDEO_ONE).remove("pcloud_account_userid");
        blocked(missingAccount.plan(null, source, missingAccount.remote(missingAccount.audio), missingAccount.index()),
            "unverified_video_reference", "snapshot video without private account origin");
        Fixture folder = new Fixture();
        JSONObject wrongFolder = folder.index().put("music_folderid", 99);
        failsClosed(() -> folder.plan(null, folder.full(), folder.remote(folder.audio), wrongFolder),
            "index root contradicts binding");
        Fixture wrongAccount = new Fixture();
        failsClosed(() -> wrongAccount.plan(null, wrongAccount.full(), wrongAccount.remote(wrongAccount.audio),
            wrongAccount.index().put("account_userid", 8)), "index account contradicts binding");
    }

    private static void legacyMarkersAndUnattestableEntries() throws Exception {
        Fixture legacy = new Fixture();
        JSONObject source = legacy.full();
        byFile(source, VIDEO_ONE).remove("pcloud_music_folderid");
        byFile(source, VIDEO_TWO).remove("pcloud_music_folderid");
        JSONObject legacyPlan = legacy.plan(null, source, legacy.remote(legacy.audio), legacy.index());
        yes(legacyPlan.getBoolean("ready") && legacyPlan.getInt("local_video_count") == 2,
            "version-seven private references remain attestable without a legacy folder marker");
        Fixture stream = new Fixture();
        JSONObject local = stream.full();
        local.getJSONArray("tracks").put(new JSONObject().put("id", "unattested-stream")
            .put("title", "Synthetic stream").put("artist", "Fixture").put("album", "")
            .put("uri", "https://example.invalid/stream"));
        blocked(stream.plan(null, local, stream.remote(stream.audio), stream.index()), "unmapped_local_tracks",
            "unattestable stream");
        Fixture missing = new Fixture();
        JSONObject missingLocal = missing.full();
        missingLocal.getJSONArray("tracks").put(new JSONObject().put("id", "missing-music")
            .put("title", "Missing").put("artist", "Fixture").put("album", "")
            .put("media_path", "Missing/song.mp3").put("pcloud_fileid", 9999).put("pcloud_account_userid", USER));
        blocked(missing.plan(null, missingLocal, missing.remote(missing.audio), missing.index()), "unmapped_local_tracks",
            "missing ordinary musical file");
    }

    public static void main(String[] args) throws Exception {
        largeProjectionAndPrivateObjects();
        remotePullAndReorderPreserveVideos();
        formerlySharedVideoBlocks();
        missingOrAmbiguousMimeNeverBecomesLocalOnly();
        mimeAndNotExtensionDecidesCompatibility();
        contradictingIdentityFailsClosed();
        legacyMarkersAndUnattestableEntries();
        System.out.println("PASS : " + checks + " video/audio-collection projection assertions; " +
            "288 audio plus two private videos, synthetic metadata only, no live account or network");
    }
}
