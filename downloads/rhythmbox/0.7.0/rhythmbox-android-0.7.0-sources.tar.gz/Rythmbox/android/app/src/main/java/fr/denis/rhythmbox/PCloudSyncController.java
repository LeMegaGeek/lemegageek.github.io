package fr.denis.rhythmbox;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.ConcurrentModificationException;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.BooleanSupplier;

/** Account-bound playlist coordination. Network preparation and short local
 * commits are separate; a pending write is never retried automatically. */
public final class PCloudSyncController {
    public static final int JOB_ID=0x52425850;
    private static final ReentrantLock SYNC_LOCK=new ReentrantLock();
    private static final AtomicBoolean UI_ACTIVE=new AtomicBoolean();
    private static final AtomicLong UI_EPOCH=new AtomicLong();
    public interface AccountSource {PCloudAccount load() throws Exception;}
    public interface ClientFactory {PCloudCollections create(PCloudAccount account,Set<Long> selected,Set<String> createNames) throws Exception;}
    private final Context context;
    private final AccountSource accounts;
    private final ClientFactory clients;
    public PCloudSyncController(Context context){this(context.getApplicationContext(),()->new PCloudAccountStore(context.getApplicationContext()).load(),PCloudCollections::new);}
    /** Isolated transport/store injection for host tests. */
    PCloudSyncController(Context context,AccountSource accounts,ClientFactory clients){this.context=context;this.accounts=accounts;this.clients=clients;}
    public static final class Result {
        public final String message;
        public final JSONObject state;
        public final boolean needsAttention;
        private final String expectedFingerprint;
        private final PCloudAccount account;
        private final boolean background;
        private final long uiEpoch;
        private Result(String message,JSONObject state,String fingerprint,PCloudAccount account,boolean attention,boolean background,long uiEpoch){this.message=message;this.state=state;this.expectedFingerprint=fingerprint;this.account=account;this.needsAttention=attention;this.background=background;this.uiEpoch=uiEpoch;}
    }
    private static JSONObject copy(JSONObject value) throws Exception{return new JSONObject(value.toString());}
    /** Still a ConcurrentModificationException; only its finite diagnostic is
     * exposed by automatic synchronization, never a storage exception body. */
    private static final class LocalChangeException extends ConcurrentModificationException implements PCloudCollections.DiagnosticCarrier {
        private final PCloudCollections.Diagnostic diagnostic;
        LocalChangeException(String message,PCloudCollections.GuardReason reason,PCloudCollections.DiagnosticPhase phase,long collectionId){
            super(message);diagnostic=PCloudCollections.diagnostic(PCloudCollections.DiagnosticMethod.NONE,
                PCloudCollections.DiagnosticCheckpoint.NONE,PCloudCollections.DiagnosticCategory.GUARD,phase,reason,-1,collectionId);
        }
        public PCloudCollections.Diagnostic diagnostic(){return diagnostic;}
    }
    public JSONObject state(Library library) throws Exception {JSONObject value=library.state.optJSONObject("pcloud_native");return value==null?new JSONObject():copy(value);}
    public static void setUiActive(boolean active){if(active&&!UI_ACTIVE.getAndSet(true))UI_EPOCH.incrementAndGet();else if(!active)UI_ACTIVE.set(false);}
    public static boolean isUiActive(){return UI_ACTIVE.get();}
    private PCloudAccount account() throws Exception {PCloudAccount out=accounts.load();if(out==null||out.musicFolderId<=0)throw new IllegalStateException("Connecte le compte musical pCloud et choisis son dossier musique.");return out;}
    private static boolean sameAccount(PCloudAccount left,PCloudAccount right){return left!=null&&right!=null&&PCloudAccount.sameAuthorization(left,right);}
    private static JSONObject initial(PCloudAccount account) throws Exception{return new JSONObject().put("account_userid",account.userid).put("music_folderid",account.musicFolderId).put("bindings",new JSONArray()).put("bases",new JSONObject()).put("ack_pruning",false).put("auto_sync",false);}
    private static void validateIdentity(JSONObject settings,PCloudAccount account) throws Exception {if(PCloudCollections.integer(settings.get("account_userid"),false)!=account.userid||PCloudCollections.integer(settings.get("music_folderid"),false)!=account.musicFolderId)throw new IllegalStateException("Les listes enregistrées appartiennent à un autre compte ou dossier pCloud. Reconfigure la synchronisation.");}
    private static JSONArray bindings(JSONObject settings) throws Exception {JSONArray rows=settings.getJSONArray("bindings");if(rows.length()>1000)throw new IllegalArgumentException("Trop de listes liées");Set<Long> collections=new HashSet<>();Set<String> local=new HashSet<>();long uid=PCloudCollections.integer(settings.get("account_userid"),false);for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);if(PCloudCollections.integer(row.get("account_userid"),false)!=uid||!collections.add(PCloudCollections.integer(row.get("collection_id"),false))||!local.add(row.getString("playlist_id")))throw new IllegalArgumentException("Liaisons de listes ambiguës");}return rows;}
    private static Set<Long> selected(JSONObject settings) throws Exception {Set<Long> out=new LinkedHashSet<>();JSONArray rows=bindings(settings);for(int i=0;i<rows.length();i++)out.add(rows.getJSONObject(i).getLong("collection_id"));return out;}
    private static JSONObject find(JSONArray lists,String id) throws Exception {for(int i=0;i<lists.length();i++)if(id.equals(lists.getJSONObject(i).getString("id")))return lists.getJSONObject(i);return null;}
    private static void replace(JSONArray lists,JSONObject value) throws Exception {String id=value.getString("id");for(int i=0;i<lists.length();i++)if(id.equals(lists.getJSONObject(i).getString("id"))){lists.put(i,copy(value));return;}lists.put(copy(value));}
    private static void bind(JSONObject settings,JSONObject value) throws Exception {JSONArray rows=settings.getJSONArray("bindings"),next=new JSONArray();for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);if(row.getLong("collection_id")!=value.getLong("collection_id")&&!row.getString("playlist_id").equals(value.getString("playlist_id")))next.put(row);}next.put(value);settings.put("bindings",next);}
    private static JSONObject binding(PCloudAccount account,long cid,String localId) throws Exception {PCloudCollections.integer(cid,false);return new JSONObject().put("account_userid",account.userid).put("music_folderid",account.musicFolderId).put("collection_id",cid).put("playlist_id",localId);}
    private static String adopt(JSONObject working,JSONObject settings,String oldId,long cid,PCloudAccount account) throws Exception {
        String canonical=PCloudNativeSync.playlistId(account.userid,cid);if(canonical.equals(oldId))return canonical;
        JSONArray lists=working.getJSONArray("playlists");JSONObject source=find(lists,oldId);if(source==null)throw new IllegalArgumentException("Liste locale introuvable.");if(find(lists,canonical)!=null)throw new IllegalStateException("Une autre liste locale possède déjà l’identité de cette liste pCloud.");
        JSONObject migrated=copy(source).put("id",canonical);JSONArray next=new JSONArray();for(int i=0;i<lists.length();i++)next.put(oldId.equals(lists.getJSONObject(i).getString("id"))?migrated:lists.getJSONObject(i));working.put("playlists",next);
        JSONObject base=settings.getJSONObject("bases").optJSONObject(Long.toString(cid));if(base!=null){if(!oldId.equals(base.getString("playlist_id")))throw new IllegalStateException("La référence de cette liste pCloud est ambiguë.");base.put("playlist_id",canonical).getJSONObject("playlist").put("id",canonical);}
        bind(settings,binding(account,cid,canonical));return canonical;
    }
    private JSONObject settings(JSONObject working,PCloudAccount account) throws Exception {JSONObject out=working.optJSONObject("pcloud_native");if(out==null){out=initial(account);working.put("pcloud_native",out);}validateIdentity(out,account);bindings(out);out.getJSONObject("bases");return out;}
    private static void noPending(JSONObject settings) {if(settings.has("pending"))throw new IllegalStateException("Une modification pCloud n’a pas été confirmée. Actualise les listes concernées avant de reprendre la synchronisation.");}
    private static String now(){return java.time.Instant.now().toString();}
    public void configure(Library library,boolean acknowledgePruning,boolean autoSync) throws Exception {
        PCloudAccount account=account();String expected=library.fingerprint();JSONObject working=copy(library.state),settings=working.optJSONObject("pcloud_native");
        if(settings==null||settings.optLong("account_userid")!=account.userid||settings.optLong("music_folderid")!=account.musicFolderId){
            if(settings!=null){JSONArray archives=working.optJSONArray("pcloud_native_archives");if(archives==null)archives=new JSONArray();if(archives.length()>=8)throw new IllegalStateException("Trop d’anciens comptes enregistrés ; conserve leurs listes avant de reconfigurer.");archives.put(copy(settings));working.put("pcloud_native_archives",archives);}settings=initial(account);working.put("pcloud_native",settings);
        }
        settings.put("ack_pruning",acknowledgePruning).put("auto_sync",autoSync&&acknowledgePruning);
        if(!library.compareAndSave(working,expected)){library.reload();throw new ConcurrentModificationException("La bibliothèque a changé ; réessaie la configuration.");}
        if(context!=null)schedule(context);
    }
    private final class Session {
        final Library library;final PCloudAccount account;final long epoch;final boolean background;final BooleanSupplier cancelled;
        String expected;JSONObject working,settings;PCloudCollections client;
        PCloudCollections.GuardReason lastInvalid=PCloudCollections.GuardReason.NONE;
        Session(Library library,boolean background,BooleanSupplier cancelled) throws Exception {this.library=library;this.background=background;this.cancelled=cancelled;this.epoch=UI_EPOCH.get();this.account=account();expected=library.fingerprint();working=copy(library.state);settings=settings(working,account);}
        boolean valid(){try{
            if(cancelled.getAsBoolean()){lastInvalid=PCloudCollections.GuardReason.CANCEL;return false;}
            if(background&&(UI_ACTIVE.get()||UI_EPOCH.get()!=epoch)){lastInvalid=PCloudCollections.GuardReason.UI_TRANSITION;return false;}
            if(!sameAccount(account,accounts.load())){lastInvalid=PCloudCollections.GuardReason.ACCOUNT;return false;}
            if(!Objects.equals(expected,library.currentFingerprint())){lastInvalid=PCloudCollections.GuardReason.LIBRARY;return false;}
            lastInvalid=PCloudCollections.GuardReason.NONE;return true;
        }catch(Exception error){lastInvalid=PCloudCollections.GuardReason.STORAGE;return false;}}
        void check(){check(PCloudCollections.DiagnosticPhase.PLAN,0);}
        void check(PCloudCollections.DiagnosticPhase phase,long collectionId){if(!valid())throw new LocalChangeException("Synchronisation interrompue : le compte ou la bibliothèque a changé.",lastInvalid,phase,collectionId);}
        void client(Set<Long> selected,Set<String> create) throws Exception {check();client=clients.create(account,selected,create);if(context!=null)client.setIndexObserver(index->new PCloudAudioCache(new java.io.File(context.getNoBackupFilesDir(),"pcloud-audio-v1")).observeIndex(account,index));client.setDiagnosticContext(PCloudCollections.DiagnosticPhase.PLAN,0);client.setRequestGuard(this::valid,()->lastInvalid);client.verifyAccount();}
        void journal(JSONObject details) throws Exception {check();JSONObject persisted=copy(library.state);JSONObject current=settings(persisted,account);current.put("pending",details).put("last_status","Modification pCloud en cours de vérification");if(!library.compareAndSave(persisted,expected))throw new LocalChangeException("La bibliothèque a changé avant l’écriture pCloud.",PCloudCollections.GuardReason.LIBRARY,PCloudCollections.DiagnosticPhase.PLAN,0);expected=library.fingerprint();settings.put("pending",copy(details));}
        Result result(String message,boolean attention) throws Exception {check(PCloudCollections.DiagnosticPhase.RESULT,0);settings.put("last_status",message).put("last_sync",now());working.put("pcloud_native",settings);return new Result(message,working,expected,account,attention,background,epoch);}
    }
    private static void lock(){if(!SYNC_LOCK.tryLock())throw new IllegalStateException("Une synchronisation pCloud est déjà en cours.");}
    private static Set<String> paths(Map<Long,JSONObject> files) throws Exception {Set<String> out=new HashSet<>();for(JSONObject row:files.values())out.add(row.getString("media_path"));return out;}
    private static Set<String> hidden(JSONObject state){Set<String> out=new HashSet<>();JSONArray rows=state.optJSONArray("hidden");if(rows!=null)for(int i=0;i<rows.length();i++)out.add(rows.optString(i));return out;}
    private static JSONObject emptyList(String id,String name) throws Exception{return new JSONObject().put("id",id).put("name",name).put("tracks",new JSONArray());}
    private static String attention(JSONObject plan) throws Exception {
        JSONArray issues=plan.getJSONArray("issues");for(int i=0;i<issues.length();i++){String code=issues.getJSONObject(i).getString("code");
            if("video_reference_already_shared".equals(code))return "Une vidéo figure déjà dans cette liste pCloud ou sa base. Elle reste conservée ; aucun retrait automatique n’est effectué.";
            if("unverified_video_reference".equals(code))return "Une référence vidéo n’a pas de type ou d’origine vérifiable. Elle reste conservée ; aucune tentative d’ajout à pCloud n’est effectuée.";
            if("unmapped_local_tracks".equals(code)||"unmapped_base_tracks".equals(code))return "Une référence musicale ou un flux n’est pas associé au dossier pCloud choisi. La liste reste conservée ; son envoi est bloqué.";
        }return "Conflits ou morceaux indisponibles conservés. Ouvre les listes signalées.";
    }
    private static String summary(int cloud,int videos){return cloud+" référence(s) pCloud · "+videos+" vidéo(s) conservée(s) sur ce téléphone.";}
    public Result importCollection(Library library,long cid,boolean acknowledgePruning) throws Exception {
        lock();try{Session s=new Session(library,false,()->false);noPending(s.settings);if(!acknowledgePruning)throw new IllegalStateException("Confirme la lecture des listes pCloud.");s.client(Collections.singleton(cid),Collections.emptySet());Map<Long,JSONObject> index=s.client.indexMusic();JSONObject remote=s.client.readCollection(cid,true);
            String localId=PCloudNativeSync.playlistId(s.account.userid,cid);JSONArray bound=bindings(s.settings);for(int i=0;i<bound.length();i++)if(bound.getJSONObject(i).getLong("collection_id")==cid)localId=bound.getJSONObject(i).getString("playlist_id");
            if(find(s.working.getJSONArray("playlists"),localId)!=null)localId=adopt(s.working,s.settings,localId,cid,s.account);
            JSONObject link=binding(s.account,cid,localId),local=find(s.working.getJSONArray("playlists"),localId),base=s.settings.getJSONObject("bases").optJSONObject(Long.toString(cid));if(local==null){if(base!=null)throw new IllegalStateException("La liste locale liée a disparu ; aucune suppression distante n’est déduite.");local=emptyList(localId,remote.getString("name"));}
            JSONObject plan=PCloudNativeSync.plan(link,base,local,remote,PCloudNativeSync.mediaIndex(s.account,index,paths(index)),hidden(s.working),Collections.emptySet(),Collections.emptySet(),Collections.emptySet());
            bind(s.settings,link);s.settings.put("ack_pruning",true);boolean conflict="conflict".equals(plan.getString("direction"));if(conflict){JSONArray variants=plan.getJSONArray("conflicts");for(int i=0;i<variants.length();i++)replace(s.working.getJSONArray("playlists"),variants.getJSONObject(i));}
            else if(plan.getBoolean("ready")){replace(s.working.getJSONArray("playlists"),plan.getJSONObject("local_playlist"));if(plan.getJSONArray("operations").length()==0)s.settings.getJSONObject("bases").put(Long.toString(cid),plan.getJSONObject("proposed_base"));}
            else if(!plan.getBoolean("ready"))throw new IllegalStateException(attention(plan));
            return s.result(conflict?"Conflit préservé dans une copie de la liste pCloud.":"Liste pCloud liée ; synchronise pour publier les éventuelles modifications locales. "+summary(plan.getInt("cloud_reference_count"),plan.getInt("local_video_count")),conflict);
        }finally{SYNC_LOCK.unlock();}
    }
    public Result bindCollection(Library library,String localId,long cid,boolean acknowledgePruning) throws Exception {
        lock();try{Session s=new Session(library,false,()->false);noPending(s.settings);if(!acknowledgePruning)throw new IllegalStateException("Confirme la lecture des listes pCloud.");if(find(s.working.getJSONArray("playlists"),localId)==null)throw new IllegalArgumentException("Liste locale introuvable.");s.client(Collections.singleton(cid),Collections.emptySet());s.client.indexMusic();s.client.readCollection(cid,true);
            JSONArray prior=bindings(s.settings);for(int i=0;i<prior.length();i++){JSONObject row=prior.getJSONObject(i);if(row.getLong("collection_id")==cid&&!row.getString("playlist_id").equals(localId))throw new IllegalStateException("Cette liste pCloud est déjà liée à une autre liste locale.");if(row.getString("playlist_id").equals(localId)&&row.getLong("collection_id")!=cid)throw new IllegalStateException("Cette liste locale est déjà liée à une autre liste pCloud.");}
            String canonical=adopt(s.working,s.settings,localId,cid,s.account);bind(s.settings,binding(s.account,cid,canonical));s.settings.put("ack_pruning",true);return s.result("Listes liées ; les contenus divergents seront conservés lors de la synchronisation.",false);
        }finally{SYNC_LOCK.unlock();}
    }
    public Result createCollection(Library library,String localId,String name,boolean acknowledgePruning) throws Exception {
        lock();try{Session s=new Session(library,false,()->false);noPending(s.settings);if(!acknowledgePruning)throw new IllegalStateException("Confirme la lecture des listes pCloud.");JSONObject local=find(s.working.getJSONArray("playlists"),localId);if(local==null)throw new IllegalArgumentException("Liste locale introuvable.");JSONArray rows=bindings(s.settings);for(int i=0;i<rows.length();i++)if(localId.equals(rows.getJSONObject(i).getString("playlist_id")))throw new IllegalStateException("Cette liste est déjà liée à pCloud.");
            s.client(Collections.emptySet(),Collections.singleton(name));Map<Long,JSONObject> index=s.client.indexMusic();PCloudNativeSync.validateNewCollection(s.account,local,index,hidden(s.working));s.journal(new JSONObject().put("operation","create").put("playlist_id",localId).put("name",name).put("started",now()));JSONObject created=s.client.createCollection(name);long cid=created.getLong("id");JSONObject recorded=copy(s.settings.getJSONObject("pending")).put("collection_id",cid);s.journal(recorded);
            String canonical=adopt(s.working,s.settings,localId,cid,s.account);bind(s.settings,binding(s.account,cid,canonical));s.settings.getJSONObject("bases").put(Long.toString(cid),new JSONObject().put("account_userid",s.account.userid).put("collection_id",cid).put("playlist_id",canonical).put("playlist",emptyList(canonical,local.getString("name"))).put("fileids",new JSONArray()));s.settings.put("ack_pruning",true).remove("pending");return s.result("Liste créée sur pCloud ; synchronise pour y publier les morceaux.",false);
        }finally{SYNC_LOCK.unlock();}
    }
    public Result prepareSync(Library library) throws Exception{return prepareSync(library,false);}
    public Result prepareSync(Library library,boolean background) throws Exception{return prepareSync(library,background,()->false);}
    Result prepareSync(Library library,boolean background,BooleanSupplier cancelled) throws Exception {
        lock();try{Session s=new Session(library,background,cancelled);noPending(s.settings);if(!s.settings.optBoolean("ack_pruning"))throw new IllegalStateException("Confirme d’abord la lecture des listes pCloud.");if(background&&!s.settings.optBoolean("auto_sync"))throw new IllegalStateException("Synchronisation automatique désactivée.");
            JSONArray links=bindings(s.settings);if(links.length()==0)return s.result("Aucune liste pCloud sélectionnée.",false);s.client(selected(s.settings),Collections.emptySet());Map<Long,JSONObject> index=s.client.indexMusic();JSONObject media=PCloudNativeSync.mediaIndex(s.account,index,paths(index));List<JSONObject> plans=new ArrayList<>();boolean writes=false,attention=false;int changed=0;
            for(int i=0;i<links.length();i++){JSONObject link=links.getJSONObject(i);long cid=link.getLong("collection_id");s.client.setDiagnosticContext(PCloudCollections.DiagnosticPhase.PLAN,cid);String lid=link.getString("playlist_id");JSONObject remote=s.client.readCollection(cid,true),local=find(s.working.getJSONArray("playlists"),lid),base=s.settings.getJSONObject("bases").optJSONObject(Long.toString(cid));if(local==null)throw new IllegalStateException("Une liste locale liée a disparu ; aucune suppression distante n’est déduite.");
                JSONObject plan=PCloudNativeSync.plan(link,base,local,remote,media,hidden(s.working),Collections.emptySet(),Collections.emptySet(),Collections.emptySet());plans.add(plan);writes|=plan.getBoolean("ready")&&plan.getJSONArray("operations").length()>0;attention|=!plan.getBoolean("ready");}
            if(writes){JSONArray ids=new JSONArray();for(JSONObject p:plans)if(p.getBoolean("ready")&&p.getJSONArray("operations").length()>0)ids.put(p.getLong("collection_id"));s.journal(new JSONObject().put("operation","sync").put("collection_ids",ids).put("started",now()));}
            int cloud=0,videos=0;String reason="";JSONArray statuses=new JSONArray();for(JSONObject plan:plans){long cid=plan.getLong("collection_id");s.check(PCloudCollections.DiagnosticPhase.APPLY,cid);s.client.setDiagnosticContext(PCloudCollections.DiagnosticPhase.APPLY,cid);String direction=plan.getString("direction");videos+=plan.getInt("local_video_count");statuses.put(new JSONObject().put("collection_id",cid).put("direction",direction).put("issues",plan.getJSONArray("issues")).put("cloud_reference_count",plan.getInt("cloud_reference_count")).put("local_video_count",plan.getInt("local_video_count")));if(!plan.getBoolean("ready")){if(reason.isEmpty())reason=attention(plan);JSONArray variants=plan.getJSONArray("conflicts");for(int j=0;j<variants.length();j++)replace(s.working.getJSONArray("playlists"),variants.getJSONObject(j));continue;}cloud+=plan.getInt("cloud_reference_count");
                JSONObject applied=PCloudNativeSync.apply(s.client,plan,true,s::valid);replace(s.working.getJSONArray("playlists"),applied.getJSONObject("local_playlist"));s.settings.getJSONObject("bases").put(Long.toString(plan.getLong("collection_id")),applied.getJSONObject("proposed_base"));if(!"unchanged".equals(direction))changed++;}
            s.settings.put("list_status",statuses).remove("pending");return s.result((attention?"Synchronisation partielle : "+reason:changed+" liste(s) synchronisée(s) dans les deux sens.")+" "+summary(cloud,videos),attention);
        }finally{SYNC_LOCK.unlock();}
    }
    /** UI/background commits local playlists, bases and the cleared journal in
     * one CAS write. A stale result cannot overwrite a newer user action. */
    public boolean commit(Library library,Result result) throws Exception {if((result.background&&(UI_ACTIVE.get()||UI_EPOCH.get()!=result.uiEpoch))||!sameAccount(result.account,accounts.load())||!library.compareAndSave(result.state,result.expectedFingerprint)){library.reload();return false;}if(context!=null)schedule(context);return true;}
    /** Explicit recovery reads only journaled collections and preserves the
     * observed remote contents as copies; it performs no playlist mutation. */
    public Result recoverPending(Library library,boolean acknowledgePruning) throws Exception{return recoverPending(library,0,acknowledgePruning);}
    /** selectedCreatedCollection is an explicit chooser selection used only
     * when a collection_create response was lost before its ID was recorded. */
    public Result recoverPending(Library library,long selectedCreatedCollection,boolean acknowledgePruning) throws Exception {
        lock();try{Session s=new Session(library,false,()->false);JSONObject pending=s.settings.optJSONObject("pending");if(pending==null)return s.result("Aucune modification pCloud en attente.",false);if(!acknowledgePruning)throw new IllegalStateException("Confirme la lecture des listes pCloud.");Set<Long> ids=new LinkedHashSet<>();
            if("sync".equals(pending.optString("operation"))){if(selectedCreatedCollection!=0)throw new IllegalArgumentException("Choix de récupération invalide.");ids.addAll(PCloudCollections.ids(pending.getJSONArray("collection_ids")));}
            else if("create".equals(pending.optString("operation"))){long cid=pending.optLong("collection_id",selectedCreatedCollection);if(cid<=0)throw new IllegalStateException("La création n’a pas été confirmée. Sélectionne explicitement la liste créée dans pCloud pour la rattacher.");ids.add(cid);}
            else throw new IllegalArgumentException("Journal de synchronisation inconnu.");
            s.client(ids,Collections.emptySet());Map<Long,JSONObject> index=s.client.indexMusic();for(long cid:ids){JSONObject remote=s.client.readCollection(cid,true),variant=PCloudNativeSync.playlistFromCollection(s.account,remote,index);String material=s.account.userid+":"+cid+":"+PCloudNativeSync.canonical(variant);String id=java.util.UUID.nameUUIDFromBytes(("pcloud-recovery:"+material).getBytes(java.nio.charset.StandardCharsets.UTF_8)).toString();variant.put("id",id).put("name",variant.getString("name")+" · récupération pCloud "+id.substring(0,8));replace(s.working.getJSONArray("playlists"),variant);
                if("create".equals(pending.optString("operation"))){String localId=pending.getString("playlist_id");if(find(s.working.getJSONArray("playlists"),localId)==null)throw new IllegalStateException("La liste locale à rattacher a disparu.");String canonical=adopt(s.working,s.settings,localId,cid,s.account);bind(s.settings,binding(s.account,cid,canonical));}
            }
            s.settings.remove("pending");return s.result("État pCloud relu et conservé dans une copie. Vérifie les listes avant de relancer la synchronisation.",true);
        }finally{SYNC_LOCK.unlock();}
    }
    public static synchronized void schedule(Context context){try{scheduleChecked(context);}catch(Exception ignored){cancelJob(context);}}
    private static synchronized void scheduleChecked(Context context) throws Exception {
        JobScheduler scheduler=(JobScheduler)context.getSystemService(Context.JOB_SCHEDULER_SERVICE);if(scheduler==null)return;Library library=new Library(context);JSONObject nativeState=library.state.optJSONObject("pcloud_native");PCloudAccount account=new PCloudAccountStore(context).load();JSONObject config=new SecretStore(context).load();
        if(account==null||account.musicFolderId<=0||!"account".equals(config.optString("sync_mode"))||nativeState==null||!nativeState.optBoolean("auto_sync")||!nativeState.optBoolean("ack_pruning")||nativeState.has("pending")||nativeState.optLong("account_userid")!=account.userid||nativeState.optLong("music_folderid")!=account.musicFolderId||bindings(nativeState).length()==0){scheduler.cancel(JOB_ID);return;}
        JobInfo info=new JobInfo.Builder(JOB_ID,new ComponentName(context,PCloudSyncJobService.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_UNMETERED).setPeriodic(15*60*1000L).setPersisted(true).setRequiresBatteryNotLow(true).build();
        // schedule() replaces even an identical running periodic job. Keep its
        // current execution and next window; a changed policy still replaces it.
        JobInfo pending=scheduler.getPendingJob(JOB_ID);
        if(pending!=null){
            // API 26 compares Bundle parcel representations too. Materialize
            // both empty extras so an IPC round trip is not a policy change.
            info.getExtras().size();pending.getExtras().size();
            info.getTransientExtras().size();pending.getTransientExtras().size();
            if(info.equals(pending))return;
        }
        scheduler.schedule(info);
    }
    public static synchronized void cancelJob(Context context){JobScheduler scheduler=(JobScheduler)context.getSystemService(Context.JOB_SCHEDULER_SERVICE);if(scheduler!=null)scheduler.cancel(JOB_ID);}
}
