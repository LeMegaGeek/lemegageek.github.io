package fr.denis.rhythmbox;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.AtomicFile;
import android.widget.TextView;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.json.JSONObject;

/** Bounded framework probe for a disposable, signature-isolated emulator.
 * Uses the exact production SpotifyController and notification-listener class.
 * Its two MediaSession fixture apps have no audio, account or Internet access.
 */
public final class SpotifyFrameworkProbeActivity extends Activity {
    private static final String HARNESS="fr.denis.rhythmbox.spotifytest";
    private static final String SPOTIFY="com.spotify.music";
    private static final String FOREIGN="fr.denis.rhythmbox.foreignspotifyfixture";
    private static final String SERVICE="fr.denis.rhythmbox.spotifyfixture.FixtureService";
    private static final String PERMISSION=HARNESS+".CONTROL_FIXTURE";
    private static final String EVENT=HARNESS+".FIXTURE_EVENT";
    private static final String ACTION=HARNESS+".fixture.";
    private static final long DURATION=10000;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Map<String,Counts> counts=new HashMap<>();
    private final Map<String,ServiceConnection> connections=new HashMap<>();
    private final Set<String> bound=new HashSet<>(),connected=new HashSet<>();
    private SpotifyController controller;
    private SpotifyController.State latest,playingSnapshot;
    private TextView display;
    private Bitmap initialCover;
    private boolean began,done,receiverRegistered,revocationVerified;
    private int stage,checks,events;
    private long startedAt,enteredAt,spotifyEventBefore,foreignEventBefore,positionBefore;
    private long generationBeforeDestroy,newGeneration;
    private String phase="starting";

    private static final class Counts {
        int plays,pauses,next,previous,seeks,oldReplays,sessions,serial,sequence;
        long lastSeek;
        Counts(Intent intent,int sequence){
            plays=intent.getIntExtra("plays",-1);pauses=intent.getIntExtra("pauses",-1);
            next=intent.getIntExtra("next",-1);previous=intent.getIntExtra("previous",-1);
            seeks=intent.getIntExtra("seeks",-1);lastSeek=intent.getLongExtra("last_seek",-1);
            oldReplays=intent.getIntExtra("old_replays",-1);sessions=intent.getIntExtra("session_count",-1);
            serial=intent.getIntExtra("main_serial",-1);this.sequence=sequence;
        }
    }
    private final BroadcastReceiver receiver=new BroadcastReceiver(){
        @Override public void onReceive(Context context,Intent intent){
            if(done||!EVENT.equals(intent.getAction()))return;
            String pkg=intent.getStringExtra("pkg");
            if(SPOTIFY.equals(pkg)||FOREIGN.equals(pkg))counts.put(pkg,new Counts(intent,++events));
        }
    };

    @Override public void onCreate(Bundle state){
        super.onCreate(state);display=new TextView(this);display.setTextSize(19);display.setPadding(24,24,24,24);
        display.setText("Isolated Spotify framework probe\nSynthetic sessions only");setContentView(display);
    }
    @Override public void onResume(){
        super.onResume();
        if(!began){began=true;handler.postDelayed(this::begin,150);}
    }
    private void check(boolean condition,String message){checks++;if(!condition)throw new AssertionError(message);}
    private void begin(){
        if(done)return;
        try{
            check(HARNESS.equals(getPackageName()),"Harness package mismatch");
            for(String pkg:new String[]{HARNESS,SPOTIFY,FOREIGN}){
                PackageInfo info=getPackageManager().getPackageInfo(pkg,PackageManager.GET_PERMISSIONS);
                if(info.requestedPermissions!=null)for(String permission:info.requestedPermissions)
                    check(!"android.permission.INTERNET".equals(permission),"Fixture has Internet permission");
                check(getPackageManager().checkSignatures(HARNESS,pkg)==PackageManager.SIGNATURE_MATCH,
                      "Fixture certificate does not match this disposable harness");
            }
            registerReceiver(receiver,new IntentFilter(EVENT),PERMISSION,handler,Context.RECEIVER_EXPORTED);
            receiverRegistered=true;
            controller=new SpotifyController(this,state->{
                if(done)return;
                try{
                    if(state.available)check(state.id.startsWith("spotify-"),"Foreign session metadata reached the controller");
                    check(!state.shufflePossible,"Shuffle capability must not be invented");
                    latest=state;
                }catch(Throwable error){finishProbe(false,error);}
            });
            check(SpotifyController.isAccessEnabled(this),"Host must authorize only the test notification listener first");
            startedAt=enteredAt=SystemClock.elapsedRealtime();
            stage=-1;progress("binding-fixtures");
            bindFixture(FOREIGN);bindFixture(SPOTIFY);handler.postDelayed(tick,100);
        }catch(Throwable error){finishProbe(false,error);}
    }
    private void fixture(String pkg,String command){
        startService(new Intent(ACTION+command).setComponent(new ComponentName(pkg,SERVICE)));
    }
    private void bindFixture(final String pkg){
        ServiceConnection connection=new ServiceConnection(){
            @Override public void onServiceConnected(ComponentName name,IBinder binder){
                if(done)return;
                try{
                    check(pkg.equals(name.getPackageName())&&SERVICE.equals(name.getClassName())&&binder!=null,
                          "Unexpected bound fixture component");
                    connected.add(pkg);
                }catch(Throwable error){finishProbe(false,error);}
            }
            @Override public void onServiceDisconnected(ComponentName name){
                connected.remove(pkg);
                if(!done)finishProbe(false,new IllegalStateException("Bound fixture disconnected: "+pkg));
            }
            @Override public void onBindingDied(ComponentName name){
                connected.remove(pkg);
                if(!done)finishProbe(false,new IllegalStateException("Fixture binding died: "+pkg));
            }
            @Override public void onNullBinding(ComponentName name){
                if(!done)finishProbe(false,new IllegalStateException("Fixture returned no Binder: "+pkg));
            }
        };
        connections.put(pkg,connection);
        boolean accepted=bindService(new Intent().setComponent(new ComponentName(pkg,SERVICE)),
                                    connection,Context.BIND_AUTO_CREATE);
        check(accepted,"Cannot bind disposable fixture: "+pkg);
        if(accepted)bound.add(pkg);
    }
    private void fixturePosition(long position){
        startService(new Intent(ACTION+"position").setComponent(new ComponentName(SPOTIFY,SERVICE)).putExtra("position",position));
    }
    private Counts spotify(){return counts.get(SPOTIFY);}
    private Counts foreign(){return counts.get(FOREIGN);}
    private boolean ready(boolean condition){
        if(condition)return true;
        long limit=stage==23?18000:5000;
        if(SystemClock.elapsedRealtime()-enteredAt>limit)throw new AssertionError("Timed out in phase "+phase);
        return false;
    }
    private boolean capabilities(){return latest!=null&&latest.available&&latest.canPlay&&latest.canPause&&
        latest.canNext&&latest.canPrevious&&latest.canSeek;}
    private void art(Bitmap bitmap){
        check(bitmap!=null,"Spotify framework artwork missing");
        check(!bitmap.isRecycled()&&!bitmap.isMutable(),"Artwork must be a live immutable private copy");
        check(bitmap.getWidth()==512&&bitmap.getHeight()==512,"1024-pixel ART must be bounded to 512 pixels");
    }
    private void empty(){
        check(latest!=null&&!latest.available,"Controller must be unavailable");
        check(latest.id.isEmpty()&&latest.title.isEmpty()&&latest.artist.isEmpty()&&latest.album.isEmpty()&&latest.cover==null,
              "Unavailable controller retained metadata");
        check(!latest.playing&&!latest.canPlay&&!latest.canPause&&!latest.canNext&&!latest.canPrevious&&!latest.canSeek,
              "Unavailable controller retained transport capabilities");
    }
    private void commandsRefused(){
        check(!controller.resume()&&!controller.pause()&&!controller.next()&&!controller.previous()&&!controller.seekTo(50),
              "Unavailable or disabled controls dispatched transport");
    }
    private void foreignUntouched(){
        Counts value=foreign();check(value!=null,"Foreign signed fixture status missing");
        check(value.plays==0&&value.pauses==0&&value.next==0&&value.previous==0&&value.seeks==0,
              "Transport was redirected to the foreign player");
    }
    private void expectedSpotify(){
        Counts value=spotify();check(value!=null,"Spotify signed fixture status missing");
        check(value.plays==1&&value.pauses==1&&value.next==1&&value.previous==1&&value.seeks==2,
              "Unexpected Spotify command count, autoplay or lifecycle pause");
    }
    private void advance(int next,String label){stage=next;enteredAt=SystemClock.elapsedRealtime();progress(label);}
    private void progress(String label){
        phase=label;display.setText("Isolated Spotify framework probe\n"+label+"\nChecks: "+checks);
        try{write("spotify-framework-progress.json",new JSONObject().put("phase",label).put("checks",checks)
            .put("elapsed_ms",startedAt==0?0:SystemClock.elapsedRealtime()-startedAt));}
        catch(Exception error){throw new IllegalStateException("Cannot write probe progress",error);}
    }
    private final Runnable tick=new Runnable(){
        @Override public void run(){
            if(done)return;
            try{
                if(SystemClock.elapsedRealtime()-startedAt>45000)throw new AssertionError("Framework probe exceeded 45 seconds");
                controller.refresh();latest=controller.state();
                switch(stage){
                    case -1:
                        if(!ready(connected.contains(SPOTIFY)&&connected.contains(FOREIGN)))break;
                        fixture(FOREIGN,"init");fixture(SPOTIFY,"init");controller.start();
                        advance(0,"initial-sessions");break;
                    case 0:
                        if(!ready(spotify()!=null&&foreign()!=null&&latest.available&&"spotify-A".equals(latest.id)))break;
                        check(!latest.playing,"Observing a paused Spotify must not autoplay");
                        check(spotify().plays==0&&spotify().pauses==0&&spotify().next==0&&spotify().previous==0&&spotify().seeks==0,
                              "Initialization unexpectedly controlled Spotify");
                        foreignUntouched();check(capabilities(),"Spotify advertised controls missing");
                        check(latest.artist.equals("Synthetic Spotify artist"),"Wrong metadata artist");
                        initialCover=latest.cover;art(initialCover);controller.refresh();advance(1,"art-refresh");break;
                    case 1:
                        if(!ready(latest.available&&latest.cover!=null))break;
                        check(latest.cover==initialCover,"Unchanged metadata must reuse its private artwork copy");
                        check(controller.resume(),"Explicit Spotify play request refused");advance(2,"play-acknowledgement");break;
                    case 2:
                        if(!ready(spotify().plays==1&&latest.playing))break;
                        check(latest.cover==initialCover,"Playback state update replaced cached artwork");
                        playingSnapshot=latest;positionBefore=playingSnapshot.positionNow();advance(3,"position-estimate");break;
                    case 3:
                        if(SystemClock.elapsedRealtime()-enteredAt<250)break;
                        check(playingSnapshot.positionNow()>positionBefore,"State.positionNow did not advance during playback");
                        check(playingSnapshot.positionNow()<=playingSnapshot.duration,"Estimated position exceeded duration");
                        check(controller.pause(),"Explicit Spotify pause request refused");advance(4,"pause-acknowledgement");break;
                    case 4:
                        if(!ready(spotify().pauses==1&&!latest.playing))break;
                        check(controller.next(),"Explicit Spotify next request refused");advance(5,"next-track");break;
                    case 5:
                        if(!ready(spotify().next==1&&"spotify-B".equals(latest.id)))break;
                        check(latest.cover==initialCover,"Identical ART on another track must reuse the immutable cached copy");
                        check(controller.previous(),"Explicit Spotify previous request refused");advance(6,"previous-track");break;
                    case 6:
                        if(!ready(spotify().previous==1&&"spotify-A".equals(latest.id)))break;
                        check(!controller.seekTo(-1),"Negative seek must be rejected");
                        spotifyEventBefore=spotify().sequence;fixture(SPOTIFY,"status");advance(7,"negative-seek-status");break;
                    case 7:
                        if(!ready(spotify().sequence>spotifyEventBefore))break;
                        check(spotify().seeks==0,"Negative seek reached the MediaSession callback");
                        check(controller.seekTo(5000),"Valid seek refused");advance(8,"seek-acknowledgement");break;
                    case 8:
                        if(!ready(spotify().seeks==1&&spotify().lastSeek==5000))break;
                        check(controller.seekTo(Long.MAX_VALUE),"Bounded upper seek refused");advance(9,"bounded-seek");break;
                    case 9:
                        if(!ready(spotify().seeks==2&&spotify().lastSeek==DURATION))break;
                        check(latest.positionNow()<=DURATION,"Playback position not bounded after seek");
                        fixture(SPOTIFY,"caps_none");advance(10,"disabled-capabilities");break;
                    case 10:
                        if(!ready(latest.available&&!latest.canPlay&&!latest.canPause&&!latest.canNext&&!latest.canPrevious&&!latest.canSeek))break;
                        commandsRefused();spotifyEventBefore=spotify().sequence;fixture(SPOTIFY,"status");advance(11,"disabled-controls-status");break;
                    case 11:
                        if(!ready(spotify().sequence>spotifyEventBefore))break;
                        expectedSpotify();fixture(SPOTIFY,"restore_caps");advance(12,"restore-capabilities");break;
                    case 12:
                        if(!ready(capabilities()))break;
                        fixturePosition(1000);advance(13,"state-only-position-update");break;
                    case 13:
                        if(!ready(latest.position>=990&&latest.position<=1010))break;
                        check(latest.cover==initialCover,"Position update must retain artwork identity");
                        fixture(SPOTIFY,"second");advance(14,"ambiguous-sessions");break;
                    case 14:
                        if(!ready(spotify().sessions==2&&!latest.available))break;
                        empty();commandsRefused();fixture(SPOTIFY,"drop_second");advance(15,"single-session-restored");break;
                    case 15:
                        if(!ready(spotify().sessions==1&&latest.available&&"spotify-A".equals(latest.id)))break;
                        generationBeforeDestroy=latest.sessionGeneration;fixture(SPOTIFY,"destroy");advance(16,"session-destroyed");break;
                    case 16:
                        if(!ready(spotify().sessions==0&&!latest.available))break;
                        empty();check(latest.sessionGeneration>generationBeforeDestroy,"Destruction did not invalidate the session generation");
                        check(!controller.next(),"Destroyed Spotify session fell back to another player");
                        fixture(SPOTIFY,"new");advance(17,"new-session-token");break;
                    case 17:
                        if(!ready(spotify().sessions==1&&spotify().serial>=2&&latest.available&&"spotify-NEW-A".equals(latest.id)))break;
                        check(latest.sessionGeneration>generationBeforeDestroy,"New token did not obtain a new generation");
                        newGeneration=latest.sessionGeneration;art(latest.cover);
                        fixture(SPOTIFY,"replay_old");advance(18,"released-token-replay");break;
                    case 18:
                        if(!ready(spotify().oldReplays==1&&SystemClock.elapsedRealtime()-enteredAt>=300))break;
                        check(latest.available&&"spotify-NEW-A".equals(latest.id)&&latest.sessionGeneration==newGeneration,
                              "Released token or old callback replaced the new session");
                        controller.stop();advance(19,"observer-stop");break;
                    case 19:
                        if(!ready(!latest.available))break;
                        empty();spotifyEventBefore=spotify().sequence;fixture(SPOTIFY,"status");advance(20,"stop-is-not-pause");break;
                    case 20:
                        if(!ready(spotify().sequence>spotifyEventBefore))break;
                        expectedSpotify();controller.start();advance(21,"observer-restart");break;
                    case 21:
                        if(!ready(latest.available&&"spotify-NEW-A".equals(latest.id)))break;
                        check(!latest.playing,"Restarting the observer autoplayed Spotify");
                        spotifyEventBefore=spotify().sequence;foreignEventBefore=foreign().sequence;
                        fixture(SPOTIFY,"status");fixture(FOREIGN,"status");advance(22,"before-revocation-status");break;
                    case 22:
                        if(!ready(spotify().sequence>spotifyEventBefore&&foreign().sequence>foreignEventBefore))break;
                        expectedSpotify();foreignUntouched();advance(23,"await-revoke");break;
                    case 23:
                        if(!ready(!latest.hasAccess&&!latest.available))break;
                        empty();commandsRefused();revocationVerified=true;
                        spotifyEventBefore=spotify().sequence;foreignEventBefore=foreign().sequence;
                        fixture(SPOTIFY,"status");fixture(FOREIGN,"status");advance(24,"after-revocation-status");break;
                    case 24:
                        if(!ready(spotify().sequence>spotifyEventBefore&&foreign().sequence>foreignEventBefore))break;
                        expectedSpotify();foreignUntouched();check(revocationVerified,"Revocation was not observed");finishProbe(true,null);return;
                    default:throw new AssertionError("Unknown probe stage");
                }
                if(!done)handler.postDelayed(this,100);
            }catch(Throwable error){finishProbe(false,error);}
        }
    };
    private void write(String name,JSONObject value) throws Exception {
        AtomicFile file=new AtomicFile(new File(getFilesDir(),name));FileOutputStream output=file.startWrite();
        try{output.write(value.toString(2).getBytes(StandardCharsets.UTF_8));file.finishWrite(output);}
        catch(Exception error){file.failWrite(output);throw error;}
    }
    private void finishProbe(boolean passed,Throwable error){
        if(done)return;done=true;handler.removeCallbacks(tick);
        try{
            JSONObject result=new JSONObject().put("passed",passed).put("checks",checks).put("phase",phase)
                .put("elapsed_ms",startedAt==0?0:SystemClock.elapsedRealtime()-startedAt)
                .put("real_android_media_session_manager",true).put("synthetic_fixture_packages_only",true)
                .put("notification_access_revoked",revocationVerified).put("no_audio_or_notifications_created",true)
                .put("no_account_or_internet",true).put("foreign_transport_commands",foreign()==null?-1:
                    foreign().plays+foreign().pauses+foreign().next+foreign().previous+foreign().seeks);
            if(error!=null)result.put("error",error.getClass().getSimpleName()+": "+String.valueOf(error.getMessage()));
            write("spotify-framework-result.json",result);
        }catch(Exception ignored){}
        cleanup();finish();
    }
    private void cleanup(){
        if(controller!=null)controller.stop();
        if(receiverRegistered){try{unregisterReceiver(receiver);}catch(RuntimeException ignored){}receiverRegistered=false;}
        for(String pkg:new String[]{SPOTIFY,FOREIGN})try{stopService(new Intent().setComponent(new ComponentName(pkg,SERVICE)));}catch(RuntimeException ignored){}
        for(String pkg:new HashSet<>(bound))try{unbindService(connections.get(pkg));}catch(RuntimeException ignored){}
        bound.clear();connected.clear();connections.clear();
    }
    @Override public void onDestroy(){
        handler.removeCallbacksAndMessages(null);
        if(!done)finishProbe(false,new IllegalStateException("Harness was destroyed before completion"));
        super.onDestroy();
    }
}
