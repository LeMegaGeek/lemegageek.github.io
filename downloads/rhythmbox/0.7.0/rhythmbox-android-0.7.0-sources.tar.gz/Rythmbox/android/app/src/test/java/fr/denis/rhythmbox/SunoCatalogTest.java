package fr.denis.rhythmbox;

import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/** Public-page fixtures only; no network, account, audio, file or Android API. */
public final class SunoCatalogTest {
    static final String A="cb515581-12ae-4638-aaf8-9f9c6022e8b3",B="9d9df80b-3299-4f5b-a403-d889544e173a",P="f851e25a-0758-4b2b-aaa2-9815b9be4daa";
    static final String SONG="https://suno.com/song/"+A,PLAY="https://suno.com/playlist/"+P,CDN="https://d2lwuy8qc234o3.cloudfront.net/1/clip/",COVER="https://cdn2.suno.ai/image_large_"+A+".jpeg";
    static int checks;
    interface Checked {void run() throws Exception;}
    static void yes(boolean value,String name){checks++;if(!value)throw new AssertionError(name);}
    static void no(Checked action,String name) throws Exception {boolean rejected=false;try{action.run();}catch(Exception expected){rejected=true;}yes(rejected,name);}
    static JSONObject copy(JSONObject v) throws Exception{return new JSONObject(v.toString());}
    static JSONObject song(String id) throws Exception {return new JSONObject().put("id",id).put("entity_type","song_schema").put("status","complete").put("title","Montagem Segredo").put("display_name","Fixture artist").put("handle","fixture").put("metadata",new JSONObject().put("duration",42.5)).put("is_public",false).put("audio_url","https://studio-api.prod.suno.com/never-fetch").put("media_urls",new JSONArray().put(new JSONObject().put("url",CDN+id+".m4a").put("delivery","progressive").put("content_type","m4a-opus").put("encoding",JSONObject.NULL))).put("image_large_url",COVER.replace(A,id));}
    static JSONObject query(String id,Object song) throws Exception {return new JSONObject().put("queryKey",new JSONArray().put(new JSONObject().put("scope","clips").put("entity","clips").put("clipId",id))).put("state",new JSONObject().put("data",song));}
    static JSONObject query(String id) throws Exception{return query(id,song(id));}
    static JSONObject playlist(List<String> ids,int count,boolean embedded) throws Exception {
        JSONArray items=new JSONArray();for(String id:ids){JSONObject item=new JSONObject().put("contentType","clip").put("contentId",id);item.put("contentItem",embedded?song(id):JSONObject.NULL);items.put(item);}
        JSONObject feed=new JSONObject().put("feedId","generic_playlist:"+P).put("feedContainerType","playlist").put("feedContainerId",P).put("feedTitle","Funk").put("feedMetadata",new JSONObject().put("songCount",count)).put("items",items);
        return new JSONObject().put("queryKey",new JSONArray().put(new JSONObject().put("entity","feed").put("feedId","generic_playlist:"+P))).put("state",new JSONObject().put("data",new JSONObject().put("pages",new JSONArray().put(new JSONObject().put("feed",feed)))));
    }
    static JSONObject feed(JSONObject query) throws Exception{return query.getJSONObject("state").getJSONObject("data").getJSONArray("pages").getJSONObject(0).getJSONObject("feed");}
    static String flight(JSONArray queries) throws Exception {return "a:"+new JSONArray().put("$").put("$L1").put(JSONObject.NULL).put(new JSONObject().put("prefetched",new JSONObject().put("dehydratedState",new JSONObject().put("queries",queries)))).toString()+"\n";}
    static String page(JSONArray queries,String canonical,String prefix) throws Exception {
        return "<html><head>"+(canonical==null?"":"<link rel=\"canonical\" href=\""+canonical+"\">")+"</head><script>self.__next_f.push("+new JSONArray().put(1).put(prefix+flight(queries)).toString()+")</script></html>";
    }
    static String page(JSONArray queries) throws Exception{return page(queries,null,"");}
    static String padded(String html){StringBuilder out=new StringBuilder(SunoCatalog.MAX_HTML_BYTES);out.append("<!--");int spaces=SunoCatalog.MAX_HTML_BYTES-html.getBytes(StandardCharsets.UTF_8).length-7;for(int i=0;i<spaces;i++)out.append(' ');out.append("-->").append(html);return out.toString();}
    static JSONObject resolve(String url,String html) throws Exception{return SunoCatalog.resolve(url,(u,d)->new SunoCatalog.Page(html));}
    static JSONObject resolvedTrack() throws Exception{return resolve(SONG,page(new JSONArray().put(query(A)))).getJSONArray("tracks").getJSONObject(0);}
    static void linksAndTracks() throws Exception {
        yes(SunoCatalog.canonicalLink(SONG+"/?utm=x#anything").equals(SONG),"canonical tracking and anchor removed");
        yes(SunoCatalog.canonicalLink("HTTPS://SUNO.COM:443/song/"+A).equals(SONG),"standard HTTPS host/port normalized");
        yes(SunoCatalog.canonicalLink("https://suno.com/s/R2YMzAKnPs5bHPjq").endsWith("R2YMzAKnPs5bHPjq"),"short link accepted");
        for(String bad:new String[]{"http://suno.com/song/"+A,"https://user:pass@suno.com/song/"+A,"https://suno.com.evil/song/"+A,"https://suno.com:8443/song/"+A,"https://suno.com/account","https://suno.com/playlist/liked","https://suno.com/song/"+A.toUpperCase(Locale.ROOT),SONG+"\n","file:///tmp/song",SONG.replace("song/","song/%2e%2e/"),"https://suno.com/s/short","https://suno.com\\@evil/song/"+A})no(()->SunoCatalog.canonicalLink(bad),"bad page URL rejected");
        List<String> calls=new ArrayList<>();JSONObject manifest=SunoCatalog.resolve(SONG,(url,deadline)->{calls.add(url);yes(deadline>System.nanoTime(),"bounded future deadline passed");return new SunoCatalog.Page(page(new JSONArray().put(query(A)),SONG,""));});
        yes(calls.equals(Arrays.asList(SONG)),"one public page only, no media/API");yes(manifest.getInt("version")==1&&manifest.getString("id").equals("suno:"+A),"canonical song manifest");yes(manifest.getJSONArray("playlists").length()==0,"song has no invented playlist");JSONObject track=manifest.getJSONArray("tracks").getJSONObject(0);
        yes(track.getString("service").equals("suno")&&track.getString("stream_uri").equals(CDN+A+".m4a"),"explicit Suno stream origin");yes(track.has("stream_encoding")&&track.isNull("stream_encoding"),"plain encoding is explicit null");yes(track.getDouble("duration")==42.5&&track.getString("cover_uri").equals(COVER),"metadata and cover retained");
        yes(SunoCatalog.isSunoTrack(track),"valid marker recognized");yes(SunoCatalog.isSunoTrack(new JSONObject().put("service","suno").put("id","bad")),"invalid marker remains on Suno route");yes(!SunoCatalog.isSunoTrack(new JSONObject().put("id","pcloud:7:file:8")),"pCloud never classified as Suno");
        JSONObject clone=SunoCatalog.validateTrack(track);clone.put("title","Changed");yes(track.getString("title").equals("Montagem Segredo"),"validation returns independent canonical copy");
        for(String bad:new String[]{CDN+B+".m4a",CDN.replace("d2lwuy8qc234o3","another")+A+".m4a",CDN.replace("https:","http:")+A+".m4a",CDN+A+".m4a#fragment",CDN+A+".mp3",CDN.replace(".net/",".net:8443/")+A+".m4a",CDN.replace("https://","https://person:secret@")+A+".m4a"}){yes(!SunoCatalog.validStreamUri(bad,A),"unsafe stream rejected");JSONObject v=copy(track).put("stream_uri",bad);no(()->SunoCatalog.validateTrack(v),"stored unsafe stream rejected");}
        yes(SunoCatalog.validStreamUri(CDN+A+".m4a?Expires=123&Signature=fixture",A),"signed query accepted on exact CDN");
        yes(SunoCatalog.validCoverUri(COVER)&&SunoCatalog.validCoverUri(COVER.replace("cdn2","cdn1")),"two exact cover CDNs");
        for(String bad:new String[]{"",COVER.replace("cdn2.suno.ai","cdn2.suno.ai.evil"),COVER.replace("https:","http:"),COVER.replace("image_large_","../image_"),COVER+"#fragment","https://127.0.0.1/image.jpg"})yes(!SunoCatalog.validCoverUri(bad),"unsafe cover rejected");
        JSONObject badCover=copy(track).put("cover_uri","https://evil.invalid/image.jpg");no(()->SunoCatalog.validateTrack(badCover),"stored unsafe cover rejected");
        JSONObject noEncoding=copy(track);noEncoding.remove("stream_encoding");no(()->SunoCatalog.validateTrack(noEncoding),"missing encoding not guessed");
        for(Object bad:new Object[]{"2.0.0",true,new JSONArray()}){JSONObject v=copy(track).put("stream_encoding",bad);no(()->SunoCatalog.validateTrack(v),"unsupported encoding rejected");}
        JSONObject encoded=copy(track).put("stream_encoding","1.0.0");yes(SunoCatalog.validateTrack(encoded).getString("stream_encoding").equals("1.0.0"),"supported cipher marker preserved");
        for(Object bad:new Object[]{true,-1,86401,"42.5",JSONObject.NULL}){JSONObject v=copy(track).put("duration",bad);no(()->SunoCatalog.validateTrack(v),"bad duration rejected");}
        JSONObject nan=new JSONObject(){@Override public Object opt(String key){return key.equals("duration")?Double.NaN:track.opt(key);}@Override public boolean has(String key){return track.has(key);}};no(()->SunoCatalog.validateTrack(nan),"non-finite duration rejected");
        JSONObject mixed=copy(track).put("pcloud_account_userid",7);no(()->SunoCatalog.validateTrack(mixed),"mixed account origin rejected");
        no(()->SunoCatalog.validateTrack(copy(track).put("source_url","https://suno.com/song/"+B)),"source identity mismatch rejected");
        JSONObject withoutService=copy(track);withoutService.remove("service");yes(SunoCatalog.validateTrack(withoutService).getString("service").equals("suno"),"portable Linux metadata normalized with service marker");
    }
    static void pagesAndFlight() throws Exception {
        yes(resolve(SONG,page(new JSONArray().put(query(B)).put(query(A)))).getJSONArray("tracks").getJSONObject(0).getString("id").equals("suno:"+A),"clip query scoped to supplied ID");
        no(()->resolve(SONG,page(new JSONArray().put(query(B)))),"foreign clip query not used");
        for(JSONObject bad:new JSONObject[]{song(B),song(A).put("status","streaming"),song(A).put("entity_type","profile_schema")})no(()->resolve(SONG,page(new JSONArray().put(query(A,bad)))),"schema identity and completion checked");
        for(Object media:new Object[]{JSONObject.NULL,new JSONArray(),new JSONArray().put(new JSONObject().put("url",CDN+A+".m4a").put("delivery","hls").put("content_type","m4a-opus")),new JSONArray().put(new JSONObject().put("url",CDN+A+".m4a").put("delivery","progressive").put("content_type","mp3"))}){JSONObject v=song(A).put("media_urls",media);no(()->resolve(SONG,page(new JSONArray().put(query(A,v)))),"forbidden audio_url never fallback");}
        JSONObject absentEncoding=song(A);absentEncoding.getJSONArray("media_urls").getJSONObject(0).remove("encoding");no(()->resolve(SONG,page(new JSONArray().put(query(A,absentEncoding)))),"missing media encoding never guessed as plaintext");
        JSONObject camel=song(A);for(String[] names:new String[][]{{"entity_type","entityType"},{"display_name","displayName"},{"media_urls","mediaUrls"},{"image_large_url","imageLargeUrl"}}){camel.put(names[1],camel.remove(names[0]));}JSONObject m=camel.getJSONArray("mediaUrls").getJSONObject(0);m.put("contentType",m.remove("content_type")).put("encoding","1.0.0");yes(resolve(SONG,page(new JSONArray().put(query(A,camel)))).getJSONArray("tracks").getJSONObject(0).getString("stream_encoding").equals("1.0.0"),"camel-case aliases and explicit encoding");
        JSONObject coverBad=song(A).put("image_large_url","https://evil.invalid/image.jpg");yes(resolve(SONG,page(new JSONArray().put(query(A,coverBad)))).getJSONArray("tracks").getJSONObject(0).getString("cover_uri").isEmpty(),"unsafe scraped cover safely omitted");
        String html=page(new JSONArray().put(query(A)));String script=html.substring(html.indexOf("<script>")+8,html.indexOf("</script>"));
        no(()->resolve(SONG,"<script>fetch('https://evil.invalid');"+script+"</script>"),"prefixed JavaScript ignored");
        no(()->resolve(SONG,"<script>"+script+";alert('never')</script>"),"trailing JavaScript invalidates entire block");
        no(()->resolve(SONG,"<script>self.__next_f.push(window.secret)</script>"),"nonliteral value not executed");
        for(String number:new String[]{"NaN","Infinity","undefined"}){String raw=flight(new JSONArray().put(query(A)));String invalidRaw=raw.replace("\"duration\":42.5","\"duration\":"+number);yes(!invalidRaw.equals(raw),"bad numeric fixture substituted");String invalid="<script>self.__next_f.push("+new JSONArray().put(1).put(invalidRaw)+")</script>";no(()->resolve(SONG,invalid),"non-JSON numeric token rejected");}
        JSONObject forged=song(A).put("title","Forged lyric title");String fake="9:"+new JSONObject().put("dehydratedState",new JSONObject().put("queries",new JSONArray().put(query(A,forged))))+"\n";
        String lyrics="Paroles é🎵\n"+fake;String prefix="1:T"+Integer.toHexString(lyrics.getBytes(StandardCharsets.UTF_8).length)+","+lyrics;
        yes(resolve(SONG,page(new JSONArray().put(query(A)),null,prefix)).getJSONArray("tracks").getJSONObject(0).getString("title").equals("Montagem Segredo"),"UTF8 byte length skips fake JSON hidden in lyrics");
        no(()->resolve(SONG,page(new JSONArray(),null,prefix)),"lyric JSON is never a metadata source");
        no(()->resolve(SONG,page(new JSONArray().put(query(A)),null,"1:Tfffffff,text")),"truncated text record rejected");
        String records=flight(new JSONArray().put(query(A)));int split=records.length()/2;String fragmented="<script>self.__next_f.push("+new JSONArray().put(1).put(records.substring(0,split))+");self.__next_f.push("+new JSONArray().put(1).put(records.substring(split))+")</script>";yes(resolve(SONG,fragmented).getJSONArray("tracks").length()==1,"literal Flight chunks concatenated in order");
        yes(resolve("https://suno.com/s/fixture1",page(new JSONArray().put(query(A)),SONG,"")).getString("source_url").equals(SONG),"short link canonical page identity");
        no(()->resolve("https://suno.com/s/fixture1",html),"short link without canonical identity rejected");
        no(()->resolve(SONG,page(new JSONArray().put(query(A)),"https://suno.com/song/"+B,"")),"contradictory canonical page rejected");
        no(()->resolve(SONG,"<link rel=canonical href='"+SONG+"'><link rel=canonical href='https://suno.com/song/"+B+"'>"+html),"multiple conflicting canonical links rejected");
        yes(resolve(SONG,"<!-- <link rel=canonical href='https://evil.invalid'> -->"+html).getJSONArray("tracks").length()==1,"HTML comment is not canonical metadata");
        no(()->resolve(SONG,page(new JSONArray().put(query(A)).put(query(A,song(A).put("title","Contradiction"))))),"conflicting duplicate scoped clip data rejected");
    }
    static void playlistsAndBounds() throws Exception {
        JSONObject q=playlist(Arrays.asList(B,A,B),3,true);JSONObject v=resolve(PLAY,page(new JSONArray().put(q)));JSONArray order=v.getJSONArray("playlists").getJSONObject(0).getJSONArray("track_ids");yes(order.length()==3&&order.getString(0).equals("suno:"+B)&&order.getString(1).equals("suno:"+A)&&order.getString(2).equals("suno:"+B),"playlist repeated occurrences retain exact order");yes(v.getJSONArray("tracks").length()==2,"track catalogue deduplicates exact identities");
        no(()->resolve(PLAY,page(new JSONArray().put(playlist(Arrays.asList(A),2,true)))),"incomplete public playlist rejected");
        no(()->resolve(PLAY,page(new JSONArray().put(q).put(q))),"ambiguous duplicate playlist feeds rejected");
        JSONObject wrong=copy(q);feed(wrong).put("feedContainerId",B);no(()->resolve(PLAY,page(new JSONArray().put(wrong))),"foreign playlist container rejected");
        JSONObject badItem=playlist(Arrays.asList(A),1,true);feed(badItem).getJSONArray("items").getJSONObject(0).put("contentItem",song(B));no(()->resolve(PLAY,page(new JSONArray().put(badItem))),"embedded identity mismatch rejected");
        JSONObject p1=playlist(Arrays.asList(A),2,true),p2=playlist(Arrays.asList(B),2,true);p1.getJSONObject("state").getJSONObject("data").getJSONArray("pages").put(copy(p2.getJSONObject("state").getJSONObject("data").getJSONArray("pages").getJSONObject(0)));yes(resolve(PLAY,page(new JSONArray().put(p1))).getJSONArray("tracks").length()==2,"complete consistent multiple pages accepted");
        JSONObject inconsistent=copy(p1);inconsistent.getJSONObject("state").getJSONObject("data").getJSONArray("pages").getJSONObject(1).getJSONObject("feed").put("feedTitle","Different");no(()->resolve(PLAY,page(new JSONArray().put(inconsistent))),"multiple page title/count consistency checked");
        String decimalRaw=flight(new JSONArray().put(playlist(Arrays.asList(A),1,true))).replace("\"songCount\":1","\"songCount\":1.0");String decimalCount="<script>self.__next_f.push("+new JSONArray().put(1).put(decimalRaw)+")</script>";no(()->resolve(PLAY,decimalCount),"fractional count representation not treated as integer");
        List<String> calls=new ArrayList<>();JSONObject fallback=SunoCatalog.resolve(PLAY,(url,d)->{calls.add(url);if(url.equals(PLAY))return new SunoCatalog.Page(page(new JSONArray().put(playlist(Arrays.asList(A,B,A),3,false))));String id=url.substring(url.lastIndexOf('/')+1);return new SunoCatalog.Page(page(new JSONArray().put(query(id))));});yes(calls.equals(Arrays.asList(PLAY,SONG,"https://suno.com/song/"+B)),"missing metadata fetches only unique explicitly listed public song pages");yes(fallback.getJSONArray("tracks").length()==2,"fallback fills unique catalogue");
        no(()->resolve(PLAY,page(new JSONArray().put(playlist(new ArrayList<>(),5001,false)))),"track count upper bound checked");
        String huge=" ";StringBuilder oversized=new StringBuilder(SunoCatalog.MAX_HTML_BYTES+1);for(int i=0;i<=SunoCatalog.MAX_HTML_BYTES;i++)oversized.append(' ');huge=oversized.toString();final String tooBig=huge;no(()->resolve(SONG,tooBig),"4 MiB HTML bound");
        StringBuilder deep=new StringBuilder();for(int i=0;i<70;i++)deep.append('[');deep.append('0');for(int i=0;i<70;i++)deep.append(']');String deepFlight="a:"+deep+"\n";no(()->resolve(SONG,"<script>self.__next_f.push("+new JSONArray().put(1).put(deepFlight)+")</script>"),"depth64 guard before recursive JSON construction");
        StringBuilder records=new StringBuilder();for(int i=0;i<=SunoCatalog.MAX_RECORDS;i++)records.append("a:X\n");String tooMany="<script>self.__next_f.push("+new JSONArray().put(1).put(records.toString())+")</script>";no(()->resolve(SONG,tooMany),"20,000 Flight records bound");
        StringBuilder nodes=new StringBuilder("a:[");for(int i=0;i<SunoCatalog.MAX_NODES;i++)nodes.append("null,");nodes.append("null]\n");String manyNodes="<script>self.__next_f.push("+new JSONArray().put(1).put(nodes.toString())+")</script>";no(()->resolve(SONG,manyNodes),"200,000 JSON nodes bound");
        List<String> manyIds=new ArrayList<>();for(int i=0;i<100;i++)manyIds.add(String.format(Locale.ROOT,"%08x-1111-4111-8111-111111111111",i));int[] requests={0};no(()->SunoCatalog.resolve(PLAY,(url,d)->{requests[0]++;if(url.equals(PLAY))return new SunoCatalog.Page(page(new JSONArray().put(playlist(manyIds,100,false))));String id=url.substring(url.lastIndexOf('/')+1);return new SunoCatalog.Page(page(new JSONArray().put(query(id))));}),"100 request overall budget");yes(requests[0]==100,"request101 never reaches transport");
        List<String> five=manyIds.subList(0,5);int[] bytesRequests={0};no(()->SunoCatalog.resolve(PLAY,(url,d)->{bytesRequests[0]++;if(url.equals(PLAY))return new SunoCatalog.Page(padded(page(new JSONArray().put(playlist(five,5,false)))));String id=url.substring(url.lastIndexOf('/')+1);return new SunoCatalog.Page(padded(page(new JSONArray().put(query(id)))));}),"16 MiB overall HTML budget across pages");yes(bytesRequests[0]==5,"fifth 4 MiB page is refused before catalogue completion");
    }
    static void redirectsAndTransport() throws Exception {
        String short1="https://suno.com/s/fixture1",short2="https://suno.com/s/fixture2",short3="https://suno.com/s/fixture3",short4="https://suno.com/s/fixture4";List<String> calls=new ArrayList<>();
        JSONObject m=SunoCatalog.resolve(short1,(url,d)->{calls.add(url);if(url.equals(short1))return new SunoCatalog.Page(302,"/s/fixture2",null,null,new byte[0]);if(url.equals(short2))return new SunoCatalog.Page(307,short3,null,null,new byte[0]);if(url.equals(short3))return new SunoCatalog.Page(301,SONG,null,null,new byte[0]);return new SunoCatalog.Page(page(new JSONArray().put(query(A))));});yes(m.getString("source_url").equals(SONG)&&calls.size()==4,"three same-host redirects allowed");
        int[] denied={0};no(()->SunoCatalog.resolve(short1,(url,d)->{denied[0]++;return new SunoCatalog.Page(302,url.equals(short1)?short2:url.equals(short2)?short3:url.equals(short3)?short4:SONG,null,null,new byte[0]);}),"fourth redirect refused");yes(denied[0]==4,"refused fifth destination not fetched");
        for(String target:new String[]{"https://evil.invalid/song/"+A,"http://suno.com/song/"+A,"https://user:pass@suno.com/song/"+A})no(()->SunoCatalog.resolve(short1,(url,d)->new SunoCatalog.Page(302,target,null,null,new byte[0])),"unsafe redirect refused");
        no(()->SunoCatalog.resolve(SONG,(url,d)->new SunoCatalog.Page(302,"https://suno.com/song/"+B,null,null,new byte[0])),"known song redirect cannot change identity");
        byte[] good=page(new JSONArray().put(query(A))).getBytes(StandardCharsets.UTF_8);
        for(SunoCatalog.Page bad:new SunoCatalog.Page[]{new SunoCatalog.Page(200,null,"application/json",null,good),new SunoCatalog.Page(200,null,"text/html","gzip",good),new SunoCatalog.Page(403,null,"text/html",null,good),new SunoCatalog.Page(200,null,"text/html",null,new byte[]{(byte)0xc3,0x28})})no(()->SunoCatalog.resolve(SONG,(u,d)->bad),"transport type/status/UTF8 guarded");
        no(()->SunoCatalog.resolve(SONG,(url,d)->{throw new java.io.IOException("synthetic token=DO_NOT_EXPOSE");}),"transport exceptions sanitized");
        try{SunoCatalog.resolve(SONG,(url,d)->{throw new java.io.IOException("synthetic token=DO_NOT_EXPOSE");});}catch(Exception e){yes(!e.getMessage().contains("DO_NOT_EXPOSE"),"transport detail never exposed");}
    }
    public static void main(String[] args) throws Exception {linksAndTracks();pagesAndFlight();playlistsAndBounds();redirectsAndTransport();System.out.println("PASS : "+checks+" Suno catalogue assertions; strict public-page fixtures only, no network, account, audio or Android API");}
}
