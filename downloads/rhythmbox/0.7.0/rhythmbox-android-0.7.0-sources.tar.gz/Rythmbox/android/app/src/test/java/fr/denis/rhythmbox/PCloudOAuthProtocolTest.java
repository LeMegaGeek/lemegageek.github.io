package fr.denis.rhythmbox;

import org.json.JSONObject;
import java.net.URLEncoder;

/** Host tests exercise untrusted callback data without Android, network or credentials. */
public final class PCloudOAuthProtocolTest {
    private static int assertions;
    private static void check(boolean value) {
        assertions++;
        if (!value) throw new AssertionError("OAuth assertion " + assertions);
    }
    private interface Work { void run() throws Exception; }
    private static void refused(Work work) throws Exception {
        assertions++;
        try { work.run(); throw new AssertionError("OAuth accepted unsafe input " + assertions); }
        catch (IllegalArgumentException expected) {
            if (expected.getMessage().contains("SECRET_TOKEN")) throw new AssertionError("Token leaked in error");
        }
    }
    private static String callback(PCloudOAuthProtocol.Pending pending) throws Exception {
        return PCloudOAuthProtocol.REDIRECT_URI + "#access_token=SECRET_TOKEN&token_type=bearer&uid=17&state=" +
            pending.state + "&locationid=2&hostname=eapi.pcloud.com";
    }

    public static void main(String[] ignored) throws Exception {
        long now = 1000000;
        PCloudOAuthProtocol.Pending pending = PCloudOAuthProtocol.create("PublicApp", "Music@Example.test", 17, 0, now);
        check(pending.state.length() == 43);
        check(!pending.state.equals(PCloudOAuthProtocol.create("PublicApp", "music@example.test", 17, 0, now).state));
        check(pending.expectedEmail.equals("music@example.test"));
        check(pending.validAt(now) && pending.validAt(now + PCloudOAuthProtocol.MAX_AGE_MILLIS));
        check(!pending.validAt(now - 1) && !pending.validAt(now + PCloudOAuthProtocol.MAX_AGE_MILLIS + 1));
        PCloudOAuthProtocol.Pending restored = PCloudOAuthProtocol.pending(pending.json());
        check(restored.state.equals(pending.state) && restored.expectedUserid == 17 && !restored.claimed);
        check(!pending.json().has("token"));
        check(!pending.toString().contains(pending.state));
        String auth = PCloudOAuthProtocol.authorizationUrl(pending);
        check(auth.startsWith("https://my.pcloud.com/oauth2/authorize?client_id=PublicApp&response_type=token&"));
        check(auth.contains("redirect_uri=" + URLEncoder.encode(PCloudOAuthProtocol.REDIRECT_URI, "UTF-8")));
        check(!auth.contains("client_secret") && !auth.contains("manageshares") && !auth.contains("SECRET_TOKEN"));
        String valid = callback(pending);
        PCloudAccount candidate = PCloudOAuthProtocol.callback(valid, restored, now + 1);
        check(candidate.userid == 17 && candidate.region.equals("eu") && candidate.musicFolderId == 0);
        check(candidate.email.equals("music@example.test") && !candidate.toString().contains("SECRET_TOKEN"));
        check(!candidate.hasMusicFolder() && candidate.withMusicFolder(77).hasMusicFolder());
        check(candidate.withMusicFolder(77).token.equals(candidate.token));
        JSONObject identity = new JSONObject().put("result", 0).put("userid", 17).put("email", "MUSIC@example.test");
        check(PCloudOAuthProtocol.verifyIdentity(candidate, identity) == candidate);
        refused(() -> PCloudOAuthProtocol.verifyIdentity(candidate, new JSONObject().put("result", 0).put("userid", 17).put("email", "personal@example.test")));
        refused(() -> PCloudOAuthProtocol.verifyIdentity(candidate, new JSONObject().put("result", 0).put("userid", 18).put("email", "music@example.test")));
        refused(() -> PCloudOAuthProtocol.verifyIdentity(candidate, new JSONObject().put("result", 0).put("userid", true).put("email", "music@example.test")));
        refused(() -> PCloudOAuthProtocol.verifyIdentity(candidate, new JSONObject().put("result", "0").put("userid", 17).put("email", "music@example.test")));
        refused(() -> PCloudOAuthProtocol.verifyIdentity(candidate, new JSONObject().put("result", 0).put("userid", 17.0).put("email", "music@example.test")));
        refused(() -> PCloudOAuthProtocol.callback(valid, pending.claim(), now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid, pending, now - 1));
        refused(() -> PCloudOAuthProtocol.callback(valid, pending, now + PCloudOAuthProtocol.MAX_AGE_MILLIS + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace("https:", "http:"), pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace(PCloudOAuthProtocol.HOST, "other.example.test"), pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace(PCloudOAuthProtocol.HOST, "user@" + PCloudOAuthProtocol.HOST), pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace(PCloudOAuthProtocol.HOST, PCloudOAuthProtocol.HOST + ":443"), pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace("callback.html#", "callback.html/extra#"), pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace("callback.html#", "callback.html?access_token=SECRET_TOKEN#"), pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace("callback.html#", "%63allback.html#"), pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace("#", "?"), pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid + "&state=" + pending.state, pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid + "&%73tate=" + pending.state, pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid + "&unknown=x", pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid + "&", pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace(pending.state, "not-the-state"), pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace("uid=17", "uid=18"), pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace("uid=17", "uid=0"), pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace("uid=17", "uid=017"), pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace("uid=17", "uid=9223372036854775808"), pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace("token_type=bearer", "token_type=Bearer"), pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace("locationid=2", "locationid=1"), pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace("eapi.pcloud.com", "eapi.pcloud.com.evil.test"), pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace("SECRET_TOKEN", "SECRET_TOKEN%0d%0aAuthorization%3Aevil"), pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace("SECRET_TOKEN", "%c3%28"), pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace("SECRET_TOKEN", "SECRET_TOKEN%"), pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(PCloudOAuthProtocol.REDIRECT_URI + "#error=access_denied&state=" + pending.state, pending, now + 1));
        refused(() -> PCloudOAuthProtocol.callback(valid.replace("&hostname=eapi.pcloud.com", ""), pending, now + 1));
        PCloudOAuthProtocol.Pending firstConnect = PCloudOAuthProtocol.create("PublicApp", "music@example.test", 0, 0, now);
        PCloudAccount bootstrap = PCloudOAuthProtocol.callback(callback(firstConnect), firstConnect, now + 1);
        check(bootstrap.userid == 17);
        PCloudAccount us = PCloudOAuthProtocol.callback(valid.replace("locationid=2", "locationid=1").replace("hostname=eapi.pcloud.com", "hostname=api.pcloud.com"), pending, now + 1);
        check(us.region.equals("us"));
        refused(() -> new PCloudAccount("SECRET_TOKEN\n", "music@example.test", "eu", "PublicApp", 17, 0));
        refused(() -> new PCloudAccount("SECRET_TOKEN", "bad email@example.test", "eu", "PublicApp", 17, 0));
        refused(() -> new PCloudAccount("SECRET_TOKEN", "music@example.test", "other", "PublicApp", 17, 0));
        refused(() -> new PCloudAccount("SECRET_TOKEN", "music@example.test", "eu", "", 17, 0));
        refused(() -> new PCloudAccount("SECRET_TOKEN", "music@example.test", "eu", "PublicApp", 0, 0));
        refused(() -> candidate.withMusicFolder(0));
        System.out.println("PASS: " + assertions + " Android pCloud OAuth security assertions (offline)");
    }
}
