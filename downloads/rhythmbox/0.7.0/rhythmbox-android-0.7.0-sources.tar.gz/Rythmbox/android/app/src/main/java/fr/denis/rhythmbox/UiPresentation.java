package fr.denis.rhythmbox;

import org.json.JSONArray;
import org.json.JSONObject;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Display and filtering rules, kept independent from views and private settings. */
public final class UiPresentation {
    private UiPresentation() {}
    public static String normalize(String value) {
        return Normalizer.normalize(value == null ? "" : value, Normalizer.Form.NFD)
            .replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT).trim();
    }
    public static String title(JSONObject track) {
        String title=track.optString("title", "").trim();
        String path=track.optString("media_path", "");
        String filename=path.substring(path.lastIndexOf('/')+1);
        if(title.isEmpty()) title=filename;
        if(title.equals(filename)) title=title.replaceFirst("(?i)\\.(mp3|m4a|m4b|m4v|mp4|mpg|mpeg|flac|ogg|opus|wav|aif|aiff|aac|wma|mov|mkv|avi|webm)$", "");
        return title.isEmpty()?"Titre sans nom":title;
    }
    public static String detail(JSONObject track) {
        String artist=track.optString("artist", "").trim(), album=track.optString("album", "").trim();
        if(!artist.isEmpty() && !album.isEmpty()) return artist+" · "+album;
        if(!artist.isEmpty()) return artist;
        if(!album.isEmpty()) return album;
        return "Artiste et album à compléter";
    }
    public static final class SearchIndex {
        private final List<JSONObject> tracks=new ArrayList<>();
        private final List<String> terms=new ArrayList<>();
        public SearchIndex(JSONArray source,Set<String> hidden) {
            if(source==null)return;
            for(int i=0;i<source.length();i++) {
                JSONObject track=source.optJSONObject(i);
                if(track==null || hidden.contains(track.optString("id")))continue;
                tracks.add(track);terms.add(normalize(track.optString("title")+" "+track.optString("artist")+" "+track.optString("album")+" "+track.optString("media_path")));
            }
        }
        public List<JSONObject> filter(String query) {
            String term=normalize(query);List<JSONObject> result=new ArrayList<>();
            for(int i=0;i<tracks.size();i++)if(terms.get(i).contains(term))result.add(tracks.get(i));
            return result;
        }
    }
    public static List<JSONObject> filter(JSONArray tracks,Set<String> hidden,String query) {
        return new SearchIndex(tracks,hidden).filter(query);
    }
    public static int uniqueCount(JSONArray playlists,Set<String> hidden) {
        Set<String> ids=new HashSet<>();
        for(int i=0;i<playlists.length();i++) {
            JSONObject list=playlists.optJSONObject(i);if(list==null)continue;
            JSONArray tracks=list.optJSONArray("tracks");if(tracks==null)continue;
            for(int j=0;j<tracks.length();j++) {
                JSONObject track=tracks.optJSONObject(j);if(track==null)continue;
                String id=track.optString("id");if(!hidden.contains(id))ids.add(id);
            }
        }
        return ids.size();
    }
    public static String count(int number,String singular,String plural) { return number+" "+(number==1?singular:plural); }
}
