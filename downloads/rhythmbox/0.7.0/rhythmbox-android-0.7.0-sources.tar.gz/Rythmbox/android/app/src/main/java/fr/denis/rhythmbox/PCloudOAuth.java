package fr.denis.rhythmbox;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.verify.domain.DomainVerificationManager;
import android.content.pm.verify.domain.DomainVerificationUserState;
import android.net.Uri;
import android.os.Build;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Explicit account authorization, separate from browser or pCloud-app sessions. */
public final class PCloudOAuth {
    public static final String EXTRA_AUTH_RESULT = "fr.denis.rhythmbox.PCLOUD_AUTH_RESULT";
    private static final Object LOCK = new Object();
    private static final int MAX_IDENTITY_BYTES = 1024 * 1024;

    private PCloudOAuth() { }

    public static String configuredClientId(Context context) {
        int id = context.getResources().getIdentifier("pcloud_client_id", "string", context.getPackageName());
        String value = id == 0 ? "" : context.getString(id).trim();
        return value.matches("[A-Za-z0-9_-]{1,256}") ? value : "";
    }

    /**
     * API31+ exposes verified-host state. Earlier supported versions expose
     * only the OS link resolver: require our exact callback activity, never
     * a chooser, browser, or another app. No hidden Android API is used.
     */
    public static boolean canStart(Context context) {
        try {
            if (Build.VERSION.SDK_INT >= 31 && !Api31.verified(context)) return false;
            Intent link = new Intent(Intent.ACTION_VIEW, Uri.parse(PCloudOAuthProtocol.REDIRECT_URI));
            link.addCategory(Intent.CATEGORY_BROWSABLE);
            ResolveInfo resolved = context.getPackageManager().resolveActivity(link, PackageManager.MATCH_DEFAULT_ONLY);
            return resolved != null && resolved.activityInfo != null &&
                context.getPackageName().equals(resolved.activityInfo.packageName) &&
                PCloudOAuthCallbackActivity.class.getName().equals(resolved.activityInfo.name);
        } catch (Exception ignored) { return false; }
    }

    private static final class Api31 {
        static boolean verified(Context context) throws Exception {
            DomainVerificationManager manager = context.getSystemService(DomainVerificationManager.class);
            DomainVerificationUserState state = manager == null ? null :
                manager.getDomainVerificationUserState(context.getPackageName());
            Integer hostState = state == null ? null : state.getHostToStateMap().get(PCloudOAuthProtocol.HOST);
            return state != null && state.isLinkHandlingAllowed() && hostState != null &&
                hostState == DomainVerificationUserState.DOMAIN_STATE_VERIFIED;
        }
    }

    public static Uri begin(Context context, String clientId, String expectedEmail,
                            long expectedUserid) throws Exception {
        return begin(context, clientId, expectedEmail, expectedUserid, 0);
    }

    /** Persist encrypted state before leaving the app, including across process death. */
    public static Uri begin(Context context, String clientId, String expectedEmail,
                            long expectedUserid, long musicFolderId) throws Exception {
        if (!canStart(context))
            throw new IllegalStateException("Active les liens vérifiés de Rhythmbox dans les réglages Android avant de connecter pCloud.");
        PCloudOAuthProtocol.Pending pending = PCloudOAuthProtocol.create(clientId, expectedEmail,
            expectedUserid, musicFolderId, System.currentTimeMillis());
        synchronized (LOCK) { new PCloudAccountStore(context).savePending(pending.json()); }
        return Uri.parse(PCloudOAuthProtocol.authorizationUrl(pending));
    }

    public static void cancel(Context context) {
        synchronized (LOCK) { new PCloudAccountStore(context).clearPending(); }
    }

    /** Local disconnect never reads or changes another app's account. */
    public static void disconnect(Context context) {
        synchronized (LOCK) {
            PCloudAccountStore store = new PCloudAccountStore(context);
            store.clearPending();
            store.clear();
        }
    }

    /** Must run on a worker: only userinfo is requested before account verification. */
    public static PCloudAccount consume(Context context, String callback) throws Exception {
        return consume(context, callback, PCloudOAuth::userinfo);
    }

    interface IdentityVerifier { JSONObject verify(PCloudAccount candidate) throws Exception; }

    static PCloudAccount consume(Context context, String callback, IdentityVerifier verifier) throws Exception {
        PCloudAccountStore store = new PCloudAccountStore(context);
        PCloudOAuthProtocol.Pending pending;
        PCloudAccount candidate;
        synchronized (LOCK) {
            pending = PCloudOAuthProtocol.pending(store.loadPending());
            candidate = PCloudOAuthProtocol.callback(callback, pending, System.currentTimeMillis());
            store.savePending(pending.claim().json());
        }
        try {
            PCloudAccount verified = PCloudOAuthProtocol.verifyIdentity(candidate, verifier.verify(candidate));
            synchronized (LOCK) {
                PCloudOAuthProtocol.Pending current = PCloudOAuthProtocol.pending(store.loadPending());
                if (!current.claimed || !current.validAt(System.currentTimeMillis()) ||
                        !PCloudOAuthProtocol.sameState(current.state, pending.state))
                    throw PCloudOAuthProtocol.failure();
                store.save(verified);
                store.clearPending();
            }
            return verified;
        } catch (Exception ignored) {
            synchronized (LOCK) {
                try {
                    PCloudOAuthProtocol.Pending current = PCloudOAuthProtocol.pending(store.loadPending());
                    if (PCloudOAuthProtocol.sameState(current.state, pending.state)) store.clearPending();
                } catch (Exception unreadable) { /* Preserve an unrelated/new session. */ }
            }
            throw new IllegalStateException("Connexion pCloud refusée ou interrompue. Vérifie le compte musical et recommence.");
        }
    }

    private static JSONObject userinfo(PCloudAccount candidate) throws Exception {
        String host = "eu".equals(candidate.region) ? "eapi.pcloud.com" : "api.pcloud.com";
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL("https://" + host + "/userinfo").openConnection();
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(30000);
            connection.setUseCaches(false);
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Authorization", "Bearer " + candidate.token);
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setRequestProperty("Accept", "application/json");
            connection.setDoOutput(true);
            connection.setFixedLengthStreamingMode(0);
            connection.getOutputStream().close();
            if (connection.getResponseCode() != 200 || connection.getContentLengthLong() > MAX_IDENTITY_BYTES)
                throw PCloudOAuthProtocol.failure();
            try (InputStream input = connection.getInputStream(); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int count;
                while ((count = input.read(buffer)) != -1) {
                    if (output.size() + count > MAX_IDENTITY_BYTES) throw PCloudOAuthProtocol.failure();
                    output.write(buffer, 0, count);
                }
                return new JSONObject(new String(output.toByteArray(), StandardCharsets.UTF_8));
            }
        } catch (Exception ignored) {
            throw new IllegalStateException("Vérification du compte musical pCloud impossible.");
        } finally { if (connection != null) connection.disconnect(); }
    }
}
