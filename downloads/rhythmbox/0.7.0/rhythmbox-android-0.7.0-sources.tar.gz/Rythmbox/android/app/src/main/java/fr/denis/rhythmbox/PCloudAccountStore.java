package fr.denis.rhythmbox;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.AtomicFile;
import android.util.Base64;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.MessageDigest;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Account credentials and pending OAuth state are separate from exported pairing settings. */
public final class PCloudAccountStore {
    private static final String ALIAS = "rhythmbox.pcloud.account.v1";
    private static final int LIMIT = 65536;
    private static final Object IO_LOCK = new Object();
    /** The provider's remember-me=false choice survives only in this process. */
    private static PCloudAccount temporaryAccount;
    private final Context context;

    public PCloudAccountStore(Context context) { this.context = context.getApplicationContext(); }

    private SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (!store.containsAlias(ALIAS)) {
            KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build());
            generator.generateKey();
        }
        return (SecretKey) store.getKey(ALIAS, null);
    }

    private AtomicFile file(String kind) {
        return new AtomicFile(new File(context.getNoBackupFilesDir(), "pcloud-" + kind + "-v1.enc"));
    }

    private JSONObject read(String kind) throws Exception {
        synchronized (IO_LOCK) {
            AtomicFile file = file(kind);
            if (!file.getBaseFile().exists() && !new File(file.getBaseFile() + ".bak").exists()) return null;
            try (InputStream input = file.openRead(); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[4096];
                int count;
                while ((count = input.read(buffer)) != -1) {
                    if (output.size() + count > LIMIT) throw new IOException();
                    output.write(buffer, 0, count);
                }
                JSONObject envelope = new JSONObject(new String(output.toByteArray(), StandardCharsets.UTF_8));
                byte[] iv = Base64.decode(envelope.getString("iv"), Base64.NO_WRAP);
                if (iv.length != 12) throw new IOException();
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
                cipher.updateAAD((ALIAS + ":" + kind).getBytes(StandardCharsets.US_ASCII));
                return new JSONObject(new String(cipher.doFinal(Base64.decode(envelope.getString("data"), Base64.NO_WRAP)), StandardCharsets.UTF_8));
            } catch (Exception ignored) {
                throw new IOException("Les autorisations pCloud chiffrées sont illisibles. Reconnecte le compte musical.");
            }
        }
    }

    private void write(String kind, JSONObject value) throws Exception {
        synchronized (IO_LOCK) {
            FileOutputStream output = null;
            AtomicFile file = file(kind);
            try {
                byte[] clear = value.toString().getBytes(StandardCharsets.UTF_8);
                if (clear.length > LIMIT / 2) throw new IOException();
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.ENCRYPT_MODE, key());
                cipher.updateAAD((ALIAS + ":" + kind).getBytes(StandardCharsets.US_ASCII));
                JSONObject envelope = new JSONObject()
                    .put("iv", Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP))
                    .put("data", Base64.encodeToString(cipher.doFinal(clear), Base64.NO_WRAP));
                output = file.startWrite();
                output.write(envelope.toString().getBytes(StandardCharsets.UTF_8));
                file.finishWrite(output);
            } catch (Exception ignored) {
                if (output != null) file.failWrite(output);
                throw new IOException("Android n’a pas pu conserver l’autorisation pCloud chiffrée.");
            }
        }
    }

    public synchronized PCloudAccount load() throws Exception {
        synchronized (IO_LOCK) {
        if (temporaryAccount != null) return temporaryAccount;
        JSONObject value = read("account");
        if (value == null) return null;
        try {
            if (value.getInt("schema") != 1) throw new IOException();
            return new PCloudAccount(value.getString("token"), value.getString("email"),
                value.getString("region"), value.getString("client_id"),
                value.getLong("userid"), value.getLong("music_folderid"), value.optString("auth_type", "oauth"));
        } catch (Exception ignored) {
            throw new IOException("Les autorisations pCloud chiffrées sont illisibles. Reconnecte le compte musical.");
        }
        }
    }

    public synchronized void save(PCloudAccount account) throws Exception {
        synchronized (IO_LOCK) {
        write("account", new JSONObject().put("schema", 1).put("token", account.token)
            .put("email", account.email).put("region", account.region).put("client_id", account.clientId)
            .put("auth_type", account.authType)
            .put("userid", account.userid).put("music_folderid", account.musicFolderId));
        temporaryAccount = null;
        }
    }

    /** Apply a folder choice only to the authorization that started its lookup. */
    public synchronized boolean selectMusicFolder(PCloudAccount expected, long folderId) throws Exception {
        if (expected == null) return false;
        PCloudAccount selected = expected.withMusicFolder(folderId);
        synchronized (IO_LOCK) {
            PCloudAccount current = load();
            if (current == null || !PCloudAccount.sameAuthorization(current, expected))
                return false;
            if (temporaryAccount != null) temporaryAccount = selected;
            else save(selected);
            return true;
        }
    }

    /** A direct-login nonce invalidates an older OAuth/direct attempt without storing its password. */
    synchronized PCloudAccount beginDirect(JSONObject pending) throws Exception {
        synchronized (IO_LOCK) { PCloudAccount expected = load(); pending.put("expected_persistent", temporaryAccount == null); savePending(pending); return expected; }
    }

    synchronized boolean saveDirect(JSONObject pending, PCloudAccount expected, PCloudAccount verified) throws Exception {
        return saveDirect(pending, expected, verified, true);
    }

    synchronized boolean saveDirect(JSONObject pending, PCloudAccount expected, PCloudAccount verified, boolean persistent) throws Exception {
        synchronized (IO_LOCK) {
            if (verified == null || !"direct".equals(verified.authType)) return false;
            if (!directActive(pending, expected)) return false;
            // Consume the nonce before saving. A later nonce-delete failure must
            // never make callers revoke a token that was already committed.
            clearPending();
            if (persistent) save(verified);
            else { delete("account"); temporaryAccount = verified; }
            return true;
        }
    }

    synchronized boolean directActive(JSONObject pending, PCloudAccount expected) throws Exception {
        synchronized (IO_LOCK) {
            JSONObject current = loadPending();
            long now = System.currentTimeMillis(), created = pending.getLong("created_ms");
            if (current == null || !"direct".equals(current.optString("auth_type")) ||
                    !PCloudOAuthProtocol.sameState(current.optString("state"), pending.getString("state")) ||
                    current.optBoolean("expected_persistent", true) != (temporaryAccount == null) ||
                    now < created || now - created > PCloudOAuthProtocol.MAX_AGE_MILLIS ||
                    !PCloudAccount.sameAuthorization(expected, load())) return false;
            return true;
        }
    }

    synchronized void cancelDirect(JSONObject pending) {
        synchronized (IO_LOCK) {
            try { JSONObject current = loadPending(); if(current != null &&
                    "direct".equals(current.optString("auth_type")) &&
                    PCloudOAuthProtocol.sameState(current.optString("state"), pending.getString("state"))) clearPending(); }
            catch (Exception ignored) { /* Never remove a newer or unrelated connection attempt. */ }
        }
    }

    private void delete(String kind) {
        synchronized (IO_LOCK) {
            AtomicFile target = file(kind);
            target.delete();
            if (target.getBaseFile().exists() || new File(target.getBaseFile() + ".bak").exists() ||
                    new File(target.getBaseFile() + ".new").exists())
                throw new IllegalStateException("Android n’a pas pu retirer l’autorisation pCloud locale.");
        }
    }

    public synchronized boolean isPersistent(PCloudAccount account) throws Exception {
        synchronized (IO_LOCK) { return account != null && temporaryAccount == null && PCloudAccount.sameAuthorization(account, load()); }
    }

    public synchronized void clear() { synchronized(IO_LOCK) { delete("account"); temporaryAccount = null; } }
    synchronized JSONObject loadPending() throws Exception { return read("pending"); }
    synchronized void savePending(JSONObject value) throws Exception { write("pending", value); }
    synchronized void clearPending() { delete("pending"); }
}
