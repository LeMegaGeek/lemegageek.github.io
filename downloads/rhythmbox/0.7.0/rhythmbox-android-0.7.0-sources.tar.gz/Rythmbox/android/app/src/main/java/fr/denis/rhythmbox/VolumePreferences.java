package fr.denis.rhythmbox;

import android.content.Context;

/** One local playback preference; never part of cloud/pairing credentials. */
public final class VolumePreferences {
    private VolumePreferences(){}
    public static boolean enabled(Context context){return context.getSharedPreferences("playback-local",Context.MODE_PRIVATE).getBoolean("uniform-volume",false);}
    public static void setEnabled(Context context,boolean enabled){context.getSharedPreferences("playback-local",Context.MODE_PRIVATE).edit().putBoolean("uniform-volume",enabled).apply();}
}
