package fr.denis.rhythmbox;

import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/** Login/identity/TFA boundary tests; no account, network or Android runtime. */
public final class PCloudDirectLoginProtocolTest {
    private static int checks;
    interface Check {void run() throws Exception;}
    static void yes(boolean value,String name){checks++;if(!value)throw new AssertionError(name);}
    static void reject(Check action,String name) throws Exception{checks++;try{action.run();}catch(Exception expected){return;}throw new AssertionError("Accepted: "+name);}
    static JSONObject identity(String token) throws Exception{return new JSONObject().put("result",0).put("userid",7).put("email","music@example.test").put("auth",token);}
    static class Fake implements PCloudDirectLoginProtocol.Transport {
        final List<String> methods=new ArrayList<>();
        final List<Map<String,String>> parameters=new ArrayList<>();
        JSONObject first,second;String region="eu";
        Fake() throws Exception{first=identity("direct-token");second=identity("unused");}
        public JSONObject request(String region,String method,Map<String,String> params,char[] secret) throws Exception{
            yes(this.region.equals(region),"explicit region");methods.add(method);parameters.add(params);
            if(methods.size()==1){yes(secret!=null&&new String(secret).equals("test-password"),"password provided only for login");yes(!params.containsKey("password")&&!params.containsKey("auth"),"initial body metadata has no existing account token");return first;}
            yes(secret==null,"identity request has no password");yes(params.size()==1&&params.containsKey("auth"),"identity verification uses direct auth parameter");return second;
        }
    }
    static final class Http extends HttpURLConnection {
        final ByteArrayOutputStream body=new ByteArrayOutputStream();final byte[] response;
        Http(URL url,JSONObject response){super(url);this.response=response.toString().getBytes(StandardCharsets.UTF_8);}
        @Override public void disconnect(){}
        @Override public boolean usingProxy(){return false;}
        @Override public void connect(){}
        @Override public OutputStream getOutputStream(){return body;}
        @Override public InputStream getInputStream(){return new ByteArrayInputStream(response);}
        @Override public int getResponseCode(){return 200;}
        @Override public long getContentLengthLong(){return response.length;}
    }
    public static void main(String[] ignored) throws Exception{
        Fake f=new Fake();char[] pass="test-password".toCharArray();PCloudAccount a=PCloudDirectLoginProtocol.login("Music@example.test",pass,"eu",null,f);
        yes(a.userid==7&&a.authType.equals("direct")&&a.clientId.isEmpty()&&a.musicFolderId==0,"verified direct identity without fabricated OAuth ID");
        yes(Arrays.equals(pass,new char[pass.length]),"password buffer cleared after success");
        yes(f.methods.equals(Arrays.asList("userinfo","userinfo")),"login verifies new token before use");
        yes("1".equals(f.parameters.get(0).get("logout")),"independent session requested");
        yes("2592000".equals(f.parameters.get(0).get("authexpire"))&&"2592000".equals(f.parameters.get(0).get("authinactiveexpire")),"30 day token and inactivity limit requested");
        Fake previous=new Fake();PCloudAccount old=new PCloudAccount("old-oauth","music@example.test","eu","real-client",7,123);
        PCloudAccount renewed=PCloudDirectLoginProtocol.login("music@example.test","test-password".toCharArray(),"eu",old,previous);
        yes(renewed.musicFolderId==123&&renewed.authType.equals("direct"),"same account root survives OAuth-to-direct authorization");
        Fake different=new Fake();PCloudAccount other=new PCloudAccount("old","other@example.test","eu","old-client",8,999);
        yes(PCloudDirectLoginProtocol.login("music@example.test","test-password".toCharArray(),"eu",other,different).musicFolderId==0,"new account never inherits previous root");
        Fake wrong=new Fake();wrong.first.put("email","personal@example.test");char[] bad="test-password".toCharArray();reject(()->PCloudDirectLoginProtocol.login("music@example.test",bad,"eu",null,wrong),"unexpected login email");yes(wrong.methods.equals(Arrays.asList("userinfo","logout")),"wrong account issues only targeted token revocation");yes(Arrays.equals(bad,new char[bad.length]),"password cleared after refusal");
        Fake swapped=new Fake();swapped.second.put("userid",9);reject(()->PCloudDirectLoginProtocol.login("music@example.test","test-password".toCharArray(),"eu",null,swapped),"second response changed identity");
        yes(swapped.methods.equals(Arrays.asList("userinfo","userinfo","logout")),"failed identity revokes newly issued token");
        Fake sameEmailDifferentId=new Fake();sameEmailDifferentId.first.put("userid",9);reject(()->PCloudDirectLoginProtocol.login("music@example.test","test-password".toCharArray(),"eu",old,sameEmailDifferentId),"existing same email cannot silently change UID");
        for(Object value:new Object[]{"0",0.5,true}){Fake malformed=new Fake();malformed.first.put("result",value);reject(()->PCloudDirectLoginProtocol.login("music@example.test","test-password".toCharArray(),"eu",null,malformed),"non-integer provider status");}
        for(String token:new String[]{"",String.join("",java.util.Collections.nCopies(65,"x")),"bad\r\nheader"}){Fake malformed=new Fake();malformed.first.put("auth",token);reject(()->PCloudDirectLoginProtocol.login("music@example.test","test-password".toCharArray(),"eu",null,malformed),"invalid direct token");}
        Fake us=new Fake();us.region="us";yes(PCloudDirectLoginProtocol.login("music@example.test","test-password".toCharArray(),"us",null,us).region.equals("us"),"US region explicit");
        Fake invalidRegion=new Fake();reject(()->PCloudDirectLoginProtocol.login("music@example.test","test-password".toCharArray(),"evil.example",null,invalidRegion),"host injection");yes(invalidRegion.methods.isEmpty(),"invalid region never reaches transport");
        for(int code:new int[]{1022,2000,2306,2321,4000}){Fake denied=new Fake();denied.first=new JSONObject().put("result",code).put("error","PRIVATE RESPONSE test-password");try{PCloudDirectLoginProtocol.login("music@example.test","test-password".toCharArray(),"eu",null,denied);throw new AssertionError("denied");}catch(IllegalStateException expected){yes(!expected.toString().contains("PRIVATE RESPONSE")&&!expected.toString().contains("test-password"),"provider error redacted");}yes(denied.methods.size()==1,"no automatic retries or region fallback");}
        reject(()->PCloudDirectLoginProtocol.login("music@example.test","test-password".toCharArray(),"eu",null,(r,m,p,s)->{throw new IllegalStateException("PRIVATE test-password");}),"transport failure");
        Fake challengeFake=new Fake();challengeFake.first=new JSONObject().put("result",2297).put("token","challenge-private").put("hasdevices",true).put("tfatype",1);
        PCloudDirectLoginProtocol.Challenge challenge=null;
        try{PCloudDirectLoginProtocol.login("music@example.test","test-password".toCharArray(),"eu",old,challengeFake);throw new AssertionError("No TFA challenge");}catch(PCloudDirectLoginProtocol.TwoFactorRequired required){challenge=required.challenge;yes(!required.toString().contains("challenge-private")&&!challenge.toString().contains("challenge-private"),"challenge always redacted");}
        final PCloudDirectLoginProtocol.Challenge pending=challenge;yes(challengeFake.methods.size()==1,"no SMS or notification sent automatically");
        final int[] stage={0};char[] otp="123456".toCharArray();PCloudAccount two=PCloudDirectLoginProtocol.twoFactor(pending,otp,(region,method,params,secret)->{
            if(stage[0]++==0){yes(method.equals("tfa_login")&&"0".equals(params.get("trustdevice")),"TFA never trusts device automatically");yes("challenge-private".equals(params.get("token"))&&new String(secret).equals("123456")&&!params.containsKey("password"),"TFA sends challenge and code, no password");return identity("two-factor-token");}
            yes(method.equals("userinfo")&&secret==null&&"two-factor-token".equals(params.get("auth")),"TFA token independently verified");return identity("unused");
        });yes(two.musicFolderId==123,"TFA same account root retained");yes(Arrays.equals(otp,new char[otp.length]),"OTP cleared");
        PCloudDirectLoginProtocol.sendCode(pending,true,(r,m,p,s)->{yes(m.equals("tfa_sendcodeviasms")&&p.size()==1&&"challenge-private".equals(p.get("token"))&&s==null,"explicit SMS request contains only challenge");return new JSONObject().put("result",0);});
        PCloudDirectLoginProtocol.sendCode(pending,false,(r,m,p,s)->{yes(m.equals("tfa_sendcodeviasysnotification"),"explicit notification request");return new JSONObject().put("result",0);});
        for(int badCode:new int[]{2012,2074,2092}){char[] invalid="000000".toCharArray();try{PCloudDirectLoginProtocol.twoFactor(pending,invalid,(r,m,p,c)->new JSONObject().put("result",badCode));throw new AssertionError("TFA bad code accepted");}catch(PCloudDirectLoginProtocol.TwoFactorRequired retry){yes(retry.retry&&retry.challenge==pending,"incorrect TFA code allows same-session retry");}yes(Arrays.equals(invalid,new char[invalid.length]),"incorrect OTP cleared before retry");}
        final int[] revoked={0};PCloudDirectLoginProtocol.revoke("eu","direct-token",null,(r,m,p,c)->{yes(m.equals("logout")&&p.size()==1&&"direct-token".equals(p.get("auth")),"revocation targets exact newly issued token only");revoked[0]++;return new JSONObject().put("result",0);});
        PCloudDirectLoginProtocol.revoke("eu",old.token,old,(r,m,p,c)->{revoked[0]++;return new JSONObject().put("result",0);});yes(revoked[0]==1,"previous account token is never revoked by failed renewal");
        final Http[] captured={null};PCloudDirectLoginProtocol.HttpTransport transport=new PCloudDirectLoginProtocol.HttpTransport(url->{captured[0]=new Http(url,identity("new-token"));return captured[0];});
        transport.request("eu","userinfo",java.util.Collections.singletonMap("username","music@example.test"),"p&a ss".toCharArray());
        Http request=captured[0];String body=new String(request.body.toByteArray(),StandardCharsets.UTF_8);
        yes(request.getURL().toString().equals("https://eapi.pcloud.com/userinfo")&&request.getRequestMethod().equals("POST"),"HTTPS endpoint with no query credentials");
        yes(body.contains("password=p%26a+ss")&&body.contains("username=music%40example.test"),"password URL-encoded inside POST body");
        yes(request.getRequestProperty("Authorization")==null&&!request.getInstanceFollowRedirects()&&!request.getUseCaches(),"no Bearer for direct login, no redirect or cache");
        reject(()->transport.request("eu","deletefile",java.util.Collections.emptyMap(),null),"login transport cannot delete files");
        System.out.println("PASS : "+checks+" direct pCloud login assertions (identity, token type, expiry, region, TFA, redaction, HTTPS POST)");
    }
}
