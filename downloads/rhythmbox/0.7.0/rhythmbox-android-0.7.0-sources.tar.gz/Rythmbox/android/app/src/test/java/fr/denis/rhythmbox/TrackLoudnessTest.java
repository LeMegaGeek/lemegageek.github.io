package fr.denis.rhythmbox;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;

/** Synthetic PCM and private-cache tests; no Android profile, audio or network. */
public final class TrackLoudnessTest {
    private static int checks;
    private interface Checked {void run() throws Exception;}
    private static void yes(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
    private static void reject(Checked work,String label) throws Exception {checks++;try{work.run();}catch(Exception expected){return;}throw new AssertionError("Accepted: "+label);}
    private interface Signal {double value(long frame,int channel,int rate);}
    private static TrackLoudness.Result signal(File directory,String name,int rate,int channels,double seconds,Signal signal,JSONArray fixtures) throws Exception {
        TrackLoudness meter=new TrackLoudness(rate,channels);File file=new File(directory,name+".f32le");
        ByteBuffer bytes=ByteBuffer.allocate(8192).order(ByteOrder.LITTLE_ENDIAN);
        try(FileOutputStream output=new FileOutputStream(file)){
            for(long f=0;f<(long)(rate*seconds);f++){
                double left=signal.value(f,0,rate),right=channels==1?left:signal.value(f,1,rate);meter.addFrame(left,right);
                bytes.putFloat((float)left);if(channels==2)bytes.putFloat((float)right);
                if(bytes.remaining()<8){output.write(bytes.array(),0,bytes.position());bytes.clear();}
            }
            if(bytes.position()>0)output.write(bytes.array(),0,bytes.position());
        }
        TrackLoudness.Result result=meter.finish();JSONObject row=new JSONObject().put("name",name).put("rate",rate).put("channels",channels).put("file",file.getAbsolutePath())
            .put("measured",result.measured).put("peak",result.peak).put("gain_db",result.gainDb());
        if(result.measured)row.put("lufs",result.integratedLufs);fixtures.put(row);return result;
    }
    private static String key(int n){return String.format(java.util.Locale.ROOT,"%064x",n);}
    public static void main(String[] args) throws Exception {
        File directory=new File(args[0]);directory.mkdirs();JSONArray fixtures=new JSONArray();
        Signal tone=(f,c,r)->.1*Math.sin(2*Math.PI*1000*f/r);
        TrackLoudness.Result stereo=signal(directory,"stereo-1k",48000,2,3,tone,fixtures);
        TrackLoudness.Result mono=signal(directory,"mono-1k",48000,1,3,tone,fixtures);
        yes(stereo.measured&&mono.measured,"mono and stereo decoded PCM are measured");
        yes(Math.abs(stereo.integratedLufs+20)<.2,"1k stereo calibration matches BS1770");
        yes(Math.abs(stereo.integratedLufs-mono.integratedLufs)<1e-9,"mono is explicitly dual-mono for rendered stereo parity");
        yes(Math.abs(stereo.gainDb()-2)<.2,"measured track gain approaches -18 LUFS");
        TrackLoudness.Result quiet=signal(directory,"quiet",44100,2,3,(f,c,r)->.001*Math.sin(2*Math.PI*1000*f/r),fixtures);
        yes(quiet.measured&&quiet.gainDb()==12,"quiet track gain capped at 12 dB");
        TrackLoudness.Result loud=signal(directory,"loud",48000,2,3,(f,c,r)->.8*Math.sin(2*Math.PI*1000*f/r),fixtures);
        yes(loud.gainDb()< -15&&Math.abs(loud.integratedLufs+loud.gainDb()+18)<.001,"loud track receives fixed attenuation to target");
        TrackLoudness.Result gated=signal(directory,"gated",48000,2,6,(f,c,r)->f<3*r?tone.value(f,c,r):0,fixtures);
        yes(Math.abs(gated.integratedLufs-stereo.integratedLufs)<.35,"relative gate excludes trailing silence except its boundary windows");
        TrackLoudness.Result silence=signal(directory,"silence",8000,1,1,(f,c,r)->0,fixtures);
        yes(!silence.measured&&silence.gainDb()==0,"silence is never arbitrarily amplified");
        TrackLoudness.Result shortTrack=signal(directory,"short",48000,2,.1,tone,fixtures);
        yes(!shortTrack.measured&&shortTrack.gainDb()==0,"short incomplete gating window remains neutral");
        TrackLoudness.Result crest=signal(directory,"high-crest",48000,2,3,(f,c,r)->f==48000?.99:.01*Math.sin(2*Math.PI*1000*f/r),fixtures);
        yes(crest.gainDb()<0,"isolated loud transient prevents boosting a quiet average");
        yes(crest.peakDb()+crest.gainDb()<=TrackLoudness.PEAK_CEILING_DB-TrackLoudness.PEAK_MARGIN_DB+.00001,"fixed gain reserves peak headroom");
        TrackLoudness.Result intersample=signal(directory,"intersample",48000,2,2,(f,c,r)->.9*Math.sin(2*Math.PI*12000*f/r+Math.PI/4),fixtures);
        yes(intersample.peak>.75,"oversampling detects a peak above the source sample maximum");
        TrackLoudness.Result boundary=signal(directory,"boundary-intersample",48000,2,3,
            (f,c,r)->f<24?.9*Math.sin(2*Math.PI*12000*f/r+Math.PI/4):.01*Math.sin(2*Math.PI*1000*f/r),fixtures);
        yes(boundary.gainDb()<0,"a short intersample transient also limits a low average track");
        TrackLoudness.Result rate96=signal(directory,"rate96",96000,2,2,tone,fixtures);
        yes(Math.abs(rate96.integratedLufs-stereo.integratedLufs)<.15,"K weighting adapts to 96 kHz");
        reject(()->new TrackLoudness(48000,6),"ambiguous multichannel downmix is not guessed");
        reject(()->new TrackLoudness(1000,2),"unsupported sample rate rejected");
        TrackLoudness bad=new TrackLoudness(48000,2);reject(()->bad.addFrame(Double.NaN,0),"nonfinite PCM rejected");
        reject(()->bad.addFrame(0,99),"invalid PCM amplitude rejected");
        TrackLoudness done=new TrackLoudness(48000,1);done.finish();reject(()->done.addFrame(0,0),"finished meter cannot accidentally accumulate a second song");
        reject(done::finish,"finished meter cannot reuse its result as another measurement");

        TrackLoudnessCache cache=new TrackLoudnessCache(directory);cache.put(key(1),stereo);
        yes(Math.abs(cache.get(key(1)).integratedLufs-stereo.integratedLufs)<1e-10,"private cache roundtrip preserves measured metadata");
        for(int i=2;i<302;i++)cache.put(key(i),stereo);
        File metadata=new File(directory,"track-loudness-v1.json");JSONObject data=new JSONObject(new String(Files.readAllBytes(metadata.toPath()),java.nio.charset.StandardCharsets.UTF_8));
        yes(data.getJSONArray("entries").length()==256&&metadata.length()<262144,"cache count and bytes remain bounded");
        yes(cache.get(key(1))==null&&cache.get(key(301))!=null,"old cache entries expire before recent ones");
        yes(!data.toString().contains("stereo-1k")&&!data.toString().contains("token")&&!data.toString().contains(directory.getAbsolutePath()),"cache has no source path, URI, token or PCM");
        File original=new File(directory,"stereo-1k.f32le");byte[] before=Files.readAllBytes(original.toPath());String first=TrackLoudnessCache.fileKey(original);
        cache.put(first,stereo);yes(java.util.Arrays.equals(before,Files.readAllBytes(original.toPath())),"measuring and caching never rewrite the original audio");
        long time=original.lastModified();byte[] changed=before.clone();changed[0]^=1;Files.write(original.toPath(),changed);original.setLastModified(time);
        yes(!first.equals(TrackLoudnessCache.fileKey(original)),"content change invalidates cache even with equal size and coarse timestamp");Files.write(original.toPath(),before);
        Files.write(metadata.toPath(),"broken".getBytes(java.nio.charset.StandardCharsets.UTF_8));yes(cache.get(key(301))==null,"corrupt optional cache does not supply a fabricated measurement");
        cache.put(key(1),stereo);yes(cache.get(key(1))!=null,"cache can be rebuilt without touching audio");
        reject(()->cache.get("../not-a-key"),"arbitrary paths cannot become cache keys");
        File link=new File(directory,"source-link");Files.createSymbolicLink(link.toPath(),original.toPath());reject(()->TrackLoudnessCache.fileKey(link),"symlink audio identity refused");
        Files.write(new File(directory,"fixtures.json").toPath(),fixtures.toString(2).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        System.out.println("PASS : "+checks+" fixed loudness/gating/dual-mono/peak/cache assertions; synthetic PCM only");
    }
}
