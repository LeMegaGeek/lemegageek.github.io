package fr.denis.rhythmbox;

import org.json.JSONObject;

/** Pure playback routing. A private account marker is authoritative and must
 * never fall back to another account, a document tree or a public share. */
final class MediaOrigin {
    enum Kind {ACCOUNT,FOLDER,LINKS}
    private MediaOrigin(){}
    static String mode(JSONObject config){return config.optString("sync_mode",config.has("read_code")?"links":"folder");}
    static Kind route(JSONObject track,JSONObject config,PCloudAccount connected) throws Exception {
        if(track.has("pcloud_account_userid")){
            long owner=PCloudCollections.integer(track.get("pcloud_account_userid"),false);
            if(connected==null||connected.musicFolderId<=0)throw new IllegalStateException("Reconnecte le compte musical pCloud associé à ce morceau.");
            if(owner!=connected.userid)throw new IllegalStateException("Ce morceau appartient à un autre compte musical pCloud. Aucun autre dossier n’a été utilisé.");
            return Kind.ACCOUNT;
        }
        String mode=mode(config);
        if("links".equals(mode)){
            if(!track.has("pcloud_fileid"))throw new IllegalStateException("Ce morceau n’est pas associé au partage musique.");
            PCloudCollections.integer(track.get("pcloud_fileid"),false);return Kind.LINKS;
        }
        if("account".equals(mode)&&config.optString("media_tree","").isEmpty())throw new IllegalStateException("Ce morceau local n’est pas lié au compte pCloud. Choisis son dossier musique sur ce téléphone.");
        if(!track.has("media_path"))throw new IllegalStateException("Ce morceau n’est pas associé au dossier musique.");
        FolderProtocol.mediaPath(track.getString("media_path"));return Kind.FOLDER;
    }
}
