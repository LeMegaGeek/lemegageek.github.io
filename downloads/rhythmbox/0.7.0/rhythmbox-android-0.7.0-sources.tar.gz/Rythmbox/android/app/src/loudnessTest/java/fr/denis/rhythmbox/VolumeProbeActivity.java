package fr.denis.rhythmbox;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/** Disposable foreground for this UID's synthetic MediaPlayer/Visualizer. */
public final class VolumeProbeActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        TextView label=new TextView(this);
        label.setText("Essais isolés de normalisation\nAudio synthétique uniquement · aucun compte ni réseau");
        label.setTextSize(20);label.setPadding(32,48,32,32);setContentView(label);
    }
}
