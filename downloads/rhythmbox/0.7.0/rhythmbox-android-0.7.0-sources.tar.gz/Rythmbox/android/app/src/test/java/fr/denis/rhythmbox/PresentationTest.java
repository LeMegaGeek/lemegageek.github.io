package fr.denis.rhythmbox;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.util.Collections;
import java.util.HashSet;

/** Offline presentation, waveform and export boundaries, without an Android runtime. */
public final class PresentationTest {
    private static int assertions;
    private static void check(boolean value,String message){assertions++;if(!value)throw new AssertionError(message);}
    private static JSONObject track(String id,String title,String artist,String album)throws Exception{return new JSONObject().put("id",id).put("title",title).put("artist",artist).put("album",album);}
    public static void main(String[] args)throws Exception {
        JSONArray songs=new JSONArray().put(track("one","Déjeuner en paix","Stéphan Eicher","Engelberg")).put(track("two","100%","Chromeo","Fancy Footwork")).put(track("hidden","Un titre caché","Artiste","Album"));
        HashSet<String> hidden=new HashSet<>();hidden.add("hidden");
        check(UiPresentation.filter(songs,hidden,"stephan").size()==1,"search handles missing accents");
        check(UiPresentation.filter(songs,hidden,"DÉJEUNER").size()==1,"search ignores case");
        check(UiPresentation.filter(songs,hidden,"fancy footwork").size()==1,"search covers albums");
        check(UiPresentation.filter(songs,hidden,"100%").size()==1,"literal percent search");
        check(UiPresentation.filter(songs,hidden,"").size()==2,"hidden tracks stay hidden");
        check(UiPresentation.filter(songs,hidden,"caché").isEmpty(),"search cannot reveal hidden track");
        JSONObject filename=track("file","13 On verra demain - Duo.mp3","","").put("media_path","Gilles Bordonneau/Album/13 On verra demain - Duo.mp3");
        check(UiPresentation.title(filename).equals("13 On verra demain - Duo"),"imported filename is readable without changing stored metadata");
        check(filename.getString("title").endsWith(".mp3"),"display never edits metadata");
        check(UiPresentation.title(track("empty","","","")).equals("Titre sans nom"),"empty title fallback");
        check(!UiPresentation.detail(track("empty","","","")).contains(" · "),"no empty separators");
        check(UiPresentation.uniqueCount(new JSONArray().put(new JSONObject().put("tracks",songs)).put(new JSONObject().put("tracks",songs)),hidden)==2,"library count is unique across lists");
        check(UiPresentation.count(1,"titre","titres").equals("1 titre"),"singular count");
        JSONArray queue=new JSONArray().put(songs.getJSONObject(0)).put(songs.getJSONObject(1)).put(songs.getJSONObject(0)).put(songs.getJSONObject(2));
        PlaybackQueue.Selection preserved=PlaybackQueue.excluding(queue,2,hidden);
        check(preserved.tracks.length()==3 && preserved.selected==2 && !preserved.currentRemoved,"removing another title preserves current occurrence and intentional repeats");
        HashSet<String> removeOne=new HashSet<>();removeOne.add("one");
        PlaybackQueue.Selection stopped=PlaybackQueue.excluding(queue,2,removeOne);
        check(stopped.currentRemoved && stopped.selected==-1 && stopped.tracks.length()==2,"hiding the playing title clears current selection and all duplicate occurrences");
        check(!stopped.tracks.toString().contains("Déjeuner"),"hidden audio cannot remain in shuffle or next queue");
        PlaybackQueue.Selection advanced=PlaybackQueue.excluding(queue,1,removeOne);
        check(advanced.selected==0 && !advanced.currentRemoved && advanced.tracks.getJSONObject(0).getString("id").equals("two"),"current index follows removal before it without restarting audio");
        JSONArray demo=DemoAudio.tracks();check(demo.length()==2,"two original demonstration tracks");
        check(DemoAudio.isDemo(demo.getJSONObject(0)),"owned demo identified");
        check(!DemoAudio.isDemo(track("demo-elan","Forged","","")),"wire id alone cannot activate demo source");
        check(!DemoAudio.isDemo(track("other","Forged","","").put("demo_source","built-in")),"arbitrary demo source rejected");
        JSONArray mixed=new JSONArray().put(songs.getJSONObject(0)).put(demo.getJSONObject(0)).put(demo.getJSONObject(1)).put(songs.getJSONObject(2));
        JSONArray portable=Library.portableTracks(mixed,hidden);
        check(portable.length()==1 && portable.getJSONObject(0).getString("id").equals("one"),"demo and hidden entries excluded from outgoing playlists");
        check(!portable.toString().contains("demo_source"),"no demo marker exported");
        for(int variant=0;variant<2;variant++) {
            ByteArrayOutputStream output=new ByteArrayOutputStream();DemoAudio.writeWave(output,variant);byte[] bytes=output.toByteArray();
            check(bytes.length==44+DemoAudio.RATE*DemoAudio.SECONDS*4,"bounded WAV duration and stereo bytes");
            check(new String(bytes,0,4,"US-ASCII").equals("RIFF") && new String(bytes,8,4,"US-ASCII").equals("WAVE"),"real WAV header");
            check(bytes[22]==2 && bytes[23]==0 && bytes[34]==16,"16-bit stereo PCM");
            long energyLeft=0,energyRight=0;boolean different=false;int peak=0;
            for(int i=44;i<bytes.length;i+=4){int l=(short)((bytes[i]&255)|(bytes[i+1]<<8)),r=(short)((bytes[i+2]&255)|(bytes[i+3]<<8));energyLeft+=(long)l*l;energyRight+=(long)r*r;different|=l!=r;peak=Math.max(peak,Math.max(Math.abs(l),Math.abs(r)));}
            check(energyLeft>1000000 && energyRight>1000000 && different,"both real audio channels contain original non-identical signal");
            check(peak<24575,"demo has headroom rather than clipping");
            check(bytes[44]==0 && bytes[45]==0,"start fades from silence");
        }
        System.out.println("PASS : "+assertions+" UI/demo/export assertions");
    }
}
