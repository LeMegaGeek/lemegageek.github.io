package fr.denis.rhythmbox;

import org.json.JSONObject;
import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Arrays;
import java.util.Map;
import java.util.Set;

/** Pure OAuth validation; no browser, account, storage or network is accessed here. */
public final class PCloudOAuthProtocol {
    public static final String HOST = "lemegageek.github.io";
    public static final String PATH = "/rhythmbox/pcloud/oauth/callback.html";
    public static final String REDIRECT_URI = "https://" + HOST + PATH;
    public static final long MAX_AGE_MILLIS = 15 * 60 * 1000;
    private static final Set<String> KEYS = new HashSet<>(Arrays.asList(
        "access_token", "token_type", "uid", "state", "hostname", "locationid", "error", "error_description"));
    private static final Set<String> SUCCESS_KEYS = new HashSet<>(Arrays.asList(
        "access_token", "token_type", "uid", "state", "hostname", "locationid"));

    public static final class Pending {
        public final String clientId, expectedEmail, state;
        public final long expectedUserid, musicFolderId, createdMillis;
        public final boolean claimed;
        private Pending(String clientId, String expectedEmail, String state, long expectedUserid,
                        long musicFolderId, long createdMillis, boolean claimed) {
            if (clientId == null || !clientId.matches("[A-Za-z0-9_-]{1,256}") ||
                    state == null || !state.matches("[A-Za-z0-9_-]{43}") ||
                    expectedUserid < 0 || musicFolderId < 0 || createdMillis < 0)
                throw failure();
            this.clientId = clientId;
            this.expectedEmail = PCloudAccount.normalizedEmail(expectedEmail);
            this.state = state;
            this.expectedUserid = expectedUserid;
            this.musicFolderId = musicFolderId;
            this.createdMillis = createdMillis;
            this.claimed = claimed;
        }
        public JSONObject json() throws Exception {
            return new JSONObject().put("schema", 1).put("client_id", clientId).put("email", expectedEmail)
                .put("state", state).put("userid", expectedUserid).put("music_folderid", musicFolderId)
                .put("created_ms", createdMillis).put("claimed", claimed);
        }
        public Pending claim() { return new Pending(clientId, expectedEmail, state, expectedUserid, musicFolderId, createdMillis, true); }
        public boolean validAt(long now) { return now >= createdMillis && now - createdMillis <= MAX_AGE_MILLIS; }
        @Override public String toString() { return "PCloudOAuthPending{state=<redacted>}"; }
    }

    public static Pending create(String clientId, String expectedEmail, long expectedUserid,
                                 long musicFolderId, long now) {
        byte[] bytes = new byte[32];
        new SecureRandom().nextBytes(bytes);
        return new Pending(clientId, expectedEmail, Base64.getUrlEncoder().withoutPadding().encodeToString(bytes),
                           expectedUserid, musicFolderId, now, false);
    }

    public static Pending pending(JSONObject value) throws Exception {
        try {
            if (value == null || value.getInt("schema") != 1) throw failure();
            return new Pending(value.getString("client_id"), value.getString("email"), value.getString("state"),
                value.getLong("userid"), value.getLong("music_folderid"), value.getLong("created_ms"), value.getBoolean("claimed"));
        } catch (Exception ignored) { throw failure(); }
    }

    public static String authorizationUrl(Pending pending) throws Exception {
        return "https://my.pcloud.com/oauth2/authorize?client_id=" + encode(pending.clientId) +
            "&response_type=token&redirect_uri=" + encode(REDIRECT_URI) + "&state=" + encode(pending.state);
    }

    private static String encode(String value) throws Exception { return URLEncoder.encode(value, "UTF-8"); }
    public static boolean sameState(String first, String second) {
        return first != null && second != null && MessageDigest.isEqual(
            first.getBytes(StandardCharsets.UTF_8), second.getBytes(StandardCharsets.UTF_8));
    }

    /** Account values are unverified until verifyIdentity consumes an actual userinfo response. */
    public static PCloudAccount callback(String callback, Pending pending, long now) throws Exception {
        try {
            if (pending == null || pending.claimed || !pending.validAt(now) || callback == null || callback.length() > 16384)
                throw failure();
            URI uri = new URI(callback);
            if (!"https".equals(uri.getScheme()) || !HOST.equals(uri.getRawAuthority()) ||
                    !PATH.equals(uri.getRawPath()) || uri.getRawQuery() != null || uri.getRawFragment() == null)
                throw failure();
            Map<String, String> values = new HashMap<>();
            String fragment = uri.getRawFragment();
            if (fragment.isEmpty()) throw failure();
            for (String part : fragment.split("&", -1)) {
                int equal = part.indexOf('=');
                if (equal <= 0 || values.size() >= 9) throw failure();
                String key = URLDecoder.decode(part.substring(0, equal), "UTF-8");
                String value = URLDecoder.decode(part.substring(equal + 1), "UTF-8");
                if (!KEYS.contains(key) || values.put(key, value) != null) throw failure();
            }
            if (!sameState(pending.state, values.get("state"))) throw failure();
            if (values.containsKey("error") || values.containsKey("error_description"))
                throw new IllegalArgumentException("L’autorisation pCloud a été refusée.");
            if (!values.keySet().equals(SUCCESS_KEYS) || !"bearer".equals(values.get("token_type"))) throw failure();
            String region;
            if ("eapi.pcloud.com".equals(values.get("hostname")) && "2".equals(values.get("locationid"))) region = "eu";
            else if ("api.pcloud.com".equals(values.get("hostname")) && "1".equals(values.get("locationid"))) region = "us";
            else throw failure();
            String uid = values.get("uid");
            if (uid == null || !uid.matches("[1-9][0-9]{0,18}")) throw failure();
            long userId = Long.parseLong(uid);
            if (userId <= 0 || (pending.expectedUserid != 0 && pending.expectedUserid != userId)) throw failure();
            return new PCloudAccount(values.get("access_token"), pending.expectedEmail, region, pending.clientId,
                                     userId, pending.musicFolderId);
        } catch (Exception ignored) { throw failure(); }
    }

    public static PCloudAccount verifyIdentity(PCloudAccount candidate, JSONObject identity) throws Exception {
        try {
            Object result = identity.opt("result"), uid = identity.opt("userid");
            if (!(result instanceof Integer || result instanceof Long) || ((Number) result).longValue() != 0 ||
                    !(uid instanceof Integer || uid instanceof Long) || ((Number) uid).longValue() != candidate.userid ||
                    !candidate.email.equals(PCloudAccount.normalizedEmail(identity.getString("email"))))
                throw failure();
            return candidate;
        } catch (Exception ignored) { throw failure(); }
    }

    public static IllegalArgumentException failure() {
        return new IllegalArgumentException("Retour pCloud invalide ou compte différent du compte musical attendu.");
    }
}
