package fr.denis.rhythmbox;

import android.content.Context;
import android.os.Build;
import java.security.SecureRandom;
import java.util.Base64;

/** Per-attempt browser capability is memory-only; only its local nonce is encrypted. */
public final class PCloudDeviceLogin {
    public static final class Session {
        final PCloudDirectLogin.Session guard;
        final PCloudDeviceLoginProtocol.Request request;
        private Session(PCloudDirectLogin.Session guard,PCloudDeviceLoginProtocol.Request request){this.guard=guard;this.request=request;}
        public String browserUrl(){return request.browserUrl();}
        @Override public String toString(){return "PCloudDeviceSession{capability=<redacted>}";}
    }
    private PCloudDeviceLogin(){}
    public static Session begin(Context context,String email) throws Exception {
        return begin(context,email,new PCloudDeviceLoginProtocol.HttpTransport());
    }
    static Session begin(Context context,String email,PCloudDirectLoginProtocol.Transport transport) throws Exception {
        PCloudDirectLogin.Session guard=PCloudDirectLogin.begin(context);
        try{
            byte[] bytes=new byte[32];new SecureRandom().nextBytes(bytes);
            String deviceId="rhythmbox-android-"+Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
            String version=context.getPackageManager().getPackageInfo(context.getPackageName(),0).versionName;
            PCloudDeviceLoginProtocol.Request request=PCloudDeviceLoginProtocol.begin(email,PCloudDirectLogin.expectedAccount(guard),deviceId,version,Build.VERSION.RELEASE,System.currentTimeMillis(),transport);
            if(!PCloudDirectLogin.active(context,guard))throw PCloudDeviceLoginProtocol.failure();
            return new Session(guard,request);
        }catch(Exception failure){PCloudDirectLogin.cancel(context,guard);throw failure;}
    }
    public static PCloudDeviceLoginProtocol.Poll poll(Context context,Session session) throws Exception {
        return poll(context,session,new PCloudDeviceLoginProtocol.HttpTransport());
    }
    static PCloudDeviceLoginProtocol.Poll poll(Context context,Session session,PCloudDirectLoginProtocol.Transport transport) throws Exception {
        if(session==null)throw PCloudDeviceLoginProtocol.failure();
        try{
            if(!PCloudDirectLogin.active(context,session.guard))throw PCloudDeviceLoginProtocol.failure();
            PCloudDeviceLoginProtocol.Poll result=PCloudDeviceLoginProtocol.poll(session.request,System.currentTimeMillis(),transport);
            if(!result.pending){
                // Ownership transfer and local commit are one critical section:
                // cancelling after commit must never revoke the saved grant.
                synchronized(session.request){
                    if(!session.request.validAt(System.currentTimeMillis())||!PCloudDeviceLoginProtocol.owns(session.request,result))throw PCloudDeviceLoginProtocol.failure();
                    try{PCloudDirectLogin.commit(context,session.guard,result.account,transport,result.persistent,false);}
                    catch(java.io.IOException storage){throw new PCloudDeviceLoginProtocol.LoginFailure("storage",-1);}
                    catch(Exception stale){throw PCloudDeviceLoginProtocol.failure();}
                    PCloudDeviceLoginProtocol.complete(session.request,result);
                }
            }
            return result;
        }catch(PCloudDeviceLoginProtocol.NetworkFailure retry){
            boolean active;
            try{active=PCloudDirectLogin.active(context,session.guard);}
            catch(Exception storage){cleanup(session,transport);throw new PCloudDeviceLoginProtocol.LoginFailure("storage",-1);}
            if(active&&session.request.validAt(System.currentTimeMillis()))throw retry;
            cleanup(session,transport);throw PCloudDeviceLoginProtocol.failure();
        }catch(PCloudDeviceLoginProtocol.LoginFailure terminal){cleanup(session,transport);throw terminal;}
        catch(Exception terminal){cleanup(session,transport);throw new PCloudDeviceLoginProtocol.LoginFailure("storage",-1);}
    }
    private static void cleanup(Session session,PCloudDirectLoginProtocol.Transport transport){PCloudDeviceLoginProtocol.Cleanup cleanup=PCloudDeviceLoginProtocol.cancel(session.request,transport);if(cleanup!=null)cleanup.run();}
    static void cancel(Context context,Session session,PCloudDirectLoginProtocol.Transport transport){if(session!=null){PCloudDirectLogin.cancel(context,session.guard);cleanup(session,transport);}}
    public static void cancel(Context context,Session session){
        if(session==null)return;
        PCloudDirectLogin.cancel(context,session.guard);
        PCloudDeviceLoginProtocol.Cleanup cleanup=PCloudDeviceLoginProtocol.cancel(session.request,new PCloudDeviceLoginProtocol.HttpTransport());
        if(cleanup!=null){Thread worker=new Thread(cleanup,"Rhythmbox-pCloud-grant-cleanup");worker.setDaemon(true);worker.start();}
    }
}
