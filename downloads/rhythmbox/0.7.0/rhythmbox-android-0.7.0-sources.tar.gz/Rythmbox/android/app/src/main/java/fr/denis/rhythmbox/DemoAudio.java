package fr.denis.rhythmbox;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/** Original, local demonstration tones. Never persisted as a user playlist or uploaded. */
public final class DemoAudio {
    static final int RATE=22050,SECONDS=18;
    private DemoAudio() {}
    public static JSONArray tracks() {
        JSONArray tracks=new JSONArray();
        try {
            tracks.put(new JSONObject().put("id","demo-elan").put("title","Élan").put("artist","Studio Rhythmbox").put("album","Premiers rythmes").put("demo_source","built-in"));
            tracks.put(new JSONObject().put("id","demo-minuit").put("title","Minuit").put("artist","Studio Rhythmbox").put("album","Premiers rythmes").put("demo_source","built-in"));
        } catch(Exception impossible) { throw new IllegalStateException(impossible); }
        return tracks;
    }
    public static boolean isDemo(JSONObject track) {
        if(track==null || !"built-in".equals(track.optString("demo_source")))return false;
        return "demo-elan".equals(track.optString("id")) || "demo-minuit".equals(track.optString("id"));
    }
    public static File materialize(Context context,JSONObject track) throws Exception {
        if(!isDemo(track))throw new IllegalArgumentException("Morceau de découverte inconnu");
        File target=new File(context.getCacheDir(),track.getString("id")+".wav");
        File temporary=new File(context.getCacheDir(),track.getString("id")+".partial");
        if(!target.exists() || target.length()!=44L+RATE*SECONDS*4L) {
            try(FileOutputStream out=new FileOutputStream(temporary)) { writeWave(out,"demo-minuit".equals(track.getString("id"))?1:0);out.getFD().sync(); }
            if(!temporary.renameTo(target)){temporary.delete();throw new IOException("Extrait de découverte indisponible");}
        }
        return target;
    }
    static void writeWave(OutputStream out,int variant) throws IOException {
        if(variant!=0 && variant!=1)throw new IllegalArgumentException("Extrait inconnu");
        int samples=RATE*SECONDS,bytes=samples*4;
        out.write(new byte[]{'R','I','F','F'});little(out,bytes+36,4);out.write(new byte[]{'W','A','V','E','f','m','t',' '});little(out,16,4);little(out,1,2);little(out,2,2);little(out,RATE,4);little(out,RATE*4,4);little(out,4,2);little(out,16,2);out.write(new byte[]{'d','a','t','a'});little(out,bytes,4);
        double[] melody=variant==0?new double[]{261.6256,329.6276,391.9954,523.2511,440,391.9954,329.6276,293.6648}:new double[]{220,261.6256,329.6276,391.9954,329.6276,261.6256,293.6648,246.9417};
        byte[] block=new byte[4096];int used=0;
        for(int n=0;n<samples;n++) {
            double t=n/(double)RATE,beat=t*(variant==0?2.4:1.7),phase=beat-Math.floor(beat),freq=melody[((int)beat)%melody.length];
            double envelope=Math.min(1,t/.12)*Math.min(1,(SECONDS-t)/.8),note=Math.exp(-phase*4.4)*Math.min(1,phase/.025);
            double lead=Math.sin(2*Math.PI*freq*t)*.15*note;
            double pad=(Math.sin(2*Math.PI*melody[0]/2*t)+Math.sin(2*Math.PI*melody[2]/2*t))*.035;
            double pulse=Math.sin(2*Math.PI*(57+24*Math.exp(-phase*18))*t)*Math.exp(-phase*20)*.08;
            short left=(short)(Math.max(-.65,Math.min(.65,(lead+pad+pulse)*envelope))*32767);
            short right=(short)(Math.max(-.65,Math.min(.65,(lead*.78+pad+Math.sin(2*Math.PI*freq*.5*t)*note*.035+pulse)*envelope))*32767);
            block[used++]=(byte)left;block[used++]=(byte)(left>>8);block[used++]=(byte)right;block[used++]=(byte)(right>>8);
            if(used==block.length){out.write(block);used=0;}
        }
        if(used>0)out.write(block,0,used);
    }
    private static void little(OutputStream out,int value,int size) throws IOException {for(int i=0;i<size;i++)out.write(value>>(8*i)&255);}
}
