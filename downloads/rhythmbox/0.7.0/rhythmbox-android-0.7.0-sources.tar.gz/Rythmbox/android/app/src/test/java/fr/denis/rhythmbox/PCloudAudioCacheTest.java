package fr.denis.rhythmbox;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/** Isolated filesystem/playlist adversarial cases. No Android profile, account,
 * API, URL connection, personal media or document provider is accessed. */
public final class PCloudAudioCacheTest {
    interface Work {void run() throws Exception;}
    static int checks;
    static void yes(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
    static void reject(Work work,String label) throws Exception {checks++;try{work.run();}catch(Exception expected){return;}throw new AssertionError("Accepted: "+label);}
    static PCloudAccount account(long uid,long root){return new PCloudAccount("synthetic-credential","music@example.test","eu","fixture-client",uid,root);}
    static JSONObject metadata(long fid,String path,String hash,long size) throws Exception {return new JSONObject().put("fileid",fid).put("music_folderid",10).put("media_path",path).put("name",path.substring(path.lastIndexOf('/')+1)).put("hash",hash).put("size",size);}
    static JSONObject track(long fid,String path) throws Exception {return new JSONObject().put("id","fixture-"+fid).put("title","Track").put("artist","Artist").put("album","Album").put("pcloud_account_userid",7).put("pcloud_music_folderid",10).put("pcloud_fileid",fid).put("media_path",path);}
    static JSONObject copy(JSONObject row) throws Exception{return new JSONObject(row.toString());}
    static JSONObject library(JSONObject... tracks) throws Exception {
        String lid="pcloud:7:collection:20";JSONObject list=new JSONObject().put("id",lid).put("name","Selected music").put("tracks",new JSONArray(Arrays.asList(tracks)));
        JSONObject binding=new JSONObject().put("account_userid",7).put("music_folderid",10).put("collection_id",20).put("playlist_id",lid);
        return new JSONObject().put("playlists",new JSONArray().put(list)).put("hidden",new JSONArray()).put("pcloud_native",new JSONObject().put("account_userid",7).put("music_folderid",10).put("bindings",new JSONArray().put(binding)));
    }
    static File original(PCloudAudioCache cache,JSONObject metadata) throws Exception {File file=new File(cache.directory(),PCloudCollections.cacheName(metadata,account(7,10)));try(RandomAccessFile output=new RandomAccessFile(file,"rw")){output.setLength(metadata.getLong("size"));}return file;}
    public static void main(String[] args) throws Exception {
        File directory=Files.createTempDirectory("rb-pcloud-audio-cache-test-").toFile();PCloudAudioCache cache=new PCloudAudioCache(directory);PCloudAccount account=account(7,10);JSONObject a=track(101,"Artist/Album/A.flac"),b=track(102,"Artist/Album/B.m4a");
        JSONObject ma=metadata(101,a.getString("media_path"),"version-one",19),mb=metadata(102,b.getString("media_path"),"version-two",23);File fa=original(cache,ma),fb=original(cache,mb);cache.remember(account,a,fa,ma);cache.remember(account,b,fb,mb);
        PCloudAudioCache restarted=new PCloudAudioCache(directory);
        yes(restarted.find(account,a).equals(fa)&&restarted.find(account,b).equals(fb),"previous and next originals survive a new cache instance");
        yes(restarted.findVersion(account,a,ma).equals(fa),"same attested version reuses original file");
        yes(restarted.findVersion(account,a,copy(ma).put("hash","changed"))==null,"changed cloud version misses the cache");
        reject(()->restarted.find(account(8,10),a),"another account cannot reuse local audio");reject(()->restarted.find(account(7,11),a),"another chosen music root cannot reuse audio");
        yes(restarted.find(account,copy(a).put("media_path","Other/A.flac"))==null,"same ID under another path is not silently substituted");
        reject(()->restarted.find(account,copy(a).put("pcloud_music_folderid",11)),"private folder marker authoritative");reject(()->restarted.find(account,copy(a).put("local_uri","file:///personal.flac")),"native arbitrary URI rejected");
        reject(()->cache.remember(account,a,fb,ma),"receipt cannot attest a different file");
        java.util.Map<Long,JSONObject> observed=new java.util.LinkedHashMap<>();observed.put(101L,ma);observed.put(102L,mb);cache.observeIndex(account,observed);yes(cache.find(account,a)!=null,"fresh matching index preserves offline hit");observed.put(101L,copy(ma).put("hash","updated"));cache.observeIndex(account,observed);yes(cache.find(account,a)==null,"fresh synchronization invalidates known replaced version without networking at playback");observed.remove(102L);cache.observeIndex(account,observed);yes(cache.find(account,b)==null,"removed or moved-out cloud file cannot reappear from old cache");observed.put(101L,ma);observed.put(102L,mb);cache.observeIndex(account,observed);
        PCloudAccount us=new PCloudAccount("synthetic-credential","music@example.test","us","fixture-client",7,10);yes(cache.find(us,b)==null&&!PCloudCollections.cacheName(mb,us).equals(PCloudCollections.cacheName(mb,account)),"regional accounts cannot reuse receipts or underlying byte filenames");
        for(JSONObject polyglot:Arrays.asList(copy(a).put("service","suno"),copy(a).put("id","suno:synthetic"),copy(a).put("stream_uri","https://example.invalid/synthetic")))reject(()->cache.find(account,polyglot),"contradictory service provenance never enters private cache");
        fa.delete();yes(restarted.find(account,a)==null,"evicted file becomes a clean cache miss");
        File outside=new File(directory.getParentFile(),"rb-cache-unrelated-"+System.nanoTime());Files.write(outside.toPath(),"unrelated".getBytes(StandardCharsets.UTF_8));
        File receipt=new File(directory,"receipt-"+PCloudAudioCache.sha256(PCloudAudioCache.identity(account,a))+".json");PCloudAudioCache.write(receipt,new JSONObject().put("schema",1).put("identity",PCloudAudioCache.identity(account,a)).put("file","../"+outside.getName()).put("size",outside.length()));
        yes(restarted.find(account,a)==null,"tampered receipt cannot escape private directory");
        JSONObject largeA=metadata(201,"Large/A.flac","large-a",300L*1024*1024),largeB=metadata(202,"Large/B.flac","large-b",300L*1024*1024);java.util.Map<Long,JSONObject> largeIndex=new java.util.LinkedHashMap<>();largeIndex.put(201L,largeA);largeIndex.put(202L,largeB);cache.observeIndex(account,largeIndex);File la=original(cache,largeA);cache.remember(account,track(201,"Large/A.flac"),la,largeA);la.setLastModified(1);File lb=original(cache,largeB);cache.remember(account,track(202,"Large/B.flac"),lb,largeB);
        yes(!la.exists()&&lb.exists(),"bounded cache evicts older audio while retaining newly prefetched track");yes(outside.exists(),"cache eviction leaves unrelated personal-path sentinel intact");
        Set<String> selected=Collections.singleton("pcloud:7:collection:20");JSONObject suno=new JSONObject().put("id","suno:synthetic").put("service","suno").put("stream_uri","https://example.invalid/not-requested");JSONObject demo=new JSONObject().put("id","demo").put("demo_source","built-in");JSONObject hidden=copy(b).put("id","hidden");JSONObject lib=library(a,a,suno,demo,hidden);lib.getJSONArray("hidden").put("hidden");
        PCloudOfflineSelection.Selection selection=PCloudOfflineSelection.select(account,lib,selected);yes(selection.tracks.length()==1&&selection.tracks.getJSONObject(0).getLong("pcloud_fileid")==101,"shared list references deduplicated without publishing Suno, demo or hidden items");yes(selection.skipped==3,"excluded sources counted separately");
        reject(()->PCloudOfflineSelection.select(account,lib,Collections.singleton("unbound-private-list")),"unbound lists are not offline download authority");
        reject(()->PCloudOfflineSelection.select(account(8,10),lib,selected),"foreign account cannot authorize selected lists");reject(()->PCloudOfflineSelection.select(account(7,11),lib,selected),"foreign folder cannot authorize selected lists");
        reject(()->PCloudOfflineSelection.select(account,library(copy(a).put("pcloud_account_userid",8)),selected),"same file ID from other account blocked before networking");
        reject(()->PCloudOfflineSelection.select(account,library(copy(a).put("pcloud_music_folderid",11)),selected),"same file ID from other folder blocked");
        reject(()->PCloudOfflineSelection.select(account,library(a,copy(a).put("media_path","Other/A.flac")),selected),"one ID under ambiguous paths blocked");
        reject(()->PCloudOfflineSelection.select(account,library(a,copy(b).put("media_path",a.getString("media_path"))),selected),"same path under different identities blocked");
        reject(()->PCloudOfflineSelection.select(account,library(copy(a).put("media_path","../outside.flac")),selected),"path traversal cannot become a destination");
        yes(PCloudOfflineSelection.alternateName("A.flac",2).equals("A (2).flac")&&PCloudOfflineSelection.alternateName("song.live.m4a",3).equals("song.live (3).m4a"),"collision preserves readable original name and extension");
        JSONObject extra=library(a);extra.getJSONArray("playlists").put(new JSONObject().put("id","private-unbound").put("name","Not selected").put("tracks",new JSONArray().put(copy(b).put("pcloud_account_userid",999))));yes(PCloudOfflineSelection.select(account,extra,selected).tracks.length()==1,"unselected files never inspected or exported");
        JSONObject removed=library(a);removed.getJSONObject("pcloud_native").put("bindings",new JSONArray());reject(()->PCloudOfflineSelection.select(account,removed,selected),"removed binding stops resumption");
        // A warm downloaded original is checked against fresh scoped metadata,
        // and does not even request a CDN URL. No network handler is installed.
        PCloudCollectionsTest.Fake fake=new PCloudCollectionsTest.Fake();fake.files.get(101L).put("hash","known-version");PCloudCollections client=PCloudCollectionsTest.client(fake);JSONObject warm=client.indexMusic().get(101L);File old=new File(directory,PCloudCollections.cacheName(warm,account));try(RandomAccessFile file=new RandomAccessFile(old,"rw")){file.setLength(100);}int links=Collections.frequency(fake.calls,"getfilelink"),inventories=Collections.frequency(fake.calls,"listfolder");
        PCloudCollections.DownloadedMedia result=client.downloadedMedia(track(101,"A.mp3"),directory,null);yes(result.file.equals(old),"freshly verified warm original used directly");yes(Collections.frequency(fake.calls,"getfilelink")==links,"cache hit avoids CDN URL request and download");yes(Collections.frequency(fake.calls,"listfolder")==inventories+1,"download lookup uses one fresh scoped inventory, not two");
        reject(()->client.fileIdForTrack(track(999,"A.mp3")),"pinned file identity cannot silently rebind after replacement");reject(()->client.fileIdForTrack(copy(a).put("pcloud_music_folderid",11)),"fresh download respects private folder marker");
        PCloudAudioCache.Cancellation cancelled=new PCloudAudioCache.Cancellation();java.util.concurrent.atomic.AtomicInteger closed=new java.util.concurrent.atomic.AtomicInteger();java.io.Closeable registration=cancelled.register(closed::incrementAndGet);cancelled.cancel();cancelled.cancel();registration.close();yes(closed.get()==1,"cancellation disconnects an active resource exactly once");reject(cancelled::check,"cancelled generation cannot commit an audio preparation");reject(()->cancelled.register(closed::incrementAndGet),"resource registered after cancellation is immediately closed");yes(closed.get()==2,"late network resource cannot escape cancellation");
        PCloudAudioCache.Cancellation retired=new PCloudAudioCache.Cancellation();java.io.Closeable done=retired.register(closed::incrementAndGet);done.close();retired.cancel();yes(closed.get()==2,"completed resource detached from later cancellation");
        PCloudAudioCache.Cancellation superseded=new PCloudAudioCache.Cancellation(()->false);reject(superseded::check,"superseded queue generation rejected");int beforeCancelled=fake.calls.size();reject(()->client.downloadedMedia(track(101,"A.mp3"),directory,null,cancelled),"cancelled load does not start metadata or CDN work");yes(fake.calls.size()==beforeCancelled,"cancelled request causes no API request");
        final int[] observations={0};client.setIndexObserver(index->{observations[0]++;yes(index.get(101L).getLong("music_folderid")==10,"observer receives scoped folder metadata only");});client.indexMusic();yes(observations[0]==1,"verified index reaches cache invalidation observer");fake.rootOwned=false;reject(client::indexMusic,"unowned index rejected");yes(observations[0]==1,"failed or foreign index never replaces valid cache knowledge");
        JSONObject parallelTrack=track(601,"Parallel.mp3"),parallelMetadata=metadata(601,"Parallel.mp3","parallel",31);cache.observeIndex(account,Collections.singletonMap(601L,parallelMetadata));PCloudAudioCache.Cancellation waitingCancellation=new PCloudAudioCache.Cancellation();java.util.concurrent.CountDownLatch waiting=new java.util.concurrent.CountDownLatch(1),finished=new java.util.concurrent.CountDownLatch(1);java.util.concurrent.atomic.AtomicReference<Throwable> waitingResult=new java.util.concurrent.atomic.AtomicReference<>();
        try(java.io.Closeable held=cache.lockDownload(account,parallelTrack,new PCloudAudioCache.Cancellation())){
            Thread waiter=new Thread(()->{waiting.countDown();try(java.io.Closeable own=cache.lockDownload(account,parallelTrack,waitingCancellation)){waitingResult.set(new AssertionError("Concurrent duplicate entered while held"));}catch(Exception expected){waitingResult.set(expected);}finally{finished.countDown();}});waiter.start();waiting.await();yes(!finished.await(40,java.util.concurrent.TimeUnit.MILLISECONDS),"same-reference download waits instead of duplicating active transfer");
            try(java.io.Closeable other=cache.lockDownload(account,track(602,"Other.mp3"),new PCloudAudioCache.Cancellation())){yes(true,"unrelated track not serialized by global network lock");}
            waitingCancellation.cancel();yes(finished.await(2,java.util.concurrent.TimeUnit.SECONDS)&&waitingResult.get() instanceof PCloudAudioCache.Cancelled,"queued next-track load cancels while original download stays active");
            long started=System.currentTimeMillis();File finishedFile=original(cache,parallelMetadata);cache.remember(account,parallelTrack,finishedFile,parallelMetadata);yes(cache.findVerifiedAfter(account,parallelTrack,started).equals(finishedFile),"waiter can reuse original freshly completed by another request");
        }
        JSONObject racingTrack=track(701,"Race/Original.flac"),racingV1=metadata(701,"Race/Original.flac","v1",29),racingV2=copy(racingV1).put("hash","v2");File racingBytes=original(cache,racingV1),racingReceipt=new File(directory,"receipt-"+PCloudAudioCache.sha256(PCloudAudioCache.identity(account,racingTrack))+".json");
        cache.observeIndex(account,Collections.singletonMap(701L,racingV1));yes(cache.acceptsVersion(account,racingTrack,racingV1),"download or offline restore starts with V1 accepted by current index");cache.observeIndex(account,Collections.singletonMap(701L,racingV2));reject(()->cache.remember(account,racingTrack,racingBytes,racingV1),"V2 learned during preparation blocks stale V1 receipt commit under the index lock");yes(!racingReceipt.exists()&&cache.find(account,racingTrack)==null,"failed stale-version commit publishes no receipt or playback hit");
        cache.observeIndex(account,Collections.singletonMap(701L,racingV1));yes(cache.acceptsVersion(account,racingTrack,racingV1),"second preparation precheck accepts V1 before removal is observed");cache.observeIndex(account,Collections.emptyMap());reject(()->cache.remember(account,racingTrack,racingBytes,racingV1),"removal learned during preparation blocks stale receipt commit");yes(!racingReceipt.exists()&&cache.find(account,racingTrack)==null,"removed reference cannot be returned through a newly remembered original");
        System.out.println("PASS: "+checks+" persistent cache and selected-playlist offline boundaries; synthetic filesystem only");
        // Clean up only this test's own synthetic directory/sentinel.
        for(File file:directory.listFiles())file.delete();directory.delete();outside.delete();
    }
}
