package fr.denis.rhythmbox;

public final class SunoShareTest {
    static int count;
    interface Op{void run()throws Exception;}
    static void yes(boolean ok,String why){count++;if(!ok)throw new AssertionError(why);}
    static void no(Op op,String why)throws Exception{boolean blocked=false;try{op.run();}catch(Exception expected){blocked=true;}yes(blocked,why);}
    public static void main(String[] args)throws Exception{
        String song="https://suno.com/song/11111111-1111-4111-8111-111111111111",list="https://suno.com/playlist/22222222-2222-4222-8222-222222222222";
        yes(SunoShare.extract(song).equals(song),"exact song link");
        yes(SunoShare.extract("Écoute ce morceau : ("+song+")").equals(song),"share title and punctuation are not persisted");
        yes(SunoShare.extract(song+"?si=tracking#details").equals(song),"tracking query and fragment are not forwarded");
        yes(SunoShare.extract(list).equals(list),"playlist link supported");
        yes(SunoShare.extract("https://suno.com/s/ABCdef123").equals("https://suno.com/s/ABCdef123"),"short share link supported");
        yes(SunoShare.extract(song+"\n"+song).equals(song),"same repeated link is unambiguous");
        no(()->SunoShare.extract(song+"\n"+list),"different links require explicit choice");
        for(String input:new String[]{"https://suno.com.evil.invalid/song/11111111-1111-4111-8111-111111111111","https://user:password@suno.com/song/11111111-1111-4111-8111-111111111111","http://suno.com/s/ABCdef123","https://suno.com/s/abc",song+"unrelated","https://suno.com/create","file:///private/song","https://evil.invalid/song",""})no(()->SunoShare.extract(input),"unsupported share rejected");
        no(()->SunoShare.extract(null),"missing text");no(()->SunoShare.extract(new String(new char[8193]).replace('\0','x')),"large external intent bounded");
        System.out.println("PASS: "+count+" Suno share validation assertions; no navigation, network or account");
    }
}
