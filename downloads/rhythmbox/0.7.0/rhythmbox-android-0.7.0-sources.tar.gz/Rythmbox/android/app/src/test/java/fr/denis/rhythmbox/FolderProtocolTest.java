package fr.denis.rhythmbox;

import org.json.JSONObject;
import java.util.Base64;

/** Pure rules: executable without an Android provider or credentials. */
public final class FolderProtocolTest {
    interface Check{void run() throws Exception;}
    private static int assertions;
    private static void reject(Check work,String label)throws Exception{assertions++;try{work.run();}catch(Exception expected){return;}throw new AssertionError("Accepted "+label);}
    private static void check(boolean ok,String label){assertions++;if(!ok)throw new AssertionError(label);}
    public static void main(String[] args)throws Exception{
        for(String name:new String[]{"sound.mp3","Album/01.flac","old.wma","cover-track.aif","mix.alac","lesson.M4V","concert.mp4","clip.mpg","clip.mpeg","film.mov","film.mkv","film.avi","film.webm"})check(FolderProtocol.isSupportedMedia(name,"application/octet-stream"),"music or soundtrack container "+name);
        for(String name:new String[]{"notes.pdf",".DS_Store","._song.mp3.txt","cover.jpg","readme.txt"})check(!FolderProtocol.isSupportedMedia(name,"application/octet-stream"),"nonmusic rejected "+name);
        check(FolderProtocol.isSupportedMedia("unusual-extension","audio/aac"),"audio MIME accepted");
        for(String path:new String[]{"album/01 - Lumière.flac","single.ogg","Été/À bientôt.mp3","Chromeo 100%/11 100%.mp3"})check(FolderProtocol.mediaPath(path).equals(path),"relative literal document path");
        for(String path:new String[]{"","/etc/passwd","../song.mp3","../private 100%.mp3","album/../../secret","album/./track","album//track","album/","C:/secret.mp3","https://outside.test/song","album\\track.mp3","album/%2e%2e/secret","album/%252e%252e/secret","album/a%2fb.mp3","album/a%2Fb.mp3","album/a%5cb.mp3","album/a%00b.mp3","album/a%25b.mp3","album/\u0000track","album/\ntrack","album/\u007ftrack"})reject(()->FolderProtocol.mediaPath(path),"unsafe relative path");
        String key=Base64.getEncoder().encodeToString(new byte[32]);
        JSONObject record=new JSONObject().put("schema",1).put("kind","rhythmbox-pairing").put("key",key).put("library_id","11111111-1111-4111-8111-111111111111").put("display_name","Mon PC").put("unexpected_token","private");
        JSONObject clean=FolderProtocol.pairing(record);check(clean.length()==2 && !clean.has("unexpected_token"),"pairing only key and identity retained");
        check(clean.getString("key").equals(key),"same encryption key");
        for(Object schema:new Object[]{true,1.0,"1",2}){JSONObject bad=new JSONObject(record.toString()).put("schema",schema);reject(()->FolderProtocol.pairing(bad),"pairing schema");}
        for(String badId:new String[]{"1-1-1-1-1","not-an-id","11111111-1111-4111-8111-11111111111Z"}){JSONObject bad=new JSONObject(record.toString()).put("library_id",badId);reject(()->FolderProtocol.pairing(bad),"pairing identity");}
        JSONObject badKey=new JSONObject(record.toString()).put("key",Base64.getEncoder().encodeToString(new byte[16]));reject(()->FolderProtocol.pairing(badKey),"short key");
        JSONObject wrongKind=new JSONObject(record.toString()).put("kind","another-app");reject(()->FolderProtocol.pairing(wrongKind),"wrong kind");
        System.out.println("PASS : "+assertions+" folder/pairing security assertions");
    }
}
