package fr.denis.rhythmbox;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.util.List;

/** Human-facing folder setup by default; legacy scoped links stay available. */
public final class SyncConnection {
    private final Context context;
    private final JSONObject config;
    private final String mode;
    private final java.util.function.BooleanSupplier active;
    public String lastMediaSource="";
    public SyncConnection(Context context,JSONObject config) throws Exception {
        this(context,config,()->true);
    }
    /** Queue generation/cancellation belongs to the caller; a superseded
     * prefetch must stop before any further account request or downloaded block. */
    public SyncConnection(Context context,JSONObject config,java.util.function.BooleanSupplier active) throws Exception {
        this.context=context.getApplicationContext();this.config=new JSONObject(config.toString());this.mode=MediaOrigin.mode(this.config);this.active=active==null?()->false:active;
    }
    private FolderSync folder(){return new FolderSync(context,config);}
    private SyncEngine links() throws Exception{return new SyncEngine(config);}
    private PCloudCollections account(PCloudAccount selected) throws Exception {
        final PCloudAccount saved=selected==null?new PCloudAccountStore(context).load():selected;
        if(saved==null||saved.musicFolderId<=0)throw new IllegalStateException("Connecte le compte musical pCloud et sélectionne son dossier musique.");
        PCloudCollections client=new PCloudCollections(saved,java.util.Collections.emptySet(),java.util.Collections.emptySet());
        client.setIndexObserver(index->audioCache().observeIndex(saved,index));
        client.setRequestGuard(()->{try{return active.getAsBoolean()&&PCloudAccount.sameAuthorization(saved,new PCloudAccountStore(context).load());}catch(Exception error){return false;}});
        client.verifyAccount();return client;
    }
    public void validateConfig() throws Exception {if("account".equals(mode))account(null).indexMusic();else if("links".equals(mode))links().validateConfig();else folder().validateConfig();}
    public List<JSONObject> heads() throws Exception {if("account".equals(mode))throw new IllegalStateException("Utilise la synchronisation des listes du compte musical pCloud.");return "links".equals(mode)?links().heads():folder().heads();}
    public void upload(JSONObject value) throws Exception {if("account".equals(mode))throw new IllegalStateException("Utilise la synchronisation des listes du compte musical pCloud.");if("links".equals(mode))links().upload(value);else folder().upload(value);}
    public JSONArray importMedia() throws Exception {if("account".equals(mode))return account(null).importedMusic();return "links".equals(mode)?links().importMedia():folder().importMedia();}
    public File mediaFile(JSONObject track,File cache) throws Exception {
        return mediaFile(track,cache,new PCloudAudioCache.Cancellation(active),null);
    }
    public File mediaFile(JSONObject track,File cache,PCloudAudioCache.Cancellation cancellation,PCloudCollections.MediaProgress progress) throws Exception {
        cancellation.check();SyncConnection scoped=new SyncConnection(context,config,()->active.getAsBoolean()&&!cancellation.isCancelled());File result=scoped.mediaFileChecked(track,cache,cancellation,progress);lastMediaSource=scoped.lastMediaSource;return result;
    }
    private File mediaFileChecked(JSONObject track,File cache,PCloudAudioCache.Cancellation cancellation,PCloudCollections.MediaProgress progress) throws Exception {
        if(!active.getAsBoolean())throw new java.io.IOException("Préparation audio annulée");
        PCloudAccount connected=track.has("pcloud_account_userid")?new PCloudAccountStore(context).load():null;
        MediaOrigin.Kind origin=MediaOrigin.route(track,config,connected);
        if(origin==MediaOrigin.Kind.ACCOUNT){
            PCloudAudioCache.identity(connected,track);PCloudAudioCache persistent=audioCache();File saved=persistent.find(connected,track);
            if(saved!=null){if(!active.getAsBoolean()||!PCloudAccount.sameAuthorization(connected,new PCloudAccountStore(context).load()))throw new java.io.IOException("Préparation audio annulée");lastMediaSource="Cache musical privé";return saved;}
            try(java.io.Closeable lock=persistent.lockDownload(connected,track,cancellation)){
                cancellation.check();if(!PCloudAccount.sameAuthorization(connected,new PCloudAccountStore(context).load()))throw new java.io.IOException("Le compte musical a changé");saved=persistent.find(connected,track);if(saved!=null){lastMediaSource="Cache musical privé";return saved;}
                PCloudOfflineAudio.Cancellation copyCancellation=new PCloudOfflineAudio.Cancellation(()->active.getAsBoolean()&&!cancellation.isCancelled());
                try{saved=new PCloudOfflineAudio(context).cachedFile(connected,track,persistent,copyCancellation);}catch(Exception optionalCopy){cancellation.check();if(!active.getAsBoolean())throw new java.io.IOException("Préparation audio annulée");}
                if(!active.getAsBoolean()||!PCloudAccount.sameAuthorization(connected,new PCloudAccountStore(context).load()))throw new java.io.IOException("Le compte musical a changé");
                if(saved!=null){lastMediaSource="Dossier musical hors ligne";return saved;}
                return downloadAccount(connected,track,persistent,progress,cancellation,false);
            }
        }
        if(origin==MediaOrigin.Kind.FOLDER)return folder().mediaFile(track.getString("media_path"),cache);
        return links().mediaFile(track.getLong("pcloud_fileid"),cache);
    }
    private PCloudAudioCache audioCache() throws Exception{return new PCloudAudioCache(new File(context.getNoBackupFilesDir(),"pcloud-audio-v1"));}
    private File downloadAccount(PCloudAccount connected,JSONObject track,PCloudAudioCache cache,PCloudCollections.MediaProgress progress,PCloudAudioCache.Cancellation cancellation,boolean refresh) throws Exception {
        long started=System.currentTimeMillis();try(java.io.Closeable lock=cache.lockDownload(connected,track,cancellation)){
            cancellation.check();if(!active.getAsBoolean()||!PCloudAccount.sameAuthorization(connected,new PCloudAccountStore(context).load()))throw new java.io.IOException("Préparation audio annulée");
            File shared=refresh?cache.findVerifiedAfter(connected,track,started):cache.find(connected,track);if(shared!=null){lastMediaSource="Cache musical privé";return shared;}
            PCloudCollections.DownloadedMedia result=account(connected).downloadedMedia(track,cache.directory(),progress,cancellation);
            if(!active.getAsBoolean()||!PCloudAccount.sameAuthorization(connected,new PCloudAccountStore(context).load()))throw new java.io.IOException("Préparation audio annulée");
            cache.remember(connected,track,result.file,result.metadata);lastMediaSource="Compte musical pCloud";return result.file;
        }
    }
    /** Call on a separate low-priority worker after playback starts. Only an
     * account track may be prefetched; Suno, demos and other origins are refused.
     * A fresh remote version is checked, while ordinary playback can immediately
     * reuse its verified local snapshot without a network round trip. */
    public File prefetchMedia(JSONObject track,PCloudCollections.MediaProgress progress) throws Exception {
        return prefetchMedia(track,new PCloudAudioCache.Cancellation(active),progress);
    }
    public File prefetchMedia(JSONObject track,PCloudAudioCache.Cancellation cancellation,PCloudCollections.MediaProgress progress) throws Exception {
        cancellation.check();SyncConnection scoped=new SyncConnection(context,config,()->active.getAsBoolean()&&!cancellation.isCancelled());File result=scoped.prefetchChecked(track,cancellation,progress);lastMediaSource=scoped.lastMediaSource;return result;
    }
    private File prefetchChecked(JSONObject track,PCloudAudioCache.Cancellation cancellation,PCloudCollections.MediaProgress progress) throws Exception {
        if(!active.getAsBoolean())throw new java.io.IOException("Préchargement annulé");PCloudAccount connected=new PCloudAccountStore(context).load();PCloudAudioCache.identity(connected,track);
        return downloadAccount(connected,track,audioCache(),progress,cancellation,true);
    }
}
