#!/usr/bin/env bash
set -euo pipefail
pcm_root="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$pcm_root"
mkdir -p build/pcm-host-tests
javac --release 8 -encoding UTF-8 -d build/pcm-host-tests \
  app/src/main/java/fr/denis/rhythmbox/StereoSpectrum.java \
  app/src/test/java/fr/denis/rhythmbox/StereoSpectrumTest.java
java -cp build/pcm-host-tests fr.denis.rhythmbox.StereoSpectrumTest
