#!/usr/bin/env bash
set -euo pipefail
rbx_volume_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$rbx_volume_dir"
rbx_volume_json="${RBX_JSON_TEST_JAR:-$rbx_volume_dir/.toolchain/json-test.jar}"
rbx_volume_stage="$(mktemp -d "$rbx_volume_dir/build/volume-host-XXXXXX")"
javac --release 8 -Xlint:-options -encoding UTF-8 -classpath "$rbx_volume_json" -d "$rbx_volume_stage/classes" \
  app/src/main/java/fr/denis/rhythmbox/TrackLoudness.java \
  app/src/main/java/fr/denis/rhythmbox/TrackLoudnessCache.java \
  app/src/test/java/fr/denis/rhythmbox/TrackLoudnessTest.java
java -cp "$rbx_volume_stage/classes:$rbx_volume_json" fr.denis.rhythmbox.TrackLoudnessTest "$rbx_volume_stage/fixtures"
python3 - "$rbx_volume_stage/fixtures" <<'PY'
import json,pathlib,subprocess,sys,re
directory=pathlib.Path(sys.argv[1]);fixtures=json.loads((directory/'fixtures.json').read_text());compared=[]
for row in fixtures:
    if not row['measured']:continue
    result=subprocess.run(['ffmpeg','-nostdin','-hide_banner','-f','f32le','-ar',str(row['rate']),'-ac',str(row['channels']),'-i',row['file'],
        '-af','loudnorm=I=-18:TP=-1:dual_mono=true:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
    oracle=json.loads(result.stderr[result.stderr.rfind('{'):]);resampled_lufs=float(oracle['input_i']);peak=float(oracle['input_tp'])
    native=subprocess.run(['ffmpeg','-nostdin','-hide_banner','-f','f32le','-ar',str(row['rate']),'-ac',str(row['channels']),'-i',row['file'],
        '-af','ebur128=dualmono=true:peak=true','-f','null','-'],capture_output=True,text=True,check=True)
    lufs=float(re.findall(r'\bI:\s*([-+]?\d+(?:\.\d+)?)\s+LUFS',native.stderr)[-1])
    import math
    measured_peak=20*math.log10(row['peak'])
    assert abs(row['lufs']-lufs)<.15,(row['name'],row['lufs'],lufs)
    assert abs(measured_peak-peak)<.7,(row['name'],measured_peak,peak)
    assert peak+row['gain_db']<=-1+.03,(row['name'],'independent peak ceiling',peak,row['gain_db'])
    compared.append({'name':row['name'],'android_meter_lufs':row['lufs'],'ffmpeg_native_ebur128_lufs':lufs,
        'ffmpeg_192k_loudnorm_lufs':resampled_lufs,'android_estimated_peak_db':measured_peak,'ffmpeg_peak_db':peak,
        'predicted_ffmpeg_peak_after_fixed_gain_db':peak+row['gain_db']})
(directory/'ffmpeg-comparison.json').write_text(json.dumps(compared,indent=2)+'\n')
print('PASS :',len(compared),'independent FFmpeg integrated-loudness/peak comparisons; no playback or user media')
print('Volume host evidence:',directory)
PY
