#!/usr/bin/env python3
"""Compile/run an isolated no-Internet Suno MediaDataSource codec test.

Uses only installed tools and an explicitly selected emulator. Never starts an
emulator, downloads SDK packages, installs the production app or reads its data.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

from android_build import Tools, run, write_zip_entry

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = 'fr.denis.rhythmbox.sunotest'
RUNNER = 'fr.denis.rhythmbox.SunoPlaybackInstrumentation'


def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--serial', default='emulator-5582')
    parser.add_argument('--adb', type=Path)
    parser.add_argument('--report', type=Path,
                        default=ROOT / 'dist/android-suno-native-codec-validation.json')
    args = parser.parse_args()
    if not re.fullmatch(r'emulator-[0-9]+', args.serial):
        raise ValueError('Only a specifically identified emulator is permitted')
    tools = Tools.local()
    stage = ROOT / 'android/build/suno-playback-test'
    if stage.is_symlink():
        raise ValueError('Symbolic test build folder refused')
    if stage.exists():
        shutil.rmtree(stage)
    stage.mkdir(parents=True)
    for name in ('classes', 'dex', 'generated', 'assets/suno-fixtures'):
        (stage / name).mkdir(parents=True)
    assets = stage / 'assets/suno-fixtures'
    common = ['ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'error', '-y']
    tone = ['-f', 'lavfi', '-i', 'sine=frequency=517:sample_rate=48000',
            '-t', '6', '-ac', '2']
    run([*common, *tone, '-c:a', 'aac', '-b:a', '96k', '-movflags', '+faststart', assets / 'aac.m4a'])
    run([*common, *tone, '-c:a', 'libopus', '-b:a', '96k', '-movflags', '+faststart', assets / 'opus.mp4'])
    run([*common, '-f', 'lavfi', '-i', 'color=c=black:s=128x96:r=5',
         '-t', '2', '-an', '-c:v', 'mpeg4', '-movflags', '+faststart', assets / 'no-audio.mp4'])
    test = ROOT / 'android/app/src/sunoTest'
    manifest = test / 'AndroidManifest.xml'
    main_java = ROOT / 'android/app/src/main/java/fr/denis/rhythmbox'
    sources = [main_java / 'SunoAudio.java', main_java / 'SunoMediaDataSource.java']
    sources += sorted((test / 'java').rglob('*.java'))
    inputs = [*sources, manifest]
    fingerprints = {str(path.relative_to(ROOT)): sha(path) for path in inputs}
    run([tools.aapt2, 'link', '--manifest', manifest, '-I', tools.platform,
         '--java', stage / 'generated', '--min-sdk-version', '26', '--target-sdk-version', '36',
         '-A', stage / 'assets', '-o', stage / 'resources.apk'])
    run(['javac', '--release', '8', '-Xlint:-options', '-encoding', 'UTF-8', '-g',
         '-classpath', tools.platform, '-d', stage / 'classes', *sources])
    run(['jar', '--create', '--file', stage / 'classes.jar', '-C', stage / 'classes', '.'])
    run([tools.directory / 'd8', '--release', '--min-api', '26', '--lib', tools.platform,
         '--output', stage / 'dex', stage / 'classes.jar'])
    unsigned = stage / 'unsigned.apk'
    shutil.copy2(stage / 'resources.apk', unsigned)
    with zipfile.ZipFile(unsigned, 'a') as archive:
        for dex in sorted((stage / 'dex').glob('classes*.dex')):
            write_zip_entry(archive, dex.name, dex.read_bytes())
    run([tools.directory / 'zipalign', '-f', '-p', '4', unsigned, stage / 'aligned.apk'])
    key = stage / 'test-only.p12'
    run(['keytool', '-genkeypair', '-noprompt', '-storetype', 'PKCS12', '-keystore', key,
         '-storepass', 'android', '-keypass', 'android', '-alias', 'isolated-suno-test',
         '-keyalg', 'RSA', '-keysize', '2048', '-validity', '3',
         '-dname', 'CN=Disposable isolated Suno test'])
    apk = stage / 'suno-playback-isolated-test.apk'
    run([tools.directory / 'apksigner', 'sign', '--ks', key, '--ks-key-alias', 'isolated-suno-test',
         '--ks-pass', 'pass:android', '--key-pass', 'pass:android', '--out', apk, stage / 'aligned.apk'])
    run([tools.directory / 'apksigner', 'verify', apk])
    if any(sha(ROOT / name) != digest for name, digest in fingerprints.items()):
        raise ValueError('Suno source changed during compilation')
    result = {'package': PACKAGE, 'apk': str(apk.relative_to(ROOT)), 'apk_sha256': sha(apk),
              'source_sha256': fingerprints,
              'fixture_plaintext_sha256': {p.name: sha(p) for p in assets.iterdir()},
              'network_permission': False, 'test_only_signing': True,
              'production_app_installed_or_accessed': False,
              'device_run': False, 'emulator_started_by_this_script': False}
    if args.run:
        adb = args.adb or Path(shutil.which('adb') or '')
        if not adb.is_file():
            raise ValueError('Installed adb not found')
        command = [adb, '-s', args.serial]
        if run([*command, 'shell', 'getprop', 'ro.kernel.qemu']).strip() != '1':
            raise ValueError('The device is not an emulator')
        api = int(run([*command, 'shell', 'getprop', 'ro.build.version.sdk']).strip())
        if api != 36:
            raise ValueError('This validation requires the pinned API36 emulator')
        subprocess.run([str(v) for v in [*command, 'uninstall', PACKAGE]],
                       capture_output=True, text=True, timeout=30)
        run([*command, 'install', '-t', '--no-streaming', apk])
        apk_path = run([*command, 'shell', 'pm', 'path', PACKAGE]).strip().removeprefix('package:')
        installed_sha = run([*command, 'shell', 'sha256sum', apk_path]).split()[0]
        if installed_sha != sha(apk):
            raise ValueError('Installed test APK differs from verified build')
        completed = subprocess.run([str(v) for v in [*command, 'shell', 'am', 'instrument', '-w', '-r', PACKAGE + '/' + RUNNER]],
                                   capture_output=True, text=True, timeout=150)
        text = completed.stdout + completed.stderr
        log = args.report.with_suffix('.log')
        log.parent.mkdir(parents=True, exist_ok=True)
        log.write_text(text)
        match = re.search(r'^INSTRUMENTATION_RESULT: report=(\{.*\})$', text, re.MULTILINE)
        if not match:
            raise RuntimeError('Test did not return its bounded report: ' + text[-3000:])
        result.update(device_run=True, serial=args.serial, api=api,
                      installed_test_apk_sha256=installed_sha,
                      instrumentation=json.loads(match.group(1)), log=str(log))
        result['ok'] = (completed.returncode == 0 and result['instrumentation'].get('failures') == 0
                        and 'INSTRUMENTATION_CODE: -1' in text)
    else:
        result['ok'] = True
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['ok'] else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        print(str(error), file=sys.stderr)
        raise SystemExit(1)
