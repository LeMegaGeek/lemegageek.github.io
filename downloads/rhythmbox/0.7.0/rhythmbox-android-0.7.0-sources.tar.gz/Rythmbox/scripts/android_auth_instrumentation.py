#!/usr/bin/python3
"""Build/run an isolated UID instrumentation APK; never installs the main app.

No Internet permission, real account, production signing key or app data is used.
Requires the already installed local SDK; does not download dependencies.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

from android_build import Tools, run, write_zip_entry

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = 'fr.denis.rhythmbox.authtest'
RUNNER = 'fr.denis.rhythmbox.PCloudAuthInstrumentation'
AUTH_NAMES = ('PCloudAccount', 'PCloudAccountStore', 'PCloudOAuthProtocol',
              'PCloudOAuth', 'PCloudOAuthCallbackActivity', 'PCloudDirectLoginProtocol', 'PCloudDirectLogin', 'PCloudDeviceLoginProtocol', 'PCloudDeviceLogin')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--serial', default='emulator-5580')
    parser.add_argument('--adb', help='Path to the SDK adb used by the existing emulator session')
    parser.add_argument('--install', action='store_true', help='Install only the isolated test APK')
    parser.add_argument('--run', action='store_true', help='Install and run only the isolated test instrumentation')
    args = parser.parse_args()
    if not re.fullmatch(r'emulator-[0-9]+', args.serial):
        raise ValueError('Only an explicitly identified local emulator is accepted')
    tools = Tools.local()
    stage = ROOT / 'android/build/pcloud-auth-test'
    if stage.is_symlink():
        raise ValueError('Symbolic build directory refused')
    if stage.exists():
        shutil.rmtree(stage)
    stage.mkdir(parents=True)
    for folder in ('classes', 'generated', 'dex'):
        (stage / folder).mkdir()
    test = ROOT / 'android/app/src/androidTest'
    main_java = ROOT / 'android/app/src/main/java/fr/denis/rhythmbox'
    sources = [main_java / (name + '.java') for name in AUTH_NAMES]
    sources += sorted((test / 'java').rglob('*.java'))
    source_hashes = {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sources}
    run([tools.aapt2, 'link', '--manifest', test / 'AndroidManifest.xml', '-I', tools.platform,
         '--java', stage / 'generated', '--min-sdk-version', '26', '--target-sdk-version', '36',
         '-o', stage / 'resources.apk'])
    run(['javac', '--release', '8', '-encoding', 'UTF-8', '-g', '-classpath', tools.platform,
         '-d', stage / 'classes', *sources])
    run(['jar', '--create', '--file', stage / 'classes.jar', '-C', stage / 'classes', '.'])
    run([tools.directory / 'd8', '--release', '--min-api', '26', '--lib', tools.platform,
         '--output', stage / 'dex', stage / 'classes.jar'])
    unsigned = stage / 'unsigned.apk'
    shutil.copy2(stage / 'resources.apk', unsigned)
    with zipfile.ZipFile(unsigned, 'a') as output:
        for dex in sorted((stage / 'dex').glob('classes*.dex')):
            write_zip_entry(output, dex.name, dex.read_bytes())
    run([tools.directory / 'zipalign', '-f', '-p', '4', unsigned, stage / 'aligned.apk'])
    # Disposable, public-password test certificate. Never used by the app or assetlinks.
    key = stage / 'test-only.p12'
    run(['keytool', '-genkeypair', '-noprompt', '-storetype', 'PKCS12', '-keystore', key,
         '-storepass', 'android', '-keypass', 'android', '-alias', 'isolated-auth-test',
         '-keyalg', 'RSA', '-keysize', '2048', '-validity', '3',
         '-dname', 'CN=Disposable isolated auth test'])
    apk = stage / 'pcloud-auth-isolated-test.apk'
    run([tools.directory / 'apksigner', 'sign', '--ks', key, '--ks-key-alias', 'isolated-auth-test',
         '--ks-pass', 'pass:android', '--key-pass', 'pass:android', '--out', apk, stage / 'aligned.apk'])
    run([tools.directory / 'apksigner', 'verify', apk])
    result = {'package': PACKAGE, 'apk': str(apk), 'source_sha256': source_hashes,
              'network_permission': False, 'production_app_install_performed': False,
              'production_app_data_accessed': False, 'device_run': False}
    if args.install or args.run:
        adb = args.adb or shutil.which('adb')
        if not adb:
            raise ValueError('Local adb is missing')
        command = [adb, '-s', args.serial]
        if run([*command, 'shell', 'getprop', 'ro.kernel.qemu']).strip() != '1':
            raise ValueError('The selected device is not an emulator')
        # Uninstall only our disposable package, allowing a fresh test-only key per build.
        subprocess.run([*command, 'uninstall', PACKAGE], capture_output=True, text=True, timeout=30)
        run([*command, 'install', '-t', '--no-streaming', apk])
        result['test_apk_installed'] = True
        if args.run:
            completed = subprocess.run([*command, 'shell', 'am', 'instrument', '-w', '-r', PACKAGE + '/' + RUNNER],
                                       capture_output=True, text=True, timeout=180)
            text = completed.stdout + completed.stderr
            (stage / 'instrumentation.txt').write_text(text)
            match = re.search(r'^INSTRUMENTATION_RESULT: report=(\{.*\})$', text, re.MULTILINE)
            if not match:
                raise RuntimeError('Instrumentation did not return its bounded, credential-free report: ' + text[-3000:])
            report = json.loads(match.group(1))
            result.update(device_run=True, serial=args.serial, report=report)
            (stage / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
            if completed.returncode or report.get('failures') != 0 or 'INSTRUMENTATION_CODE: -1' not in text:
                print(json.dumps(result, indent=2))
                return 1
    (stage / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
