#!/usr/bin/env python3
"""Exercise the browser-device account login screen in an isolated Android emulator.

Never targets a physical device, signs in, or reads another application's data.
The separate authentication instrumentation covers encrypted storage and races.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = 'fr.denis.rhythmbox'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--serial', default='emulator-5580')
    parser.add_argument('--adb', type=Path, default=Path.home() / 'Android/Sdk/platform-tools/adb')
    parser.add_argument('--apk', type=Path, default=ROOT / 'android/build/release/rhythmbox-android-release.apk')
    parser.add_argument('--check-app-links', action='store_true', help='Require verified release signer; debug certificates are intentionally unpublished.')
    parser.add_argument('--artifact-prefix', default='android-device', help='Distinct evidence prefix for debug/release candidates.')
    args = parser.parse_args()
    if not re.fullmatch(r'[a-z0-9-]+', args.artifact_prefix):
        parser.error('Préfixe de preuve invalide.')
    if not re.fullmatch(r'emulator-\d+', args.serial):
        parser.error('Un émulateur de test explicite est requis ; aucun téléphone physique.')
    output = ROOT / 'dist/pcloud-native-qa'
    output.mkdir(exist_ok=True)

    def adb(*command, binary=False):
        completed = subprocess.run([str(args.adb), '-s', args.serial, *command], check=True,
                                   capture_output=True, timeout=35)
        return completed.stdout if binary else completed.stdout.decode('utf-8')

    def tap(node):
        x1, y1, x2, y2 = map(int, re.findall(r'\d+', node.get('bounds')))
        adb('shell', 'input', 'tap', str((x1 + x2)//2), str((y1 + y2)//2))

    def nodes():
        adb('shell', 'uiautomator', 'dump', '/sdcard/rhythmbox-pcloud-qa.xml')
        return list(ET.fromstring(adb('shell', 'cat', '/sdcard/rhythmbox-pcloud-qa.xml')).iter('node'))

    assert adb('shell', 'getprop', 'ro.kernel.qemu').strip() == '1', 'Émulateur réel requis.'
    expected_apk_sha = hashlib.sha256(args.apk.read_bytes()).hexdigest()
    assert 'Success' in adb('install', '-r', '--no-streaming', str(args.apk.resolve()))
    installed = adb('shell', 'pm', 'path', PACKAGE).strip().splitlines()
    assert len(installed) == 1 and installed[0].startswith('package:/data/app/'), installed
    installed_apk_sha = hashlib.sha256(adb('exec-out', 'cat', installed[0][8:], binary=True)).hexdigest()
    assert installed_apk_sha == expected_apk_sha, 'Le paquet installé doit être exactement celui testé.'
    adb('shell', 'am', 'force-stop', PACKAGE)
    launch = adb('shell', 'am', 'start', '-W', '-n', PACKAGE + '/.MainActivity')
    assert 'Status: ok' in launch, launch
    settings = next(n for n in nodes() if n.get('content-desc') == 'Ouvrir les réglages')
    x1, y1, x2, y2 = map(int, re.findall(r'\d+', settings.get('bounds')))
    adb('shell', 'input', 'tap', str((x1 + x2)//2), str((y1 + y2)//2))
    settings_nodes = nodes()
    texts = [n.get('text', '') for n in settings_nodes]
    assert 'Compte musical pCloud' in texts
    assert 'Aucun compte musical connecté' in texts
    connect = next(n for n in settings_nodes if n.get('text') == 'Connecter mon compte musical…')
    assert connect.get('enabled') == 'true', 'La connexion directe doit fonctionner sans identifiant OAuth.'
    assert not any(n.get('text') == 'Autre autorisation pCloud…' for n in settings_nodes), 'OAuth sans ID reste hors du parcours principal.'
    (output / (args.artifact_prefix + '-settings.png')).write_bytes(adb('exec-out', 'screencap', '-p', binary=True))
    tap(connect)
    form = nodes()
    fields = [n for n in form if n.get('class') == 'android.widget.EditText']
    assert len(fields) == 1 and fields[0].get('password') == 'false', 'Le parcours principal ne demande aucun mot de passe dans Rhythmbox.'
    assert any('page officielle pCloud' in n.get('text', '') for n in form), 'Destination et retour manuel expliqués.'
    assert any(n.get('text', '').casefold() == 'ouvrir pcloud' for n in form), 'Handoff explicite vers pCloud requis.'
    tap(fields[0])
    adb('shell', 'input', 'text', 'qa%stest@example.invalid')  # Local form only; never submitted.
    typed = nodes()
    tap(next(n for n in typed if n.get('text', '').casefold() == 'annuler'))
    tap(next(n for n in nodes() if n.get('text') == 'Connecter mon compte musical…'))
    fresh_form = nodes()
    fresh_fields = [n for n in fresh_form if n.get('class') == 'android.widget.EditText']
    assert len(fresh_fields) == 1 and fresh_fields[0].get('text') == '', 'Annuler ne mémorise pas une nouvelle adresse.'
    tap(next(n for n in fresh_form if n.get('text', '').casefold() == 'annuler'))

    # A forged external intent can only refresh the UI. It cannot establish identity.
    adb('shell', 'am', 'start', '-W', '-f', '0x20000000', '-n', PACKAGE + '/.MainActivity',
        '--ez', PACKAGE + '.PCLOUD_AUTH_RESULT', 'true')
    after_forged_hint = nodes()
    assert any(n.get('text') == 'Aucun compte musical connecté' for n in after_forged_hint)
    assert not any('@' in n.get('text', '') for n in after_forged_hint)
    app_links = adb('shell', 'pm', 'get-app-links', '--user', '0', PACKAGE)
    if args.check_app_links:
        assert 'lemegageek.github.io: verified' in app_links
    # MATCH_DEFAULT_ONLY matches the exact PackageManager check used by OAuth.
    resolver = adb('shell', 'cmd', 'package', 'resolve-activity', '--brief',
                   '--query-flags', '65536', '-a', 'android.intent.action.VIEW',
                   '-c', 'android.intent.category.BROWSABLE', '-d',
                   'https://lemegageek.github.io/rhythmbox/pcloud/oauth/callback.html')
    if args.check_app_links:
        assert PACKAGE + '/.PCloudOAuthCallbackActivity' in resolver
    (output / (args.artifact_prefix + '-app-links.txt')).write_text(app_links + '\n' + resolver)
    report = {
        'schema': 1, 'serial': args.serial, 'api': adb('shell', 'getprop', 'ro.build.version.sdk').strip(),
        'apk_sha256': expected_apk_sha, 'installed_apk_sha256': installed_apk_sha,
        'checks': {'emulator_verified': True, 'exact_candidate_installed': True,
                   'cold_or_warm_launch': True, 'browser_account_screen': True, 'browser_connect_enabled_without_oauth_id': True,
                   'unconfigured_oauth_outside_primary_flow': True, 'no_password_in_app': True,
                   'official_browser_handoff_explained': True, 'cancel_does_not_persist_email': True,
                   'forged_auth_hint_cannot_sign_in': True},
        'screenshots': [args.artifact_prefix + '-settings.png'],
        'oauth_links_required': args.check_app_links,
        'oauth_links_observed': {'domain_verified': 'lemegageek.github.io: verified' in app_links,
                                 'exact_resolver': PACKAGE + '/.PCloudOAuthCallbackActivity' in resolver},
        'real_account_authorized': False, 'real_cloud_sync_tested': False,
        'physical_device_tested': False,
    }
    if args.check_app_links:
        report['checks'].update(release_domain_verified=True, callback_resolves_to_exact_activity=True)
    (output / (args.artifact_prefix + '-ui-validation.json')).write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
