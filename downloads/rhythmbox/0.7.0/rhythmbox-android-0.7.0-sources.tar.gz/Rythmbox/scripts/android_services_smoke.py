#!/usr/bin/env python3
"""Exercise the candidate's public UI on an explicitly selected emulator.

No production phone, account authorization, notification grant, private app
storage or paid Suno action is used. --live-suno explicitly permits resolving
the user-provided public link and playing its normally authorized audio, muted
by the test emulator. Evidence uses public UI and MediaSession state only.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = 'fr.denis.rhythmbox'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--serial', default='emulator-5582')
    parser.add_argument('--adb', type=Path, default=Path.home() / 'Android/Sdk/platform-tools/adb')
    parser.add_argument('--live-suno', action='store_true')
    args = parser.parse_args()
    if not re.fullmatch(r'emulator-[0-9]+', args.serial):
        parser.error('An explicit emulator is required; physical devices are refused.')
    output = ROOT / 'dist/android-services-code9'
    output.mkdir(exist_ok=True)

    def adb(*command, binary=False):
        value = subprocess.run([str(args.adb), '-s', args.serial, *command],
                               capture_output=True, check=True, timeout=30).stdout
        return value if binary else value.decode('utf-8')

    def nodes():
        status = adb('shell', 'uiautomator', 'dump', '/sdcard/rhythmbox-services-qa.xml')
        if 'dumped to:' not in status.casefold():
            raise RuntimeError('No fresh UI snapshot; a previous dump must not be reused')
        return list(ET.fromstring(adb('shell', 'cat', '/sdcard/rhythmbox-services-qa.xml')).iter('node'))

    def matching(label, source=None):
        return [n for n in (nodes() if source is None else source)
                if n.get('text', '').casefold() == label.casefold()
                or n.get('content-desc', '').casefold() == label.casefold()]

    def click_node(n):
        bounds = list(map(int, re.findall(r'\d+', n.get('bounds', ''))))
        assert len(bounds) == 4 and bounds[3] > bounds[1]
        assert n.get('enabled') == 'true'
        x1, y1, x2, y2 = bounds
        adb('shell', 'input', 'tap', str((x1+x2)//2), str((y1+y2)//2))

    def tap(label, scroll=False):
        for attempt in range(7 if scroll else 1):
            found = matching(label)
            actionable = [n for n in found if n.get('clickable') == 'true']
            found = actionable or found
            if found:
                n = found[0]
                bounds = list(map(int, re.findall(r'\d+', n.get('bounds', ''))))
                if len(bounds) == 4 and bounds[3] > bounds[1]:
                    assert n.get('enabled') == 'true', label + ' disabled'
                    click_node(n)
                    return
            if attempt < 6 and scroll:
                adb('shell', 'input', 'swipe', '350', '930', '350', '390', '250')
        raise AssertionError('UI action missing: ' + label)

    def screenshot(name):
        (output / (name + '.png')).write_bytes(adb('exec-out', 'screencap', '-p', binary=True))

    def media():
        raw = adb('shell', 'dumpsys', 'media_session')
        assert 'package=' + PACKAGE in raw
        section = raw.split('package=' + PACKAGE, 1)[1].split('\n  Media', 1)[0]
        state = re.search(r'state=PlaybackState\s*\{state=(?:[A-Z_]+\()?(\d+)\)?, position=(\d+)', section)
        return None if state is None else (int(state[1]), int(state[2]))

    def wait_media(expected, timeout=40):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            state = media()
            if state is not None and state[0] == expected:
                return state
            if state is not None and state[0] == 7:
                raise AssertionError('Native playback entered ERROR; inspect app UI on the test emulator')
            time.sleep(.5)
        raise AssertionError('MediaSession did not reach state ' + str(expected))

    assert adb('shell', 'getprop', 'ro.kernel.qemu').strip() == '1'
    installed = adb('shell', 'pm', 'path', PACKAGE).strip().removeprefix('package:')
    expected = ROOT / 'android/build/debug/rhythmbox-android-debug.apk'
    sha = hashlib.sha256(expected.read_bytes()).hexdigest()
    assert adb('shell', 'sha256sum', installed).split()[0] == sha
    adb('shell', 'am', 'force-stop', PACKAGE)
    adb('shell', 'am', 'start', '-W', '-n', PACKAGE + '/.MainActivity')
    checks = {}
    tap('Services')
    current = nodes()
    assert matching('Services musicaux', current) and matching('Autoriser le pilotage Spotify…', current)
    checks['fourth_services_tab'] = True
    screenshot('services')
    tap('Autoriser le pilotage Spotify…')
    text = '\n'.join(n.get('text', '') for n in nodes())
    assert 'accès global aux notifications' in text and 'ne consulte pas le contenu' in text
    assert 'désactiver la transmission' in text
    screenshot('spotify-permission-explanation')
    tap('Annuler')
    checks['global_permission_explained_without_grant'] = True
    tap('Ouvrir Spotify')
    assert matching('Installer Spotify')
    tap('Fermer')
    checks['missing_spotify_offers_install_without_navigation'] = True

    link = 'https://suno.com/s/R2YMzAKnPs5bHPjq'
    adb('shell', 'am', 'start', '-W', '-n', PACKAGE + '/.MainActivity',
        '-a', 'android.intent.action.SEND', '-t', 'text/plain',
        '--es', 'android.intent.extra.TEXT', link)
    form = nodes()
    assert matching('Écouter Suno dans Rhythmbox', form)
    assert any(n.get('class') == 'android.widget.EditText' and n.get('text') == link for n in form)
    screenshot('suno-share-review')
    checks['shared_link_requires_review'] = True
    if args.live_suno:
        tap('Ajouter')
        deadline = time.monotonic() + 95
        while time.monotonic() < deadline:
            if matching('Voir et écouter'):
                break
            adb('shell', 'input', 'swipe', '350', '930', '350', '450', '250')
        else:
            screenshot('suno-catalogue-failure')
            raise AssertionError('The public Suno catalogue did not become available')
        checks['real_public_suno_catalogue_loaded'] = True
        tap('Voir et écouter', scroll=True)
        current = nodes()
        # The provided source is a single public song. Select the actual listed
        # title beneath the search field, without depending on its spelling.
        lists = [n for n in current if n.get('class') == 'android.widget.ListView']
        titles = [n for parent in lists for n in parent.iter('node')
                  if n.get('class') in ('android.widget.CheckedTextView', 'android.widget.TextView')
                  and n.get('text')]
        assert len(titles) == 1, 'Expected exactly the one public song in the reviewed source'
        tap(titles[0].get('text'))
        started = wait_media(3)
        screenshot('suno-native-playing')
        time.sleep(2)
        # Animated playback deliberately never becomes accessibility-idle.
        # Pause with Android's media command before taking a fresh UI snapshot.
        adb('shell', 'input', 'keyevent', 'KEYCODE_MEDIA_PAUSE')
        paused = wait_media(2)
        assert paused[1] > started[1], 'The native playback clock must advance'
        checks['real_suno_native_playback_and_system_pause'] = True
        stable = nodes()
        play_control = matching('Lire', stable)[0]
        stop_control = matching('Arrêter la lecture', stable)[0]
        click_node(play_control)
        wait_media(3)
        time.sleep(2)
        # Same fixed transport controls and layout, only their glyph changes.
        click_node(play_control)
        again = wait_media(2)
        assert again[1] > paused[1], 'Resume and the actual app pause button must work'
        click_node(play_control)
        wait_media(3)
        click_node(stop_control)
        wait_media(1)
        checks['common_transport_resume_pause_and_stop'] = True
    else:
        tap('Annuler')

    tap('Bibliothèque')
    assert matching('Ta musique commence ici')
    tap('Réglages')
    assert matching('Aucun compte musical connecté')
    checks['suno_does_not_populate_pcloud_or_authorize_account'] = True
    report = {'apk_sha256': sha, 'serial': args.serial, 'api': 36, 'checks': checks,
              'live_public_suno_test': args.live_suno, 'physical_phone_tested': False,
              'pcloud_account_authorized': False, 'spotify_permission_granted': False,
              'paid_actions_or_download_credits': False, 'private_app_storage_read': False}
    (output / 'validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
