#!/usr/bin/env python3
"""Compile/run an isolated no-Internet volume normalization codec/effect test.

Uses only installed tools and an explicitly selected emulator. Never starts an
emulator, downloads SDK packages, installs the production app or reads its data.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

from android_build import Tools, run, write_zip_entry

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = 'fr.denis.rhythmbox.loudnesstest'
RUNNER = 'fr.denis.rhythmbox.VolumeNormalizationInstrumentation'


def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--serial', default='emulator-5590')
    parser.add_argument('--adb', type=Path)
    parser.add_argument('--report', type=Path,
                        default=ROOT / 'dist/android-volume-native-validation.json')
    args = parser.parse_args()
    if not re.fullmatch(r'emulator-[0-9]+', args.serial):
        raise ValueError('Only a specifically identified emulator is permitted')
    tools = Tools.local()
    stage = ROOT / 'android/build/volume-normalization-test'
    if stage.is_symlink():
        raise ValueError('Symbolic test build folder refused')
    if stage.exists():
        shutil.rmtree(stage)
    stage.mkdir(parents=True)
    for name in ('classes', 'dex', 'generated', 'assets/volume-fixtures'):
        (stage / name).mkdir(parents=True)
    assets = stage / 'assets/volume-fixtures'
    import math, struct, wave
    for name, channels, peak in [('quiet.wav', 2, -24), ('very-quiet.wav', 2, -40),
                                  ('loud.wav', 2, -6), ('mono.wav', 1, -24),
                                  ('silence.wav', 2, None), ('crest.wav', 2, -26),
                                  ('two-levels.wav', 2, -38)]:
        amplitude = 0 if peak is None else 10 ** (peak / 20)
        values = bytearray()
        duration = 12 if name == 'two-levels.wav' else 4
        for frame in range(duration * 48000):
            level = amplitude * (10 ** (12 / 20) if name == 'two-levels.wav' and frame >= 6 * 48000 else 1)
            value = level * math.sin(2 * math.pi * 1000 * frame / 48000)
            if name == 'crest.wav' and frame % 2400 == 0:
                value = .88
            values += struct.pack('<h', round(value * 32767)) * channels
        with wave.open(str(assets / name), 'wb') as output:
            output.setnchannels(channels); output.setsampwidth(2); output.setframerate(48000)
            output.writeframes(values)
    common = ['ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'error', '-y']
    run([*common, '-i', assets / 'quiet.wav', '-c:a', 'aac', '-b:a', '128k', '-movflags', '+faststart', assets / 'quiet-aac.m4a'])
    run([*common, '-i', assets / 'quiet.wav', '-c:a', 'libopus', '-b:a', '128k', '-movflags', '+faststart', assets / 'quiet-opus.mp4'])
    references = {}
    for name in ('quiet.wav', 'very-quiet.wav', 'loud.wav', 'mono.wav', 'quiet-aac.m4a', 'quiet-opus.mp4', 'two-levels.wav'):
        result = subprocess.run(['ffmpeg', '-nostdin', '-hide_banner', '-nostats', '-i', str(assets / name),
            '-map', '0:a:0', '-vn', '-sn', '-dn', '-af',
            'loudnorm=I=-18:TP=-1:LRA=50:dual_mono=true:print_format=json', '-f', 'null', '-'],
            capture_output=True, text=True, check=True, timeout=20)
        match = re.search(r'\{\s*"input_i".*?\}', result.stderr, re.DOTALL)
        if not match:
            raise ValueError('Missing reference loudness for authored fixture')
        references[name] = json.loads(match.group())
    (assets / 'references.json').write_text(json.dumps(references, indent=2) + '\n')
    test = ROOT / 'android/app/src/loudnessTest'
    manifest = test / 'AndroidManifest.xml'
    main_java = ROOT / 'android/app/src/main/java/fr/denis/rhythmbox'
    sources = [main_java / name for name in ('TrackLoudness.java', 'TrackLoudnessAnalyzer.java', 'TrackLoudnessCache.java', 'TrackVolumeEffect.java')]
    sources += sorted((test / 'java').rglob('*.java'))
    inputs = [*sources, manifest]
    fingerprints = {str(path.relative_to(ROOT)): sha(path) for path in inputs}
    run([tools.aapt2, 'link', '--manifest', manifest, '-I', tools.platform,
         '--java', stage / 'generated', '--min-sdk-version', '26', '--target-sdk-version', '36',
         '-A', stage / 'assets', '-o', stage / 'resources.apk'])
    run(['javac', '--release', '8', '-Xlint:-options', '-encoding', 'UTF-8', '-g',
         '-classpath', tools.platform, '-d', stage / 'classes', *sources])
    run(['jar', '--create', '--file', stage / 'classes.jar', '-C', stage / 'classes', '.'])
    run([tools.directory / 'd8', '--release', '--min-api', '26', '--lib', tools.platform,
         '--output', stage / 'dex', stage / 'classes.jar'])
    unsigned = stage / 'unsigned.apk'
    shutil.copy2(stage / 'resources.apk', unsigned)
    with zipfile.ZipFile(unsigned, 'a') as archive:
        for dex in sorted((stage / 'dex').glob('classes*.dex')):
            write_zip_entry(archive, dex.name, dex.read_bytes())
    run([tools.directory / 'zipalign', '-f', '-p', '4', unsigned, stage / 'aligned.apk'])
    key = stage / 'test-only.p12'
    run(['keytool', '-genkeypair', '-noprompt', '-storetype', 'PKCS12', '-keystore', key,
         '-storepass', 'android', '-keypass', 'android', '-alias', 'isolated-volume-test',
         '-keyalg', 'RSA', '-keysize', '2048', '-validity', '3',
         '-dname', 'CN=Disposable isolated volume test'])
    apk = stage / 'volume-normalization-isolated-test.apk'
    run([tools.directory / 'apksigner', 'sign', '--ks', key, '--ks-key-alias', 'isolated-volume-test',
         '--ks-pass', 'pass:android', '--key-pass', 'pass:android', '--out', apk, stage / 'aligned.apk'])
    run([tools.directory / 'apksigner', 'verify', apk])
    if any(sha(ROOT / name) != digest for name, digest in fingerprints.items()):
        raise ValueError('Volume source changed during compilation')
    result = {'package': PACKAGE, 'apk': str(apk.relative_to(ROOT)), 'apk_sha256': sha(apk),
              'source_sha256': fingerprints,
              'fixture_plaintext_sha256': {p.name: sha(p) for p in assets.iterdir()},
              'network_permission': False, 'test_only_signing': True,
              'production_app_installed_or_accessed': False,
              'test_only_visualizer_permission': True, 'microphone_opened': False,
              'test_only_modify_audio_settings_permission': True,
              'output_mix_capture_in_named_empty_emulator_only': True,
              'device_run': False, 'emulator_started_by_this_script': False}
    if args.run:
        adb = args.adb or Path(shutil.which('adb') or '')
        if not adb.is_file():
            raise ValueError('Installed adb not found')
        command = [adb, '-s', args.serial]
        if run([*command, 'shell', 'getprop', 'ro.kernel.qemu']).strip() != '1':
            raise ValueError('The device is not an emulator')
        avd = run([*command, 'emu', 'avd', 'name']).strip().splitlines()[0]
        if avd != 'RhythmboxVolume36':
            raise ValueError('Only the purpose-created empty, muted volume test AVD is permitted')
        api = int(run([*command, 'shell', 'getprop', 'ro.build.version.sdk']).strip())
        if api != 36:
            raise ValueError('This validation requires the pinned API36 emulator')
        subprocess.run([str(v) for v in [*command, 'uninstall', PACKAGE]],
                       capture_output=True, text=True, timeout=30)
        run([*command, 'install', '-t', '--no-streaming', apk])
        run([*command, 'shell', 'pm', 'grant', PACKAGE, 'android.permission.RECORD_AUDIO'])
        apk_path = run([*command, 'shell', 'pm', 'path', PACKAGE]).strip().removeprefix('package:')
        installed_sha = run([*command, 'shell', 'sha256sum', apk_path]).split()[0]
        if installed_sha != sha(apk):
            raise ValueError('Installed test APK differs from verified build')
        completed = subprocess.run([str(v) for v in [*command, 'shell', 'am', 'instrument', '-w', '-r', PACKAGE + '/' + RUNNER]],
                                   capture_output=True, text=True, timeout=150)
        text = completed.stdout + completed.stderr
        log = args.report.with_suffix('.log')
        log.parent.mkdir(parents=True, exist_ok=True)
        log.write_text(text)
        match = re.search(r'^INSTRUMENTATION_RESULT: report=(\{.*\})$', text, re.MULTILINE)
        if not match:
            raise RuntimeError('Test did not return its bounded report: ' + text[-3000:])
        result.update(device_run=True, serial=args.serial, api=api,
                      installed_test_apk_sha256=installed_sha,
                      instrumentation=json.loads(match.group(1)), log=str(log))
        result['ok'] = (completed.returncode == 0 and result['instrumentation'].get('failures') == 0
                        and 'INSTRUMENTATION_CODE: -1' in text)
    else:
        result['ok'] = True
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['ok'] else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        print(str(error), file=sys.stderr)
        raise SystemExit(1)
