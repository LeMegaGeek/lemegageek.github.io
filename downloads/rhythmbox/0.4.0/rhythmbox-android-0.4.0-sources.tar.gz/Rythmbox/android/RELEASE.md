# Construire une version Google Play

L'identifiant stable est `fr.denis.rhythmbox`. La version Android 0.4.0 utilise
le code 4, Android 8 minimum (API 26) et cible Android 16 (API 36). La cible 36 est
exigée pour les nouvelles applications depuis le 31 août 2026 par
[Google Play](https://developer.android.com/google/play/requirements/target-sdk).

## Outils et commandes

```sh
./android/prepare-toolchain.sh
./android/test.sh
./android/build.sh
./android/build-release.sh
```

Python 3.11 ou ultérieur, JDK 17 ou 21 et outils Unix doivent être installés. Les outils officiels Google sont
téléchargés dans `android/.toolchain/`, avec versions et SHA256 épinglés dans
`scripts/android_toolchain.py`. Aucune commande n'accepte automatiquement une
licence (`sdkmanager --licenses` n'est pas appelé). Les notices des distributions
SDK restent conservées dans le cache. Le build n'utilise pas de SDK global.

AAPT2 Maven compile les ressources et produit un manifeste protobuf ; javac et
D8 compilent le Java. Bundletool construit et valide l'AAB. Le bundle est signé
par jarsigner, puis un APK universel est généré et sa signature est vérifiée par
apksigner. Cette procédure suit le
[build en ligne de commande officiel](https://developer.android.com/build/building-cmdline).
L'application Java n'embarque pas de bibliothèque native.

Les variantes restent séparées : le manifeste de production est explicitement
non débogable ; seul le manifeste temporaire du build debug autorise le
débogage nécessaire aux essais d'émulateur.

## Signature privée

La première compilation release génère une clé d'upload RSA 4096 distincte de la
clé debug. Elle est conservée dans
`~/.local/share/rhythmbox-android/signing/` (dossier 0700, fichiers 0600), hors du
projet et du dossier musical pCloud. Le mot de passe aléatoire reste dans ce
dossier et n'est jamais affiché ni passé en clair sur la ligne de commande.
Le build refuse de remplacer une clé existante ou une signature incomplète.

Le chemin peut être fourni par `RBX_ANDROID_SIGNING_DIR` ou `--signing-dir`.
Il doit rester hors du projet, dans un emplacement privé non synchronisé.
Conserver une sauvegarde privée de cette signature pour les futures mises à jour.
Seul le certificat **public** est exporté. Les clés et profils privés ne figurent
ni dans les APK/AAB ni dans l'archive de sources.

Une APK release signée différemment ne remplace pas l'ancienne APK debug sur un
téléphone. Aucun désinstalleur ni effacement de données personnelles n'est lancé
par ces scripts ; les essais se font sur un émulateur isolé ou via une piste de
test Play. Avec Play App Signing, Google gère la clé de distribution et la clé
locale sert à l'upload.

## Fichiers produits

- `dist/rhythmbox-android-release.aab` : bundle à importer dans Play Console.
- `dist/rhythmbox-android-release.apk` : APK universel dérivé du bundle pour les essais.
- `dist/rhythmbox-upload-certificate.pem` : certificat public d'upload.
- `dist/rhythmbox-android-0.4.0-sources.tar.gz` : sources GPL, ressources et scripts de build/test.
- `dist/android-play-release-validation.json` : versions, signatures et empreintes vérifiées.

Les artefacts ont chacun un SHA256. Le rapport de build ne signifie pas que
l'application est publiée ou qu'un téléphone a été testé : ces étapes sont
suivies séparément. Les exigences d'accès au compte Play, de fiche magasin,
de confidentialité et de piste de test restent à satisfaire dans la console.

Le champ `publication_readiness` distingue la validité du bundle de la préparation
du magasin : URL HTTPS de confidentialité et de sources renseignées dans
`publication.xml`, contact public dans `play/fr-FR.json`, fichiers de captures
et vidéo du service multimédia. Les URL vides sont signalées comme bloquantes.
Ces contrôles locaux ne prouvent pas que les pages sont publiques, que les
captures et la vidéo ont été examinées, ni que les déclarations et l'accès à la
production sont validés dans Play Console. Le build ne fait aucun contrôle
réseau caché et n'accepte aucune déclaration au nom du propriétaire.

## Piste de livraison

La préparation du 29 octobre 2026 vise un **test fermé** pour l'application
`fr.denis.rhythmbox`. Pour cette application, Play Console impose douze testeurs
inscrits pendant quatorze jours continus avant la demande d'accès à la production.
Un bundle signé et un test d'émulateur réussis ne remplissent pas cette condition.
Les candidats précédents sont conservés sous `dist/candidates/` avec leur scope
de validation ; seul le candidat corrigé et revérifié doit servir au téléversement.
