# Client Android Rhythmbox

Application Android native en Java, version 0.4.0 (code 4), sans WebView ni bibliothèque embarquée. Android 8 (API 26) minimum, cible Android 16 (API 36). Le code original de ce client est distribué sous GPL-2.0-or-later, comme le projet Rhythmbox.

L’APK de développement est dans `../dist/rhythmbox-android-debug.apk`. Il conserve sa clé locale et les signatures Android v2 et v3. La chaîne de production fournit un AAB et un APK universel signés avec une clé d’upload distincte ; voir [la construction Google Play](RELEASE.md). Les essais d’émulateur et d’appareil sont consignés séparément des contrôles de compilation et de protocole.

## Utilisation

### Choisir les dossiers, sans saisir de code

Les réglages proposent maintenant **Choisir le dossier des playlists**, **Choisir le dossier musique** et **Associer avec le PC**. Les boutons ouvrent le sélecteur de dossiers Android ; les chemins et les clés ne sont pas à recopier.

Sur le PC, choisir les dossiers synchronisés et utiliser **Associer Android**. Transférer le fichier d’association par un canal privé, puis le sélectionner sur Android. Ce fichier contient la clé de chiffrement et doit rester hors du dossier pCloud des playlists. La clé importée est ensuite conservée dans les paramètres privés chiffrés avec Android Keystore. Le fichier de transfert n’est pas effacé automatiquement.

Le dossier des playlists doit être accessible en lecture/écriture et autoriser la création et le renommage de documents ; le dossier musique reçoit une autorisation de lecture uniquement. Les autorisations sont persistées et les anciens dossiers inutilisés sont révoqués lorsque le choix change. L’application n’obtient aucune permission générale d’accès aux fichiers. Les fichiers de playlists sont toujours les révisions chiffrées `rb-sync-UUID.rbx`, compatibles avec le PC.

La disponibilité du dossier pCloud dépend du **fournisseur de documents Android** installé : il doit apparaître dans le sélecteur et permettre de choisir un dossier entier. La présence de l’application pCloud ne prouve pas qu’elle expose cette fonction. Si aucun fournisseur compatible ne présente ce dossier, ce mode ne réalise pas à lui seul la synchronisation pCloud ; la connexion avancée ci-dessous reste disponible. Ce point doit être essayé sur le téléphone cible.

Les références musicales utilisent `media_path`, un chemin relatif au seul dossier musique choisi. Les chemins absolus, URL, composants `..`, `.`, vides, antislash, deux-points, séquences encodées `%HH` et caractères de contrôle sont refusés. Les noms contenant un `%` littéral, par exemple `11 100%.mp3`, sont conservés. Aucun chemin du PC n’est utilisable comme chemin Android. Le contenu est résolu par noms exacts sous le dossier autorisé, sans décodage d’URL, puis copié dans le cache privé pour lecture. Le PC et le téléphone doivent tous deux utiliser cette correction : un ancien client qui refusait tout `%` rejettera les révisions contenant ces noms.

### Connexion pCloud avancée

Dans **Réglages**, saisir la région pCloud, le lien de lecture et le lien de dépôt du même dossier dédié aux listes, puis la clé Base64 générée sur le PC. Le lien musique/collection est facultatif : les listes peuvent être synchronisées sans donner accès à des médias. Aucun identifiant ou jeton de compte pCloud n’est demandé.

Le bouton **↓ pCloud** importe les titres du dossier ou de la collection explicitement partagé par le lien musique. Créer et renommer des listes, rechercher un artiste/album/titre, toucher un titre pour écouter. Le menu `⋮` permet d’ajouter un titre à une liste, modifier ses métadonnées ou le retirer. Un appui long sur une liste ouvre son menu. La barre de lecture fournit lecture/pause, précédent/suivant, mode aléatoire et position. La lecture utilise un service de premier plan avec notification multimédia, gestion de la sortie casque et du focus audio.

**↻ Synchro** propose récupération ou envoi explicites. Les fichiers échangés sont des snapshots AES-256-GCM, compatibles avec le cœur Python. Chaque envoi crée une révision immuable. Plusieurs révisions terminales sont affichées comme variantes ; le choix de celle qui remplace les listes locales exige une confirmation. L’envoi depuis une base ancienne conserve une variante supplémentaire. Les révisions pCloud restent disponibles. La suppression d’une liste entière est locale en V1 et peut être annulée par une récupération ; le cœur bureau conserve aussi les listes absentes d’un export partiel.

La **mise à l’écart Android** masque un titre, un album ou un artiste sur ce téléphone et exclut ses entrées des prochains envois. Les fichiers pCloud restent en place. Le déplacement physique vers le dossier de quarantaine se fait dans l’application Rhythmbox sur le PC. Les identifiants des titres masqués restent exclusivement dans le stockage privé Android ; les réglages permettent de les réafficher.

### Piste audio des vidéos

Les conteneurs M4V, MP4, MPG/MPEG, MOV, MKV, AVI et WebM sont proposés avec les fichiers musicaux. L’application exige une piste audio lisible après préparation et ne fournit aucune surface vidéo : ces fichiers sont écoutés sans image. Leur extension ne garantit pas que le téléphone possède le codec audio requis. La lecture effective dépend encore d’un essai sur le téléphone cible ; la compilation et les tests JVM ne prouvent pas les codecs de l’appareil.

## Confidentialité et limites

- Seuls `showpublink`, `getpublinkdownload` et `uploadtolink` sont appelés. Aucune API de compte, racine, recherche globale ou suppression n’est implémentée.
- Un `fileid` audio n’est utilisé qu’après vérification de son appartenance au partage musique. Une playlist reçue ne peut pas imposer d’URL ni de chemin local. Le serveur CDN doit appartenir à `.pcloud.com`, le transport est HTTPS et les redirections HTTP sont refusées.
- Les liens sont des capacités d’accès : toute personne possédant un lien musique peut lire les médias de ce partage. Le chiffrement protège les métadonnées des listes, pas les médias. Tout contenu futur du dossier partagé devient accessible par ce lien. Voir `../docs/SECURITY.md` et `../docs/PCLOUD-SETUP.md`.
- Les paramètres sont chiffrés avec une clé Android Keystore non exportable. Bibliothèque et paramètres sont dans `noBackupFilesDir`, le cache audio dans le stockage privé de l’application. La sauvegarde système est désactivée. Les champs secrets n’activent ni suggestions, ni apprentissage personnalisé du clavier, ni remplissage automatique.
- Aucun accès général aux fichiers, photos, contacts, microphone ou compte Android n’est demandé. Les seules permissions sont réseau, service de premier plan, service multimédia et maintien du CPU pendant la lecture. La notification MediaSession est exemptée de la permission de notifications ; aucun dialogue général de notifications n’est demandé au lancement.
- L’audio est téléchargé dans un cache privé avant lecture, avec une limite de 256 Mio par fichier et un seul morceau conservé. Les liens temporaires ne sont pas confiés au moteur multimédia, ce qui permet de refuser les redirections réseau. Il ne s’agit donc pas encore d’un lecteur à démarrage instantané par streaming. Pas de téléchargement hors connexion de bibliothèque complète.
- La modification des collections natives pCloud nécessiterait des droits de compte plus larges ; V1 importe leur lien de partage et synchronise ensuite les playlists Rhythmbox chiffrées.

## Compilation Linux

Prérequis : Python 3.11 ou ultérieur, JDK 17 ou 21 et outils Unix usuels. Les téléchargements restent dans `.toolchain/` et sont vérifiés par SHA-256. Les plateformes/outils Android officiels sont soumis à leurs licences respectives. `org.json` est utilisé uniquement par les tests JVM et n’est pas inclus dans l’APK.

```sh
./prepare-toolchain.sh
./build.sh
./test.sh
./build-release.sh
```

Pour utiliser des outils déjà installés, définir `RBX_ANDROID_PLATFORM=/chemin/platforms/android-36/android.jar` et `RBX_ANDROID_BUILD_TOOLS=/chemin/build-tools/36.0.0`. AAPT2 Maven et bundletool restent épinglés localement ; leurs chemins peuvent être fournis par `RBX_ANDROID_AAPT2` et `RBX_ANDROID_BUNDLETOOL`. Les tests acceptent `RBX_JSON_TEST_JAR=/chemin/org.json.jar`.

Le build compile les ressources et les classes Java, produit le DEX avec D8, construit le manifeste avec AAPT2, aligne puis signe l’APK. La clé de développement reste sous `.signing/`, exclue du versionnement ; conserver cette clé permet de mettre à jour la même installation de développement. La clé d’upload de production est gérée séparément, hors du projet et du dossier musical synchronisé. Les scripts de release vérifient aussi l’AAB, son certificat et l’APK universel généré par bundletool.

## Vérification effectuée

`./test.sh` vérifie le chiffrement Python→Java et Java→Python sur une fixture commune, l’authentification GCM, la mauvaise clé, les limites du protocole, les types des identifiants, l’exclusion des URI locales, les codes de liens, les serveurs CDN, les conflits et les cycles de révisions. Il teste aussi les chemins relatifs, l’import d’association, la sélection des formats musicaux/vidéo, la présentation, la file de lecture et la séparation de la démo lors des exports. Il vérifie les permissions, l’absence de sauvegarde/HTTP clair, la version et l’absence de surface vidéo dans les sources. `./build.sh` compile et vérifie les signatures de l’APK, en conservant la clé de développement existante pour permettre sa mise à jour.

La QA réelle utilise un émulateur Android 16 (API 36) isolé, sans compte pCloud ni musique personnelle. Le véritable APK universel signé, dérivé de l’AAB, a passé onze scénarios : démarrage/démo, seek MediaSession, rotation, police agrandie, commandes multimédias en arrière-plan, import de dossier SAF, MP3 avec pochette, piste audio d’une vidéo, écran éteint, fermeture par retrait des tâches et recherche d’exceptions fatales dans la fenêtre collectée. Les erreurs de fichier sans audio et de codec ont été vérifiées séparément sur la debug.

Le détail figure dans `dist/android-emulator-validation.json` et `dist/android-runtime-validation.md`, livrés séparément du rapport de compilation et de cette archive de sources. Les trois captures Play et la vidéo réelle muette proviennent du candidat signé testé. La présence d’une signature valide ne prouve pas à elle seule ces essais. Aucun test sur téléphone physique/API 26 ni connexion à des données pCloud réelles n’a été effectué. Les fournisseurs de documents pCloud et les codecs du téléphone cible restent à vérifier sur cet appareil.

Références : [API publique pCloud](https://docs.pcloud.com/methods/public_links/showpublink.html), [dépôt par lien](https://docs.pcloud.com/methods/upload_links/uploadtolink.html), [service multimédia Android](https://developer.android.com/develop/background-work/services/fgs/service-types#media).

Le périmètre des autorisations du sélecteur et la disponibilité des fournisseurs sont décrits dans la [documentation officielle du Storage Access Framework](https://developer.android.com/training/data-storage/shared/documents-files#grant-access-directory).
