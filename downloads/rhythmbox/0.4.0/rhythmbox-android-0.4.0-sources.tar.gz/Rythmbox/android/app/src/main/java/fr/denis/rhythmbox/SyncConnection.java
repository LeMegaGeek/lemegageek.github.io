package fr.denis.rhythmbox;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.util.List;

/** Human-facing folder setup by default; legacy scoped links stay available. */
public final class SyncConnection {
    private final FolderSync folder;
    private final SyncEngine links;
    public SyncConnection(Context context,JSONObject config) throws Exception {
        if("links".equals(config.optString("sync_mode",config.has("read_code")?"links":"folder"))){folder=null;links=new SyncEngine(config);}
        else{folder=new FolderSync(context,config);links=null;}
    }
    public void validateConfig() throws Exception {if(folder!=null)folder.validateConfig();else links.validateConfig();}
    public List<JSONObject> heads() throws Exception {return folder!=null?folder.heads():links.heads();}
    public void upload(JSONObject value) throws Exception {if(folder!=null)folder.upload(value);else links.upload(value);}
    public JSONArray importMedia() throws Exception {return folder!=null?folder.importMedia():links.importMedia();}
    public File mediaFile(JSONObject track,File cache) throws Exception {
        if(folder!=null){if(!track.has("media_path"))throw new IllegalStateException("Ce morceau n’est pas associé au dossier musique");return folder.mediaFile(track.getString("media_path"),cache);}
        if(!track.has("pcloud_fileid"))throw new IllegalStateException("Ce morceau n’est pas associé au partage musique");return links.mediaFile(track.getLong("pcloud_fileid"),cache);
    }
}
