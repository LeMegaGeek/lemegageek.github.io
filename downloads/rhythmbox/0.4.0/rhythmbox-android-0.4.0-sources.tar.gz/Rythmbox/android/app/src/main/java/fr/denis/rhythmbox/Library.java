package fr.denis.rhythmbox;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class Library {
    public JSONObject state;
    private final File file;
    public Library(Context context) throws Exception {
        file = new File(context.getNoBackupFilesDir(), "library.json");
        state = file.exists() ? new JSONObject(new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8)) :
            new JSONObject().put("device", UUID.randomUUID().toString()).put("parents", new JSONArray()).put("playlists", new JSONArray()).put("hidden", new JSONArray());
    }
    static void writeAtomic(File file, String value) throws Exception {
        File tmp = new File(file.getParentFile(), file.getName() + ".tmp");
        try (FileOutputStream out = new FileOutputStream(tmp)) { out.write(value.getBytes(StandardCharsets.UTF_8)); out.getFD().sync(); }
        Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
    }
    public void save() throws Exception { writeAtomic(file, state.toString()); }
    public JSONArray playlists() { return state.optJSONArray("playlists"); }
    public Set<String> hidden() {
        Set<String> result = new HashSet<>(); JSONArray hidden = state.optJSONArray("hidden");
        if (hidden != null) for (int i=0;i<hidden.length();i++) result.add(hidden.optString(i)); return result;
    }
    public boolean isHidden(JSONObject track) { return hidden().contains(track.optString("id")); }
    public void hide(JSONArray tracks) throws Exception {
        Set<String> hidden = hidden(); for (int i=0;i<tracks.length();i++) hidden.add(tracks.getJSONObject(i).getString("id"));
        state.put("hidden", new JSONArray(hidden)); save();
    }
    public JSONObject snapshot() throws Exception {
        JSONArray lists = new JSONArray(); Set<String> hidden = hidden();
        for (int i=0;i<playlists().length();i++) {
            JSONObject source = playlists().getJSONObject(i), copy = new JSONObject().put("id", source.getString("id")).put("name", source.getString("name"));
            JSONArray tracks = portableTracks(source.getJSONArray("tracks"), hidden);
            copy.put("tracks", tracks); lists.put(copy);
        }
        return new JSONObject().put("schema",1).put("id",UUID.randomUUID().toString()).put("parents",state.getJSONArray("parents"))
            .put("device",state.getString("device")).put("created",java.time.Instant.now().toString()).put("playlists",lists);
    }
    static JSONArray portableTracks(JSONArray source, Set<String> hidden) throws Exception {
        JSONArray tracks = new JSONArray();
        for(int i=0;i<source.length();i++) {
            JSONObject track=source.getJSONObject(i);
            // A demonstration entry must never escape through a future edit path.
            if(hidden.contains(track.getString("id")) || track.has("demo_source"))continue;
            JSONObject portable=new JSONObject();
            for(String field:new String[]{"id","title","artist","album"})portable.put(field,track.optString(field,""));
            if(track.has("pcloud_fileid"))portable.put("pcloud_fileid",track.get("pcloud_fileid"));
            if(track.has("media_path"))portable.put("media_path",track.get("media_path"));
            tracks.put(portable);
        }
        return tracks;
    }
    public void importSnapshot(JSONObject snapshot) throws Exception {
        validate(snapshot); state.put("playlists", snapshot.getJSONArray("playlists")); state.put("parents",new JSONArray().put(snapshot.getString("id"))); save();
    }
    public static void validate(JSONObject value) throws Exception {
        Set<String> rootKeys = new HashSet<>(java.util.Arrays.asList("schema","id","parents","device","created","playlists"));
        java.util.Iterator<String> keys=value.keys(); while(keys.hasNext()) if(!rootKeys.contains(keys.next())) throw new IllegalArgumentException("Champ snapshot non autorisé");
        if (!(value.get("schema") instanceof Integer) || value.getInt("schema")!=1) throw new IllegalArgumentException("Version inconnue");
        UUID.fromString(value.getString("id")); UUID.fromString(value.getString("device")); requireText(value,"created",64);java.time.Instant.parse(value.getString("created"));
        JSONArray parents=value.getJSONArray("parents"); if(parents.length()>1000) throw new IllegalArgumentException("Trop de parents");
        for(int i=0;i<parents.length();i++) UUID.fromString(parents.getString(i));
        JSONArray lists=value.getJSONArray("playlists"); if(lists.length()>1000) throw new IllegalArgumentException("Trop de listes");
        Set<String> listIds = new HashSet<>(); int totalTracks=0;
        for(int i=0;i<lists.length();i++) {
            JSONObject list=lists.getJSONObject(i); requireText(list,"id",128); requireText(list,"name",1024);
            if(!listIds.add(list.getString("id"))) throw new IllegalArgumentException("Liste invalide");
            keys=list.keys(); while(keys.hasNext()) if(!java.util.Arrays.asList("id","name","tracks").contains(keys.next())) throw new IllegalArgumentException("Champ liste non autorisé");
            JSONArray tracks=list.getJSONArray("tracks"); totalTracks+=tracks.length(); if(totalTracks>50000) throw new IllegalArgumentException("Trop de morceaux");
            for(int j=0;j<tracks.length();j++) {
                JSONObject track=tracks.getJSONObject(j); keys=track.keys();
                while(keys.hasNext()) if(!java.util.Arrays.asList("id","title","artist","album","pcloud_fileid","media_path").contains(keys.next())) throw new IllegalArgumentException("Champ titre non autorisé");
                for(String field:new String[]{"id","title","artist","album"}) requireText(track,field,2048);
                if(track.has("media_path")){requireText(track,"media_path",2048);FolderProtocol.mediaPath(track.getString("media_path"));}
                if(track.has("pcloud_fileid") && (!(track.get("pcloud_fileid") instanceof Integer || track.get("pcloud_fileid") instanceof Long) || track.getLong("pcloud_fileid")<=0)) throw new IllegalArgumentException("Identifiant audio invalide");
            }
        }
    }
    private static void requireText(JSONObject object,String field,int limit) throws Exception {
        Object raw=object.get(field);
        if(!(raw instanceof String)) throw new IllegalArgumentException("Métadonnée texte invalide");
        String text=(String)raw; if(text.codePointCount(0,text.length())>limit || text.indexOf(0)>=0) throw new IllegalArgumentException("Métadonnée invalide ou trop longue");
    }
}
