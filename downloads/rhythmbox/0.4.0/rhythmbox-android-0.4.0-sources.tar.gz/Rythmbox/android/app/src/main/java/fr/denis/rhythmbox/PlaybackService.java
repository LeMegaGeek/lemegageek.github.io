package fr.denis.rhythmbox;

import android.app.*;
import android.content.*;
import android.media.*;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Background playback with audio focus, headset handling and a media notification. */
public final class PlaybackService extends Service {
    public final class LocalBinder extends Binder { public PlaybackService service() { return PlaybackService.this; } }
    private final LocalBinder binder=new LocalBinder();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private MediaPlayer player; private MediaSession session; private AudioManager audio; private AudioFocusRequest focus;
    private JSONArray queue=new JSONArray(); private int index=-1, generation=0; private boolean shuffle=false,autoplay=true;
    public String title="À vous de choisir", artist="", status="Prêt"; public boolean loading=false;
    public Bitmap artwork; private String currentTrackId="";
    public String currentTrackId(){return currentTrackId;}
    public boolean hasCurrentTrack(){return index>=0 && index<queue.length();}
    public boolean canPrevious(){return hasCurrentTrack() && (index>0 || shuffle && queue.length()>1);}
    public boolean canNext(){return hasCurrentTrack() && (index<queue.length()-1 || shuffle && queue.length()>1);}
    public boolean isShuffle(){return shuffle;}
    private final BroadcastReceiver noisy=new BroadcastReceiver(){public void onReceive(Context c,Intent i){ pause(); }};
    @Override public void onCreate() {
        super.onCreate(); audio=(AudioManager)getSystemService(AUDIO_SERVICE);
        focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setOnAudioFocusChangeListener(change->{ if(change<0) pause(); }).build();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(new NotificationChannel("playback","Lecture musicale",NotificationManager.IMPORTANCE_LOW));
        session=new MediaSession(this,"Rhythmbox");
        session.setCallback(new MediaSession.Callback(){
            public void onPlay(){if(loading)autoplay=true;else if(!isPlaying())toggle();} public void onPause(){pause();} public void onSkipToNext(){next(1);} public void onSkipToPrevious(){next(-1);} public void onSeekTo(long pos){seek((int)pos);} public void onStop(){stopPlayback();}
        }); session.setActive(true);
        if(Build.VERSION.SDK_INT>=33) registerReceiver(noisy,new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(noisy,new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
    }
    @Override public IBinder onBind(Intent intent){return binder;}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        String action=intent==null?null:intent.getAction();
        if("previous".equals(action))next(-1);else if("next".equals(action))next(1);else if("toggle".equals(action))toggle();else if("stop".equals(action)){stopPlayback();return START_NOT_STICKY;}
        notification();return START_NOT_STICKY;
    }
    public void play(JSONArray tracks,int selected){ queue=tracks; load(selected); }
    public void excludeTracks(JSONArray tracks){
        java.util.Set<String> ids=new java.util.HashSet<>();for(int i=0;i<tracks.length();i++){JSONObject item=tracks.optJSONObject(i);if(item!=null)ids.add(item.optString("id"));}
        PlaybackQueue.Selection kept=PlaybackQueue.excluding(queue,index,ids);
        if(kept.currentRemoved){stopPlayback();currentTrackId="";title="À toi de choisir";artist="";artwork=null;}
        queue=kept.tracks;index=kept.selected;
    }
    public void setShuffle(boolean value){shuffle=value;}
    public boolean isPlaying(){try{return player!=null && !loading && player.isPlaying();}catch(Exception invalidState){return false;}}
    public int position(){try{return player==null?0:player.getCurrentPosition();}catch(Exception e){return 0;}}
    public int duration(){try{return player==null?0:player.getDuration();}catch(Exception e){return 0;}}
    public void seek(int position){if(player!=null)try{player.seekTo(position);}catch(Exception ignored){}}
    public void toggle(){if(player==null && !loading && hasCurrentTrack()){load(index);return;}if(player!=null && !loading){if(isPlaying())pause();else if(audio.requestAudioFocus(focus)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED){player.start();status="Lecture";notification();}}}
    public void pause(){autoplay=false;if(player!=null && !loading){try{player.pause();}catch(Exception ignored){}}status="En pause";notification();}
    public void stopPlayback(){generation++;autoplay=false;loading=false;if(player!=null){player.release();player=null;}audio.abandonAudioFocusRequest(focus);status="Arrêté";session.setPlaybackState(new PlaybackState.Builder().setState(PlaybackState.STATE_STOPPED,0,0).build());session.setActive(false);stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}
    public void next(int direction){if(queue.length()==0)return; int next=shuffle && queue.length()>1?(index+1+new java.util.Random().nextInt(queue.length()-1))%queue.length():index+direction;if(next>=queue.length()){stopPlayback();return;}load(Math.max(0,next));}
    private void load(int selected){
        if(selected<0 || selected>=queue.length())return;
        final JSONObject track=queue.optJSONObject(selected); if(track==null)return;
        index=selected; final int request=++generation;
        if(player!=null){player.release();player=null;}
        title=UiPresentation.title(track); artist=track.optString("artist","");currentTrackId=track.optString("id","");artwork=null;
        if(!DemoAudio.isDemo(track) && track.optLong("pcloud_fileid",0)<=0 && !track.has("media_path")){fail(request,"Ce morceau n’est pas associé à un dossier musical");return;}
        loading=true;autoplay=true;session.setActive(true);status="Préparation du morceau…";startForegroundService(new Intent(this,PlaybackService.class));notification();
        worker.execute(()->{
            try{
                File file;
                if(DemoAudio.isDemo(track))file=DemoAudio.materialize(this,track);
                else{SyncConnection engine=new SyncConnection(this,new SecretStore(this).load());file=engine.mediaFile(track,getCacheDir());}
                final Bitmap cover=embeddedArtwork(file);
                handler.post(()->{
                    if(request!=generation)return;
                    artwork=cover;
                    try{
                        player=new MediaPlayer(); player.setWakeMode(this,PowerManager.PARTIAL_WAKE_LOCK);player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
                        // This music client never supplies a rendering surface,
                        // including when the selected file is a video container.
                        player.setSurface(null);
                        player.setDataSource(file.getAbsolutePath());
                        player.setOnPreparedListener(p->{
                            if(request!=generation)return;
                            loading=false;
                            boolean hasAudio=false;
                            MediaPlayer.TrackInfo[] tracks=p.getTrackInfo();
                            if(tracks!=null)for(MediaPlayer.TrackInfo info:tracks)if(info.getTrackType()==MediaPlayer.TrackInfo.MEDIA_TRACK_TYPE_AUDIO)hasAudio=true;
                            if(!hasAudio){fail(request,"Ce fichier ne contient pas de piste audio lisible");return;}
                            if(!autoplay)status="En pause";
                            else if(audio.requestAudioFocus(focus)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED){p.start();status="Lecture";}
                            else status="Sortie audio occupée";
                            notification();
                        });
                        player.setOnCompletionListener(p->{if(request==generation)next(1);});
                        player.setOnSeekCompleteListener(p->{if(request==generation && p==player)notification();});
                        player.setOnErrorListener((p,what,extra)->{fail(request,"Ce format audio ne peut pas être lu");return true;});
                        player.prepareAsync();
                    }catch(Exception failure){fail(request,"Échec de préparation audio");}
                });
            }catch(Exception failure){handler.post(()->{if(request!=generation)return;fail(request,"Audio indisponible : vérifie le dossier et la connexion");});}
        });
    }
    private void fail(int request,String message){
        if(request!=generation)return;
        generation++;loading=false;autoplay=false;
        if(player!=null){try{player.release();}catch(Exception ignored){}player=null;}
        audio.abandonAudioFocusRequest(focus);status=message;
        session.setPlaybackState(new PlaybackState.Builder().setState(PlaybackState.STATE_ERROR,0,0).setErrorMessage(message).build());session.setActive(false);
        stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
    }
    private void notification(){
        if(session==null)return;
        MediaMetadata.Builder metadata=new MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE,title).putString(MediaMetadata.METADATA_KEY_ARTIST,artist).putLong(MediaMetadata.METADATA_KEY_DURATION,duration());
        if(artwork!=null)metadata.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART,artwork);session.setMetadata(metadata.build());
        session.setPlaybackState(new PlaybackState.Builder().setActions(PlaybackState.ACTION_PLAY_PAUSE|PlaybackState.ACTION_PLAY|PlaybackState.ACTION_PAUSE|PlaybackState.ACTION_SKIP_TO_NEXT|PlaybackState.ACTION_SKIP_TO_PREVIOUS|PlaybackState.ACTION_SEEK_TO)
            .setState(loading?PlaybackState.STATE_BUFFERING:isPlaying()?PlaybackState.STATE_PLAYING:PlaybackState.STATE_PAUSED,position(),isPlaying()?1:0).build());
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification=new Notification.Builder(this,"playback").setSmallIcon(R.drawable.ic_stat_music).setContentTitle(title).setContentText(artist+" · "+status).setContentIntent(open).setLargeIcon(artwork)
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_previous,"Précédent",command("previous",1)).build())
            .addAction(new Notification.Action.Builder(isPlaying()?android.R.drawable.ic_media_pause:android.R.drawable.ic_media_play,isPlaying()?"Pause":"Lecture",command("toggle",2)).build())
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_next,"Suivant",command("next",3)).build())
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"Arrêter",command("stop",4)).build())
            .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0,1,2)).setVisibility(Notification.VISIBILITY_PRIVATE).setOngoing(isPlaying()||loading).build();
        if(loading||player!=null)startForeground(1,notification);
    }
    private Bitmap embeddedArtwork(File file){
        MediaMetadataRetriever retriever=new MediaMetadataRetriever();
        try{retriever.setDataSource(file.getAbsolutePath());byte[] bytes=retriever.getEmbeddedPicture();if(bytes==null || bytes.length>4*1024*1024)return null;BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(bytes,0,bytes.length,options);if(options.outWidth<=0 || options.outHeight<=0 || options.outWidth>8192 || options.outHeight>8192 || (long)options.outWidth*options.outHeight>32L*1024*1024)return null;options.inJustDecodeBounds=false;options.inSampleSize=1;while(Math.max(options.outWidth,options.outHeight)/options.inSampleSize>512)options.inSampleSize*=2;return BitmapFactory.decodeByteArray(bytes,0,bytes.length,options);}
        catch(Exception unreadable){return null;}finally{try{retriever.release();}catch(Exception ignored){}}
    }
    @Override public void onTaskRemoved(Intent intent){stopPlayback();super.onTaskRemoved(intent);}
    private PendingIntent command(String action,int request){return PendingIntent.getService(this,request,new Intent(this,PlaybackService.class).setAction(action),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);}
    @Override public void onDestroy(){generation++;worker.shutdownNow();if(player!=null)player.release();if(session!=null)session.release();audio.abandonAudioFocusRequest(focus);unregisterReceiver(noisy);super.onDestroy();}
}
