# Confidentialité de la synchronisation pCloud

Analyse du 28 octobre 2026. La version 0.3 propose par défaut la **sélection de dossiers**, sans jeton OAuth ni mot de passe pCloud dans les clients. Une connexion avancée par capacités de partage limitées reste disponible. Les résultats des essais effectifs sont consignés séparément ; une propriété de conception ne constitue pas un essai sur un compte réel.

## Dossiers sélectionnés

Sur Linux, l'utilisateur choisit un dossier réservé aux playlists, déjà synchronisé par pCloud ou situé dans pCloudDrive, et un dossier musical distinct. Une copie locale répliquée est acceptée ; la sélection n'est pas obligatoirement située sous le lecteur monté. Le moteur n'énumère que le premier pour les fichiers `rb-sync-UUID.rbx`, et n'importe le contenu audio du second que sur demande. Le transfert réseau de ce mode appartient au client pCloud officiel déjà installé. Le greffon ne lit pas ses identifiants et ne demande pas d'accès API au compte. Cette restriction est celle des accès effectués par le code ; le greffon s'exécute avec les droits locaux de Rhythmbox, sans bac à sable système supplémentaire. Le client pCloud officiel conserve ses propres accès et ses liaisons existantes.

Les fichiers sont ouverts relativement à des descripteurs de répertoire et avec `O_NOFOLLOW`. Les liens symboliques ne peuvent pas élargir la sélection. Un média reçu est identifié par un `media_path` relatif strict : pas de chemin absolu, composant vide, `.` ou `..`, séparateur inverse, séquence d'échappement `%HH`, deux-points ou caractère de contrôle. Un `%` littéral dans un titre comme `100%` est conservé ; les chemins reçus ne sont jamais décodés comme des URL. Les chemins absolus du PC ne sont jamais exportés. Les autres fichiers du dossier de playlists sont ignorés et ne sont ni modifiés ni envoyés.

Android utilise le [sélecteur système de documents](https://developer.android.com/training/data-storage/shared/documents-files) et conserve uniquement les autorisations accordées aux arbres choisis. Le dossier playlists nécessite lecture/écriture et le dossier musique lecture seule. Aucun accès général au stockage n'est demandé. Le fournisseur doit exposer un arbre et prendre en charge les opérations requises ; la compatibilité du fournisseur pCloud Android n'est pas prouvée dans cet environnement.

La clé est créée automatiquement dans la configuration privée du PC. L'association Android passe par un fichier choisi hors de toutes les racines pCloud connues, contenant uniquement version, type, clé et identifiant de bibliothèque. Ne pas déposer ce fichier dans le dossier de playlists. Le code refuse cet export dans les dossiers partagés déclarés. La synchronisation ne transmet ni ce fichier ni les chemins de configuration ni le journal de quarantaine.

## Connexion avancée : frontière d'accès des liens

Le propriétaire prépare un dossier pCloud vide réservé aux échanges de playlists, puis crée deux liens : un lien de lecture vers ce dossier et un lien de dépôt vers le même dossier. Les appareils reçoivent seulement ces liens et une clé de chiffrement indépendante. Ils ne reçoivent aucune session du compte personnel.

Le lien de lecture autorise la consultation du seul objet partagé et de ses descendants ; le lien de dépôt autorise l'ajout de fichiers au dossier désigné. La documentation de [showpublink](https://docs.pcloud.com/methods/public_links/showpublink.html) décrit la consultation sans authentification de compte, et [uploadtolink](https://docs.pcloud.com/methods/upload_links/uploadtolink.html) décrit le dépôt sans authentification. Un détenteur de ces capacités ne peut pas les transformer en jeton d'accès au compte.

Les liens sont des secrets. Leur possession donne les pouvoirs associés, même hors de l'application. Le dossier d'échange doit rester réservé aux manifestes chiffrés : ne pas y placer de document privé en clair. La taille, le nombre et les dates des objets restent visibles au service et aux détenteurs du lien de lecture. Le lien de dépôt peut être utilisé pour remplir son quota ; le propriétaire doit fixer des limites et le révoquer si nécessaire.

## Chiffrement des playlists

Les clients chiffrent les manifestes avec AES-256-GCM et une clé aléatoire de 32 octets, partagée entre les appareils autorisés. Chaque chiffrement exige un nouveau nonce aléatoire. L'authentification GCM permet de refuser un objet modifié ou une mauvaise clé avant de traiter son contenu.

L'enveloppe commune est `RBX1` suivi d'un nonce de 12 octets et du résultat AES-GCM (texte chiffré et tag de 16 octets). Les données associées authentifiées sont les octets UTF-8 de `rhythmbox-playlists-v1`. Le contenu JSON versionné et sa taille sont validés après déchiffrement. Ces paramètres doivent rester identiques sur Android et sur le bureau.

La clé ne doit jamais être placée dans le dossier pCloud d'échange, dans une URL de téléchargement, dans un journal ou dans le dépôt de sources. L'appairage entre appareils est un transfert explicite d'un secret. Les appareils autorisés peuvent déchiffrer et produire des playlists : cette clé commune n'authentifie pas une personne ou un appareil distinct.

Les révisions sont des objets immuables avec références aux parents. Une collision de noms lors d'un dépôt est renommée par pCloud ; elle ne doit pas remplacer silencieusement une autre révision. Les modifications concurrentes doivent conserver plusieurs branches et rester visibles jusqu'à leur résolution. Le chiffrement n'empêche ni la suppression d'objets par le propriétaire du compte ni la présentation d'un ancien état par le service ; il ne fournit pas, à lui seul, une protection contre le rejeu.

## Pourquoi aucun OAuth global

La documentation publique de [l'autorisation OAuth pCloud](https://docs.pcloud.com/methods/oauth_2.0/authorize.html) ne décrit aucun droit limité à un dossier d'application ; son paramètre `permissions` ne documente qu'une permission supplémentaire, `manageshares`. Un choix de `folderid` dans une interface ne restreint pas un jeton du compte principal.

De plus, [les jetons OAuth actuels](https://docs.pcloud.com/methods/oauth_2.0/index.html) sont documentés sans expiration. Les clients de ce projet ne demandent donc pas ces jetons et ne lisent pas ceux des installations pCloud du PC ou du téléphone.

## Validation des données et du réseau

Les clients doivent limiter les méthodes API aux capacités requises et valider les hôtes HTTPS. Aucune URL fournie par une playlist ne doit déclencher une requête avec des secrets de synchronisation. Un identifiant de fichier importé doit appartenir au partage autorisé ; les chemins locaux et les URL arbitraires restent hors du protocole distant.

Les objets trop volumineux, JSON invalides, signatures d'enveloppe incorrectes, références incohérentes ou contenus non authentifiés doivent être refusés avec une erreur visible. Aucun échec n'autorise une recherche sur la racine du compte. Les journaux doivent omettre codes de partage, clé et URL temporaires signées.

Ces règles se vérifient dans les deux implémentations. Les tests d'API simulée montrent le comportement du code ; l'essai avec les deux liens réels reste nécessaire pour confirmer l'association au bon dossier et la réponse du service.

## Collections natives et fichiers audio

Les collections natives pCloud sont des listes rattachées au compte, distinctes des fichiers de playlists. Voir [le modèle des collections](https://docs.pcloud.com/methods/collection/). Le chiffrement des manifestes du projet ne transforme pas ces objets en collections modifiables dans le lecteur pCloud officiel.

Un lien explicitement choisi vers une collection peut servir à l'import en lecture seule. La documentation de [getcollectionpublink](https://docs.pcloud.com/methods/public_links/getcollectionpublink.html) précise que le lien suit les changements de la collection. Les métadonnées et fichiers exposés par cette collection sont accessibles aux détenteurs du lien : leur partage est une décision distincte du partage des manifestes chiffrés.

L'application n'utilise pas le jeton du compte principal pour éditer ses collections natives. Une écriture bidirectionnelle dans ces collections n'est donc pas offerte par cette architecture. Les listes importées peuvent être conservées et échangées au format du projet, avec indication de cette limite. Les collections système ne doivent jamais être modifiées.

## Révocation et limites

Pour couper un appareil, révoquer ses liens ; si les autres appareils les partagent, ils doivent être réappairés avec les nouveaux liens. Une clé commune divulguée doit être remplacée sur tous les appareils. Révoquer les liens n'efface ni les playlists déjà déchiffrées ni les fichiers audio téléchargés. Une nouvelle clé ne rend pas secrets les anciens manifestes déjà accessibles avec l'ancienne clé.

Les copies Android et bureau doivent rester dans les espaces privés prévus par chaque système. L'application ne peut pas assurer la confidentialité sur un appareil compromis ou dont l'utilisateur autorisé exporte volontairement les secrets.

## Quarantaine locale des morceaux

La quarantaine appartient à l'application native, avec un composant local
indépendant du greffon pCloud. Le dossier par défaut est
`~/Musique/Quarantaine-Rhythmbox`, hors de la bibliothèque et du lecteur pCloud.
Le plan liste les chemins sources, destinations et empreintes SHA-256. Le
bouton de déplacement s'active après la case de confirmation du plan.

Les liens symboliques, fichiers à liens multiples, sources situées directement
sur pCloudDrive et destinations à l'intérieur des racines protégées sont
refusés. Une source dans la copie locale de musique peut être déplacée après
confirmation : **le client pCloud peut alors propager son retrait vers le
cloud**. Le module n'appelle pas d'API de suppression pCloud. L'isolation du
dossier de destination ne supprime pas cet effet de la réplication des sources.

Les fichiers sont copiés vers des noms créés exclusivement, vérifiés, puis
retirés de leur emplacement original ; aucun fichier existant n'est écrasé.
Un journal privé permet la restauration. Celle-ci demande confirmation et
refuse de remplacer un fichier présent à son ancien emplacement. Le journal,
les exclusions et la clé d'association restent hors des dossiers synchronisés.
Les titres déplacés sont exclus des prochaines publications et imports de
playlists ; les anciennes révisions déjà présentes dans pCloud restent en place.

Les racines protégées doivent inclure toutes les copies locales synchronisées,
y compris celles d'autres outils. Le seul chemin `~/pCloudDrive` ne permet pas
de découvrir toutes les synchronisations de l'ordinateur. La destination est
revérifiée au moment de l'opération. L'export d'association Android est aussi
refusé dans ces racines.

La quarantaine et la synchronisation des listes partagent le verrou
`sync-state/.sync.lock`. Le moteur recharge les exclusions privées sous ce
verrou avant de lire les données distantes ; les écritures des préférences
préservent les exclusions courantes. Une opération interrompue laisse une
barrière de récupération persistante qui suspend la synchronisation des listes
jusqu'à restauration. Cela empêche une synchronisation démarrée avec une
ancienne configuration de réintroduire les références mises en quarantaine.
