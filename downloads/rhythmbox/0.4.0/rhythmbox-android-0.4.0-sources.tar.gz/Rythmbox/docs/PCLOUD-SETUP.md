# Préparer pCloud pour Rhythmbox et Android

Le mode principal permet de sélectionner les dossiers et gère la clé automatiquement. **Ne fournir ni mot de passe ni jeton du compte pCloud principal.** Les liens restent une option avancée.

## Où apparaissent les listes ?

Le greffon synchronise des **listes chiffrées entre Rhythmbox et le client
Android du projet**. Elles sont conservées dans le dossier d'échange sous
forme de fichiers `.rbx`. Le lecteur audio pCloud officiel ne lit pas ce
format : ces fichiers ne remplissent pas sa rubrique **Listes de lecture**.

Une liste créée dans le lecteur audio pCloud est une collection distincte,
rattachée au compte. Sa création ou sa modification dans le site pCloud
ne met pas en place une synchronisation automatique avec Rhythmbox.
Le greffon n'utilise pas de jeton donnant accès au compte complet pour la
modifier. L'import volontaire d'une collection par un lien est décrit plus
bas ; il fonctionne en lecture seule.

## Choisir les dossiers sur le PC

Le greffon **pCloud** se configure par le bouton **pCloud** du Rhythmbox
modifié, ou dans **Greffons → pCloud → Configurer**. L'interface, les pochettes,
l'analyseur et la quarantaine appartiennent à l'application et restent
utilisables sans ce greffon.

Deux dossiers ont des rôles distincts :

| Champ | Choix préparé sur ce poste | Usage |
|---|---|---|
| **Dossier musique utilisé par Rhythmbox** | `/home/denis/Musique/Bibliothèque` | Morceaux utilisés pour l'écoute et références relatives des listes |
| **Dossier des listes chiffrées** | `/home/denis/pCloudDrive/Playlists-Rhythmbox` | Échange Rhythmbox et Android ; un dossier existant déjà choisi est conservé |

La copie locale de musique est reliée à **`/Ma musique`** dans le compte,
visible dans `/home/denis/pCloudDrive/Ma musique`. Il n'y a pas de sous-dossier
`Bibliothèque` dans ce chemin distant. Cette liaison a été vérifiée dans le
client officiel.

On peut choisir la **copie locale synchronisée par pCloud**, ou le dossier
musique du lecteur pCloudDrive. La copie locale permet d'écouter sans dépendre
du montage. Le dossier des playlists est distinct de la musique et doit être
accessible par les appareils associés. Un autre dossier local convient aussi
si sa réplication pCloud a déjà été configurée séparément.

Les options repliées d'emplacements indiquent le lecteur pCloud et les autres
racines synchronisées pour protéger les exports privés et la quarantaine. Ce
chemin de protection n'est pas un deuxième choix de bibliothèque. Les valeurs
du greffon ne créent ni ne changent les liaisons du client pCloud.

Cocher les playlists voulues, puis enregistrer ou synchroniser. La clé est
générée automatiquement ; région et liens de partage restent facultatifs
dans ce mode. Rhythmbox écrit les manifestes chiffrés dans le dossier choisi.
Le client pCloud officiel assure leur transfert ; vérifier son état pour
confirmer que les fichiers ont atteint le cloud. Le greffon n'envoie aucun
fichier audio et ne parcourt pas les autres dossiers du compte.

La quarantaine se règle dans **Quarantaine → Choisir le dossier de
quarantaine…**, dans l'application. Sa destination doit rester hors de toutes
les racines synchronisées, y compris les copies locales. Si une source est
retirée d'une copie locale répliquée, le client pCloud peut propager ce retrait
vers le cloud ; le dialogue de confirmation le précise. Les déplacements
faits directement depuis le montage pCloudDrive sont refusés.

Après un déplacement ou un ajout de morceaux, utiliser **Actualiser la
bibliothèque**. Cette commande réanalyse le dossier musical ; elle est
distincte de la synchronisation des playlists.

## Une seule liste Mon top

**Mon top** reste la liste automatique de Rhythmbox : elle regroupe les
morceaux notés au moins quatre étoiles. Si elle est cochée dans le greffon,
un changement de note déclenche la synchronisation après un bref délai.
Le greffon réutilise cette liste et ne crée pas de copie « pCloud · Mon top ».

Lors d'une synchronisation, un favori ajouté sur un autre appareil devient
un favori local. Un morceau déjà noté quatre étoiles garde cette note. Le
retrait d'un favori précédemment partagé retire sa note de favori ; les
favoris locaux jamais partagés restent conservés. Une référence distante
sans fichier local accessible ne provoque aucun retrait de note. Les notes
modifiées sont sauvegardées avant application ; l'historique d'écoute et les
commentaires restent conservés.

## Associer Android sans recopier une clé

Cliquer **Associer Android…**, choisir un emplacement privé hors de pCloud pour le fichier d'association, puis le transférer au téléphone par un canal privé. Dans les réglages Android, sélectionner ce fichier avec **Associer avec le PC**, puis choisir le dossier playlists et le dossier musique avec les sélecteurs système.

Le fournisseur de fichiers Android doit rendre les dossiers disponibles au sélecteur et autoriser les opérations demandées. Si pCloud ne propose pas de dossier sélectionnable sur le téléphone, ce mode nécessite un dossier synchronisé exposé par un fournisseur compatible ; la connexion avancée par liens reste disponible. Cette limite est affichée dans l'application. Aucun essai sur téléphone n'a encore confirmé la compatibilité du fournisseur pCloud.

Le fichier d'association contient une clé privée et n'appartient pas aux playlists synchronisées. Ne pas le placer dans pCloud. Les appareils associés lisent les mêmes révisions et conservent les modifications concurrentes.

## Connexion avancée par liens

Les sections suivantes concernent uniquement cette option, repliée dans les paramètres.

## Préparer le dossier d'échange

Créer un nouveau dossier vide, par exemple `Rhythmbox-Echanges`, dédié uniquement aux manifestes chiffrés. Il est distinct des dossiers de documents et des répertoires contenant la musique en clair.

Créer un lien de lecture de ce dossier et un lien de dépôt vers ce même dossier. Les interfaces pCloud et les offres disponibles peuvent différer ; la documentation API décrit la création d'un [lien de dépôt](https://docs.pcloud.com/methods/upload_links/createuploadlink.html) vers un dossier possédé par le compte, avec limites optionnelles de taille, de nombre de fichiers et de durée.

Vérifier que les deux liens concernent le dossier vide choisi. Ne pas partager une racine, un dossier de sauvegarde ou un dossier déjà rempli de documents personnels. Ne pas rendre ce lien public dans un message ou un dépôt de sources : il donne accès à l'objet partagé à toute personne qui le possède.

Pour vérifier le périmètre, placer uniquement un objet témoin sans donnée privée dans ce dossier et confirmer sa visibilité via le lien. Les autres dossiers du compte ne doivent pas apparaître dans ce partage. Le client ne doit pas proposer une navigation vers le reste du compte.

## Appairer le bureau et Android

Choisir la région API du compte : `api.pcloud.com` pour les États-Unis ou `eapi.pcloud.com` pour l'Europe. Fournir les deux capacités dans la configuration privée prévue par le client.

Créer une clé aléatoire de 32 octets avec la fonction d'appairage du projet, puis transférer cette même clé au second appareil par un canal privé. Ne pas inventer une phrase courte comme clé et ne pas déposer la clé dans le dossier synchronisé. Le format exact de configuration et la commande d'appairage de la version livrée sont décrits par son README et son interface.

Une clé incorrecte doit produire une erreur de déchiffrement visible et ne jamais écraser une liste locale. Les deux liens ne suffisent pas à déchiffrer les playlists sans cette clé. Inversement, la clé ne donne aucun accès au compte pCloud en dehors des objets obtenus via les liens.

## Importer une liste pCloud existante

Une playlist du lecteur musical officiel pCloud est une collection native, différente d'un fichier M3U ou d'un manifeste du projet. Créer volontairement un lien vers la seule collection à importer, puis le fournir à la fonction d'import. Le [lien de collection](https://docs.pcloud.com/methods/public_links/getcollectionpublink.html) est une image à jour de cette collection et n'exige pas de jeton global pour sa consultation.

Ce partage expose les métadonnées et fichiers désignés aux détenteurs du lien. Une collection contenant des éléments qui ne doivent pas être partagés ne convient pas. Le chiffrement du dossier d'échange ne chiffre pas le contenu rendu public par un autre lien de collection.

L'import est en lecture seule pour la collection pCloud. Les modifications faites dans Rhythmbox ou Android sont échangées sous forme de manifestes chiffrés du projet ; elles ne modifient pas automatiquement la collection du lecteur pCloud officiel. Le client ne demandera pas un jeton global pour contourner cette limite.

Les collections système doivent rester intactes. Tout import incomplet ou référence devenue inaccessible doit être signalé, sans considérer silencieusement une liste partielle comme une réussite.

## Premier essai

Commencer avec une petite playlist de test, sans données sensibles. Vérifier le nombre de pistes et leur ordre sur le bureau puis sur Android. Modifier la liste sur un appareil et confirmer que l'autre récupère la nouvelle révision. Créer ensuite deux modifications concurrentes et confirmer que les deux variantes sont conservées jusqu'à résolution.

Tester une mauvaise clé et un fichier chiffré altéré : les clients doivent refuser les données. Révoquer un lien et confirmer que les prochaines requêtes échouent explicitement. Les données déjà téléchargées restent présentes sur l'appareil ; elles ne sont pas effacées par une révocation distante.

Les liens réels et un appareil Android sont nécessaires pour valider la synchronisation de bout en bout. La simple compilation ou un essai d'API simulée ne suffit pas. Voir [les garanties et limites de confidentialité](SECURITY.md) et le compte rendu de validation du projet.
