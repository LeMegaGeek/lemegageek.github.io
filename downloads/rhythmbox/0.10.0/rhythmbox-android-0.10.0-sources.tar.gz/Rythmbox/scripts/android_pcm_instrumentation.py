#!/usr/bin/env python3
"""Build an isolated synthetic PCM probe; explicit --execute is required for ADB."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile
import zipfile

from android_build import Tools, publish_file, run, write_zip_entry

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = 'fr.lemegageek.rhythmbox.pcmtest'
RUNNER = 'fr.lemegageek.rhythmbox.PcmProbeInstrumentation'
OUTPUT = ROOT / 'dist/android-pcm-test'

MANIFEST = f'''<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="{PACKAGE}" android:versionCode="1" android:versionName="isolated-pcm-test">
  <uses-sdk android:minSdkVersion="26" android:targetSdkVersion="36" />
  <application android:label="Rhythmbox · essai PCM synthétique" android:debuggable="true" android:testOnly="true" android:allowBackup="false" android:usesCleartextTraffic="false" android:theme="@android:style/Theme.Material.Light.NoActionBar">
    <activity android:name="fr.lemegageek.rhythmbox.PcmProbeActivity" android:exported="false" />
  </application>
  <instrumentation android:name="{RUNNER}" android:targetPackage="{PACKAGE}" />
</manifest>'''

ACTIVITY = '''package fr.lemegageek.rhythmbox;
public final class PcmProbeActivity extends android.app.Activity {
  @Override public void onCreate(android.os.Bundle state) {
    super.onCreate(state);android.widget.TextView text=new android.widget.TextView(this);
    text.setText("Essai PCM synthétique de Rhythmbox\\nAucun compte, réseau ou enregistrement audio.");
    text.setTextSize(20);text.setPadding(24,48,24,24);setContentView(text);
  }
}'''

INSTRUMENTATION = '''package fr.lemegageek.rhythmbox;
import android.app.*;import android.os.*;import android.media.*;import android.content.*;import org.json.*;
public final class PcmProbeInstrumentation extends Instrumentation {
  @Override public void onCreate(Bundle args){super.onCreate(args);start();}
  @Override public void onStart(){
    Activity activity=null;AudioManager audio=null;AudioFocusRequest focus=null;JSONObject report=new JSONObject();boolean ok=false;
    try{
      activity=startActivitySync(new Intent(getTargetContext(),PcmProbeActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
      audio=(AudioManager)getTargetContext().getSystemService(Context.AUDIO_SERVICE);
      int before=audio.getStreamVolume(AudioManager.STREAM_MUSIC);
      focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
        .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
        .setOnAudioFocusChangeListener(change->{}).build();
      final AudioManager manager=audio;final AudioFocusRequest request=focus;final int[] granted={0};
      runOnMainSync(()->granted[0]=manager.requestAudioFocus(request));
      if(granted[0]!=AudioManager.AUDIOFOCUS_REQUEST_GRANTED)throw new IllegalStateException("Audio focus unavailable");
      report=PcmAudioPlayerProbe.run(getTargetContext());
      int after=audio.getStreamVolume(AudioManager.STREAM_MUSIC);
      report.put("music_volume_before",before).put("music_volume_after",after).put("system_volume_unchanged",before==after);
      if(before!=after)throw new AssertionError("System volume changed during probe");
      ok=report.optBoolean("ok");
    }catch(Throwable failure){try{report.put("ok",false).put("error_type",failure.getClass().getSimpleName())
      .put("error",String.valueOf(failure.getMessage()).replace('\\n',' ').substring(0,Math.min(240,String.valueOf(failure.getMessage()).length())));}catch(Exception ignored){}}
    finally{if(audio!=null&&focus!=null)audio.abandonAudioFocusRequest(focus);if(activity!=null){final Activity done=activity;runOnMainSync(done::finish);}}
    Bundle result=new Bundle();result.putString("report",report.toString());finish(ok?Activity.RESULT_OK:Activity.RESULT_CANCELED,result);
  }
}'''


def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def build():
    tools = Tools.local()
    main = ROOT / 'android/app/src/main/java/fr/lemegageek/rhythmbox'
    sources = [main / name for name in ('StereoSpectrum.java', 'PcmAudioPlayer.java')]
    sources += [ROOT / 'android/app/src/pcmTest/java/fr/lemegageek/rhythmbox/PcmAudioPlayerProbe.java',
                ROOT / 'android/app/src/test/java/fr/lemegageek/rhythmbox/StereoSpectrumTest.java']
    hashes = {str(path.relative_to(ROOT)): sha(path) for path in sources}
    with tempfile.TemporaryDirectory(prefix='rhythmbox-pcm-probe-') as temporary:
        stage = Path(temporary)
        for name in ('classes', 'dex', 'generated'):
            (stage / name).mkdir()
        manifest = stage / 'AndroidManifest.xml'; manifest.write_text(MANIFEST)
        runner = stage / 'PcmProbeInstrumentation.java'; runner.write_text(INSTRUMENTATION)
        activity = stage / 'PcmProbeActivity.java'; activity.write_text(ACTIVITY)
        run([tools.aapt2, 'link', '--manifest', manifest, '-I', tools.platform, '--java', stage / 'generated',
             '--min-sdk-version', '26', '--target-sdk-version', '36', '-o', stage / 'resources.apk'])
        run(['javac', '--release', '8', '-Xlint:-options', '-encoding', 'UTF-8', '-classpath', tools.platform,
             '-d', stage / 'classes', *sources, runner, activity])
        dsp = run(['java', '-cp', stage / 'classes', 'fr.lemegageek.rhythmbox.StereoSpectrumTest'])
        matched = re.search(r'PASS (\d+) stereo PCM assertions', dsp)
        if not matched:
            raise RuntimeError('Pure stereo DSP checks did not return their expected result')
        run(['jar', '--create', '--file', stage / 'classes.jar', '-C', stage / 'classes', '.'])
        run([tools.directory / 'd8', '--release', '--min-api', '26', '--lib', tools.platform,
             '--output', stage / 'dex', stage / 'classes.jar'])
        unsigned = stage / 'unsigned.apk'; unsigned.write_bytes((stage / 'resources.apk').read_bytes())
        with zipfile.ZipFile(unsigned, 'a') as archive:
            for dex in sorted((stage / 'dex').glob('classes*.dex')):
                write_zip_entry(archive, dex.name, dex.read_bytes())
        run([tools.directory / 'zipalign', '-f', '-p', '4', unsigned, stage / 'aligned.apk'])
        key = stage / 'disposable-test.p12'
        run(['keytool', '-genkeypair', '-noprompt', '-storetype', 'PKCS12', '-keystore', key,
             '-storepass', 'android', '-keypass', 'android', '-alias', 'pcm-test', '-keyalg', 'RSA',
             '-keysize', '2048', '-validity', '3', '-dname', 'CN=Disposable Rhythmbox PCM probe'])
        apk = stage / 'pcm-test.apk'
        run([tools.directory / 'apksigner', 'sign', '--ks', key, '--ks-pass', 'pass:android',
             '--key-pass', 'pass:android', '--out', apk, stage / 'aligned.apk'])
        signature = run([tools.directory / 'apksigner', 'verify', '--print-certs', apk])
        certificate = re.search(r'Signer #1 certificate SHA-256 digest: ([a-fA-F0-9]{64})', signature)
        permissions = run([tools.aapt2, 'dump', 'permissions', apk])
        if not certificate or 'uses-permission:' in permissions:
            raise RuntimeError('Unexpected test certificate or requested Android permissions')
        if any(sha(ROOT / name) != value for name, value in hashes.items()):
            raise RuntimeError('PCM sources changed during probe compilation')
        OUTPUT.mkdir(parents=True, exist_ok=True)
        publish_file(apk, OUTPUT / 'pcm-test.apk')
    return {'package': PACKAGE, 'apk': str((OUTPUT / 'pcm-test.apk').relative_to(ROOT)),
            'apk_sha256': sha(OUTPUT / 'pcm-test.apk'), 'certificate_sha256': certificate.group(1).lower(),
            'source_sha256': hashes, 'host_dsp_assertions': int(matched.group(1)), 'permissions': [],
            'permissions_checked_from_apk': True, 'production_app_accessed': False,
            'network_used': False, 'global_audio_capture_used': False, 'microphone_used': False,
            'device_run': False, 'ok': True}


def execute(args, report):
    if not args.serial or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._:-]{0,127}', args.serial):
        raise ValueError('--execute requires an explicit valid --serial')
    adb = args.adb or Path.home() / 'Android/Sdk/platform-tools/adb'
    if not adb.is_file(): raise ValueError('An installed adb executable is required')
    command = [adb, '-s', args.serial]
    call = lambda *items: run([*command, *items])
    physical = call('shell', 'getprop', 'ro.kernel.qemu').strip() != '1'
    if physical and not args.allow_physical:
        raise ValueError('Physical devices require explicit --allow-physical')
    api = int(call('shell', 'getprop', 'ro.build.version.sdk').strip())
    if api < 26: raise ValueError('The native renderer requires API26 or later')
    ownership = OUTPUT / 'ownership.json'
    def installed_sha():
        query = subprocess.run([str(v) for v in [*command, 'shell', 'pm', 'path', PACKAGE]], capture_output=True, text=True, timeout=20)
        paths = [line.removeprefix('package:') for line in query.stdout.splitlines() if line.startswith('package:')]
        if not paths: return None
        if len(paths) != 1 or not paths[0].startswith('/data/app/') or not paths[0].endswith('/base.apk'):
            raise RuntimeError('Unexpected existing test-package paths')
        return call('shell', 'sha256sum', paths[0]).split()[0]
    existing = installed_sha()
    if existing:
        attested = json.loads(ownership.read_text()) if ownership.is_file() and not ownership.is_symlink() else {}
        if attested.get('serial') != args.serial or attested.get('package') != PACKAGE or attested.get('apk_sha256') != existing:
            raise RuntimeError('Existing test package is not locally attested; it was left untouched')
        if 'Success' not in call('uninstall', PACKAGE): raise RuntimeError('Owned old test package removal failed')
    installed = False
    try:
        if 'Success' not in call('install', '-t', '--no-streaming', ROOT / report['apk']):
            raise RuntimeError('Test installation failed')
        installed = True
        if installed_sha() != report['apk_sha256']: raise RuntimeError('Installed test APK hash differs')
        ownership.write_text(json.dumps(dict(package=PACKAGE, serial=args.serial,
            apk_sha256=report['apk_sha256'], certificate_sha256=report['certificate_sha256'])) + '\n')
        completed = subprocess.run([str(v) for v in [*command, 'shell', 'am', 'instrument', '-w', '-r', PACKAGE + '/' + RUNNER]],
                                   capture_output=True, text=True, timeout=100)
        match = re.search(r'^INSTRUMENTATION_RESULT: report=(\{.*\})$', completed.stdout, re.MULTILINE)
        if not match: raise RuntimeError('The isolated PCM probe returned no structured result')
        value = json.loads(match.group(1)); report.update(device_run=True, physical_device_tested=physical,
            serial=args.serial, api=api, instrumentation=value)
        report['ok'] = completed.returncode == 0 and value.get('ok') is True and 'INSTRUMENTATION_CODE: -1' in completed.stdout
    finally:
        if installed:
            if installed_sha() != report['apk_sha256']: raise RuntimeError('Test cleanup refused: APK identity changed')
            report['test_package_removed'] = 'Success' in call('uninstall', PACKAGE)
            if not report['test_package_removed']: report['ok'] = False


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true'); parser.add_argument('--serial')
    parser.add_argument('--allow-physical', action='store_true'); parser.add_argument('--adb', type=Path)
    parser.add_argument('--report', type=Path, default=ROOT / 'dist/android-pcm-native-validation.json')
    args = parser.parse_args(); report = build()
    try:
        if args.execute: execute(args, report)
    except Exception as error:
        report.update(ok=False, error_type=type(error).__name__, error=str(error)[:400])
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False, indent=2)); return 0 if report['ok'] else 1


if __name__ == '__main__': raise SystemExit(main())
