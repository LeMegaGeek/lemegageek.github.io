#!/usr/bin/env python3
"""Generate synthetic Python→Java Suno playback vectors; no provider requests."""
import base64
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from core.suno_playback import decrypt_rights, _counter_at

song = '00000000-0000-4000-8000-000000000001'
key = bytes(range(16))
iv = bytes.fromhex('01020304050607080000000000000090')
guest = 'synthetic-guest-no-provider-account'
plain = b'\x00\x00\x00\x20ftypisom' + bytes(range(256)) * 1100


def licence(vector_iv):
    wrapping = AESGCM(hashlib.sha256(guest.encode()).digest())

    def wrap(value, nonce):
        return base64.b64encode(nonce + wrapping.encrypt(nonce, value, song.encode())).decode()
    return {'glt': guest, 'key': wrap(key, b'k' * 12), 'iv': wrap(vector_iv, b'i' * 12)}


payload = licence(iv)
assert decrypt_rights(payload, song) == (key, iv)
encoder = Cipher(algorithms.AES(key), modes.CTR(iv)).encryptor()
encrypted = encoder.update(plain) + encoder.finalize()
overflow_encoder = Cipher(algorithms.AES(key), modes.CTR(b'\xff' * 16)).encryptor()
overflow_encrypted = overflow_encoder.update(plain) + overflow_encoder.finalize()
virtual_start = 4 * 1024 ** 3
virtual_plain = bytes(range(256)) * 256
virtual_counter = _counter_at(iv, virtual_start // 16, len(virtual_plain))
virtual_encoder = Cipher(algorithms.AES(key), modes.CTR(virtual_counter)).encryptor()
virtual_cipher = virtual_encoder.update(virtual_plain) + virtual_encoder.finalize()
ranges = []
for position, length in ((0, 97), (1, 53), (15, 31), (16, 32), (17, 65549),
                         (65529, 130), (65535, 65539), (131071, 66000),
                         (len(plain) - 17, 17)):
    aligned = position // 16 * 16
    counter = _counter_at(iv, aligned // 16, length + position - aligned)
    decoder = Cipher(algorithms.AES(key), modes.CTR(counter)).decryptor()
    part = decoder.update(encrypted[aligned:position + length]) + decoder.finalize()
    assert part[position - aligned:] == plain[position:position + length]
    ranges.append({'position': position, 'length': length,
                   'sha256': hashlib.sha256(plain[position:position + length]).hexdigest()})

out = Path(sys.argv[1])
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps({'song': song, 'track': {'id': 'suno:' + song,
    'stream_uri': 'https://d2lwuy8qc234o3.cloudfront.net/1/clip/' + song + '.m4a',
    'stream_encoding': '1.0.0'}, 'licence': payload, 'overflow_licence': licence(b'\xff' * 16),
    'key_hex': key.hex(), 'iv_hex': iv.hex(),
    'plaintext': base64.b64encode(plain).decode(),
    'ciphertext': base64.b64encode(encrypted).decode(),
    'virtual_page_start': virtual_start,
    'virtual_page_plaintext': base64.b64encode(virtual_plain).decode(),
    'virtual_page_ciphertext': base64.b64encode(virtual_cipher).decode(),
    'overflow_ciphertext': base64.b64encode(overflow_encrypted).decode(), 'ranges': ranges}), encoding='utf-8')
print('Suno fixture: synthetic Python licence/CTR vectors generated; no network or account')
