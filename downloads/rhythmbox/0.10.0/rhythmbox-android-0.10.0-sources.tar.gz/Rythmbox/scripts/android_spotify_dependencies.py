#!/usr/bin/python3
"""Fetch/check the exact official Spotify SDK and Gson used by Android builds.

No Spotify account, API key or client secret is needed. Archives stay in the
excluded toolchain; the lock file and this fetcher are corresponding sources.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import tempfile
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / 'android'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def dependencies(fetch=False):
    lock = json.loads((ANDROID / 'spotify-dependencies.json').read_text())
    folder = ANDROID / '.toolchain/spotify'
    if folder.is_symlink():
        raise ValueError('Dossier de dépendances Spotify symbolique refusé')
    folder.mkdir(parents=True, exist_ok=True)
    jars = []
    for item in lock['dependencies']:
        name, classes = item['name'], item['classes']
        if Path(name).name != name or Path(classes).name != classes:
            raise ValueError('Nom de dépendance Spotify invalide')
        archive = folder / name
        if archive.is_symlink():
            raise ValueError('Archive Spotify symbolique refusée')
        if not archive.is_file():
            if not fetch:
                raise ValueError('SDK Spotify absent : exécuter android/prepare-spotify.sh')
            request = urllib.request.Request(item['url'], headers={'User-Agent': 'Rhythmbox-build/0.8'})
            with urllib.request.urlopen(request, timeout=60) as source:
                content = source.read(4 * 1024 * 1024 + 1)
            if len(content) > 4 * 1024 * 1024 or digest(content) != item['sha256']:
                raise ValueError('Empreinte ou taille de dépendance Spotify invalide : ' + name)
            fd, temporary = tempfile.mkstemp(prefix='.spotify-download-', dir=folder)
            try:
                with os.fdopen(fd, 'wb') as output:
                    output.write(content)
                os.replace(temporary, archive)
            finally:
                Path(temporary).unlink(missing_ok=True)
        content = archive.read_bytes()
        if digest(content) != item['sha256']:
            raise ValueError('Empreinte de dépendance Spotify invalide : ' + name)
        target = folder / classes
        if target.is_symlink():
            raise ValueError('Classes Spotify symboliques refusées')
        if name.endswith('.aar'):
            with zipfile.ZipFile(archive) as source:
                info = source.getinfo('classes.jar')
                if info.file_size > 4 * 1024 * 1024:
                    raise ValueError('Classes Spotify trop volumineuses')
                expected = source.read(info)
            if not target.is_file() or target.read_bytes() != expected:
                target.write_bytes(expected)
        jars.append(target)
    return jars


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fetch', action='store_true')
    parser.add_argument('--classpath', action='store_true')
    arguments = parser.parse_args()
    jars = dependencies(fetch=arguments.fetch)
    print(os.pathsep.join(map(str, jars)) if arguments.classpath else 'SDK Spotify App Remote et Gson : empreintes vérifiées.')
