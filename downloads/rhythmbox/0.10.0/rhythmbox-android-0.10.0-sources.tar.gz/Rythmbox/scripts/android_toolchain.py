#!/usr/bin/python3
"""Fetch pinned official tools locally; never accept SDK licenses or alter a global SDK."""
from concurrent.futures import ThreadPoolExecutor
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import tempfile
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
CACHE = ROOT / 'android/.toolchain'
ARTIFACTS = (
    ('platform-36.zip', 'https://dl.google.com/android/repository/platform-36_r02.zip',
     '37607369a28c5b640b3a7998868d45898ebcb777565a0e85f9acf36f29631d2e', 'android-36/', 'android-36'),
    ('build-tools-36.zip', 'https://dl.google.com/android/repository/build-tools_r36_linux.zip',
     '5d9ac77fb6ff43d9da518a337b4fcf8f9097113df531d99ccefe80ef7ce8250b', 'android-16/', 'build-tools-36'),
    ('aapt2-9.5.0-16666295-linux.jar',
     'https://dl.google.com/dl/android/maven2/com/android/tools/build/aapt2/9.5.0-16666295/aapt2-9.5.0-16666295-linux.jar',
     'fa1014cb1431622d292ef55ba870e75882ea19987bec541698b912f446a2d08f', '', 'aapt2-9.5.0'),
    ('bundletool-all-1.18.3.jar',
     'https://github.com/google/bundletool/releases/download/1.18.3/bundletool-all-1.18.3.jar',
     'a099cfa1543f55593bc2ed16a70a7c67fe54b1747bb7301f37fdfd6d91028e29', None, None),
    ('json-test.jar', 'https://repo.maven.apache.org/maven2/org/json/json/20250517/json-20250517.jar',
     '3ea61b2a06e31edf1c91134fe9106b0ebb16628be169f3db75bc7a2b06b45796', None, None),
)
EMULATOR_ARTIFACTS = (
    ('emulator-linux-x64.zip', 'https://dl.google.com/android/repository/emulator-linux_x64-16696583.zip',
     '2c234e5d38a9ac2f962acd80d5b724e87373e9fc7b632b3f39f7c01f4ff81ea5', 'emulator/', 'emulator-sdk/emulator'),
    ('system-image-36-x86_64.zip', 'https://dl.google.com/android/repository/sys-img/android/x86_64-36_r02.zip',
     'e1b9d9fb665001ef27b16e57d8762a2d54aec6bff617e17506edb8676667b9da', 'x86_64/',
     'emulator-sdk/system-images/android-36/default/x86_64'),
)


def digest(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def extract_checked(archive, prefix, target):
    if target.is_symlink():
        raise ValueError('Symbolic tool destination refused')
    target.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as zipped:
        for item in zipped.infolist():
            if not item.filename.startswith(prefix):
                continue
            relative = Path(item.filename[len(prefix):])
            mode = item.external_attr >> 16
            if relative.is_absolute() or '..' in relative.parts or stat.S_ISLNK(mode):
                raise ValueError('Unsafe tool archive member')
            if not relative.parts:
                continue
            destination = target / relative
            for component in (destination, *destination.parents):
                if component.is_symlink():
                    raise ValueError('Symbolic tool extraction path refused')
                if component == target:
                    break
            if item.is_dir():
                destination.mkdir(parents=True, exist_ok=True)
            else:
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(zipped.read(item))
                destination.chmod(0o755 if mode & 0o111 else 0o644)


def fetch(item):
    name, url, checksum, prefix, target = item
    path = CACHE / name
    if path.is_symlink():
        raise ValueError('Symbolic cached tool refused')
    if not path.exists():
        fd, temporary = tempfile.mkstemp(prefix='.download-', dir=CACHE)
        try:
            with os.fdopen(fd, 'wb') as output, urllib.request.urlopen(url, timeout=120) as source:
                while chunk := source.read(1024 * 1024):
                    output.write(chunk)
            temporary = Path(temporary)
            if digest(temporary) != checksum:
                raise ValueError('Official tool checksum mismatch: ' + name)
            temporary.replace(path)
        finally:
            Path(temporary).unlink(missing_ok=True)
    if digest(path) != checksum:
        raise ValueError('Cached tool checksum mismatch: ' + name)
    if target:
        extract_checked(path, prefix, CACHE / target)
        if target.startswith('aapt2-'):
            (CACHE / target / 'aapt2').chmod(0o755)
    return {'name': name, 'url': url, 'sha256': checksum, 'bytes': path.stat().st_size}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--emulator', action='store_true', help='Also fetch the isolated AOSP API36 emulator/image (about 1.2GB)')
    args = parser.parse_args()
    if CACHE.is_symlink():
        raise ValueError('Symbolic tool cache refused')
    CACHE.mkdir(parents=True, exist_ok=True)
    with ThreadPoolExecutor(max_workers=4) as executor:
        artifacts = list(executor.map(fetch, (*ARTIFACTS, *(EMULATOR_ARTIFACTS if args.emulator else ()))))
    (CACHE / 'play-toolchain-lock.json').write_text(json.dumps({'version': 1, 'artifacts': artifacts}, indent=2) + '\n')
    print('Outils officiels vérifiés : API36, build-tools36, AAPT2 Maven et bundletool1.18.3.')


if __name__ == '__main__':
    main()
