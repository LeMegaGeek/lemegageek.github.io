#!/usr/bin/env python3
"""Isolated, package-scoped Android UI snapshot without waiting for UI idle.

Build is the default and never uses ADB. Device actions require explicit
--setup/--snapshot/--cleanup and --serial; physical devices require opt-in.
"""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile

from android_build import Tools, publish_file, run, write_zip_entry

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'dist/android-ui-test'
PACKAGE = 'fr.lemegageek.rhythmbox.uitest'
TARGET = 'fr.lemegageek.rhythmbox'
RUNNER = 'fr.lemegageek.rhythmbox.uitest.SnapshotInstrumentation'
APK = OUTPUT / 'ui-test.apk'
BUILD = OUTPUT / 'build.json'
OWNERSHIP = OUTPUT / 'ownership.json'
MANIFEST = f'''<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="{PACKAGE}" android:versionCode="1" android:versionName="isolated-ui-snapshot">
 <uses-sdk android:minSdkVersion="26" android:targetSdkVersion="36" />
 <application android:debuggable="true" android:testOnly="true" android:allowBackup="false" android:usesCleartextTraffic="false" android:label="Rhythmbox UI probe" />
 <instrumentation android:name="{RUNNER}" android:targetPackage="{PACKAGE}" />
</manifest>'''
SOURCE = r'''package fr.lemegageek.rhythmbox.uitest;
import android.app.Instrumentation;
import android.app.UiAutomation;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Base64;
import android.util.Xml;
import android.view.accessibility.AccessibilityNodeInfo;
import org.xmlpull.v1.XmlSerializer;
import java.io.StringWriter;

public final class SnapshotInstrumentation extends Instrumentation {
 private int nodes;
 private final StringWriter output = new StringWriter();
 @Override public void onCreate(Bundle args) { super.onCreate(args); start(); }
 private String value(CharSequence text) { return text == null ? "" : text.toString(); }
 private void node(XmlSerializer xml, AccessibilityNodeInfo node, int depth, boolean hidden) throws Exception {
  if (!"fr.lemegageek.rhythmbox".equals(value(node.getPackageName())))
   throw new IllegalStateException("Refused: UI subtree is outside fr.lemegageek.rhythmbox");
  if (depth > 64 || ++nodes > 10000 || output.getBuffer().length() > 8*1024*1024)
   throw new IllegalStateException("UI snapshot exceeds bounded traversal");
  hidden |= node.isPassword();
  Rect bounds = new Rect(); node.getBoundsInScreen(bounds);
  xml.startTag(null,"node");
  xml.attribute(null,"class",value(node.getClassName()));
  xml.attribute(null,"package",value(node.getPackageName()));
  xml.attribute(null,"text",hidden ? "" : value(node.getText()));
  xml.attribute(null,"content-desc",hidden ? "" : value(node.getContentDescription()));
  xml.attribute(null,"bounds",bounds.toShortString());
  xml.attribute(null,"clickable",Boolean.toString(node.isClickable()));
  xml.attribute(null,"enabled",Boolean.toString(node.isEnabled()));
  xml.attribute(null,"visible",Boolean.toString(node.isVisibleToUser()));
  xml.attribute(null,"checked",Boolean.toString(node.isChecked()));
  xml.attribute(null,"scrollable",Boolean.toString(node.isScrollable()));
  int children=node.getChildCount();
  if(children>10000-nodes) throw new IllegalStateException("UI child traversal exceeds bounds");
  for (int index=0; index<children; index++) {
   AccessibilityNodeInfo child=node.getChild(index);
   if (child!=null) try { node(xml,child,depth+1,hidden); } finally { child.recycle(); }
  }
  xml.endTag(null,"node");
 }
 @Override public void onStart() {
  Bundle result=new Bundle(); boolean ok=false; AccessibilityNodeInfo root=null;
  long started=android.os.SystemClock.elapsedRealtime();
  try {
   UiAutomation automation=getUiAutomation(UiAutomation.FLAG_DONT_SUPPRESS_ACCESSIBILITY_SERVICES);
   long connected=android.os.SystemClock.elapsedRealtime(),deadline=connected+2000;
   int attempts=0;
   do {
    attempts++; root=automation.getRootInActiveWindow();
    if(root!=null) break;
    long remaining=deadline-android.os.SystemClock.elapsedRealtime();
    if(remaining<=0) break;
    android.os.SystemClock.sleep(Math.min(100,remaining));
   } while(android.os.SystemClock.elapsedRealtime()<deadline);
   result.putBoolean("root_null",root==null);
   result.putString("root_package",root==null ? "" : value(root.getPackageName()));
   result.putInt("root_attempts",attempts);
   result.putLong("connect_ms",connected-started);
   result.putLong("root_lookup_ms",android.os.SystemClock.elapsedRealtime()-connected);
   if(root==null) throw new IllegalStateException("Refused: active root remains null");
   if (!"fr.lemegageek.rhythmbox".equals(value(root.getPackageName())))
    throw new IllegalStateException("Refused: active root belongs to another package");
   XmlSerializer xml=Xml.newSerializer(); xml.setOutput(output);
   xml.startDocument("UTF-8",true); xml.startTag(null,"hierarchy");
   node(xml,root,0,false); xml.endTag(null,"hierarchy"); xml.endDocument();
   byte[] bytes=output.toString().getBytes("UTF-8");
   if (bytes.length>8*1024*1024) throw new IllegalStateException("UI snapshot exceeds byte limit");
   result.putString("xml_base64",Base64.encodeToString(bytes,Base64.NO_WRAP));
   result.putInt("nodes",nodes); ok=true;
  } catch (Exception failure) {
   result.putString("error",failure.getClass().getSimpleName()+": "+String.valueOf(failure.getMessage()));
  } finally {
   result.putLong("elapsed_ms",android.os.SystemClock.elapsedRealtime()-started);
   if(root!=null)root.recycle();
  }
  finish(ok ? -1 : 0,result);
 }
}
'''


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build():
    if OWNERSHIP.exists():
        raise RuntimeError('Clean up the attested device probe before rebuilding it')
    tools = Tools.local()
    with tempfile.TemporaryDirectory(prefix='rhythmbox-ui-probe-') as temporary:
        stage = Path(temporary)
        for name in ('classes', 'dex', 'generated'):
            (stage / name).mkdir()
        manifest = stage / 'AndroidManifest.xml'; manifest.write_text(MANIFEST)
        source = stage / 'SnapshotInstrumentation.java'; source.write_text(SOURCE)
        run([tools.aapt2, 'link', '--manifest', manifest, '-I', tools.platform, '--java', stage / 'generated',
             '--min-sdk-version', '26', '--target-sdk-version', '36', '-o', stage / 'resources.apk'])
        run(['javac', '--release', '8', '-encoding', 'UTF-8', '-classpath', tools.platform,
             '-d', stage / 'classes', source])
        run(['jar', '--create', '--file', stage / 'classes.jar', '-C', stage / 'classes', '.'])
        run([tools.directory / 'd8', '--release', '--min-api', '26', '--lib', tools.platform,
             '--output', stage / 'dex', stage / 'classes.jar'])
        unsigned = stage / 'unsigned.apk'; unsigned.write_bytes((stage / 'resources.apk').read_bytes())
        with zipfile.ZipFile(unsigned, 'a') as archive:
            for dex in sorted((stage / 'dex').glob('classes*.dex')):
                write_zip_entry(archive, dex.name, dex.read_bytes())
        run([tools.directory / 'zipalign', '-f', '-p', '4', unsigned, stage / 'aligned.apk'])
        key = stage / 'disposable-test.p12'
        run(['keytool', '-genkeypair', '-noprompt', '-storetype', 'PKCS12', '-keystore', key,
             '-storepass', 'android', '-keypass', 'android', '-alias', 'ui-test', '-keyalg', 'RSA',
             '-keysize', '2048', '-validity', '3', '-dname', 'CN=Disposable Rhythmbox UI probe'])
        run([tools.directory / 'apksigner', 'sign', '--ks', key, '--ks-pass', 'pass:android',
             '--key-pass', 'pass:android', '--out', stage / 'ui-test.apk', stage / 'aligned.apk'])
        signature = run([tools.directory / 'apksigner', 'verify', '--print-certs', stage / 'ui-test.apk'])
        certificate = re.search(r'Signer #1 certificate SHA-256 digest: ([a-fA-F0-9]{64})', signature)
        permissions = run([tools.aapt2, 'dump', 'permissions', stage / 'ui-test.apk'])
        if not certificate or 'uses-permission:' in permissions:
            raise RuntimeError('Unexpected UI probe certificate or permissions')
        OUTPUT.mkdir(parents=True, exist_ok=True)
        publish_file(stage / 'ui-test.apk', APK)
    report = dict(package=PACKAGE, target_package=PACKAGE, observed_package=TARGET,
                  apk=str(APK.relative_to(ROOT)), apk_sha256=sha(APK),
                  certificate_sha256=certificate.group(1).lower(), sdk=36,
                  script_sha256=sha(Path(__file__)),
                  java_source_sha256=hashlib.sha256(SOURCE.encode()).hexdigest(), permissions=[], activity=False,
                  audio_focus=False, wait_for_idle=False, adb_used=False)
    BUILD.write_text(json.dumps(report, indent=2) + '\n')
    return report


def device(args):
    if not args.serial or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._:-]{0,127}', args.serial):
        raise ValueError('Device actions require an explicit valid --serial')
    adb = args.adb or Path.home() / 'Android/Sdk/platform-tools/adb'
    if not adb.is_file():
        raise ValueError('An installed ADB executable is required')
    command = [str(adb), '-s', args.serial]
    def call(*items, timeout=30, check=True):
        completed = subprocess.run([*command, *map(str, items)], capture_output=True, text=True, timeout=timeout)
        if completed.returncode and check:
            raise RuntimeError(('ADB failed: ' + completed.stderr.strip())[:400])
        return completed.stdout
    if call('shell', 'getprop', 'ro.kernel.qemu').strip() != '1' and not args.allow_physical:
        raise ValueError('Physical devices require explicit --allow-physical')
    if int(call('shell', 'getprop', 'ro.build.version.sdk').strip()) < 26:
        raise ValueError('The UI probe requires API26 or later')
    return call


def installed_sha(call):
    response = call('shell', 'pm', 'path', PACKAGE, check=False)
    paths = [line[8:] for line in response.splitlines() if line.startswith('package:')]
    if not paths:
        return None
    if len(paths) != 1 or not re.fullmatch(r'/data/app/[A-Za-z0-9_=/+.~\-]+/base\.apk', paths[0]):
        raise RuntimeError('Unexpected QA package path')
    return call('shell', 'sha256sum', paths[0]).split()[0]


def owned(call, serial):
    if not OWNERSHIP.is_file() or OWNERSHIP.is_symlink():
        raise RuntimeError('No locally attested QA installation')
    receipt = json.loads(OWNERSHIP.read_text())
    if receipt.get('serial') != serial or receipt.get('package') != PACKAGE or installed_sha(call) != receipt.get('apk_sha256'):
        raise RuntimeError('QA package identity changed; existing installation left untouched')
    return receipt


def checked_xml(xml):
    if len(xml) > 8 * 1024 * 1024:
        raise RuntimeError('QA XML exceeds byte limit')
    tree = ET.fromstring(xml)
    if tree.tag != 'hierarchy' or len(tree) != 1:
        raise RuntimeError('QA XML has an unexpected hierarchy')
    pending, count = [(tree[0], 0)], 0
    while pending:
        node, depth = pending.pop(); count += 1
        if node.tag != 'node' or node.get('package') != TARGET:
            raise RuntimeError('Refused: QA XML contains a node outside the requested application')
        if count > 10000 or depth > 64:
            raise RuntimeError('QA XML exceeds traversal bounds')
        pending.extend((child, depth + 1) for child in node)
    return xml.decode('utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_mutually_exclusive_group()
    for action in ('build', 'setup', 'snapshot', 'cleanup'):
        actions.add_argument('--' + action, action='store_true')
    parser.add_argument('--serial'); parser.add_argument('--allow-physical', action='store_true')
    parser.add_argument('--adb', type=Path)
    args = parser.parse_args()
    if not (args.setup or args.snapshot or args.cleanup):
        print(json.dumps(build(), indent=2)); return 0
    call = device(args)
    if args.setup:
        report = json.loads(BUILD.read_text())
        if sha(APK) != report.get('apk_sha256') or report.get('package') != PACKAGE:
            raise RuntimeError('QA build identity differs')
        if installed_sha(call):
            if owned(call, args.serial)['apk_sha256'] != report['apk_sha256']:
                raise RuntimeError('Installed QA artifact differs from this build; clean it up first')
        else:
            if 'Success' not in call('install', '-t', '--no-streaming', APK, timeout=60):
                raise RuntimeError('QA installation failed')
            if installed_sha(call) != report['apk_sha256']:
                raise RuntimeError('Installed QA APK differs from compiled artifact')
            OWNERSHIP.write_text(json.dumps(dict(package=PACKAGE, serial=args.serial,
                apk_sha256=report['apk_sha256'], certificate_sha256=report['certificate_sha256'])) + '\n')
        print(json.dumps(dict(package=PACKAGE, setup=True, apk_sha256=report['apk_sha256']))); return 0
    owned(call, args.serial)
    if args.cleanup:
        if 'Success' not in call('uninstall', PACKAGE):
            raise RuntimeError('Owned QA cleanup failed')
        OWNERSHIP.unlink(); print(json.dumps(dict(package=PACKAGE, removed=True))); return 0
    response = call('shell', 'am', 'instrument', '-w', '-r', PACKAGE + '/' + RUNNER, timeout=30)
    match = re.search(r'^INSTRUMENTATION_RESULT: xml_base64=([A-Za-z0-9+/=]+)\s*$', response, re.MULTILINE)
    if not match or 'INSTRUMENTATION_CODE: -1' not in response:
        error = re.search(r'^INSTRUMENTATION_RESULT: error=(.*)$', response, re.MULTILINE)
        diagnostics = {}
        for key in ('root_null', 'root_package', 'root_attempts', 'connect_ms', 'root_lookup_ms', 'elapsed_ms'):
            value = re.search(r'^INSTRUMENTATION_RESULT: ' + key + r'=(.*)$', response, re.MULTILINE)
            if value:
                diagnostics[key] = value.group(1)[:200]
        message = error.group(1) if error else 'QA snapshot returned no successful XML result'
        raise RuntimeError(message + (' ' + json.dumps(diagnostics) if diagnostics else ''))
    xml = base64.b64decode(match.group(1), validate=True)
    print(checked_xml(xml)); return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        print(str(error), file=sys.stderr); raise SystemExit(1)
