# Identité Android Rhythmbox

`launcher-master.png` est l’icône originale créée avec le générateur intégré image_gen. Le prompt exact et la provenance sont dans `PROVENANCE.json`.

`launcher-foreground.svg` et les drawables Android sont les sources vectorielles éditables de la déclinaison adaptative. Les masques cercle et carré arrondi sont pris en charge sans découper le symbole ; une déclinaison monochrome est fournie à partir d’Android13.

Les exports GooglePlay sont dans `../play/graphics/` : icône512×512 RGB et bandeau1024×500 RGB. Aucun visuel ne contient de données personnelles ni de pochette musicale de tiers.
