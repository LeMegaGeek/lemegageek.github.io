package fr.lemegageek.rhythmbox;

import java.util.Collections;

/** Folder-choice transaction regression with synthetic accounts and transport.
 * No Android profile, credential store, network, user files or device is used.
 */
public final class PCloudFolderSelectionTest {
    private static int checks;
    interface Checked { void run() throws Exception; }
    private static void yes(boolean value, String label) {
        checks++;
        if (!value) throw new AssertionError(label);
    }
    private static void reject(Checked work, String label) throws Exception {
        checks++;
        try { work.run(); } catch (Exception expected) { return; }
        throw new AssertionError("Accepted: " + label);
    }
    private static PCloudAccount account(long folder) {
        return PCloudCollectionsTest.account(folder);
    }
    private static PCloudCollections client(PCloudFolderSelection choice,
            PCloudAccount[] current, PCloudCollectionsTest.Fake fake) throws Exception {
        PCloudCollections client = new PCloudCollections(choice.candidate,
            Collections.emptySet(), Collections.emptySet(), fake);
        client.setRequestGuard(() -> choice.valid(current[0]));
        return client;
    }
    public static void main(String[] args) throws Exception {
        PCloudAccount original = account(0);
        PCloudFolderSelection first = new PCloudFolderSelection(original, 10);
        yes(first.candidate.musicFolderId == 10, "candidate requests the selected non-root folder");
        yes(original.musicFolderId == 0, "validation does not persist or mutate the original choice");
        yes(!PCloudAccount.sameAuthorization(original, first.candidate),
            "regression: old candidate-vs-store guard refuses the first folder");
        yes(first.valid(account(0)), "fresh unchanged original account authorizes candidate validation");
        yes(!first.valid(first.candidate), "candidate cannot silently replace the starting authorization");
        yes(first.candidate.userid == original.userid && first.candidate.token.equals(original.token)
                && first.candidate.email.equals(original.email)
                && first.candidate.region.equals(original.region)
                && first.candidate.clientId.equals(original.clientId)
                && first.candidate.authType.equals(original.authType),
            "candidate changes only the explicit folder scope");
        PCloudAccount[] current = { original };
        PCloudCollectionsTest.Fake fake = new PCloudCollectionsTest.Fake();
        PCloudCollections verified = client(first, current, fake);
        verified.verifyAccount();
        yes(verified.indexMusic().size() == fake.files.size(),
            "first folder index succeeds while the original authorization remains stored");
        yes(fake.calls.equals(java.util.Arrays.asList("userinfo", "listfolder")),
            "preflight verifies identity and only the explicit music folder");
        yes("10".equals(fake.parameters.get(1).get("folderid")),
            "remote request uses the candidate folder rather than root");
        yes(current[0] == original && current[0].musicFolderId == 0,
            "successful remote preflight does not save account or folder");

        PCloudFolderSelection change = new PCloudFolderSelection(account(10), 11);
        yes(change.candidate.musicFolderId == 11 && change.valid(account(10)),
            "changing an already selected folder validates against its prior choice");
        yes(!change.valid(account(11)) && !change.valid(account(12)),
            "another folder selection invalidates the old operation");
        PCloudFolderSelection same = new PCloudFolderSelection(account(10), 10);
        yes(same.valid(account(10)), "revalidating the same folder remains valid");
        reject(() -> new PCloudFolderSelection(null, 10), "missing original account rejected");
        reject(() -> new PCloudFolderSelection(original, 0), "root cannot become a candidate library");
        reject(() -> new PCloudFolderSelection(original, -1), "negative candidate rejected");

        PCloudAccount[] replacements = {
            new PCloudAccount("new-token", "music@example.test", "eu", "fixture-client", 7, 0),
            new PCloudAccount("fixture-bearer", "other@example.test", "eu", "fixture-client", 7, 0),
            new PCloudAccount("fixture-bearer", "music@example.test", "us", "fixture-client", 7, 0),
            new PCloudAccount("fixture-bearer", "music@example.test", "eu", "other-client", 7, 0),
            new PCloudAccount("fixture-bearer", "music@example.test", "eu", "", 7, 0, "direct"),
            new PCloudAccount("fixture-bearer", "music@example.test", "eu", "fixture-client", 8, 0),
            account(11), null
        };
        for (int i = 0; i < replacements.length; i++) {
            final int caseNumber = i;
            current[0] = replacements[i];
            yes(!first.valid(current[0]), "changed authorization invalidates preflight " + i);
            PCloudCollectionsTest.Fake blocked = new PCloudCollectionsTest.Fake();
            reject(() -> client(first, current, blocked).verifyAccount(),
                "changed authorization prevents the first provider request " + caseNumber);
            yes(blocked.calls.isEmpty(), "no provider request after authorization change " + i);
        }
        current[0] = original;
        PCloudCollectionsTest.Fake interrupted = new PCloudCollectionsTest.Fake();
        PCloudCollections inFlight = client(first, current, interrupted);
        inFlight.verifyAccount();
        current[0] = account(11);
        reject(inFlight::indexMusic, "competing folder change cancels between identity and index");
        yes(interrupted.calls.equals(Collections.singletonList("userinfo")),
            "cancelled candidate sends no index or collection operation");

        PCloudAccount direct = new PCloudAccount("direct-fixture", "music@example.test", "eu", "", 7, 0, "direct");
        PCloudFolderSelection directChoice = new PCloudFolderSelection(direct, 10);
        yes(directChoice.valid(new PCloudAccount("direct-fixture", "music@example.test", "eu", "", 7, 0, "direct")),
            "browser-direct authorization supports the same guarded first-folder transition");
        yes(!directChoice.valid(direct.withMusicFolder(10)),
            "direct authorization retains the original-folder CAS too");
        yes(PCloudAccount.sameAuthorization(account(0), account(0))
                && !PCloudAccount.sameAuthorization(account(0), account(10)),
            "general account equality remains strict for every other operation");
        System.out.println("PASS : " + checks + " folder-selection preflight/account-CAS assertions; synthetic accounts and transport only");
    }
}
