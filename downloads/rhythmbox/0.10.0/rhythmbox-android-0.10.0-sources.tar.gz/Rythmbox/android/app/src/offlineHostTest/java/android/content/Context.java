package android.content;
public abstract class Context {
    public Context getApplicationContext(){return this;}
    public abstract ContentResolver getContentResolver();public abstract java.io.File getNoBackupFilesDir();
    public abstract java.io.File getExternalFilesDir(String type);public abstract String getPackageName();
}
