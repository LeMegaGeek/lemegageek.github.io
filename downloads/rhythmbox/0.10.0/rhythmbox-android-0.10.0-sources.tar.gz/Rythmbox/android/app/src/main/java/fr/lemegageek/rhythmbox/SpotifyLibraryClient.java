package fr.lemegageek.rhythmbox;

import android.content.Context;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static fr.lemegageek.rhythmbox.SpotifyLibraryProtocol.*;

/** Each operation runs on the same worker, including callbacks after an activity restart. */
final class SpotifyLibraryClient {
    static final ExecutorService WORK = Executors.newSingleThreadExecutor(r -> new Thread(r,"rhythmbox-spotify-library"));
    private final SecretStore store;
    private final String clientId;

    SpotifyLibraryClient(Context context) {
        Context app=context.getApplicationContext();
        store=new SecretStore(app,"rhythmbox.spotify.library.v1","spotify-library.enc");
        int resource=app.getResources().getIdentifier("spotify_app_remote_client_id","string",app.getPackageName());
        clientId=resource==0 ? "" : app.getString(resource).trim();
    }
    static final class Status {
        final boolean authorized;
        final String error;
        Status(boolean authorized,String error){this.authorized=authorized;this.error=error;}
    }
    Status status() throws Exception {
        JSONObject record=store.load();
        return new Status(record.optJSONObject("session")!=null,record.optString("error"));
    }
    String begin() throws Exception {
        JSONObject record=store.load();
        JSONObject attempt=pending(System.currentTimeMillis());
        String url=authUrl(clientId,attempt);
        record.put("pending",attempt);
        record.remove("error");
        store.save(record);
        return url;
    }
    void accept(String callback) throws Exception {
        JSONObject record=store.load();
        JSONObject attempt=record.optJSONObject("pending");
        String code=code(callback,attempt,System.currentTimeMillis());
        record.remove("pending");
        store.save(record); // A verified return is single use, including a declined consent.
        try {
            if(code.isEmpty()) throw new Problem("Autorisation de la bibliothèque refusée.");
            JSONObject tokenReply=request(TOKEN,null,form("client_id",clientId, "grant_type","authorization_code",
                "code",code,"redirect_uri",REDIRECT,"code_verifier",attempt.getString("verifier")));
            JSONObject auth=session(tokenReply,null,System.currentTimeMillis());
            try { request(API+"/me",auth.getString("access"),null); }
            catch(HttpProblem failure) {
                if(failure.status==403) throw new Problem("Spotify n’autorise pas encore ce compte à consulter ses listes dans cette version de test.");
                throw failure;
            }
            record.put("session",auth);
            record.remove("error");
        } catch(Exception failure) {
            record.put("error",message(failure));
            store.save(record);
            throw failure;
        }
        store.save(record);
    }
    void forget() throws Exception { store.save(new JSONObject()); }

    private JSONObject refresh(JSONObject record, JSONObject auth) throws Exception {
        try {
            JSONObject reply=request(TOKEN,null,form("client_id",clientId,"grant_type","refresh_token","refresh_token",auth.getString("refresh")));
            JSONObject updated=session(reply,auth,System.currentTimeMillis());
            record.put("session",updated);
            store.save(record);
            return updated;
        } catch(HttpProblem failure) {
            if(failure.invalidGrant || failure.status==401) {
                record.remove("session");
                record.put("error","La connexion à la bibliothèque Spotify a expiré.");
                store.save(record);
            }
            throw failure;
        }
    }
    Page fetch(Query query,int offset) throws Exception {
        String url=query.url(offset);
        JSONObject record=store.load(), auth=record.optJSONObject("session");
        if(auth==null) throw new Problem("Autorisez l’accès à votre bibliothèque Spotify.");
        if(auth.getLong("expires")<=System.currentTimeMillis()+30_000L) auth=refresh(record,auth);
        JSONObject result;
        try { result=request(url,auth.getString("access"),null); }
        catch(HttpProblem failure) {
            if(failure.status!=401) throw failure;
            auth=refresh(record,auth);
            try {result=request(url,auth.getString("access"),null);}
            catch(HttpProblem retry) {
                if(retry.status==401) {
                    record.remove("session");
                    record.put("error","Reconnectez votre bibliothèque Spotify.");
                    store.save(record);
                }
                throw retry;
            }
        }
        return page(query,offset,result);
    }

    private static final class HttpProblem extends Exception {
        final int status;
        final boolean invalidGrant;
        HttpProblem(int status,boolean invalidGrant,String message){super(message);this.status=status;this.invalidGrant=invalidGrant;}
    }
    static String message(Exception failure) {
        if(failure instanceof HttpProblem || failure instanceof Problem) return failure.getMessage();
        if(failure instanceof java.io.IOException) return "Spotify est inaccessible. Vérifiez la connexion puis réessayez.";
        return "Impossible d’ouvrir la bibliothèque Spotify. Réessayez.";
    }
    private static HttpProblem rejected(HttpURLConnection connection,int status,boolean tokenEndpoint) {
        boolean invalidGrant=false;
        if(tokenEndpoint && status==400) {
            try(InputStream stream=connection.getErrorStream()) {
                if(stream!=null) invalidGrant="invalid_grant".equals(readJson(stream,8192).optString("error"));
            } catch(Exception ignored){ /* Never show a provider response body or credential. */ }
        }
        String text;
        if(invalidGrant || status==401) text="La connexion à la bibliothèque Spotify a expiré.";
        else if(status==403) text="Spotify refuse l’accès à cette bibliothèque ou à cette liste.";
        else if(status==404) text="Ce contenu Spotify est indisponible.";
        else if(status==429) {
            String seconds=connection.getHeaderField("Retry-After");
            text=seconds!=null && seconds.matches("[0-9]{1,5}") ? "Réessayez dans "+seconds+" secondes." : "Spotify reçoit trop de demandes. Réessayez plus tard.";
        } else text="Spotify n’a pas accepté la demande. Réessayez.";
        return new HttpProblem(status,invalidGrant,text);
    }
    private static JSONObject readJson(InputStream stream,int maximum) throws Exception {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        byte[] chunk=new byte[8192]; int count;
        while((count=stream.read(chunk))!=-1) {
            if(bytes.size()+count>maximum) throw invalid();
            bytes.write(chunk,0,count);
        }
        return new JSONObject(new String(bytes.toByteArray(),StandardCharsets.UTF_8));
    }
    private static JSONObject request(String url,String bearer,String body) throws Exception {
        boolean post=body!=null;
        if(post ? !TOKEN.equals(url) || bearer!=null : !url.startsWith(API+"/") || bearer==null) throw invalid();
        HttpURLConnection connection=(HttpURLConnection)new URL(url).openConnection();
        try {
            connection.setConnectTimeout(10000);connection.setReadTimeout(18000);
            connection.setInstanceFollowRedirects(false);connection.setUseCaches(false);
            connection.setRequestMethod(post?"POST":"GET");
            connection.setRequestProperty("Accept","application/json");
            if(bearer!=null) connection.setRequestProperty("Authorization","Bearer "+token(bearer));
            if(post) {
                byte[] bytes=body.getBytes(StandardCharsets.UTF_8);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
                connection.setFixedLengthStreamingMode(bytes.length);
                try(OutputStream out=connection.getOutputStream()){out.write(bytes);}
            }
            int status=connection.getResponseCode();
            if(status!=200) throw rejected(connection,status,post);
            int maximum=post?32*1024:2*1024*1024;
            if(connection.getContentLengthLong()>maximum) throw invalid();
            try(InputStream input=connection.getInputStream()){return readJson(input,maximum);}
        } finally {connection.disconnect();}
    }
}
