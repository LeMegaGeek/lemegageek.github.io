# Isolated pCloud authorization instrumentation

The self-targeted `fr.lemegageek.rhythmbox.authtest` APK compiles the actual account,
encrypted store and OAuth classes into a separate application UID. It declares
no Internet permission, activities, account providers, or shared UID. It never
loads the main application's data or changes its installation. Test identities,
tokens and verifier results are synthetic and stay within the test application.
The disposable test certificate is never an App Links association or release key.

Build only, using the pinned local Android SDK:

```sh
python3 scripts/android_auth_instrumentation.py
```

Run on the project's already booted, isolated emulator:

```sh
python3 scripts/android_auth_instrumentation.py --run --serial emulator-5580 \
  --adb /home/denis/Android/Sdk/platform-tools/adb
```

The runner only uninstalls/reinstalls its own disposable test package. The report
and source SHA-256 values are written into `android/build/pcloud-auth-test/`.
The test cleans its own encrypted records and AndroidKeyStore alias afterwards.

Coverage includes actual AndroidKeyStore AES-GCM round trips, randomized nonces,
encrypted pending state, tamper/kind binding, clear, concurrent store instances
and initial key creation, atomic music folder selection against a new login,
callback replay, state/user identity rejection, cancellation during a blocked
fake identity request, and preservation of newer requests or authorizations.

This exercises the Android implementation on an emulator. It does not test a
physical device's hardware security, a live pCloud account, or a browser OAuth
round trip; those require the approved public client ID and verified App Links.
