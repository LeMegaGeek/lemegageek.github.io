package fr.lemegageek.rhythmbox;

import org.json.JSONObject;
import java.io.Closeable;
import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.util.Collections;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

/** CDN and flight torture tests. Connections are local memory objects, never
 * URL.openConnection; all bytes and account identities are synthetic. */
public final class PCloudAudioConcurrencyTest {
    private static int checks;
    private static void yes(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    private static void await(CountDownLatch latch,String message) throws Exception {yes(latch.await(3,TimeUnit.SECONDS),message);}
    private static final class Cdn extends HttpURLConnection {
        final CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);
        final AtomicInteger disconnected=new AtomicInteger();final byte[] bytes=new byte[100];
        volatile boolean stopped;
        Cdn(URL url){super(url);for(int i=0;i<bytes.length;i++)bytes[i]=(byte)i;}
        public void connect(){}public boolean usingProxy(){return false;}
        public void disconnect(){stopped=true;disconnected.incrementAndGet();release.countDown();}
        public int getResponseCode(){return 200;}public long getContentLengthLong(){return bytes.length;}
        public void setRequestProperty(String key,String value){if("Authorization".equalsIgnoreCase(key))throw new AssertionError("Credential sent to CDN");super.setRequestProperty(key,value);}
        public InputStream getInputStream(){return new InputStream(){int position;
            public int read() throws java.io.IOException {byte[] one=new byte[1];return read(one,0,1)<0?-1:one[0]&255;}
            public int read(byte[] block,int offset,int count) throws java.io.IOException {entered.countDown();try{if(!release.await(3,TimeUnit.SECONDS))throw new java.io.IOException("Synthetic CDN timeout");}catch(InterruptedException error){Thread.currentThread().interrupt();throw new java.io.IOException(error);}if(stopped)throw new java.io.IOException("Synthetic disconnected CDN");if(position==bytes.length)return -1;int n=Math.min(count,bytes.length-position);System.arraycopy(bytes,position,block,offset,n);position+=n;return n;}
        };}
    }
    private static PCloudCollections client(PCloudCollectionsTest.Fake fake,PCloudAudioCache cache,PCloudAccount account) throws Exception {
        PCloudCollections value=PCloudCollectionsTest.client(fake);value.setIndexObserver(index->cache.observeIndex(account,index));return value;
    }
    private static void deleteTree(File directory) throws Exception {try(java.util.stream.Stream<java.nio.file.Path> files=Files.walk(directory.toPath())){java.nio.file.Path[] rows=files.sorted(java.util.Comparator.reverseOrder()).toArray(java.nio.file.Path[]::new);for(java.nio.file.Path row:rows)Files.delete(row);}}
    public static void main(String[] args) throws Exception {
        File directory=Files.createTempDirectory("rb-audio-flights-").toFile();
        try{
            PCloudAudioCache cache=new PCloudAudioCache(directory);PCloudAccount account=PCloudAudioCacheTest.account(7,10);JSONObject track=PCloudAudioCacheTest.track(101,"A.mp3");
            PCloudCollectionsTest.Fake fake=new PCloudCollectionsTest.Fake();fake.files.get(101L).put("hash","stable-original");PCloudCollections first=client(fake,cache,account);AtomicInteger connections=new AtomicInteger();AtomicReference<Cdn> cdn=new AtomicReference<>();
            first.setMediaConnections(url->{connections.incrementAndGet();Cdn value=new Cdn(url);cdn.set(value);return value;});
            AtomicReference<File> resultA=new AtomicReference<>(),resultB=new AtomicReference<>();AtomicReference<Throwable> error=new AtomicReference<>();CountDownLatch doneA=new CountDownLatch(1),doneB=new CountDownLatch(1);
            Runnable load=()->{try(Closeable flight=cache.lockDownload(account,track,new PCloudAudioCache.Cancellation())){File value=cache.find(account,track);if(value==null){PCloudCollections.DownloadedMedia media=first.downloadedMedia(track,directory,null);value=media.file;cache.remember(account,track,value,media.metadata);}if(resultA.get()==null)resultA.set(value);else resultB.set(value);}catch(Throwable failure){error.compareAndSet(null,failure);}};
            Thread owner=new Thread(()->{try{load.run();}finally{doneA.countDown();}},"synthetic-cdn-owner");owner.start();
            long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(3);while(cdn.get()==null&&System.nanoTime()<deadline)Thread.yield();yes(cdn.get()!=null,"first reference opens a synthetic CDN");await(cdn.get().entered,"first flight reaches its blocked byte read");
            Thread waiter=new Thread(()->{try{load.run();}finally{doneB.countDown();}},"synthetic-cdn-waiter");waiter.start();yes(!doneB.await(60,TimeUnit.MILLISECONDS),"same-reference waiter does not bypass the active transfer");cdn.get().release.countDown();await(doneA,"owner completes");await(doneB,"waiter rechecks the receipt after the owner commits");yes(error.get()==null,"concurrent preparations complete without errors: "+error.get());yes(resultA.get()!=null&&resultA.get().equals(resultB.get())&&connections.get()==1,"two simultaneous preparations share one original and exactly one CDN transfer");
            int links=Collections.frequency(fake.calls,"getfilelink");PCloudCollections.DownloadedMedia warm=first.downloadedMedia(track,directory,null);yes(warm.file.equals(resultA.get())&&connections.get()==1&&Collections.frequency(fake.calls,"getfilelink")==links,"same-version refreshed prefetch obtains neither CDN link nor connection");
            JSONObject moved=PCloudAudioCacheTest.copy(warm.metadata).put("media_path","Other/A.mp3");yes(!PCloudCollections.cacheName(warm.metadata,account).equals(PCloudCollections.cacheName(moved,account)),"underlying original filename also binds the normalized cloud path");
            File cancelDirectory=Files.createTempDirectory(directory.toPath(),"cancel-").toFile();PCloudAudioCache cancelCache=new PCloudAudioCache(cancelDirectory);PCloudCollections cancelling=client(new PCloudCollectionsTest.Fake(),cancelCache,account);AtomicReference<Cdn> blocked=new AtomicReference<>();cancelling.setMediaConnections(url->{Cdn value=new Cdn(url);blocked.set(value);return value;});PCloudAudioCache.Cancellation cancellation=new PCloudAudioCache.Cancellation();CountDownLatch cancelledDone=new CountDownLatch(1);AtomicReference<Throwable> cancelResult=new AtomicReference<>();
            Thread cancelled=new Thread(()->{try{cancelling.downloadedMedia(track,cancelDirectory,null,cancellation);cancelResult.set(new AssertionError("Cancelled bytes committed"));}catch(Throwable failure){cancelResult.set(failure);}finally{cancelledDone.countDown();}},"synthetic-cdn-cancel");cancelled.start();deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(3);while(blocked.get()==null&&System.nanoTime()<deadline)Thread.yield();yes(blocked.get()!=null,"cancel fixture connects");await(blocked.get().entered,"cancel fixture blocks on CDN read");cancellation.cancel();await(cancelledDone,"rapid-next cancellation disconnects blocked CDN without read timeout");yes(blocked.get().disconnected.get()>=1&&cancelResult.get() instanceof PCloudAudioCache.Cancelled,"cancellation propagates its typed result after active disconnect");File[] leftovers=cancelDirectory.listFiles(file->file.getName().endsWith(".partial")||file.getName().endsWith(".cache"));yes(leftovers!=null&&leftovers.length==0,"cancelled transfer leaves neither partial audio nor a published original");
            PCloudCollections refusing=client(new PCloudCollectionsTest.Fake(),cache,account);refusing.setIndexObserver(index->{throw new java.io.IOException("Synthetic observer failure");});try{refusing.indexMusic();throw new AssertionError("Observer failure accepted");}catch(PCloudCollections.CloudException expected){}yes(refusing.allowedCollectionIds().contains(20L),"failed cache observer preserves selection authority without exposing a partial new index");
            System.out.println("PASS: "+checks+" concurrent audio and cancellable CDN assertions; synthetic memory connections only");
        }finally{deleteTree(directory);}
    }
}
