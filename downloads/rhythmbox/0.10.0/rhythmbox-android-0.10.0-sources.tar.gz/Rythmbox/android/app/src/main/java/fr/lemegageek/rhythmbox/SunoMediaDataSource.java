package fr.lemegageek.rhythmbox;

import android.media.MediaDataSource;
import org.json.JSONObject;
import java.io.IOException;

/** Android adapter: audio is delivered directly from HTTPS/RAM to MediaPlayer.
 * No loopback server, cleartext exception, video surface or file cache. */
public final class SunoMediaDataSource extends MediaDataSource {
    private final SunoAudio audio;
    private SunoMediaDataSource(SunoAudio audio){this.audio=audio;}
    public static SunoMediaDataSource open(JSONObject track) throws IOException {return new SunoMediaDataSource(SunoAudio.open(track));}
    public static SunoMediaDataSource open(JSONObject track,SunoAudio.Cancellation cancellation) throws IOException {
        return new SunoMediaDataSource(SunoAudio.open(track,SunoAudio.httpsTransport(),cancellation));
    }
    static SunoMediaDataSource open(JSONObject track,SunoAudio.Transport transport,SunoAudio.Cancellation cancellation) throws IOException {
        return new SunoMediaDataSource(SunoAudio.open(track,transport,cancellation));
    }
    @Override public int readAt(long position,byte[] buffer,int offset,int size) throws IOException {return audio.readAt(position,buffer,offset,size);}
    @Override public long getSize() throws IOException {return audio.size();}
    @Override public void close(){audio.close();}
}
