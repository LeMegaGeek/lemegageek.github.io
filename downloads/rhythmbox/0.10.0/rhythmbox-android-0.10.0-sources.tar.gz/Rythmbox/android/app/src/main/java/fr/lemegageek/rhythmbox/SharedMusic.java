package fr.lemegageek.rhythmbox;

import java.net.URI;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** A share is a selection to preview. Trust only whole supported music URLs. */
final class SharedMusic {
    private static final Pattern REFERENCES = Pattern.compile(
            "(?:^|[\\s<(\\[\\\"“])((?:https?://|spotify:)[^\\s<>\\\"”]+)");
    final String reference;
    final boolean spotify;

    private SharedMusic(String reference, boolean spotify) {
        this.reference = reference;
        this.spotify = spotify;
    }

    static SharedMusic parse(CharSequence raw) throws Exception {
        if (raw == null || raw.length() > 8192) throw unsupported();
        Matcher candidates = REFERENCES.matcher(raw);
        SharedMusic selection = null;
        while (candidates.find()) {
            String url = candidates.group(1).replaceFirst("[)\\].,;!]+$", "");
            URI parsed;
            try { parsed = new URI(url); } catch (Exception invalid) { throw unsupported(); }
            SharedMusic item;
            if ("spotify".equals(parsed.getScheme()) || "open.spotify.com".equals(parsed.getHost())) {
                item = new SharedMusic(SpotifyUri.parse(url), true);
            } else if ("suno.com".equalsIgnoreCase(parsed.getHost())) {
                item = new SharedMusic(SunoBrowserProtocol.musicPage(url), false);
            } else {
                throw unsupported();
            }
            if (selection != null && !selection.reference.equals(item.reference)) {
                throw new IllegalArgumentException("Partager un seul morceau, album ou une seule playlist à la fois.");
            }
            selection = item;
        }
        if (selection == null) throw unsupported();
        return selection;
    }

    private static IllegalArgumentException unsupported() {
        return new IllegalArgumentException("Choisir un morceau ou une playlist depuis Spotify ou Suno.");
    }
}
