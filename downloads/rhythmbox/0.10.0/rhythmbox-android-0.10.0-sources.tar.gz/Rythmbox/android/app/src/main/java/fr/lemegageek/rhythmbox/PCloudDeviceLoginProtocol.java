package fr.lemegageek.rhythmbox;

import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Request-capability browser login, following the official pCloud Console flow.
 * Own client/device identity only; no OAuth client ID or pCloud app cookie is borrowed. */
public final class PCloudDeviceLoginProtocol {
    public static final String CLIENT_ID="rhythmbox-musique";
    /** Provider web UI's Console lifecycle mode, not the Android OS version.
     * authenticationpage.js confirms the grant on-page in this mode. */
    public static final int PROVIDER_WEB_MODE=10;
    public static final long MAX_AGE_MILLIS=15*60*1000;
    private static final int MAX_RESPONSE=1024*1024;
    public static final class Request {
        private final String requestId;
        public final String expectedEmail;
        final PCloudAccount previous;
        public final long createdMillis,expiresMillis;
        private final String browserUrl;
        private volatile boolean cancelled;
        private Grant grant;
        private Request(String id,String email,PCloudAccount previous,long created,long expires,String deviceId,String appVersion,String androidVersion) throws Exception {
            if(id==null||id.isEmpty()||id.length()>4096||!id.matches("[\\x21-\\x7e]+"))throw failure();
            this.requestId=id;this.expectedEmail=PCloudAccount.normalizedEmail(email);this.previous=previous;
            if(created<0||created>Long.MAX_VALUE-MAX_AGE_MILLIS||expires<=created)throw failure();this.createdMillis=created;this.expiresMillis=Math.min(expires,created+MAX_AGE_MILLIS);
            if(deviceId==null||!deviceId.matches("rhythmbox-android-[A-Za-z0-9_-]{43}")||appVersion==null||!appVersion.matches("[A-Za-z0-9._-]{1,64}")||androidVersion==null||androidVersion.length()>128||androidVersion.matches(".*[\\r\\n].*"))throw failure();
            Map<String,String> params=new LinkedHashMap<>();params.put("view","login");params.put("request_id",id);
            params.put("device","Rhythmbox Musique Android");params.put("deviceid",deviceId);params.put("osversion","Android "+androidVersion);
            params.put("appversion",appVersion);params.put("clientid",CLIENT_ID);params.put("lang","fr");params.put("os",Integer.toString(PROVIDER_WEB_MODE));
            this.browserUrl="https://my.pcloud.com/webview/authentication?"+form(params);
        }
        public boolean validAt(long now){return !cancelled&&now>=createdMillis&&now<expiresMillis;}
        public String browserUrl(){return browserUrl;}
        @Override public String toString(){return "PCloudDeviceRequest{capability=<redacted>}";}
    }
    public static final class Poll {
        public final PCloudAccount account;
        public final boolean pending,persistent;
        private final Grant grant;
        private Poll(PCloudAccount account,boolean pending,boolean persistent,Grant grant){this.account=account;this.pending=pending;this.persistent=persistent;this.grant=grant;}
        @Override public String toString(){return "PCloudDevicePoll{pending="+pending+", token=<redacted>}";}
    }
    private static final class Grant {
        final String token,region;final long userid;final boolean persistent;
        Grant(String token,String region,long userid,boolean persistent){this.token=token;this.region=region;this.userid=userid;this.persistent=persistent;}
    }
    /** Only sanitized phase/codes can reach the UI. Never attach raw provider/IO causes. */
    public static class LoginFailure extends IllegalStateException {
        public final String phase;public final int code;
        LoginFailure(String phase,int code){super(message(phase,code));this.phase=phase;this.code=code;}
    }
    public static final class NetworkFailure extends LoginFailure {
        NetworkFailure(String phase){super(phase,-1);}
    }
    /** Detached cleanup owns exactly one uncommitted grant; safe to run off the UI thread. */
    public static final class Cleanup implements Runnable {
        private final Grant grant;private final PCloudAccount previous;private final PCloudDirectLoginProtocol.Transport transport;
        private final java.util.concurrent.atomic.AtomicBoolean ran=new java.util.concurrent.atomic.AtomicBoolean();
        private Cleanup(Grant grant,PCloudAccount previous,PCloudDirectLoginProtocol.Transport transport){this.grant=grant;this.previous=previous;this.transport=transport;}
        public void run(){if(ran.compareAndSet(false,true))PCloudDirectLoginProtocol.revoke(grant.region,grant.token,previous,transport);}
        @Override public String toString(){return "PCloudGrantCleanup{token=<redacted>}";}
    }
    private static String message(String phase,int code){
        String detail=" (étape "+phase+(code>=0?", code "+code:"")+").";
        if(phase.equals("identity-email")||phase.equals("identity-uid"))return "Le compte choisi sur pCloud ne correspond pas au compte musical attendu. Choisis la même adresse dans pCloud et Rhythmbox."+detail;
        if(phase.equals("session-expired"))return "La demande de connexion pCloud a expiré. Recommence dans Rhythmbox."+detail;
        if(phase.equals("session"))return "La demande de connexion a été annulée ou remplacée. Recommence dans Rhythmbox."+detail;
        if(phase.endsWith("-network"))return "La connexion réseau avec pCloud est interrompue. La vérification reprendra avec la même demande."+detail;
        if(phase.equals("storage"))return "Android n’a pas pu enregistrer l’autorisation pCloud. Le compte précédent est conservé."+detail;
        if(phase.endsWith("-tls"))return "La connexion sécurisée à pCloud n’a pas pu être vérifiée."+detail;
        if(phase.equals("identity-api"))return "pCloud a refusé la vérification du compte musical. Recommence dans Rhythmbox."+detail;
        if(phase.endsWith("-api")||phase.endsWith("-http"))return "pCloud n’a pas accepté cette étape de connexion. Recommence dans Rhythmbox."+detail;
        return "La réponse de connexion pCloud n’est pas conforme à ce qui est attendu. Aucun autre compte n’a été enregistré."+detail;
    }
    private PCloudDeviceLoginProtocol(){}
    private static long integer(JSONObject value,String key,String phase) throws Exception {Object raw=value.get(key);if(!(raw instanceof Integer||raw instanceof Long))throw new LoginFailure(phase,-1);return ((Number)raw).longValue();}
    private static int safeCode(long value){return value>=0&&value<=999999?(int)value:-1;}
    public static Request begin(String email,PCloudAccount previous,String deviceId,String version,String androidVersion,long now,PCloudDirectLoginProtocol.Transport transport) throws Exception {
        try{
            String expected=PCloudAccount.normalizedEmail(email);
            JSONObject response=transport.request("eu","getrequestid",Collections.emptyMap(),null);
            long result=integer(response,"result","request-format");if(result!=0)throw new LoginFailure("request-api",safeCode(result));
            Object id=response.get("request_id"),expires=response.get("expires");if(!(id instanceof String)||!(expires instanceof String))throw new LoginFailure("request-format",-1);
            long expiry=ZonedDateTime.parse((String)expires,DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli();
            return new Request((String)id,expected,previous,now,expiry,deviceId,version,androidVersion);
        }catch(LoginFailure safe){throw safe;}
        catch(java.io.IOException ignored){throw new NetworkFailure("request-network");}
        catch(Exception ignored){throw new LoginFailure("request-format",-1);}
    }
    private static Cleanup detach(Request request,Grant expected,boolean cancel,PCloudDirectLoginProtocol.Transport transport){
        synchronized(request){
            if(cancel)request.cancelled=true;
            if(request.grant==null||(expected!=null&&request.grant!=expected))return null;
            Grant grant=request.grant;request.grant=null;return new Cleanup(grant,request.previous,transport);
        }
    }
    public static Cleanup cancel(Request request,PCloudDirectLoginProtocol.Transport transport){return request==null?null:detach(request,null,true,transport);}
    static boolean owns(Request request,Poll result){synchronized(request){return !request.cancelled&&result.grant!=null&&request.grant==result.grant;}}
    static void complete(Request request,Poll result){synchronized(request){if(request.grant==result.grant){request.grant=null;request.cancelled=true;}}}
    private static void terminal(Request request,Grant grant,PCloudDirectLoginProtocol.Transport transport){Cleanup cleanup=detach(request,grant,true,transport);if(cleanup!=null)cleanup.run();}
    /** A network interruption retains the same capability, or the unverified grant
     * if it already arrived. Identity verification then retries userinfo only. */
    public static Poll poll(Request request,long now,PCloudDirectLoginProtocol.Transport transport) throws Exception {
        if(request==null)throw new LoginFailure("session",-1);
        if(!request.validAt(now)){Cleanup cleanup=cancel(request,transport);if(cleanup!=null)cleanup.run();throw new LoginFailure("session-expired",-1);}
        Grant grant; synchronized(request){grant=request.grant;}
        String unownedToken=null,region="eu",phase=grant==null?"poll":"identity";
        try{
            if(grant==null){
                Map<String,String> params=new LinkedHashMap<>();params.put("typelogin","1");params.put("request_id",request.requestId);params.put("timeout","1");
                JSONObject response=transport.request("eu","pcloud_oauth2_token",Collections.unmodifiableMap(params),null);
                long result=integer(response,"result","poll-format");
                if(result==6002){if(response.has("token")||response.has("userid"))throw new LoginFailure("poll-format",-1);return new Poll(null,true,false,null);}
                if(result!=0)throw new LoginFailure("poll-api",safeCode(result));
                phase="grant";Object rawToken=response.get("token");if(!(rawToken instanceof String))throw new LoginFailure("grant-token",-1);
                String token=(String)rawToken;if(token.isEmpty()||token.length()>64||!token.matches("[\\x21-\\x7e]+"))throw new LoginFailure("grant-token",-1);
                unownedToken=token;
                long location=integer(response,"locationid","grant-region");if(location==1)region="us";else if(location!=0&&location!=2)throw new LoginFailure("grant-region",-1);
                long uid=integer(response,"userid","grant-uid");if(uid<=0)throw new LoginFailure("grant-uid",-1);
                boolean persistent=false;if(response.has("rememberme")){Object remember=response.get("rememberme");if(!(remember instanceof Boolean))throw new LoginFailure("grant-mode",-1);persistent=(Boolean)remember;}
                if(request.previous!=null&&request.previous.email.equals(request.expectedEmail)&&request.previous.userid!=uid)throw new LoginFailure("identity-uid",-1);
                grant=new Grant(token,region,uid,persistent);
                synchronized(request){if(request.cancelled)throw new LoginFailure("session",-1);request.grant=grant;unownedToken=null;}
            }
            phase="identity";
            JSONObject identity=transport.request(grant.region,"userinfo",Collections.singletonMap("auth",grant.token),null);
            long result=integer(identity,"result","identity-format");if(result!=0)throw new LoginFailure("identity-api",safeCode(result));
            if(integer(identity,"userid","identity-format")!=grant.userid)throw new LoginFailure("identity-uid",-1);
            if(!request.expectedEmail.equals(PCloudAccount.normalizedEmail(identity.getString("email"))))throw new LoginFailure("identity-email",-1);
            if(!request.validAt(now))throw new LoginFailure("session",-1);
            long folder=request.previous!=null&&request.previous.userid==grant.userid&&request.previous.email.equals(request.expectedEmail)&&request.previous.region.equals(grant.region)?request.previous.musicFolderId:0;
            PCloudAccount account=new PCloudAccount(grant.token,request.expectedEmail,grant.region,"",grant.userid,folder,"direct");
            return new Poll(account,false,grant.persistent,grant);
        }catch(NetworkFailure retry){throw retry;}
        catch(java.io.IOException ignored){throw new NetworkFailure(phase+"-network");}
        catch(LoginFailure safe){terminal(request,grant,transport);throw safe;}
        catch(Exception ignored){terminal(request,grant,transport);throw new LoginFailure(phase+"-format",-1);}
        finally{if(unownedToken!=null)PCloudDirectLoginProtocol.revoke(region,unownedToken,request.previous,transport);}
    }
    static LoginFailure failure(){return new LoginFailure("session",-1);}
    private static String form(Map<String,String> params) throws Exception {
        StringBuilder out=new StringBuilder();for(Map.Entry<String,String> e:params.entrySet()){if(out.length()>0)out.append('&');out.append(URLEncoder.encode(e.getKey(),"UTF-8")).append('=').append(URLEncoder.encode(e.getValue(),"UTF-8"));}return out.toString();
    }
    public static final class HttpTransport implements PCloudDirectLoginProtocol.Transport {
        interface ConnectionFactory{HttpURLConnection open(URL url) throws Exception;}
        private final ConnectionFactory connections;
        public HttpTransport(){this(url->(HttpURLConnection)url.openConnection());}
        HttpTransport(ConnectionFactory connections){this.connections=connections;}
        @Override public JSONObject request(String region,String method,Map<String,String> parameters,char[] secret) throws Exception {
            if(secret!=null||(!method.equals("getrequestid")&&!method.equals("pcloud_oauth2_token")&&!method.equals("userinfo")&&!method.equals("logout")))throw new LoginFailure("destination",-1);
            String phase=method.equals("getrequestid")?"request":method.equals("pcloud_oauth2_token")?"poll":method.equals("userinfo")?"identity":"revocation";
            String host=PCloudDirectLoginProtocol.host(region);HttpURLConnection connection=null;byte[] body=null;
            try{
                body=form(parameters).getBytes(StandardCharsets.UTF_8);connection=connections.open(new URL("https://"+host+"/"+method));
                connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(10000);connection.setReadTimeout(15000);connection.setUseCaches(false);
                connection.setRequestMethod("POST");connection.setDoOutput(true);connection.setRequestProperty("Content-Type","application/x-www-form-urlencoded");connection.setRequestProperty("Accept","application/json");connection.setRequestProperty("Cookie","");connection.setFixedLengthStreamingMode(body.length);
                try(java.io.OutputStream output=connection.getOutputStream()){output.write(body);}
                int status=connection.getResponseCode();if(status!=200)throw new LoginFailure(phase+"-http",status>=100&&status<=599?status:-1);
                if(connection.getContentLengthLong()>MAX_RESPONSE)throw new LoginFailure(phase+"-format",-1);
                try(InputStream input=connection.getInputStream();ByteArrayOutputStream output=new ByteArrayOutputStream()){
                    byte[] buffer=new byte[8192];int count;while((count=input.read(buffer))!=-1){if(output.size()+count>MAX_RESPONSE)throw new LoginFailure(phase+"-format",-1);output.write(buffer,0,count);}
                    return new JSONObject(new String(output.toByteArray(),StandardCharsets.UTF_8));
                }
            }catch(LoginFailure safe){throw safe;}
            catch(javax.net.ssl.SSLHandshakeException|javax.net.ssl.SSLPeerUnverifiedException invalidTls){throw new LoginFailure(phase+"-tls",-1);}
            catch(java.io.IOException ignored){throw new NetworkFailure(phase+"-network");}
            catch(Exception ignored){throw new LoginFailure(phase+"-format",-1);}
            finally{if(body!=null)Arrays.fill(body,(byte)0);if(connection!=null)connection.disconnect();}
        }

    }
}
