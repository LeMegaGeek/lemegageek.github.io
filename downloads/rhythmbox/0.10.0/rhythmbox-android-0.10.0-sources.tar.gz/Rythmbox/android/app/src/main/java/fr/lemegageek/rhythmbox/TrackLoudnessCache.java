package fr.lemegageek.rhythmbox;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;

/** Bounded private metadata cache. It contains no PCM, token, URI or path. */
public final class TrackLoudnessCache {
    private static final int MAX_ENTRIES=256,MAX_BYTES=262144;
    private final File file;
    public TrackLoudnessCache(File privateDirectory){file=new File(privateDirectory,"track-loudness-v1.json");}
    private JSONArray read() throws Exception {
        if(!file.isFile())return new JSONArray();
        if(Files.isSymbolicLink(file.toPath())||file.length()>MAX_BYTES)throw new IllegalArgumentException("Cache invalide");
        JSONObject value=new JSONObject(new String(Files.readAllBytes(file.toPath()),StandardCharsets.UTF_8));
        if(!TrackLoudness.ALGORITHM.equals(value.getString("algorithm")))return new JSONArray();
        JSONArray entries=value.getJSONArray("entries");if(entries.length()>MAX_ENTRIES)throw new IllegalArgumentException("Cache trop grand");return entries;
    }
    private static void key(String key){if(key==null||!key.matches("[a-f0-9]{64}"))throw new IllegalArgumentException("Identité de mesure invalide");}
    public synchronized TrackLoudness.Result get(String key){
        key(key);try{JSONArray entries=read();for(int i=entries.length()-1;i>=0;i--){JSONObject row=entries.getJSONObject(i);if(key.equals(row.optString("key"))){
            return new TrackLoudness.Result(row.getInt("rate"),row.getInt("channels"),row.getLong("frames"),row.getDouble("lufs"),row.getDouble("peak"),true);
        }}}catch(Exception unusable){/* Re-measure; an optional cache never grants audio access. */}return null;
    }
    public synchronized void put(String key,TrackLoudness.Result result) throws Exception {
        key(key);if(result==null||!result.measured)return;
        JSONArray prior;try{prior=read();}catch(Exception unusable){prior=new JSONArray();}
        JSONArray entries=new JSONArray();for(int i=Math.max(0,prior.length()-MAX_ENTRIES+1);i<prior.length();i++){
            JSONObject row=prior.optJSONObject(i);if(row!=null&&!key.equals(row.optString("key")))entries.put(row);
        }
        entries.put(new JSONObject().put("key",key).put("rate",result.sampleRate).put("channels",result.channels)
            .put("frames",result.frames).put("lufs",result.integratedLufs).put("peak",result.peak));
        byte[] bytes=new JSONObject().put("algorithm",TrackLoudness.ALGORITHM).put("entries",entries).toString().getBytes(StandardCharsets.UTF_8);
        if(bytes.length>MAX_BYTES||Files.isSymbolicLink(file.toPath()))throw new IllegalArgumentException("Cache invalide");
        File temporary=File.createTempFile(".loudness-",".tmp",file.getParentFile());
        try{temporary.setReadable(false,false);temporary.setWritable(false,false);temporary.setReadable(true,true);temporary.setWritable(true,true);
            try(FileOutputStream output=new FileOutputStream(temporary)){output.write(bytes);output.getFD().sync();}
            Files.move(temporary.toPath(),file.toPath(),StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);
        }finally{temporary.delete();}
    }
    public static String fileKey(File source) throws Exception {
        if(source==null||!source.isFile()||Files.isSymbolicLink(source.toPath()))throw new IllegalArgumentException("Source audio indisponible");
        java.nio.file.attribute.BasicFileAttributes attributes=Files.readAttributes(source.toPath(),java.nio.file.attribute.BasicFileAttributes.class);
        MessageDigest digest=MessageDigest.getInstance("SHA-256");
        digest.update((TrackLoudness.ALGORITHM+"\n"+source.getCanonicalPath()+"\n"+attributes.fileKey()+"\n"+
            attributes.size()+"\n"+attributes.lastModifiedTime().toMillis()).getBytes(StandardCharsets.UTF_8));
        // Bounded content checks also invalidate replaced/imported cache files
        // whose size and coarse timestamp happen to coincide.
        try(RandomAccessFile input=new RandomAccessFile(source,"r")){
            byte[] bytes=new byte[65536];int count=input.read(bytes);if(count>0)digest.update(bytes,0,count);
            if(input.length()>65536){input.seek(Math.max(65536,input.length()-65536));count=input.read(bytes);if(count>0)digest.update(bytes,0,count);}
            java.util.Arrays.fill(bytes,(byte)0);
        }
        StringBuilder out=new StringBuilder();for(byte b:digest.digest())out.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return out.toString();
    }
}
