package fr.lemegageek.rhythmbox;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaDataSource;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;

/** Native mono/stereo renderer. Spectrum measurements come only from accepted writes. */
public final class PcmAudioPlayer implements AutoCloseable {
    public static final class UnsupportedAudioException extends IOException {
        public UnsupportedAudioException(String message) { super(message); }
        public UnsupportedAudioException(String message, Throwable cause) { super(message, cause); }
    }

    public interface Source { OpenedSource open() throws Exception; }
    public interface OnPreparedListener { void onPrepared(PcmAudioPlayer player); }
    public interface OnCompletionListener { void onCompletion(PcmAudioPlayer player); }
    public interface OnSeekCompleteListener { void onSeekComplete(PcmAudioPlayer player); }
    public interface OnErrorListener { void onError(PcmAudioPlayer player, Exception error); }

    public static final class OpenedSource implements AutoCloseable {
        public final MediaExtractor extractor;
        private final AutoCloseable owner;
        private final AtomicBoolean resourceClosed = new AtomicBoolean();
        public OpenedSource(MediaExtractor extractor, AutoCloseable owner) {
            if (extractor == null) throw new NullPointerException("extractor");
            this.extractor = extractor;
            this.owner = owner;
        }
        private void closeOwner() {
            if (owner != null && resourceClosed.compareAndSet(false, true))
                try { owner.close(); } catch (Exception ignored) { }
        }
        @Override public void close() {
            try { extractor.release(); } finally { closeOwner(); }
        }
    }

    public static Source file(File file) {
        if (file == null) throw new NullPointerException("file");
        return () -> {
            MediaExtractor extractor = new MediaExtractor();
            FileInputStream input = null;
            try {
                input = new FileInputStream(file);
                extractor.setDataSource(input.getFD());
                return new OpenedSource(extractor, input);
            } catch (Exception failure) {
                extractor.release();
                if (input != null) try { input.close(); } catch (IOException ignored) { }
                throw failure;
            }
        };
    }

    public static Source uri(Context context, Uri uri) {
        if (context == null || uri == null) throw new NullPointerException();
        if (!"content".equals(uri.getScheme()) && !"file".equals(uri.getScheme()))
            throw new IllegalArgumentException("Une source locale autorisée est requise");
        Context application = context.getApplicationContext();
        return () -> {
            MediaExtractor extractor = new MediaExtractor();
            try {
                extractor.setDataSource(application, uri, null);
                return new OpenedSource(extractor, null);
            } catch (Exception failure) { extractor.release(); throw failure; }
        };
    }

    /** Ownership is transferred to this player and ends when it is released. */
    public static Source mediaDataSource(MediaDataSource source) {
        return dataSource(source, true);
    }

    /** The caller retains ownership, including across a decoder fallback. */
    public static Source borrowedMediaDataSource(MediaDataSource source) {
        return dataSource(source, false);
    }

    private static Source dataSource(MediaDataSource source, boolean owned) {
        if (source == null) throw new NullPointerException("source");
        return () -> {
            MediaExtractor extractor = new MediaExtractor();
            MediaDataSource borrowed = new MediaDataSource() {
                @Override public int readAt(long at, byte[] data, int offset, int size) throws IOException {
                    return source.readAt(at, data, offset, size);
                }
                @Override public long getSize() throws IOException { return source.getSize(); }
                @Override public void close() { }
            };
            try {
                extractor.setDataSource(borrowed);
                return new OpenedSource(extractor, owned ? source : null);
            } catch (Exception failure) {
                extractor.release();
                if (owned) try { source.close(); } catch (IOException ignored) { }
                throw failure;
            }
        };
    }

    private final Object lock = new Object();
    private final Source source;
    private final Handler callbacks = new Handler(Looper.getMainLooper());
    private volatile AudioTrack output;
    private volatile OpenedSource opened;
    private volatile StereoSpectrum spectrum;
    private OnPreparedListener onPrepared;
    private OnCompletionListener onCompletion;
    private OnSeekCompleteListener onSeek;
    private OnErrorListener onError;
    private boolean preparing, prepared, preparedCallbackDone, playing, completed, terminated, released;
    private int generation;
    private long seekUs = -1, seekSequence, segmentStartUs, writtenFrames, headWraps, previousHead;
    private int sampleRate, channels, encoding, durationMs, reportedPositionMs;
    private float leftVolume = 1, rightVolume = 1;
    private PowerManager.WakeLock wakeLock;
    private AudioAttributes attributes = new AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();

    public PcmAudioPlayer(Source source) {
        if (source == null) throw new NullPointerException("source");
        this.source = source;
    }

    public void setOnPreparedListener(OnPreparedListener listener) { synchronized (lock) { onPrepared = listener; } }
    public void setOnCompletionListener(OnCompletionListener listener) { synchronized (lock) { onCompletion = listener; } }
    public void setOnSeekCompleteListener(OnSeekCompleteListener listener) { synchronized (lock) { onSeek = listener; } }
    public void setOnErrorListener(OnErrorListener listener) { synchronized (lock) { onError = listener; } }
    public void setAudioAttributes(AudioAttributes attributes) {
        if (attributes == null) throw new NullPointerException();
        synchronized (lock) {
            if (preparing) throw new IllegalStateException("Préparation déjà commencée");
            this.attributes = attributes;
        }
    }

    public void setWakeMode(Context context, int mode) {
        synchronized (lock) {
            releaseWake();
            PowerManager power = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            wakeLock = power.newWakeLock(mode, "Rhythmbox:pcm-playback");
            wakeLock.setReferenceCounted(false);
            if (playing && preparedCallbackDone) acquireWake();
        }
    }

    public void prepareAsync() {
        final int request;
        synchronized (lock) {
            if (preparing || terminated) throw new IllegalStateException("Lecteur déjà préparé ou fermé");
            preparing = true;
            request = generation;
        }
        Thread decoder = new Thread(() -> decode(request), "rhythmbox-pcm-renderer");
        decoder.start();
    }

    public void start() {
        synchronized (lock) {
            if (terminated) throw new IllegalStateException("Lecteur fermé");
            if (completed) { seekUs = 0; seekSequence++; completed = false; }
            playing = true;
            if (preparedCallbackDone && output != null) { output.play(); acquireWake(); }
            lock.notifyAll();
        }
    }

    public void pause() {
        synchronized (lock) {
            // A device playback head can settle asynchronously after pause().
            // Freeze the last playing position before asking the HAL to pause.
            getCurrentPosition();
            playing = false;
            if (output != null) try { output.pause(); } catch (IllegalStateException ignored) { }
            releaseWake();
            lock.notifyAll();
        }
    }

    public void seekTo(int milliseconds) {
        synchronized (lock) {
            if (terminated) return;
            int target = Math.max(0, durationMs > 0 ? Math.min(durationMs, milliseconds) : milliseconds);
            seekUs = target * 1000L;
            seekSequence++;
            completed = false;
            reportedPositionMs = target;
            lock.notifyAll();
        }
    }

    public boolean isPlaying() {
        synchronized (lock) {
            return !terminated && preparedCallbackDone && playing && !completed && output != null
                && output.getPlayState() == AudioTrack.PLAYSTATE_PLAYING;
        }
    }
    public int getDuration() { synchronized (lock) { return durationMs; } }
    public int getAudioSessionId() { synchronized (lock) { return output == null ? 0 : output.getAudioSessionId(); } }
    public int getCurrentPosition() {
        synchronized (lock) {
            if (seekUs >= 0 || !playing) return reportedPositionMs;
            if (output != null && sampleRate > 0) {
                long position = segmentStartUs / 1000 + playedFrames() * 1000 / sampleRate;
                reportedPositionMs = (int) Math.min(Integer.MAX_VALUE, Math.max(0,
                    durationMs > 0 ? Math.min(durationMs, position) : position));
            }
            return reportedPositionMs;
        }
    }
    public void setVolume(float left, float right) {
        if (!Float.isFinite(left) || !Float.isFinite(right)) throw new IllegalArgumentException("Volume invalide");
        synchronized (lock) {
            leftVolume = Math.max(0, Math.min(1, left));
            rightVolume = Math.max(0, Math.min(1, right));
            if (output != null && output.setStereoVolume(leftVolume, rightVolume) != AudioTrack.SUCCESS)
                throw new IllegalStateException("Réglage du volume PCM indisponible");
        }
    }
    public StereoSpectrum.Snapshot getSpectrum() {
        synchronized (lock) {
            if (terminated || !playing || !preparedCallbackDone || completed || seekUs >= 0 || spectrum == null)
                return StereoSpectrum.Snapshot.unavailable();
            return spectrum.atFrame(playedFrames());
        }
    }

    public void stop() { terminate(false); }
    public void release() { terminate(true); }
    @Override public void close() { release(); }
    private void terminate(boolean release) {
        final OpenedSource current;
        synchronized (lock) {
            if (released || (terminated && !release)) return;
            getCurrentPosition();
            terminated = true;
            released |= release;
            generation++;
            playing = false;
            if (output != null) {
                try { output.pause(); output.flush(); } catch (IllegalStateException ignored) { }
            }
            releaseWake();
            current = opened;
            lock.notifyAll();
        }
        // Closing an owned network source may unblock a native read. Never do
        // its I/O on the UI thread, and never close a borrowed Suno source here.
        if (current != null) new Thread(current::closeOwner, "pcm-source-close").start();
    }

    private void acquireWake() { if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire(); }
    private void releaseWake() { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); }
    private void check(int request) throws InterruptedException {
        synchronized (lock) { if (terminated || generation != request) throw new InterruptedException(); }
    }
    private long playedFrames() {
        if (output == null) return 0;
        long head;
        try { head = Integer.toUnsignedLong(output.getPlaybackHeadPosition()); }
        catch (IllegalStateException gone) { return previousHead + (headWraps << 32); }
        if (head < previousHead) headWraps++;
        previousHead = head;
        return Math.min(writtenFrames, head + (headWraps << 32));
    }

    private void decode(int request) {
        MediaCodec codec = null;
        OpenedSource current = null;
        boolean started = false;
        Exception failure = null;
        try {
            current = source.open();
            synchronized (lock) { opened = current; }
            check(request);
            MediaExtractor extractor = current.extractor;
            MediaFormat input = null;
            int selected = -1;
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat candidate = extractor.getTrackFormat(i);
                String mime = candidate.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) { input = candidate; selected = i; break; }
            }
            if (selected < 0) throw new UnsupportedAudioException("Aucune piste audio native disponible");
            if (!input.containsKey(MediaFormat.KEY_CHANNEL_COUNT))
                throw new UnsupportedAudioException("Disposition des canaux non annoncée");
            int inputChannels = input.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            if (inputChannels != 1 && inputChannels != 2)
                throw new UnsupportedAudioException("Analyseur disponible pour les pistes mono et stéréo");
            synchronized (lock) {
                long duration = input.containsKey(MediaFormat.KEY_DURATION) ? input.getLong(MediaFormat.KEY_DURATION) : 0;
                durationMs = (int) Math.min(Integer.MAX_VALUE, Math.max(0, duration / 1000));
            }
            extractor.selectTrack(selected);
            try {
                codec = MediaCodec.createDecoderByType(input.getString(MediaFormat.KEY_MIME));
                codec.configure(input, null, null, 0);
                codec.start();
                started = true;
            } catch (Exception unavailable) {
                throw new UnsupportedAudioException("Ce codec nécessite le lecteur de compatibilité", unavailable);
            }
            boolean inputEnded = false, outputEnded = false;
            long discardBeforeUs = 0;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            while (true) {
                check(request);
                long target = -1, sequence = -1;
                synchronized (lock) {
                    if (prepared && seekUs >= 0) {
                        target = seekUs; seekUs = -1; sequence = seekSequence;
                    } else if (prepared && (!preparedCallbackDone || !playing || completed)) {
                        lock.wait();
                        continue;
                    }
                }
                if (target >= 0) {
                    synchronized (lock) {
                        output.pause(); output.flush();
                        spectrum.reset(); writtenFrames = 0; previousHead = 0; headWraps = 0;
                        segmentStartUs = target;
                        reportedPositionMs = (int) Math.min(Integer.MAX_VALUE, target / 1000);
                    }
                    codec.flush();
                    extractor.seekTo(target, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
                    discardBeforeUs = target;
                    inputEnded = false; outputEnded = false;
                    final long notifiedSequence = sequence;
                    callbacks.post(() -> {
                        OnSeekCompleteListener listener;
                        synchronized (lock) {
                            if (terminated || generation != request || notifiedSequence != seekSequence) return;
                            listener = onSeek;
                        }
                        if (listener != null) listener.onSeekComplete(this);
                    });
                    synchronized (lock) { if (playing && preparedCallbackDone) output.play(); }
                    continue;
                }
                if (outputEnded) {
                    if (!prepared) throw new UnsupportedAudioException("Aucun échantillon audio décodé");
                    boolean drained;
                    synchronized (lock) {
                        // Pause/seek must not interleave the drain decision and
                        // completion, or turn a paused/obsolete segment into EOS.
                        if (terminated || generation != request || !playing || seekUs >= 0) continue;
                        drained = playedFrames() >= writtenFrames;
                        if (drained) {
                            reportedPositionMs = getCurrentPosition();
                            completed = true; playing = false; output.pause(); releaseWake();
                        }
                    }
                    if (drained) {
                        callbacks.post(() -> {
                            OnCompletionListener listener;
                            synchronized (lock) {
                                if (terminated || generation != request || !completed) return;
                                listener = onCompletion;
                            }
                            if (listener != null) listener.onCompletion(this);
                        });
                    } else Thread.sleep(5);
                    continue;
                }
                if (!inputEnded) {
                    int slot = codec.dequeueInputBuffer(10000);
                    if (slot >= 0) {
                        ByteBuffer compressed = codec.getInputBuffer(slot);
                        if (compressed == null) throw new IOException("Décodeur audio indisponible");
                        compressed.clear();
                        int size = extractor.readSampleData(compressed, 0);
                        if (size < 0) {
                            codec.queueInputBuffer(slot, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputEnded = true;
                        } else {
                            if ((extractor.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_ENCRYPTED) != 0)
                                throw new UnsupportedAudioException("Piste protégée non analysable");
                            codec.queueInputBuffer(slot, 0, size, Math.max(0, extractor.getSampleTime()), 0);
                            extractor.advance();
                        }
                    }
                }
                int slot = codec.dequeueOutputBuffer(info, 10000);
                if (slot == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    configureOutput(codec.getOutputFormat(), request);
                } else if (slot >= 0) {
                    try {
                        if (info.size > 0 && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                            ByteBuffer pcm = codec.getOutputBuffer(slot);
                            if (pcm == null || info.offset < 0 || info.size < 0 || info.size > 8 * 1024 * 1024 ||
                                (long) info.offset + info.size > pcm.capacity())
                                throw new IOException("Bloc PCM invalide");
                            int stride = channels * (encoding == AudioFormat.ENCODING_PCM_FLOAT ? 4 : 2);
                            if (!prepared || info.size % stride != 0)
                                throw new UnsupportedAudioException("Disposition PCM non prise en charge");
                            long trim = info.presentationTimeUs < discardBeforeUs
                                ? Math.min(info.size / stride, (long) Math.ceil((discardBeforeUs - info.presentationTimeUs) * sampleRate / 1_000_000.0)) : 0;
                            pcm.position(info.offset + (int) trim * stride);
                            pcm.limit(info.offset + info.size);
                            synchronized (lock) {
                                if (writtenFrames == 0 && pcm.hasRemaining())
                                    segmentStartUs = Math.max(discardBeforeUs, info.presentationTimeUs + trim * 1_000_000 / sampleRate);
                            }
                            write(pcm, stride, request);
                        }
                    } finally { codec.releaseOutputBuffer(slot, false); }
                    outputEnded = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                }
            }
        } catch (InterruptedException cancelled) {
            Thread.currentThread().interrupt();
        } catch (Exception error) { failure = error; }
        finally {
            if (codec != null) {
                if (started) try { codec.stop(); } catch (Exception ignored) { }
                codec.release();
            }
            synchronized (lock) {
                if (!terminated) getCurrentPosition();
                playing = false;
                releaseWake();
                if (output != null) { output.release(); output = null; }
                opened = null;
            }
            if (current != null) try { current.close(); } catch (Exception ignored) { }
        }
        if (failure != null) {
            final Exception error = failure;
            callbacks.post(() -> {
                OnErrorListener listener;
                synchronized (lock) {
                    if (terminated || generation != request) return;
                    listener = onError;
                }
                if (listener != null) listener.onError(this, error);
            });
        }
    }

    private void configureOutput(MediaFormat format, int request) throws Exception {
        if (!format.containsKey(MediaFormat.KEY_SAMPLE_RATE) || !format.containsKey(MediaFormat.KEY_CHANNEL_COUNT))
            throw new UnsupportedAudioException("Format PCM non annoncé");
        int rate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE);
        int count = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
        int pcm = format.containsKey(MediaFormat.KEY_PCM_ENCODING)
            ? format.getInteger(MediaFormat.KEY_PCM_ENCODING) : AudioFormat.ENCODING_PCM_16BIT;
        if (rate < 8000 || rate > 192000 || (count != 1 && count != 2) ||
            (pcm != AudioFormat.ENCODING_PCM_16BIT && pcm != AudioFormat.ENCODING_PCM_FLOAT))
            throw new UnsupportedAudioException("Format PCM non pris en charge par l’analyseur");
        synchronized (lock) {
            if (prepared) {
                if (rate != sampleRate || count != channels || pcm != encoding)
                    throw new UnsupportedAudioException("Le format PCM change pendant la piste");
                return;
            }
            check(request);
            int mask = count == 1 ? AudioFormat.CHANNEL_OUT_MONO : AudioFormat.CHANNEL_OUT_STEREO;
            if (format.containsKey(MediaFormat.KEY_CHANNEL_MASK)) {
                int declaredMask = format.getInteger(MediaFormat.KEY_CHANNEL_MASK);
                if (declaredMask != 0 && declaredMask != mask)
                    throw new UnsupportedAudioException("Disposition PCM non prise en charge");
            }
            int minimum = AudioTrack.getMinBufferSize(rate, mask, pcm);
            if (minimum <= 0) throw new UnsupportedAudioException("Sortie PCM indisponible");
            int stride = count * (pcm == AudioFormat.ENCODING_PCM_FLOAT ? 4 : 2);
            int size = Math.max(minimum, Math.min(1024 * 1024, rate * stride / 10));
            size += (stride - size % stride) % stride;
            try {
                output = new AudioTrack.Builder().setAudioAttributes(attributes)
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate)
                        .setChannelMask(mask).setEncoding(pcm).build())
                    .setTransferMode(AudioTrack.MODE_STREAM).setBufferSizeInBytes(size).build();
                if (output.getState() != AudioTrack.STATE_INITIALIZED || output.getAudioSessionId() <= 0)
                    throw new IllegalStateException();
                if (output.setStereoVolume(leftVolume, rightVolume) != AudioTrack.SUCCESS)
                    throw new IllegalStateException();
            } catch (Exception unavailable) {
                throw new UnsupportedAudioException("Sortie PCM incompatible", unavailable);
            }
            sampleRate = rate; channels = count; encoding = pcm;
            spectrum = new StereoSpectrum(rate, count);
            prepared = true;
        }
        callbacks.post(() -> {
            OnPreparedListener listener;
            synchronized (lock) {
                if (terminated || generation != request) return;
                listener = onPrepared;
            }
            try { if (listener != null) listener.onPrepared(this); }
            finally {
                synchronized (lock) {
                    preparedCallbackDone = true;
                    if (!terminated && playing && output != null) { output.play(); acquireWake(); }
                    lock.notifyAll();
                }
            }
        });
    }

    private void write(ByteBuffer pcm, int stride, int request) throws Exception {
        while (pcm.hasRemaining()) {
            check(request);
            synchronized (lock) {
                if (seekUs >= 0) return;
                if (!preparedCallbackDone || !playing) { lock.wait(); continue; }
                if (output.getPlayState() != AudioTrack.PLAYSTATE_PLAYING) output.play();
            }
            int before = pcm.position();
            int size = Math.min(pcm.remaining(), 4096 * stride);
            if (encoding == AudioFormat.ENCODING_PCM_FLOAT) {
                ByteBuffer checked = pcm.duplicate().order(java.nio.ByteOrder.LITTLE_ENDIAN);
                checked.limit(before + size);
                while (checked.hasRemaining())
                    if (!Float.isFinite(checked.getFloat())) throw new IOException("Échantillon PCM invalide");
            }
            int accepted = output.write(pcm, size, AudioTrack.WRITE_NON_BLOCKING);
            if (accepted < 0) throw new IOException("La sortie audio a été interrompue");
            if (accepted == 0) { Thread.sleep(5); continue; }
            if (accepted % stride != 0) throw new IOException("Écriture PCM incomplète");
            ByteBuffer measured = pcm.duplicate();
            measured.position(before); measured.limit(before + accepted);
            if (encoding == AudioFormat.ENCODING_PCM_FLOAT) spectrum.acceptPcmFloat(measured);
            else spectrum.acceptPcm16(measured);
            synchronized (lock) { writtenFrames += accepted / stride; }
        }
    }
}
