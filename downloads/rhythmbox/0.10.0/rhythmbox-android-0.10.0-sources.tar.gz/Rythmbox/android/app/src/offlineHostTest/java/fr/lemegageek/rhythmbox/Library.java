package fr.lemegageek.rhythmbox;
/** Synthetic playlist source; never opens a real library/profile. */
public final class Library {
    public static org.json.JSONObject synthetic;public final org.json.JSONObject state;
    public Library(android.content.Context context){state=synthetic;}public String fingerprint(){return "synthetic";}public String currentFingerprint(){return "synthetic";}
}
