package fr.lemegageek.rhythmbox;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.Locale;
import java.util.function.Supplier;

/** Displays measured source PCM only; it never generates motion without data. */
public final class StereoSpectrumView extends View {
    private static final int CARD = 0xff1c2635, TEXT = 0xfff3f7fd, MUTED = 0xffb4c3d7;
    private static final int LEFT = 0xff81e6c8, RIGHT = 0xffc5a4ff, TRACK = 0xff304154;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Paint title = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint caption = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint metric = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint axis = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bars = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rectangle = new RectF();
    private Supplier<StereoSpectrum.Snapshot> source;
    private Supplier<String> statusSource;
    private StereoSpectrum.Snapshot snapshot = StereoSpectrum.Snapshot.unavailable();
    private float[] left = new float[StereoSpectrum.BAND_COUNT], right = new float[StereoSpectrum.BAND_COUNT];
    private String status = "Analyseur en attente";
    private boolean active, attached, scheduled;

    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            scheduled = false;
            if (!shouldRefresh()) return;
            capture();
            invalidate();
            schedule();
        }
    };

    public StereoSpectrumView(Context context) { this(context, null); }
    public StereoSpectrumView(Context context, AttributeSet attributes) { super(context, attributes); initialize(); }

    private float dp(float value) { return value * getResources().getDisplayMetrics().density; }
    private float sp(float value) { return value * getResources().getDisplayMetrics().scaledDensity; }

    private void initialize() {
        setFocusable(true);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);
        setAccessibilityLiveRegion(ACCESSIBILITY_LIVE_REGION_NONE);
        setContentDescription("Analyseur stéréo. Signal source avant le traitement du niveau. " +
            "Canaux gauche et droit mesurés séparément.");
        title.setColor(TEXT); title.setTextSize(sp(13)); title.setTypeface(Typeface.DEFAULT_BOLD);
        caption.setColor(MUTED); caption.setTextSize(sp(11));
        metric.setColor(MUTED); metric.setTextSize(sp(10));
        axis.setColor(MUTED); axis.setTextSize(sp(10));
        setMinimumHeight((int) dp(140));
    }

    public void setSource(Supplier<StereoSpectrum.Snapshot> source, Supplier<String> statusSource) {
        onMain(() -> {
            this.source = source;
            this.statusSource = statusSource;
            snapshot = StereoSpectrum.Snapshot.unavailable();
            if (isShown()) { capture(); invalidate(); }
            schedule();
        });
    }

    public void setActive(boolean active) {
        onMain(() -> {
            boolean changed = this.active != active;
            this.active = active;
            if (!active) {
                snapshot = StereoSpectrum.Snapshot.unavailable();
                handler.removeCallbacks(refresh);
                scheduled = false;
            }
            if (isShown() && (changed || !active)) { capture(); invalidate(); }
            schedule();
        });
    }

    private void onMain(Runnable action) {
        if (Looper.myLooper() == Looper.getMainLooper()) action.run();
        else handler.post(action);
    }

    private boolean shouldRefresh() { return attached && active && isShown() && getWindowVisibility() == VISIBLE; }

    private void schedule() {
        if (handler == null) return; // View can receive visibility callbacks during construction.
        if (!shouldRefresh()) {
            handler.removeCallbacks(refresh);
            scheduled = false;
        } else if (!scheduled) {
            scheduled = true;
            handler.postDelayed(refresh, 50);
        }
    }

    private void capture() {
        String next = "";
        try { if (statusSource != null) next = statusSource.get(); }
        catch (RuntimeException unavailable) { next = "Analyseur indisponible"; }
        status = next == null || next.trim().isEmpty() ? "Analyseur en attente" : next.replace('\n', ' ').trim();
        StereoSpectrum.Snapshot measured = null;
        if (active && source != null) try { measured = source.get(); }
        catch (RuntimeException unavailable) { status = "Analyseur indisponible"; }
        snapshot = measured != null && measured.available ? measured : StereoSpectrum.Snapshot.unavailable();
        if (snapshot.available) { left = snapshot.leftBands(); right = snapshot.rightBands(); }
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        attached = true;
        if (isShown()) { capture(); invalidate(); }
        schedule();
    }

    @Override protected void onDetachedFromWindow() {
        attached = false;
        handler.removeCallbacks(refresh);
        scheduled = false;
        snapshot = StereoSpectrum.Snapshot.unavailable();
        super.onDetachedFromWindow();
    }

    @Override protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        if (handler != null) {
            if (attached && isShown()) { capture(); invalidate(); }
            schedule();
        }
    }

    @Override protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        if (handler != null) {
            if (attached && isShown() && visibility == VISIBLE) { capture(); invalidate(); }
            schedule();
        }
    }

    private float rowHeight() { return dp(21) + metric.getFontSpacing() + dp(5); }
    private float desiredHeight() {
        return dp(24) + title.getFontSpacing() + caption.getFontSpacing() + dp(8)
            + 2 * rowHeight() + axis.getFontSpacing();
    }

    @Override protected void onMeasure(int widthSpec, int heightSpec) {
        int width = resolveSize((int) dp(320), widthSpec);
        int height = resolveSize(Math.max(getSuggestedMinimumHeight(), (int) Math.ceil(desiredHeight())), heightSpec);
        setMeasuredDimension(width, height);
    }

    private String captionText() {
        return "Signal source · " + (snapshot.available && snapshot.channels == 1 ? "Mono (G = D) · " : "") + status;
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float pad = dp(12), width = getWidth() - 2 * pad;
        if (width <= 0) return;
        bars.setColor(CARD);
        rectangle.set(0, 0, getWidth(), getHeight());
        canvas.drawRoundRect(rectangle, dp(14), dp(14), bars);
        float baseline = pad - title.ascent();
        canvas.drawText("Analyseur stéréo", pad, baseline, title);
        baseline += title.descent() + dp(3) - caption.ascent();
        drawFitting(canvas, captionText(), pad, baseline, width, caption);
        float rowTop = baseline + caption.descent() + dp(9);
        boolean available = active && snapshot.available;
        drawChannel(canvas, "G", LEFT, left, snapshot.leftRmsDb, snapshot.leftDominantHz,
            pad, rowTop, width, available);
        rowTop += rowHeight();
        drawChannel(canvas, "D", RIGHT, right, snapshot.rightRmsDb, snapshot.rightDominantHz,
            pad, rowTop, width, available);
        float axisY = rowTop + rowHeight() - axis.ascent() + dp(1);
        canvas.drawText("20 Hz", pad + dp(18), axisY, axis);
        int high = snapshot.available ? Math.min(20000, snapshot.sampleRate / 2) : 20000;
        String maximum = high >= 1000 ? String.format(Locale.FRANCE, "%s kHz", high % 1000 == 0
            ? Integer.toString(high / 1000) : String.format(Locale.FRANCE, "%.1f", high / 1000f)) : high + " Hz";
        canvas.drawText(maximum, getWidth() - pad - axis.measureText(maximum), axisY, axis);
    }

    private void drawChannel(Canvas canvas, String label, int color, float[] values, float rms, float dominant,
                             float x, float y, float width, boolean available) {
        float barHeight = dp(21), start = x + dp(18), span = width - dp(18);
        metric.setColor(color);
        canvas.drawText(label, x, y + barHeight - metric.descent(), metric);
        float unit = span / StereoSpectrum.BAND_COUNT, gap = Math.min(dp(2), unit / 4);
        for (int i = 0; i < StereoSpectrum.BAND_COUNT; i++) {
            float leftEdge = start + i * unit, rightEdge = leftEdge + Math.max(0, unit - gap);
            rectangle.set(leftEdge, y, rightEdge, y + barHeight);
            bars.setColor(TRACK); canvas.drawRect(rectangle, bars);
            if (available && i < values.length && Float.isFinite(values[i])) {
                float ratio = Math.max(0, Math.min(1, (values[i] - StereoSpectrum.FLOOR_DB) / -StereoSpectrum.FLOOR_DB));
                if (ratio > 0) {
                    rectangle.top = y + barHeight * (1 - ratio);
                    bars.setColor(color); canvas.drawRect(rectangle, bars);
                }
            }
        }
        metric.setColor(MUTED);
        String reading = available ? rmsText(rms) + " · " + frequencyText(dominant) : "— dBFS · — Hz";
        drawFitting(canvas, reading, start, y + barHeight + dp(3) - metric.ascent(), span, metric);
    }

    private static String rmsText(float value) {
        if (!Float.isFinite(value)) return "— dBFS";
        if (value <= StereoSpectrum.FLOOR_DB) return "≤ −90 dBFS";
        return String.format(Locale.FRANCE, "%.1f dBFS", value);
    }

    private static String frequencyText(float frequency) {
        return Float.isFinite(frequency) && frequency > 0 ? Math.round(frequency) + " Hz" : "— Hz";
    }

    private static void drawFitting(Canvas canvas, String text, float x, float y, float width, Paint paint) {
        if (paint.measureText(text) <= width) canvas.drawText(text, x, y, paint);
        else {
            int end = paint.breakText(text, true, Math.max(0, width - paint.measureText("…")), null);
            if (end > 0 && end < text.length() && Character.isHighSurrogate(text.charAt(end - 1))) end--;
            canvas.drawText(text.substring(0, Math.max(0, end)) + "…", x, y, paint);
        }
    }

    @Override public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info) {
        super.onInitializeAccessibilityNodeInfo(info);
        String description = "Analyseur stéréo. Signal source avant le traitement du niveau. " + status + ".";
        if (active && snapshot.available) {
            description += snapshot.channels == 1 ? " Mono, G égale D." : " Canaux gauche et droit séparés.";
            description += " Gauche : " + rmsText(snapshot.leftRmsDb) + ", " + frequencyText(snapshot.leftDominantHz)
                + ". Droite : " + rmsText(snapshot.rightRmsDb) + ", " + frequencyText(snapshot.rightDominantHz) + ".";
        } else description += " Aucun spectre animé sans signal mesuré.";
        info.setContentDescription(description);
    }
}
