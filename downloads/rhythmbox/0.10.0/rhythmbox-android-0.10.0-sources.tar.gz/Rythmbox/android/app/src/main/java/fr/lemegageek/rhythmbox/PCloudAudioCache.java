package fr.lemegageek.rhythmbox;

import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Private, bounded snapshots of original pCloud bytes. No URL or credential is
 * persisted. A receipt is bound to an account, its chosen root and exact file
 * identity; it is never a fallback for a different connection. */
public final class PCloudAudioCache {
    public static final long MAX_BYTES=512L*1024*1024;
    public static final class Cancelled extends java.io.IOException {Cancelled(){super("Préparation audio annulée");}}
    public static final class Cancellation {
        private boolean cancelled;private final java.util.function.BooleanSupplier active;private final java.util.Set<Runnable> resources=new java.util.HashSet<>();
        public Cancellation(){this(()->true);}public Cancellation(java.util.function.BooleanSupplier active){this.active=active==null?()->false:active;}
        public synchronized boolean isCancelled(){return cancelled||!active.getAsBoolean();}
        public void check() throws Cancelled {if(isCancelled()||Thread.currentThread().isInterrupted())throw new Cancelled();}
        public void cancel(){java.util.List<Runnable> close;synchronized(this){cancelled=true;close=new java.util.ArrayList<>(resources);resources.clear();}for(Runnable resource:close)try{resource.run();}catch(RuntimeException ignored){}}
        public java.io.Closeable register(Runnable close) throws Cancelled {synchronized(this){if(isCancelled()){close.run();throw new Cancelled();}resources.add(close);}return ()->{synchronized(Cancellation.this){resources.remove(close);}};}
    }
    private static final Object LOCK=new Object();
    private static final java.util.concurrent.ConcurrentHashMap<String,java.util.concurrent.locks.ReentrantLock> DOWNLOADS=new java.util.concurrent.ConcurrentHashMap<>();
    private final File directory;
    public PCloudAudioCache(File privateDirectory) throws Exception {
        directory=privateDirectory;
        if(!directory.isDirectory()&&!directory.mkdirs())throw new java.io.IOException("Cache musical indisponible");
        if(Files.isSymbolicLink(directory.toPath()))throw new java.io.IOException("Cache musical invalide");
    }
    public File directory(){return directory;}
    static String hex(byte[] bytes){StringBuilder out=new StringBuilder();for(byte b:bytes)out.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return out.toString();}
    static String sha256(String value) throws Exception{return hex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));}
    static long positive(JSONObject value,String key) throws Exception{return PCloudCollections.integer(value.get(key),false);}
    static String identity(PCloudAccount account,JSONObject track) throws Exception {
        if(account==null||account.musicFolderId<=0||positive(track,"pcloud_account_userid")!=account.userid||
            positive(track,"pcloud_music_folderid")!=account.musicFolderId)throw new IllegalArgumentException("Ce morceau appartient à un autre compte ou dossier musical");
        long fid=positive(track,"pcloud_fileid");String path=FolderProtocol.mediaPath(track.getString("media_path"));
        if("suno".equals(track.optString("service"))||track.optString("id").startsWith("suno:")||track.has("stream_uri")||track.has("suno_id")||track.has("suno_source")||track.has("demo_source")||track.has("local_uri")||track.optBoolean("quarantined"))throw new IllegalArgumentException("Source musicale hors du compte sélectionné");
        return account.region+":"+account.userid+":"+account.musicFolderId+":"+fid+":"+path;
    }
    private File receipt(PCloudAccount account,JSONObject track) throws Exception{return new File(directory,"receipt-"+sha256(identity(account,track))+".json");}
    static String version(JSONObject metadata) throws Exception {
        return positive(metadata,"fileid")+":"+PCloudCollections.integer(metadata.get("size"),true)+":"+metadata.optString("hash","")+":"+metadata.optString("modified","");
    }
    private JSONObject read(File file) throws Exception {
        if(!Files.isRegularFile(file.toPath(),LinkOption.NOFOLLOW_LINKS)||file.length()>16384)return null;
        return new JSONObject(new String(Files.readAllBytes(file.toPath()),StandardCharsets.UTF_8));
    }
    private File stored(PCloudAccount account,JSONObject track,JSONObject metadata) throws Exception {
        JSONObject value=read(receipt(account,track));if(value==null||value.optInt("schema")!=1||!identity(account,track).equals(value.optString("identity")))return null;
        if(metadata!=null&&!version(metadata).equals(value.optString("version")))return null;
        if(!acceptsVersion(account,track,value.optString("version")))return null;
        String name=value.optString("file");if(!name.matches("account-[1-9][0-9]*-audio-[1-9][0-9]*-[0-9a-f]{32}\\.cache"))return null;
        File output=new File(directory,name);
        if(!Files.isRegularFile(output.toPath(),LinkOption.NOFOLLOW_LINKS)||output.length()!=value.optLong("size",-1))return null;
        output.setLastModified(System.currentTimeMillis());return output;
    }
    public boolean acceptsVersion(PCloudAccount account,JSONObject track,JSONObject metadata) throws Exception {synchronized(LOCK){identity(account,track);return acceptsVersion(account,track,version(metadata));}}
    private boolean acceptsVersion(PCloudAccount account,JSONObject track,String version) throws Exception {
        File scope=indexFile(account);
        if(scope.exists()){
            // An offline snapshot may be used without a new request, but never
            // against a newer index we have already successfully verified.
            if(scope.length()>16L*1024*1024||!Files.isRegularFile(scope.toPath(),LinkOption.NOFOLLOW_LINKS))return false;
            JSONObject latest=new JSONObject(new String(Files.readAllBytes(scope.toPath()),StandardCharsets.UTF_8));JSONObject row=latest.getJSONObject("files").optJSONObject(Long.toString(positive(track,"pcloud_fileid")));
            if(latest.optLong("account_userid")!=account.userid||latest.optLong("music_folderid")!=account.musicFolderId||row==null||!track.getString("media_path").equals(row.optString("path"))||!version.equals(row.optString("version")))return false;
        }
        return true;
    }
    /** Fast/offline lookup of the last verified snapshot. A newly verified
     * remote revision replaces this receipt during prefetch or explicit sync. */
    public File find(PCloudAccount account,JSONObject track) throws Exception {synchronized(LOCK){return stored(account,track,null);}}
    public File findVersion(PCloudAccount account,JSONObject track,JSONObject metadata) throws Exception {synchronized(LOCK){return stored(account,track,metadata);}}
    public File findVerifiedAfter(PCloudAccount account,JSONObject track,long startedMillis) throws Exception {synchronized(LOCK){JSONObject row=read(receipt(account,track));return row!=null&&row.optLong("verified_ms",0)>=startedMillis?stored(account,track,null):null;}}
    /** Independent files proceed concurrently; a waiting next-track request
     * can be cancelled without waiting for somebody else's network transfer. */
    public java.io.Closeable lockDownload(PCloudAccount account,JSONObject track,Cancellation cancellation) throws Exception {
        String key=directory.getCanonicalPath()+":"+identity(account,track);java.util.concurrent.locks.ReentrantLock lock=DOWNLOADS.computeIfAbsent(key,ignored->new java.util.concurrent.locks.ReentrantLock());
        while(true){cancellation.check();if(lock.tryLock(100,java.util.concurrent.TimeUnit.MILLISECONDS)){try{cancellation.check();return lock::unlock;}catch(Exception failure){lock.unlock();throw failure;}}}
    }
    private File indexFile(PCloudAccount account){return new File(directory,"index-"+account.region+"-"+account.userid+"-"+account.musicFolderId+".json");}
    /** Called only after a complete, scoped, verified music index. Merely
     * learning of a removal/version change invalidates the old cache hit. */
    public void observeIndex(PCloudAccount account,java.util.Map<Long,JSONObject> index) throws Exception {
        synchronized(LOCK){JSONObject files=new JSONObject();for(java.util.Map.Entry<Long,JSONObject> entry:index.entrySet()){
            JSONObject row=entry.getValue();if(positive(row,"fileid")!=entry.getKey()||positive(row,"music_folderid")!=account.musicFolderId)throw new IllegalArgumentException("Index musical étranger");
            files.put(Long.toString(entry.getKey()),new JSONObject().put("path",FolderProtocol.mediaPath(row.getString("media_path"))).put("version",version(row)));
        }write(indexFile(account),new JSONObject().put("schema",1).put("account_userid",account.userid).put("music_folderid",account.musicFolderId).put("files",files));}
    }
    public void remember(PCloudAccount account,JSONObject track,File file,JSONObject metadata) throws Exception {
        synchronized(LOCK){
            identity(account,track);
            if(positive(metadata,"fileid")!=positive(track,"pcloud_fileid")||!FolderProtocol.mediaPath(metadata.getString("media_path")).equals(track.getString("media_path"))||
                positive(metadata,"music_folderid")!=account.musicFolderId||!file.getCanonicalFile().getParentFile().equals(directory.getCanonicalFile())||
                !file.getName().equals(PCloudCollections.cacheName(metadata,account))||!Files.isRegularFile(file.toPath(),LinkOption.NOFOLLOW_LINKS)||file.length()>MAX_BYTES||file.length()!=PCloudCollections.integer(metadata.get("size"),true))throw new IllegalArgumentException("Copie musicale non vérifiée");
            if(!acceptsVersion(account,track,version(metadata)))throw new java.io.IOException("Le morceau a changé ou a quitté le dossier musical pendant sa préparation ; actualise la liste");
            JSONObject value=new JSONObject().put("schema",1).put("identity",identity(account,track)).put("version",version(metadata)).put("file",file.getName()).put("size",file.length()).put("verified_ms",System.currentTimeMillis());
            write(receipt(account,track),value);file.setLastModified(System.currentTimeMillis());trim(file);
        }
    }
    static void write(File file,JSONObject value) throws Exception {
        File temporary=new File(file.getParentFile(),file.getName()+".tmp");
        try(FileOutputStream output=new FileOutputStream(temporary)){output.write(value.toString().getBytes(StandardCharsets.UTF_8));output.getFD().sync();}
        try{Files.move(temporary.toPath(),file.toPath(),StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}
        catch(java.nio.file.AtomicMoveNotSupportedException ignored){Files.move(temporary.toPath(),file.toPath(),StandardCopyOption.REPLACE_EXISTING);}
    }
    private void trim(File keep) {
        File[] files=directory.listFiles();if(files==null)return;List<File> audio=new ArrayList<>();long total=0;
        for(File file:files)if(file.getName().matches("account-[1-9][0-9]*-audio-[1-9][0-9]*-[0-9a-f]{32}\\.cache")&&Files.isRegularFile(file.toPath(),LinkOption.NOFOLLOW_LINKS)){audio.add(file);total+=file.length();}
        audio.sort(Comparator.comparingLong(File::lastModified));
        for(File old:audio)if(total>MAX_BYTES&&!old.equals(keep)){long bytes=old.length();if(old.delete())total-=bytes;}
        // Receipts are small; discard only receipts whose private cache file
        // has been evicted. Nothing outside this exclusive directory is touched.
        for(File file:files)if(file.getName().matches("receipt-[0-9a-f]{64}\\.json"))try{JSONObject row=read(file);String name=row==null?"":row.optString("file");if(name.matches("account-[1-9][0-9]*-audio-[1-9][0-9]*-[0-9a-f]{32}\\.cache")&&!new File(directory,name).exists())file.delete();}catch(Exception ignored){}
    }
}
