package fr.lemegageek.rhythmbox;

import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.os.UserHandle;
import android.provider.Settings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

/** Optional local control of the installed Spotify app, never global media keys.
 * Notification access is granted by the user in Android settings. This class
 * does not read notification contents, use a Spotify account/API, or play audio.
 * Start/stop only observe; every transport command is an explicit caller action.
 */
public final class SpotifyController {
    public static final String SPOTIFY_PACKAGE = "com.spotify.music";
    public interface Listener { void onState(State state); }

    /** Immutable presentation snapshot; positions/duration are milliseconds.
     * The artwork is an immutable private copy, obtained from Spotify metadata.
     * sessionGeneration changes on replacement/destruction/revocation/stop,
     * not on normal metadata, position or playback updates of the same session.
     */
    public static final class State {
        public final String source = "spotify";
        public final String id, title, artist, album, status;
        public final Bitmap cover;
        public final boolean hasAccess, available, playing, loading;
        public final boolean canPlay, canPause, canNext, canPrevious, canSeek;
        public final boolean shufflePossible = false;
        public final long position, duration, sessionGeneration;
        private final long observedAt;
        private final float speed;
        private State(Readout value, boolean access, boolean available, String status, long generation) {
            this.hasAccess=access;this.available=available;this.status=status;sessionGeneration=generation;
            id=text(value.id);title=text(value.title);artist=text(value.artist);album=text(value.album);
            cover=available?value.cover:null;playing=available&&value.playing;loading=available&&value.loading;
            duration=Math.max(0,value.duration);position=duration>0?Math.min(Math.max(0,value.position),duration):Math.max(0,value.position);
            observedAt=value.observedAt;speed=value.speed;
            canPlay=available&&value.canPlay;canPause=available&&value.canPause;
            canNext=available&&value.canNext;canPrevious=available&&value.canPrevious;canSeek=available&&value.canSeek;
        }
        /** Current estimated position, without any session/network request. */
        public long positionNow(){
            if(!playing||observedAt<=0||speed<=0)return position;
            double predicted=position+Math.max(0,SystemClock.elapsedRealtime()-observedAt)*(double)speed;
            long result=Double.isFinite(predicted)?(long)Math.min(Long.MAX_VALUE,Math.max(0,predicted)):position;
            return duration>0?Math.min(result,duration):result;
        }
    }

    // Android boundaries are replaceable only by package-local offline tests.
    interface Dispatcher { void post(Runnable action); }
    interface Gateway {
        boolean hasAccess(); int spotifyUid(); List<Session> sessions();
        void listen(Runnable listener); void unlisten();
    }
    interface Session {
        String packageName(); Object token(); Readout read();
        void listen(SessionCallback listener); void unlisten();
        boolean perform(Command command,long position);
    }
    interface SessionCallback { void onChanged(); void onDestroyed(); }
    enum Command { PLAY, PAUSE, NEXT, PREVIOUS, SEEK }
    static final class Readout {
        final String id,title,artist,album; final Bitmap cover;
        final boolean playing,loading,canPlay,canPause,canNext,canPrevious,canSeek;
        final long position,duration;
        final float speed;final long observedAt;
        Readout(String id,String title,String artist,String album,Bitmap cover,
                boolean playing,boolean loading,long position,long duration,
                boolean canPlay,boolean canPause,boolean canNext,boolean canPrevious,boolean canSeek) {
            this(id,title,artist,album,cover,playing,loading,position,duration,canPlay,canPause,canNext,canPrevious,canSeek,0,0);
        }
        Readout(String id,String title,String artist,String album,Bitmap cover,
                boolean playing,boolean loading,long position,long duration,
                boolean canPlay,boolean canPause,boolean canNext,boolean canPrevious,boolean canSeek,
                float speed,long observedAt) {
            this.id=id;this.title=title;this.artist=artist;this.album=album;this.cover=cover;
            this.playing=playing;this.loading=loading;this.position=position;this.duration=duration;
            this.canPlay=canPlay;this.canPause=canPause;this.canNext=canNext;
            this.canPrevious=canPrevious;this.canSeek=canSeek;
            this.speed=speed;this.observedAt=observedAt;
        }
        static Readout empty(){return new Readout("","","","",null,false,false,0,0,false,false,false,false,false);}
    }
    private static String text(String value){return value==null?"":value.substring(0,Math.min(value.length(),2048));}
    private static final Set<SpotifyController> ACTIVE = Collections.newSetFromMap(new WeakHashMap<SpotifyController,Boolean>());
    private final Gateway gateway;
    private final Dispatcher dispatcher;
    private final Listener listener;
    private final Set<Object> destroyedTokens = new HashSet<>();
    private Session selected;
    private Object token;
    private int uid = -1;
    private boolean started,watching;
    private long epoch,sessionGeneration,publication;
    private volatile State current = new State(Readout.empty(),false,false,"Commandes Spotify non activées.",0);

    public SpotifyController(Context context,Listener listener) {
        this(new AndroidGateway(context.getApplicationContext()),
             androidDispatcher(),listener);
    }
    private static Dispatcher androidDispatcher(){Handler handler=new Handler(Looper.getMainLooper());return action->handler.post(action);}
    SpotifyController(Gateway gateway,Dispatcher dispatcher,Listener listener) {
        if(gateway==null||dispatcher==null||listener==null)throw new IllegalArgumentException("Contrôleur Spotify incomplet.");
        this.gateway=gateway;this.dispatcher=dispatcher;this.listener=listener;
    }

    public State state(){return current;}
    public synchronized void start(){
        if(!started){started=true;epoch++;synchronized(ACTIVE){ACTIVE.add(this);}}
        refresh();
    }
    /** Unsubscribe without stopping Spotify or modifying its volume. */
    public synchronized void stop(){
        started=false;epoch++;
        synchronized(ACTIVE){ACTIVE.remove(this);}
        boolean hadSession=selected!=null;
        unwatch();detach();
        if(!hadSession)sessionGeneration++;
        publish(Readout.empty(),safeAccess(),false,"Commandes Spotify fermées.");
    }
    public synchronized void refresh(){
        if(!started)return;
        if(!safeAccess()){
            unwatch();detach();publish(Readout.empty(),false,false,"Autorise les commandes Spotify dans les réglages Android.");return;
        }
        try{
            if(!watching){
                long observedEpoch=epoch;watching=true;
                gateway.listen(()->{synchronized(SpotifyController.this){if(started&&epoch==observedEpoch)refresh();}});
            }
            int installedUid=gateway.spotifyUid();
            if(installedUid<0){
                if(selected!=null)destroyedTokens.add(token);
                detach();publish(Readout.empty(),true,false,"Installe ou ouvre l’application Spotify.");return;
            }
            Session fresh=uniqueSpotify();
            if(fresh==null){detach();publish(Readout.empty(),true,false,"Ouvre Spotify et lance un morceau pour activer ses commandes.");return;}
            Object freshToken=fresh.token();
            if(freshToken==null||destroyedTokens.contains(freshToken)){
                detach();publish(Readout.empty(),true,false,"La session Spotify est terminée. Rouvre Spotify.");return;
            }
            if(selected!=null&&uid!=installedUid){destroyedTokens.add(token);detach();}
            if(destroyedTokens.contains(freshToken)){
                publish(Readout.empty(),true,false,"La session Spotify a changé. Rouvre Spotify.");return;
            }
            if(selected==null||!freshToken.equals(token))bind(fresh,installedUid);
            Readout value=selected.read();
            publish(value,true,true,value.loading?"Spotify prépare la lecture.":"Commandes de l’application Spotify.");
        }catch(AmbiguousSession error){
            detach();publish(Readout.empty(),true,false,"Plusieurs sessions Spotify sont actives. Choisis la lecture dans Spotify.");
        }catch(SecurityException error){
            unwatch();detach();publish(Readout.empty(),false,false,"L’autorisation des commandes Spotify a été retirée.");
        }catch(RuntimeException error){
            detach();publish(Readout.empty(),safeAccess(),false,"Les commandes Spotify sont momentanément indisponibles. Actualise la connexion.");
        }
    }
    private boolean safeAccess(){try{return gateway.hasAccess();}catch(RuntimeException error){return false;}}
    private void unwatch(){if(watching){watching=false;try{gateway.unlisten();}catch(RuntimeException ignored){}}}
    private Session uniqueSpotify(){
        List<Session> sessions=gateway.sessions();
        if(sessions==null||sessions.size()>256)throw new IllegalStateException("Liste de sessions indisponible.");
        Session found=null;
        for(Session session:sessions){
            if(session==null||!SPOTIFY_PACKAGE.equals(session.packageName()))continue;
            if(found!=null)throw new AmbiguousSession();
            found=session;
        }
        return found;
    }
    private static final class AmbiguousSession extends RuntimeException { private static final long serialVersionUID=1L; }
    private void detach(){
        Session old=selected;
        if(old!=null){selected=null;token=null;uid=-1;sessionGeneration++;try{old.unlisten();}catch(RuntimeException ignored){}}
    }
    private void bind(Session session,int ownerUid){
        detach();selected=session;token=session.token();uid=ownerUid;sessionGeneration++;
        final long observedGeneration=sessionGeneration;
        try{
            session.listen(new SessionCallback(){
                public void onChanged(){synchronized(SpotifyController.this){
                    if(started&&selected==session&&sessionGeneration==observedGeneration)refresh();
                }}
                public void onDestroyed(){synchronized(SpotifyController.this){
                    if(selected!=session||sessionGeneration!=observedGeneration)return;
                    destroyedTokens.add(token);detach();
                    publish(Readout.empty(),safeAccess(),false,"La session Spotify est terminée. Rouvre Spotify.");
                }}
            });
        }catch(RuntimeException error){detach();throw error;}
    }
    private void publish(Readout value,boolean access,boolean available,String status){
        final State next=new State(value==null?Readout.empty():value,access,available,status,sessionGeneration);
        current=next;final long serial=++publication;
        dispatcher.post(()->{synchronized(SpotifyController.this){
            if(serial!=publication)return;
            if(next.available&&(!started||next.sessionGeneration!=sessionGeneration||!safeAccess())){
                if(started)refresh();return;
            }
            listener.onState(next);
        }});
    }
    public boolean resume(){return command(Command.PLAY,0);}
    public boolean pause(){return command(Command.PAUSE,0);}
    public boolean next(){return command(Command.NEXT,0);}
    public boolean previous(){return command(Command.PREVIOUS,0);}
    public boolean seekTo(long position){return command(Command.SEEK,position);}
    private synchronized boolean command(Command command,long position){
        if(!started){publish(Readout.empty(),safeAccess(),false,"Active les commandes Spotify avant de lancer la lecture.");return false;}
        if(!safeAccess()){refresh();return false;}
        if(selected==null){refresh();return false;}
        final Object expectedToken=token;final int expectedUid=uid;final long expectedGeneration=sessionGeneration;
        try{
            int installedUid=gateway.spotifyUid();Session fresh=uniqueSpotify();
            if(installedUid!=expectedUid){destroyedTokens.add(expectedToken);detach();refresh();return false;}
            if(fresh==null||fresh.token()==null||!expectedToken.equals(fresh.token())||
                    destroyedTokens.contains(expectedToken)||!SPOTIFY_PACKAGE.equals(fresh.packageName())||
                    expectedGeneration!=sessionGeneration){
                detach();refresh();return false;
            }
            Readout value=fresh.read();
            boolean allowed=command==Command.PLAY?value.canPlay:command==Command.PAUSE?value.canPause:
                command==Command.NEXT?value.canNext:command==Command.PREVIOUS?value.canPrevious:value.canSeek;
            if(!allowed){publish(value,true,true,"Cette commande n’est pas disponible dans Spotify pour le moment.");return false;}
            if(command==Command.SEEK){
                if(position<0){publish(value,true,true,"La position de lecture est invalide.");return false;}
                if(value.duration>0)position=Math.min(position,value.duration);
            }
            if(!safeAccess()||gateway.spotifyUid()!=expectedUid){refresh();return false;}
            long beforeSend=publication;
            if(!fresh.perform(command,position)){
                detach();publish(Readout.empty(),safeAccess(),false,"Spotify n’a pas accepté la commande. Actualise la connexion.");return false;
            }
            // A request is not proof of playback. Only Spotify's subsequent
            // session state can acknowledge pause/play to the native player.
            if(publication==beforeSend&&expectedGeneration==sessionGeneration)
                publish(value,true,true,command==Command.PAUSE?"Pause demandée à Spotify.":"Commande envoyée à Spotify.");
            return true;
        }catch(AmbiguousSession error){refresh();return false;}
        catch(SecurityException error){unwatch();detach();publish(Readout.empty(),false,false,"L’autorisation des commandes Spotify a été retirée.");return false;}
        catch(RuntimeException error){detach();publish(Readout.empty(),safeAccess(),false,"La session Spotify n’est plus disponible. Actualise la connexion.");return false;}
    }

    public static boolean isAccessEnabled(Context context){
        try{
            ComponentName component=new ComponentName(context,SpotifyNotificationListener.class);
            PackageManager pm=context.getPackageManager();
            ServiceInfo service=pm.getServiceInfo(component,PackageManager.MATCH_DISABLED_COMPONENTS);
            int enabled=pm.getComponentEnabledSetting(component);
            if(!service.applicationInfo.enabled||!(enabled==PackageManager.COMPONENT_ENABLED_STATE_ENABLED||
                    enabled==PackageManager.COMPONENT_ENABLED_STATE_DEFAULT&&service.enabled))return false;
            if(Build.VERSION.SDK_INT>=27){
                NotificationManager manager=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
                return manager!=null&&manager.isNotificationListenerAccessGranted(component);
            }
            // API26 has no public per-component query. Read only whether our
            // exact component occurs in the same platform setting AndroidX uses.
            String enabledListeners=Settings.Secure.getString(context.getContentResolver(),"enabled_notification_listeners");
            if(enabledListeners!=null&&enabledListeners.length()<65536)
                for(String value:enabledListeners.split(":"))if(component.equals(ComponentName.unflattenFromString(value)))return true;
        }catch(PackageManager.NameNotFoundException|RuntimeException ignored){}
        return false;
    }
    public static Intent notificationSettingsIntent(Context context){
        ComponentName component=new ComponentName(context,SpotifyNotificationListener.class);
        Intent result=new Intent(Build.VERSION.SDK_INT>=30?Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS:Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
        if(Build.VERSION.SDK_INT>=30)result.putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,component.flattenToString());
        if(result.resolveActivity(context.getPackageManager())==null)result=new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
        return result.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    }
    static void notificationAccessChanged(){
        List<SpotifyController> controllers;
        synchronized(ACTIVE){controllers=new ArrayList<>(ACTIVE);}
        for(SpotifyController controller:controllers)controller.dispatcher.post(controller::refresh);
    }

    private static final class AndroidGateway implements Gateway {
        final Context context;final Handler handler=new Handler(Looper.getMainLooper());
        final MediaSessionManager manager;MediaSessionManager.OnActiveSessionsChangedListener watched;
        final Map<Object,Artwork> artwork=new WeakHashMap<>();
        AndroidGateway(Context context){this.context=context;manager=(MediaSessionManager)context.getSystemService(Context.MEDIA_SESSION_SERVICE);}
        public boolean hasAccess(){return isAccessEnabled(context);}
        public int spotifyUid(){
            try{
                ApplicationInfo info=context.getPackageManager().getApplicationInfo(SPOTIFY_PACKAGE,0);
                return info.enabled&&UserHandle.getUserHandleForUid(info.uid).equals(Process.myUserHandle())?info.uid:-1;
            }catch(PackageManager.NameNotFoundException error){return -1;}
        }
        public List<Session> sessions(){
            if(manager==null)return Collections.emptyList();
            List<Session> out=new ArrayList<>();
            for(MediaController controller:manager.getActiveSessions(new ComponentName(context,SpotifyNotificationListener.class)))
                out.add(new AndroidSession(controller,handler,artwork));
            return out;
        }
        public void listen(Runnable listener){
            if(manager==null)return;
            watched=controllers->listener.run();
            manager.addOnActiveSessionsChangedListener(watched,new ComponentName(context,SpotifyNotificationListener.class),handler);
        }
        public void unlisten(){if(manager!=null&&watched!=null){manager.removeOnActiveSessionsChangedListener(watched);watched=null;}}
    }
    private static final class AndroidSession implements Session {
        final MediaController controller;final Handler handler;MediaController.Callback callback;
        final Map<Object,Artwork> artwork;
        AndroidSession(MediaController controller,Handler handler,Map<Object,Artwork> artwork){this.controller=controller;this.handler=handler;this.artwork=artwork;}
        public String packageName(){return controller.getPackageName();}
        public Object token(){return controller.getSessionToken();}
        public void listen(SessionCallback listener){
            callback=new MediaController.Callback(){
                @Override public void onPlaybackStateChanged(PlaybackState value){listener.onChanged();}
                @Override public void onMetadataChanged(MediaMetadata value){listener.onChanged();}
                @Override public void onSessionDestroyed(){listener.onDestroyed();}
            };
            controller.registerCallback(callback,handler);
        }
        public void unlisten(){if(callback!=null){controller.unregisterCallback(callback);callback=null;}}
        public Readout read(){
            // Never call this for another app, even when a foreign session is
            // first in Android's priority list.
            if(!SPOTIFY_PACKAGE.equals(packageName()))throw new SecurityException("Session non Spotify.");
            PlaybackState playback=controller.getPlaybackState();MediaMetadata metadata=controller.getMetadata();
            int state=playback==null?PlaybackState.STATE_NONE:playback.getState();long actions=playback==null?0:playback.getActions();
            boolean playing=state==PlaybackState.STATE_PLAYING||state==PlaybackState.STATE_FAST_FORWARDING||state==PlaybackState.STATE_REWINDING;
            boolean loading=state==PlaybackState.STATE_BUFFERING||state==PlaybackState.STATE_CONNECTING||
                state==PlaybackState.STATE_SKIPPING_TO_NEXT||state==PlaybackState.STATE_SKIPPING_TO_PREVIOUS||state==PlaybackState.STATE_SKIPPING_TO_QUEUE_ITEM;
            long duration=metadata==null?0:Math.max(0,metadata.getLong(MediaMetadata.METADATA_KEY_DURATION));
            long position=playback==null?0:Math.max(0,playback.getPosition());
            long now=SystemClock.elapsedRealtime();
            if(playing&&playback.getPlaybackSpeed()>0&&playback.getLastPositionUpdateTime()>0){
                long elapsed=Math.max(0,now-playback.getLastPositionUpdateTime());
                double predicted=position+elapsed*(double)playback.getPlaybackSpeed();
                if(Double.isFinite(predicted))position=(long)Math.min(Long.MAX_VALUE,Math.max(0,predicted));
            }
            if(duration>0)position=Math.min(position,duration);
            return new Readout(meta(metadata,MediaMetadata.METADATA_KEY_MEDIA_ID),
                first(meta(metadata,MediaMetadata.METADATA_KEY_TITLE),meta(metadata,MediaMetadata.METADATA_KEY_DISPLAY_TITLE)),
                first(meta(metadata,MediaMetadata.METADATA_KEY_ARTIST),meta(metadata,MediaMetadata.METADATA_KEY_ALBUM_ARTIST)),
                meta(metadata,MediaMetadata.METADATA_KEY_ALBUM),artwork(metadata),playing,loading,position,duration,
                (actions&PlaybackState.ACTION_PLAY)!=0,(actions&PlaybackState.ACTION_PAUSE)!=0,
                (actions&PlaybackState.ACTION_SKIP_TO_NEXT)!=0,(actions&PlaybackState.ACTION_SKIP_TO_PREVIOUS)!=0,
                (actions&PlaybackState.ACTION_SEEK_TO)!=0,playback==null?0:playback.getPlaybackSpeed(),now);
        }
        public boolean perform(Command command,long position){
            if(!SPOTIFY_PACKAGE.equals(packageName()))return false;
            MediaController.TransportControls controls=controller.getTransportControls();
            switch(command){
                case PLAY:controls.play();break;case PAUSE:controls.pause();break;
                case NEXT:controls.skipToNext();break;case PREVIOUS:controls.skipToPrevious();break;
                case SEEK:controls.seekTo(position);break;default:return false;
            }
            return true;
        }
        private static String meta(MediaMetadata metadata,String key){
            if(metadata==null)return "";CharSequence value=metadata.getText(key);return value==null?"":text(value.toString());
        }
        private static String first(String value,String fallback){return value.isEmpty()?fallback:value;}
        private Bitmap artwork(MediaMetadata metadata){
            if(metadata==null)return null;
            try{
                Bitmap bitmap=metadata.getBitmap(MediaMetadata.METADATA_KEY_ART);
                if(bitmap==null)bitmap=metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                if(bitmap==null)bitmap=metadata.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
                if(bitmap==null||bitmap.isRecycled()||bitmap.getWidth()<=0||bitmap.getHeight()<=0)return null;
                Artwork cached=artwork.get(token());
                if(cached!=null&&cached.same(bitmap))return cached.copy;
                double scale=Math.min(1.,512./Math.max(bitmap.getWidth(),bitmap.getHeight()));
                Bitmap sized=Bitmap.createScaledBitmap(bitmap,Math.max(1,(int)(bitmap.getWidth()*scale)),Math.max(1,(int)(bitmap.getHeight()*scale)),true);
                Bitmap copy=sized.copy(Bitmap.Config.ARGB_8888,false);
                if(copy!=null)artwork.put(token(),new Artwork(bitmap,copy));
                return copy;
            }catch(RuntimeException|OutOfMemoryError ignored){return null;}
        }
    }
    private static final class Artwork {
        Bitmap original;final Bitmap copy;int generation;
        Artwork(Bitmap original,Bitmap copy){this.original=original;this.copy=copy;generation=original.getGenerationId();}
        boolean same(Bitmap value){
            if(copy.isRecycled()||original.isRecycled())return false;
            if(value==original&&value.getGenerationId()==generation)return true;
            if(value.sameAs(original)){original=value;generation=value.getGenerationId();return true;}
            return false;
        }
    }
}
