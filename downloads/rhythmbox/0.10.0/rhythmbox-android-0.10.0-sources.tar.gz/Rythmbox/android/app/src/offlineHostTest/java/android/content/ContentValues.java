package android.content;
public final class ContentValues extends java.util.HashMap<String,Object> {
    public void put(String key,String value){super.put(key,value);}public void put(String key,Integer value){super.put(key,value);}
}
