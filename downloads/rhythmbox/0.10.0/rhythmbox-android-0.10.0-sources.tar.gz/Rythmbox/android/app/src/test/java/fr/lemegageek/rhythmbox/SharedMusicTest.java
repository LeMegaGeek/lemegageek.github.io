package fr.lemegageek.rhythmbox;

/** Regression: Android text/plain shares from Spotify used to enter the Suno-only importer. */
public final class SharedMusicTest {
    private static int checks;
    private static void test(boolean ok) {if(!ok)throw new AssertionError("Failed share check "+(checks+1));checks++;}
    private static void reject(String text)throws Exception{
        try{SharedMusic.parse(text);throw new AssertionError("Accepted unsupported share");}
        catch(IllegalArgumentException expected){test(true);}
    }
    public static void main(String[] args)throws Exception{
        String id="01234567890ABCDEFGHIJK";
        String spotify="https://open.spotify.com/track/"+id;
        String uri="spotify:track:"+id;
        String suno="https://suno.com/song/11111111-1111-4111-8111-111111111111";
        SharedMusic track=SharedMusic.parse("Mon morceau\n"+spotify+"?si=unused");
        test(track.spotify && uri.equals(track.reference));
        test(SharedMusic.parse(uri).spotify);
        test(SharedMusic.parse("Album (https://open.spotify.com/intl-fr/album/"+id+")").reference.equals("spotify:album:"+id));
        SharedMusic song=SharedMusic.parse("Écouter « Jazz » "+suno+"?tracking=x");
        test(!song.spotify && song.reference.equals(suno));
        test(SharedMusic.parse(suno+" "+suno).reference.equals(suno));
        reject(null);reject("https://suno.com/playlist/liked");
        reject(spotify+" "+suno);reject("https://example.org/redirect?url="+spotify);
        reject("https://name@open.spotify.com/track/"+id);reject("https://suno.com.invalid/song/11111111-1111-4111-8111-111111111111");
        reject("https://open.spotify.com:44/track/"+id);reject("http://suno.com/s/abcdefg");
        System.out.println("PASS: "+checks+" Android music share dispatch checks");
    }
}
