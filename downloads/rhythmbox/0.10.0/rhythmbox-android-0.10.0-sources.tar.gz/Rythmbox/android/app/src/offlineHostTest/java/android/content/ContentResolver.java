package android.content;
public abstract class ContentResolver {
    public abstract android.database.Cursor query(android.net.Uri uri,String[] columns,String selection,String[] arguments,String order);
    public abstract android.net.Uri insert(android.net.Uri uri,ContentValues values);
    public abstract int update(android.net.Uri uri,ContentValues values,String selection,String[] arguments);
    public abstract int delete(android.net.Uri uri,String selection,String[] arguments);
    public abstract java.io.InputStream openInputStream(android.net.Uri uri) throws java.io.IOException;
    public abstract java.io.OutputStream openOutputStream(android.net.Uri uri,String mode) throws java.io.IOException;
}
