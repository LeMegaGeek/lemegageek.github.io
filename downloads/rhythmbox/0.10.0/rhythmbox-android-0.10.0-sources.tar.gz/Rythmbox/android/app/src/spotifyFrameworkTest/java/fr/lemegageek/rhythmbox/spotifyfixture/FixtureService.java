package fr.lemegageek.rhythmbox.spotifyfixture;

import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Handler;
import android.os.Binder;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;

/** Signature-protected, soundless MediaSession fixture. It is compiled into
 * two disposable emulator APKs; it never creates audio or notifications. */
public final class FixtureService extends Service {
    public static final String HARNESS="fr.lemegageek.rhythmbox.spotifytest";
    public static final String PERMISSION=HARNESS+".CONTROL_FIXTURE";
    public static final String EVENT=HARNESS+".FIXTURE_EVENT";
    public static final String ACTION=HARNESS+".fixture.";
    public static final long DURATION=10000;
    private static final long CAPS=PlaybackState.ACTION_PLAY|PlaybackState.ACTION_PAUSE|
        PlaybackState.ACTION_SKIP_TO_NEXT|PlaybackState.ACTION_SKIP_TO_PREVIOUS|PlaybackState.ACTION_SEEK_TO;
    private MediaSession main,second,retired;
    private Bitmap art;
    private int plays,pauses,next,previous,seeks,oldReplays,serial,track;
    private long position=1000,updatedAt,actions=CAPS,lastSeek=-1;
    private boolean playing,newToken;
    private final Handler handler=new Handler(Looper.getMainLooper());

    @Override public void onCreate(){
        super.onCreate();
        if(!"com.spotify.music".equals(getPackageName())&&
                !"fr.lemegageek.rhythmbox.foreignspotifyfixture".equals(getPackageName()))
            throw new SecurityException("Fixture package mismatch");
        art=Bitmap.createBitmap(1024,1024,Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(art);canvas.drawColor(Color.rgb(18,52,72));
        Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);paint.setColor(Color.rgb(107,236,181));
        canvas.drawCircle(512,512,350,paint);paint.setColor(Color.rgb(24,37,58));
        canvas.drawCircle(512,512,120,paint);
    }
    private boolean spotify(){return "com.spotify.music".equals(getPackageName());}
    private long nowPosition(){
        long elapsed=playing?Math.max(0,SystemClock.elapsedRealtime()-updatedAt):0;
        return Math.max(0,Math.min(DURATION,position+elapsed));
    }
    private String trackId(){return spotify()?(newToken?"spotify-NEW-":"spotify-")+(track==0?"A":"B"):"foreign-secret-track";}
    private MediaMetadata metadata(){
        return new MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_MEDIA_ID,trackId())
            .putString(MediaMetadata.METADATA_KEY_TITLE,spotify()?"Spotify fixture "+trackId():"FOREIGN-PRIVATE-TITLE")
            .putString(MediaMetadata.METADATA_KEY_ARTIST,spotify()?"Synthetic Spotify artist":"FOREIGN-PRIVATE-ARTIST")
            .putString(MediaMetadata.METADATA_KEY_ALBUM,"Synthetic fixture album")
            .putLong(MediaMetadata.METADATA_KEY_DURATION,DURATION)
            .putBitmap(MediaMetadata.METADATA_KEY_ART,art).build();
    }
    private void playback(){
        if(main==null)return;
        updatedAt=SystemClock.elapsedRealtime();
        main.setPlaybackState(new PlaybackState.Builder().setActions(actions)
            .setState(playing?PlaybackState.STATE_PLAYING:PlaybackState.STATE_PAUSED,
                      position,playing?1f:0f,updatedAt).build());
    }
    private void createMain(boolean fresh){
        if(main!=null)main.release();
        newToken=fresh;track=0;playing=!spotify();position=1000;actions=CAPS;serial++;
        main=new MediaSession(this,"soundless-fixture-"+getPackageName()+"-"+serial);
        main.setCallback(new MediaSession.Callback(){
            @Override public void onPlay(){position=nowPosition();playing=true;plays++;playback();status();}
            @Override public void onPause(){position=nowPosition();playing=false;pauses++;playback();status();}
            @Override public void onSkipToNext(){position=0;track=1;next++;main.setMetadata(metadata());playback();status();}
            @Override public void onSkipToPrevious(){position=0;track=0;previous++;main.setMetadata(metadata());playback();status();}
            @Override public void onSeekTo(long requested){position=requested;lastSeek=requested;seeks++;playback();status();}
        },handler);
        main.setMetadata(metadata());playback();main.setActive(true);
    }
    private void status(){
        Intent event=new Intent(EVENT).setPackage(HARNESS)
            .putExtra("pkg",getPackageName()).putExtra("plays",plays).putExtra("pauses",pauses)
            .putExtra("next",next).putExtra("previous",previous).putExtra("seeks",seeks)
            .putExtra("last_seek",lastSeek).putExtra("old_replays",oldReplays)
            .putExtra("main_serial",serial).putExtra("track",trackId())
            .putExtra("session_count",(main==null?0:1)+(second==null?0:1));
        sendBroadcast(event,PERMISSION);
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        String action=intent==null?null:intent.getAction();
        if(action==null||!action.startsWith(ACTION)){status();return START_NOT_STICKY;}
        String command=action.substring(ACTION.length());
        if("init".equals(command)){
            if(second!=null){second.release();second=null;}
            if(retired!=null){retired.release();retired=null;}
            plays=pauses=next=previous=seeks=oldReplays=0;lastSeek=-1;createMain(false);
        }else if("caps_none".equals(command)){
            position=nowPosition();actions=0;playback();
        }else if("restore_caps".equals(command)){
            position=nowPosition();actions=CAPS;playback();
        }else if("position".equals(command)){
            position=Math.max(0,Math.min(DURATION,intent.getLongExtra("position",1000)));playback();
        }else if("second".equals(command)){
            if(second==null){
                second=new MediaSession(this,"ambiguous-second-fixture");
                second.setMetadata(new MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_MEDIA_ID,"spotify-secondary")
                    .putString(MediaMetadata.METADATA_KEY_TITLE,"Ambiguous synthetic session").build());
                second.setPlaybackState(new PlaybackState.Builder().setActions(CAPS)
                    .setState(PlaybackState.STATE_PAUSED,0,0f).build());second.setActive(true);
            }
        }else if("drop_second".equals(command)){
            if(second!=null){second.release();second=null;}
        }else if("destroy".equals(command)){
            if(retired!=null)retired.release();retired=main;
            if(main!=null){main.release();main=null;}
        }else if("new".equals(command)){
            createMain(true);
        }else if("replay_old".equals(command)){
            oldReplays++;
            if(retired!=null)try{
                retired.setMetadata(new MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_MEDIA_ID,"spotify-OLD-REPLAY")
                    .putString(MediaMetadata.METADATA_KEY_TITLE,"Released token replay").build());
                retired.setPlaybackState(new PlaybackState.Builder().setActions(CAPS)
                    .setState(PlaybackState.STATE_PLAYING,0,1f).build());retired.setActive(true);
            }catch(RuntimeException ignored){}
        }
        status();return START_NOT_STICKY;
    }
    @Override public IBinder onBind(Intent intent){return new Binder();}
    @Override public void onDestroy(){
        if(main!=null)main.release();if(second!=null)second.release();if(retired!=null)retired.release();
        main=second=retired=null;super.onDestroy();
    }
}
