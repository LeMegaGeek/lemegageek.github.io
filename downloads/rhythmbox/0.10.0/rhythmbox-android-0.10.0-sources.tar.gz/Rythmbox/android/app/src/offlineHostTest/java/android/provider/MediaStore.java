package android.provider;
public final class MediaStore {
    public static final String AUTHORITY="media",VOLUME_EXTERNAL_PRIMARY="external_primary";
    public static android.net.Uri setIncludePending(android.net.Uri uri){return uri;}
    public static final class MediaColumns {
        public static final String _ID="_id",DISPLAY_NAME="_display_name",RELATIVE_PATH="relative_path",OWNER_PACKAGE_NAME="owner_package_name",IS_PENDING="is_pending",SIZE="_size",MIME_TYPE="mime_type";
    }
    public static final class Audio {public static final class Media {public static android.net.Uri getContentUri(String volume){return android.net.Uri.parse("content://media/"+volume+"/audio/media");}}}
}
