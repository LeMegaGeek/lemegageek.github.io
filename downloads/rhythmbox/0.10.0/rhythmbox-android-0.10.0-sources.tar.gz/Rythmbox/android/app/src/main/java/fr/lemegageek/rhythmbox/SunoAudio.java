package fr.lemegageek.rhythmbox;

import org.json.JSONObject;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.HttpsURLConnection;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.CookieHandler;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Request-scoped playback of explicitly registered public Suno songs.
 * Only the normal guest rights exchange is used. Refused rights are terminal;
 * cookies, purchases, account credentials, audio files and keys are not stored.
 */
public final class SunoAudio implements Closeable {
    public static final long MAX_AUDIO_BYTES=5L*1024*1024*1024;
    public static final int PAGE_BYTES=65536,MAX_CACHE_BYTES=2*1024*1024;
    public static final String RIGHTS_URL="https://suno.com/a/api/mango/rights";
    private static final String MEDIA_HOST="d2lwuy8qc234o3.cloudfront.net";
    private static final Pattern UUID=Pattern.compile("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}");
    private static final Pattern CONTENT_RANGE=Pattern.compile("bytes ([0-9]{1,20})-([0-9]{1,20})/([0-9]{1,20})");
    private static final int MAX_RIGHTS_BYTES=65536;

    public static final class Failure extends IOException {
        public final int status;
        Failure(String message){this(message,0);}
        Failure(String message,int status){super(message);this.status=status;}
    }
    public static final class Request {
        public final String url,method;
        public final Map<String,String> headers;
        public final byte[] body;
        private Request(String url,String method,Map<String,String> extra,byte[] body){
            this.url=url;this.method=method;this.body=body;
            Map<String,String> values=new LinkedHashMap<>();
            values.put("User-Agent","RhythmboxSuno/0.5");values.put("Accept-Encoding","identity");
            if(body!=null){values.put("Content-Type","application/json");values.put("Accept","application/json");}
            if(extra!=null)values.putAll(extra);this.headers=Collections.unmodifiableMap(values);
        }
    }
    public interface Response extends Closeable {
        int status();String header(String name);String url();InputStream body() throws IOException;
    }
    public interface Transport {Response open(Request request,Cancellation cancellation) throws IOException;}

    /** Cancellation changes state immediately; potentially blocking disconnects
     * run on a daemon worker, never on the caller/UI thread. */
    public static final class Cancellation implements Closeable {
        private final AtomicBoolean cancelled=new AtomicBoolean();
        private final Set<Runnable> callbacks=ConcurrentHashMap.newKeySet();
        private final CountDownLatch ended=new CountDownLatch(1);
        public boolean isCancelled(){return cancelled.get();}
        private static void later(List<Runnable> work){
            if(work.isEmpty())return;
            Thread cleanup=new Thread(()->{for(Runnable action:work)try{action.run();}catch(Exception ignored){}},"suno-playback-disconnect");
            cleanup.setDaemon(true);cleanup.start();
        }
        public Closeable register(Runnable action){
            if(action==null)throw new NullPointerException("action");callbacks.add(action);
            if(cancelled.get()&&callbacks.remove(action))later(Collections.singletonList(action));
            return ()->callbacks.remove(action);
        }
        void check() throws IOException {if(cancelled.get())throw new Failure("La lecture Suno est fermée.");}
        void delay(long millis) throws IOException {
            try{if(ended.await(millis,TimeUnit.MILLISECONDS))check();}
            catch(InterruptedException interrupted){Thread.currentThread().interrupt();throw new Failure("Lecture Suno interrompue.");}
            check();
        }
        @Override public void close(){
            if(!cancelled.compareAndSet(false,true))return;ended.countDown();List<Runnable> work=new ArrayList<>();
            for(Runnable action:callbacks)if(callbacks.remove(action))work.add(action);later(work);
        }
    }

    private final String song,media;
    private final boolean encoded;
    private final Transport transport;
    private final Cancellation cancellation;
    private final AtomicBoolean closed=new AtomicBoolean();
    private final Object stateLock=new Object();
    private final LinkedHashMap<Long,byte[]> pages=new LinkedHashMap<>(16,.75f,true);
    private final Set<byte[]> secretCopies=Collections.newSetFromMap(new IdentityHashMap<byte[],Boolean>());
    private byte[] key,iv;
    private volatile long total;
    private int cacheBytes;
    private Closeable closeRegistration;

    private SunoAudio(JSONObject track,Transport transport,Cancellation cancellation) throws IOException {
        try{
            if(track==null||transport==null||cancellation==null)throw new IllegalArgumentException();
            Object rawId=track.get("id"),rawUri=track.get("stream_uri");
            if(!(rawId instanceof String)||!((String)rawId).startsWith("suno:")||!(rawUri instanceof String))throw new IllegalArgumentException();
            song=((String)rawId).substring(5);if(!UUID.matcher(song).matches())throw new IllegalArgumentException();
            media=(String)rawUri;if(!validMediaUri(media,song))throw new IllegalArgumentException();
            if(!track.has("stream_encoding"))throw new IllegalArgumentException();
            Object encoding=track.get("stream_encoding");
            if(encoding==JSONObject.NULL)encoded=false;
            else if("1.0.0".equals(encoding))encoded=true;
            else throw new IllegalArgumentException();
        }catch(Exception invalid){throw new Failure("Identité, adresse ou encodage Suno non reconnu.");}
        this.transport=transport;this.cancellation=cancellation;
        closeRegistration=cancellation.register(this::close);
    }
    public static SunoAudio open(JSONObject track) throws IOException {return open(track,httpsTransport(),new Cancellation());}
    public static SunoAudio open(JSONObject track,Transport transport) throws IOException {return open(track,transport,new Cancellation());}
    public static SunoAudio open(JSONObject track,Transport transport,Cancellation cancellation) throws IOException {
        SunoAudio audio=new SunoAudio(track,transport,cancellation);
        try{audio.initialize();return audio;}catch(IOException|RuntimeException failure){audio.close();throw failure;}
    }
    public static Transport httpsTransport(){return new HttpsTransport();}

    public static boolean validMediaUri(String value,String expectedSong){
        try{
            if(value==null||value.length()>4096||!UUID.matcher(expectedSong).matches())return false;
            for(int i=0;i<value.length();i++)if(value.charAt(i)<=32||value.charAt(i)==127||value.charAt(i)=='\\')return false;
            URI uri=new URI(value);
            return "https".equalsIgnoreCase(uri.getScheme())&&MEDIA_HOST.equalsIgnoreCase(uri.getHost())&&
                uri.getUserInfo()==null&&(uri.getPort()==-1||uri.getPort()==443)&&uri.getFragment()==null&&
                ("/1/clip/"+expectedSong+".m4a").equals(uri.getRawPath());
        }catch(Exception invalid){return false;}
    }
    private void check() throws IOException {if(closed.get())throw new Failure("La lecture Suno est fermée.");cancellation.check();}
    private static void wipe(byte[] value){if(value!=null)Arrays.fill(value,(byte)0);}
    private static String type(Response response){String value=response.header("Content-Type");return value==null?"":value.split(";",2)[0].trim().toLowerCase(Locale.ROOT);}
    private static long number(String text) throws IOException {
        if(text==null||!text.matches("[0-9]{1,20}"))throw new Failure("Métadonnée de lecture Suno invalide.");
        try{return Long.parseLong(text);}catch(NumberFormatException invalid){throw new Failure("Taille de lecture Suno hors limites.");}
    }
    private static long length(Response response,long max) throws IOException {
        long size=number(response.header("Content-Length"));if(size<=0||size>max)throw new Failure("Taille de lecture Suno hors limites.");return size;
    }
    private static void mediaHeaders(Response response) throws IOException {
        String type=type(response),encoding=response.header("Content-Encoding");
        if((!"audio/mp4".equals(type)&&!"application/octet-stream".equals(type))||
                (encoding!=null&&!"identity".equalsIgnoreCase(encoding.trim())))throw new Failure("Format de lecture Suno non reconnu.");
    }
    private Response request(String url,String method,Map<String,String> headers,byte[] body) throws IOException {
        check();Request request=new Request(url,method,headers,body);Response response=null;
        try{
            response=transport.open(request,cancellation);check();
            if(response==null||!url.equals(response.url()))throw new Failure("Redirection de lecture Suno refusée.");
            int status=response.status();
            if(status!=200&&status!=206)throw new Failure(status==401||status==403?"Le serveur refuse cette lecture Suno.":"Réponse de lecture Suno indisponible.",status);
            return response;
        }catch(IOException|RuntimeException failure){if(response!=null)try{response.close();}catch(Exception ignored){}throw failure;}
    }
    private Response media(String method,Map<String,String> headers) throws IOException {
        if(!validMediaUri(media,song))throw new Failure("Adresse de lecture Suno non autorisée.");
        for(int attempt=0;;attempt++){
            try{
                Response response=request(media,method,headers,null);
                try{mediaHeaders(response);return response;}catch(IOException invalid){response.close();throw invalid;}
            }catch(Failure error){
                if(!(encoded&&"GET".equals(method)&&error.status==405&&attempt<2))throw error;
                cancellation.delay(attempt==0?250:1000);
            }
        }
    }
    private static Map<String,String> range(long start,long end){return Collections.singletonMap("Range","bytes="+start+"-"+end);}
    private long rangeHeaders(Response response,long start,long end,Long expectedTotal) throws IOException {
        if(response.status()!=206)throw new Failure("Le serveur Suno ne respecte pas la plage de lecture.");
        String raw=response.header("Content-Range");Matcher match=CONTENT_RANGE.matcher(raw==null?"":raw);
        if(!match.matches())throw new Failure("Métadonnées de plage Suno non reconnues.");
        long first=number(match.group(1)),last=number(match.group(2)),size=number(match.group(3));
        if(first!=start||last!=end||size<=0||size>MAX_AUDIO_BYTES||end>=size||
                (expectedTotal!=null&&size!=expectedTotal)||length(response,PAGE_BYTES+16)!=end-start+1)
            throw new Failure("Le flux Suno a changé ou sa plage est incomplète.");
        return size;
    }
    private byte[] readExact(Response response,int amount) throws IOException {
        byte[] bytes=new byte[amount];boolean keep=false;
        try{
            InputStream input=response.body();int offset=0;
            while(offset<amount){check();int count=input.read(bytes,offset,amount-offset);if(count<=0)throw new Failure("Flux Suno interrompu avant la fin.");offset+=count;}
            check();if(input.read()!=-1)throw new Failure("Le serveur Suno dépasse la plage demandée.");check();keep=true;return bytes;
        }finally{if(!keep)wipe(bytes);}
    }
    private byte[] readBounded(Response response,int maximum) throws IOException {
        byte[] storage=new byte[maximum+1];
        try{
            InputStream input=response.body();int used=0;
            while(used<storage.length){check();int count=input.read(storage,used,storage.length-used);if(count<0)break;if(count==0)throw new Failure("Réponse de droits Suno interrompue.");used+=count;}
            check();if(used==0||used>maximum)throw new Failure("Réponse de droits Suno trop volumineuse ou vide.");
            if(response.header("Content-Length")!=null&&length(response,maximum)!=used)throw new Failure("Réponse de droits Suno incomplète.");
            return Arrays.copyOf(storage,used);
        }finally{wipe(storage);}
    }
    private void initialize() throws IOException {
        check();if(encoded)rights();
        try(Response response=media("HEAD",null)){
            if(response.status()!=200||response.header("Content-Range")!=null)throw new Failure("Métadonnées du flux Suno non reconnues.");
            total=length(response,MAX_AUDIO_BYTES);
        }catch(Failure error){
            if(error.status!=405)throw error;
            try(Response response=media("GET",range(0,0))){total=rangeHeaders(response,0,0,null);byte[] one=readExact(response,1);wipe(one);}
        }
        byte[] prefix=readRange(0,Math.min(31,total-1));
        try{if(prefix.length<12||prefix[4]!='f'||prefix[5]!='t'||prefix[6]!='y'||prefix[7]!='p')throw new Failure("Le flux Suno ne contient pas de conteneur MP4 reconnu.");}
        finally{wipe(prefix);}check();
    }
    private void rights() throws IOException {
        byte[] body=("{\"content_params\":{\"content_id\":\""+song+"\",\"content_type\":\"clip\"}}").getBytes(StandardCharsets.US_ASCII);
        byte[] raw=null,guest=null,wrapKey=null,songKey=null,songIv=null;
        try(Response response=request(RIGHTS_URL,"POST",null,body)){
            String contentEncoding=response.header("Content-Encoding");
            if(response.status()!=200||!"application/json".equals(type(response))||
                    (contentEncoding!=null&&!"identity".equalsIgnoreCase(contentEncoding.trim())))throw new Failure("Réponse de droits Suno non reconnue.");
            raw=readBounded(response,MAX_RIGHTS_BYTES);
            JSONObject payload=new JSONObject(new String(raw,StandardCharsets.UTF_8));Object token=payload.get("glt");
            if(!(token instanceof String)||((String)token).isEmpty()||((String)token).length()>8192)throw new Failure("Jeton invité de lecture Suno absent.");
            guest=((String)token).getBytes(StandardCharsets.UTF_8);wrapKey=MessageDigest.getInstance("SHA-256").digest(guest);
            songKey=unwrap(payload.get("key"),wrapKey);songIv=unwrap(payload.get("iv"),wrapKey);
            if((songKey.length!=16&&songKey.length!=24&&songKey.length!=32)||songIv.length!=16)throw new Failure("Droits de lecture Suno invalides.");
            synchronized(stateLock){check();key=songKey;iv=songIv;songKey=songIv=null;}
        }catch(IOException failure){throw failure;}
        catch(Exception invalid){throw new Failure("Les droits de lecture Suno ne correspondent pas au morceau.");}
        finally{wipe(raw);wipe(guest);wipe(wrapKey);wipe(songKey);wipe(songIv);wipe(body);}
    }
    private byte[] unwrap(Object value,byte[] wrappingKey) throws Exception {
        if(!(value instanceof String)||((String)value).isEmpty()||((String)value).length()>512||!((String)value).matches("[A-Za-z0-9+/]*={0,2}"))throw new Failure("Droits Suno non reconnus.");
        byte[] frame=null,nonce=null;
        try{
            frame=Base64.getDecoder().decode((String)value);if(frame.length<29||frame.length>128)throw new Failure("Droits Suno hors limites.");
            nonce=Arrays.copyOf(frame,12);Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE,new SecretKeySpec(wrappingKey,"AES"),new GCMParameterSpec(128,nonce));cipher.updateAAD(song.getBytes(StandardCharsets.US_ASCII));
            return cipher.doFinal(frame,12,frame.length-12);
        }finally{wipe(frame);wipe(nonce);}
    }
    private static void addCounter(byte[] counter,long amount) throws IOException {
        if(amount<0)throw new Failure("Compteur de lecture Suno invalide.");long carry=amount;
        for(int i=15;i>=0;i--){long sum=(counter[i]&255L)+(carry&255L);counter[i]=(byte)sum;carry=(carry>>>8)+(sum>>>8);}
        if(carry!=0)throw new Failure("Compteur de lecture Suno hors limites.");
    }
    private byte[] readRange(long start,long end) throws IOException {
        check();long aligned=encoded?(start/16)*16:start;int size=(int)(end-aligned+1);byte[] bytes=null,localKey=null,localIv=null,lastCounter=null,plain=null,output=null;boolean keep=false;
        try(Response response=media("GET",range(aligned,end))){
            rangeHeaders(response,aligned,end,total);bytes=readExact(response,size);
            if(encoded){
                synchronized(stateLock){check();if(key==null||iv==null)throw new Failure("Droits Suno absents.");localKey=key.clone();localIv=iv.clone();secretCopies.add(localKey);secretCopies.add(localIv);}
                addCounter(localIv,aligned/16);lastCounter=localIv.clone();addCounter(lastCounter,(size+15L)/16-1);
                Cipher cipher=Cipher.getInstance("AES/CTR/NoPadding");cipher.init(Cipher.DECRYPT_MODE,new SecretKeySpec(localKey,"AES"),new IvParameterSpec(localIv));plain=cipher.doFinal(bytes);
            }else{plain=bytes;bytes=null;}
            check();int skip=(int)(start-aligned);output=skip==0?plain:Arrays.copyOfRange(plain,skip,plain.length);
            if(skip==0)plain=null;check();keep=true;return output;
        }catch(IOException failure){throw failure;}
        catch(Exception invalid){throw new Failure("Le flux de lecture Suno n’a pas pu être décodé.");}
        finally{
            wipe(bytes);wipe(plain);wipe(lastCounter);if(!keep)wipe(output);
            synchronized(stateLock){wipe(localKey);wipe(localIv);secretCopies.remove(localKey);secretCopies.remove(localIv);}
        }
    }
    public long size() throws IOException {check();return total;}
    /** A call returns at most the remainder of one 64 KiB page. */
    public synchronized int readAt(long position,byte[] buffer,int offset,int length) throws IOException {
        check();if(buffer==null)throw new NullPointerException("buffer");
        if(position<0||offset<0||length<0||offset>buffer.length-length)throw new IOException("Plage de lecture Suno invalide.");
        if(length==0)return 0;if(position>=total)return -1;
        long page=position/PAGE_BYTES,start=page*PAGE_BYTES;byte[] content;
        synchronized(stateLock){check();content=pages.get(page);}
        if(content==null){
            content=readRange(start,Math.min(total-1,start+PAGE_BYTES-1));
            synchronized(stateLock){
                if(closed.get()||cancellation.isCancelled()){wipe(content);check();}
                pages.put(page,content);cacheBytes+=content.length;
                while(cacheBytes>MAX_CACHE_BYTES){Long eldest=pages.keySet().iterator().next();byte[] old=pages.remove(eldest);cacheBytes-=old.length;wipe(old);}
            }
        }
        synchronized(stateLock){check();int within=(int)(position-start),count=Math.min(length,content.length-within);System.arraycopy(content,within,buffer,offset,count);return count;}
    }
    int cachedBytes(){synchronized(stateLock){return cacheBytes;}}
    @Override public void close(){
        if(!closed.compareAndSet(false,true))return;
        synchronized(stateLock){wipe(key);wipe(iv);key=iv=null;for(byte[] value:secretCopies)wipe(value);secretCopies.clear();for(byte[] value:pages.values())wipe(value);pages.clear();cacheBytes=0;}
        if(closeRegistration!=null)try{closeRegistration.close();}catch(IOException ignored){}
        cancellation.close();
    }

    private static final class HttpsTransport implements Transport {
        @Override public Response open(Request request,Cancellation cancellation) throws IOException {
            cancellation.check();if(CookieHandler.getDefault()!=null)throw new Failure("La connexion Suno doit rester indépendante des sessions HTTP.");
            boolean rights=RIGHTS_URL.equals(request.url)&&"POST".equals(request.method);
            if(!rights){
                try{URI uri=new URI(request.url);String path=uri.getPath(),id=path.substring("/1/clip/".length(),path.length()-4);
                    if(!validMediaUri(request.url,id)||!("HEAD".equals(request.method)||"GET".equals(request.method)))throw new Exception();
                }catch(Exception invalid){throw new Failure("Adresse de lecture Suno non autorisée.");}
            }
            HttpsURLConnection connection=(HttpsURLConnection)new URL(request.url).openConnection();
            Closeable registered=cancellation.register(connection::disconnect);boolean keep=false;
            try{
                connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(20000);connection.setReadTimeout(20000);connection.setUseCaches(false);connection.setRequestMethod(request.method);
                for(Map.Entry<String,String> header:request.headers.entrySet())connection.setRequestProperty(header.getKey(),header.getValue());
                if(request.body!=null){connection.setDoOutput(true);connection.setFixedLengthStreamingMode(request.body.length);try(OutputStream output=connection.getOutputStream()){cancellation.check();output.write(request.body);}}
                int status=connection.getResponseCode();cancellation.check();keep=true;
                return new Response(){
                    public int status(){return status;}
                    public String url(){return connection.getURL().toString();}
                    public String header(String name){for(Map.Entry<String,List<String>> header:connection.getHeaderFields().entrySet())if(header.getKey()!=null&&header.getKey().equalsIgnoreCase(name)){List<String> values=header.getValue();return values.size()==1?values.get(0):"\u0000";}return null;}
                    public InputStream body() throws IOException {cancellation.check();return connection.getInputStream();}
                    public void close() throws IOException {try{registered.close();}finally{connection.disconnect();}}
                };
            }finally{if(!keep){try{registered.close();}finally{connection.disconnect();}}}
        }
    }
}
