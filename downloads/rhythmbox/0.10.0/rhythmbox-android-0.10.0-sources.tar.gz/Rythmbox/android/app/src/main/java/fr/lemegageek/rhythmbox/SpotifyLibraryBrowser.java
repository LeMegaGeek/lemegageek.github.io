package fr.lemegageek.rhythmbox;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import static fr.lemegageek.rhythmbox.SpotifyLibraryProtocol.*;

/** A source browser embedded inside Lecture. Browsing never issues a playback command. */
final class SpotifyLibraryBrowser {
    static final String ACTION_AUTH_RETURN="fr.lemegageek.rhythmbox.SPOTIFY_LIBRARY_RETURN";
    interface Listener { void play(String uri,String contextUri); }
    private final Activity activity;
    private final Listener listener;
    private final SpotifyLibraryClient client;
    private final LinearLayout root;
    private final ArrayList<Query> trail=new ArrayList<>();
    private final List<Item> rows=new ArrayList<>();
    private Query current;
    private int next=-1, request, statusRequest, firstRow, firstTop;
    private boolean authorized, known, closed, loading;
    private String error="", accountError="", searchText="";
    private ListView list;
    private EditText search;
    private static final int TEXT=0xffedf3fd, MUTED=0xffb2c0d1, ACCENT=0xff8de2c8;

    SpotifyLibraryBrowser(Activity activity,Listener listener) {
        this.activity=activity;this.listener=listener;client=new SpotifyLibraryClient(activity);
        root=new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setFocusableInTouchMode(true);
        render();
    }
    View view(){return root;}
    private int dp(int value){return Math.round(value*activity.getResources().getDisplayMetrics().density);}
    private Button button(String label,Runnable click) {
        Button button=new Button(activity);button.setText(label);button.setAllCaps(false);
        button.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);button.setMinHeight(dp(48));
        button.setOnClickListener(v->click.run());
        return button;
    }
    private TextView text(String value,int size,int color) {
        TextView label=new TextView(activity);label.setText(value);label.setTextSize(size);label.setTextColor(color);
        label.setPadding(dp(8),dp(6),dp(8),dp(6));return label;
    }
    private void update(Runnable action){activity.runOnUiThread(()->{if(!closed && !activity.isFinishing() && !activity.isDestroyed()) action.run();});}
    void refresh(){
        if(closed)return;
        int serial=++statusRequest;
        SpotifyLibraryClient.WORK.execute(()->{
            try{
                SpotifyLibraryClient.Status state=client.status();
                update(()->{
                    if(serial!=statusRequest)return;
                    boolean changed=!known || state.authorized!=authorized || !state.error.equals(accountError);
                    known=true;authorized=state.authorized;accountError=state.error;
                    if(changed){
                        if(!authorized){rows.clear();loading=false;++request;}
                        if(authorized && current!=null && rows.isEmpty() && !loading) load(0);
                        else render();
                    }
                });
            }catch(Exception failure){update(()->{if(serial==statusRequest){known=true;error=SpotifyLibraryClient.message(failure);render();}});}
        });
    }
    private void authorize(){
        if(loading)return;
        loading=true;error="";render();
        int serial=++request;
        SpotifyLibraryClient.WORK.execute(()->{
            try{
                String url=client.begin();
                update(()->{
                    if(request!=serial)return;
                    loading=false;accountError="";render();
                    try{activity.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE));}
                    catch(android.content.ActivityNotFoundException ignored){error="Aucun navigateur disponible pour ouvrir Spotify.";render();}
                });
            }catch(Exception failure){update(()->{if(serial==request){loading=false;error=SpotifyLibraryClient.message(failure);render();}});}
        });
    }
    void disconnect(){
        ++request;++statusRequest;current=null;trail.clear();rows.clear();searchText="";loading=false;
        SpotifyLibraryClient.WORK.execute(()->{
            try{client.forget();update(()->{authorized=false;known=true;error="";accountError="";render();});}
            catch(Exception failure){update(()->{error=SpotifyLibraryClient.message(failure);render();});}
        });
    }
    void close(){closed=true;++request;++statusRequest;}
    private void navigate(Query target){
        if(current!=null)trail.add(current);
        show(target);
    }
    private void show(Query target){
        ++request;current=target;rows.clear();firstRow=0;firstTop=0;next=-1;error="";loading=false;
        if(target!=null && authorized)load(0);else render();
    }
    boolean onBack(){
        if(current==null)return false;
        show(trail.isEmpty()?null:trail.remove(trail.size()-1));return true;
    }
    void saveState(Bundle state){
        if(current==null)return;
        ArrayList<String> sections=new ArrayList<>(),keys=new ArrayList<>(),titles=new ArrayList<>();
        ArrayList<Query> pages=new ArrayList<>(trail);pages.add(current);
        for(Query page:pages){sections.add(page.section.name());keys.add(page.key);titles.add(page.title);}
        state.putStringArrayList("spotify_catalog_sections",sections);state.putStringArrayList("spotify_catalog_keys",keys);state.putStringArrayList("spotify_catalog_titles",titles);
        state.putString("spotify_catalog_search",search==null?searchText:search.getText().toString());
    }
    void restoreState(Bundle state){
        if(state==null)return;
        ArrayList<String> sections=state.getStringArrayList("spotify_catalog_sections"), keys=state.getStringArrayList("spotify_catalog_keys"), titles=state.getStringArrayList("spotify_catalog_titles");
        if(sections==null || keys==null || titles==null || sections.size()!=keys.size() || sections.size()!=titles.size() || sections.size()>3)return;
        try{
            for(int i=0;i<sections.size();i++){
                Query page=new Query(Section.valueOf(sections.get(i)),keys.get(i),titles.get(i));page.url(0);
                if(i+1==sections.size())current=page;else trail.add(page);
            }
            searchText=state.getString("spotify_catalog_search","");
        } catch(Exception invalid){trail.clear();current=null;}
    }
    private void rememberScroll(){
        if(list==null)return;
        firstRow=list.getFirstVisiblePosition();
        View first=list.getChildAt(0);
        firstTop=first==null?0:first.getTop();
    }
    private void load(int offset){
        if(closed || current==null || !authorized)return;
        Query requested=current;int serial=++request;
        if(offset>0)rememberScroll();
        loading=true;error="";render();
        SpotifyLibraryClient.WORK.execute(()->{
            try{
                Page result=client.fetch(requested,offset);
                update(()->{
                    if(serial!=request)return;
                    loading=false;if(offset==0)rows.clear();
                    rows.addAll(result.items);next=result.next;render();
                });
            }catch(Exception failure){
                String message=SpotifyLibraryClient.message(failure);
                update(()->{if(serial==request){loading=false;error=message;render();refresh();}});
            }
        });
    }
    private void searchNow(){
        if(search==null)return;
        String q=search.getText().toString().trim();
        if(q.isEmpty()){search.requestFocus();return;}
        InputMethodManager keyboard=activity.getSystemService(InputMethodManager.class);
        if(keyboard!=null)keyboard.hideSoftInputFromWindow(search.getWindowToken(),0);
        searchText=q;
        Query results=new Query(Section.SEARCH,q,"Résultats");
        if(current!=null && current.section==Section.SEARCH)show(results);else navigate(results);
    }
    private void addSearch(){
        LinearLayout controls=new LinearLayout(activity);
        search=new EditText(activity);search.setSingleLine(true);search.setHint("Rechercher un morceau");
        search.setTextSize(16);search.setTextColor(TEXT);search.setHintTextColor(MUTED);
        search.setFilters(new InputFilter[]{new InputFilter.LengthFilter(256)});search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setText(searchText);search.setOnEditorActionListener((v,action,event)->{if(action!=EditorInfo.IME_ACTION_SEARCH)return false;searchNow();return true;});
        controls.addView(search,new LinearLayout.LayoutParams(0,-2,1));
        controls.addView(button("Rechercher",this::searchNow));root.addView(controls);
    }
    private void render(){
        if(search!=null)searchText=search.getText().toString();
        list=null;search=null;root.removeAllViews();
        if(!known){root.addView(text("Chargement de Spotify…",14,MUTED));return;}
        if(!authorized){
            String problem=error.isEmpty()?accountError:error;
            if(!problem.isEmpty())root.addView(text(problem,15,TEXT));
            Button connect=button("Afficher ma bibliothèque Spotify",this::authorize);
            connect.setEnabled(!loading);root.addView(connect);return;
        }
        if(current==null){
            addSearch();
            root.addView(button("Titres aimés",()->navigate(new Query(Section.LIKED,"","Titres aimés"))));
            root.addView(button("Playlists",()->navigate(new Query(Section.PLAYLISTS,"","Playlists"))));
            root.addView(button("Albums",()->navigate(new Query(Section.ALBUMS,"","Albums"))));
            return;
        }
        root.addView(button("‹  "+current.title,this::onBack));
        if(current.section==Section.SEARCH)addSearch();
        String context=current.context();
        if(!context.isEmpty())root.addView(button(current.section==Section.PLAYLIST?"Lire cette playlist":"Lire cet album",()->listener.play(context,"")));
        list=new ListView(activity);list.setDivider(null);
        if(rows.isEmpty() && !loading && error.isEmpty())root.addView(text("Aucun morceau ou résultat disponible.",15,MUTED));
        if(!error.isEmpty())root.addView(text(error,15,TEXT));
        if(loading)root.addView(text("Chargement…",14,MUTED));
        if(!rows.isEmpty()){
            list.setAdapter(new Items());list.setOnItemClickListener((p,v,position,id)->{
                Item row=rows.get(position);
                if(row.type.equals("playlist"))navigate(new Query(Section.PLAYLIST,row.id,row.name));
                else if(row.type.equals("album"))navigate(new Query(Section.ALBUM,row.id,row.name));
                else if(row.playable) listener.play(row.uri(),context);
            });
            root.addView(list,new LinearLayout.LayoutParams(-1,0,1));
            list.setSelectionFromTop(firstRow,firstTop);
        }
        if(!loading && (!error.isEmpty() || next>=0))
            root.addView(button(error.isEmpty()?"Afficher la suite":"Réessayer",()->load(next>=0?next:0)));
    }
    private final class Items extends BaseAdapter {
        public int getCount(){return rows.size();}
        public Item getItem(int position){return rows.get(position);}
        public long getItemId(int position){return position;}
        @Override public boolean areAllItemsEnabled(){return false;}
        @Override public boolean isEnabled(int position){Item item=getItem(position);return !item.type.equals("track")||item.playable;}
        public View getView(int position,View reusable,ViewGroup parent){
            LinearLayout card=(LinearLayout)reusable;
            if(card==null){
                card=new LinearLayout(activity);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER_VERTICAL);
                card.setMinimumHeight(dp(54));card.setPadding(dp(8),dp(6),dp(8),dp(6));
                TextView title=new TextView(activity);title.setTextSize(16);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);title.setMaxLines(2);card.addView(title);
                TextView detail=new TextView(activity);detail.setTextSize(14);detail.setTextColor(MUTED);detail.setMaxLines(2);card.addView(detail);
                card.setLayoutParams(new AbsListView.LayoutParams(-1,-2));
            }
            Item item=getItem(position);
            TextView title=(TextView)card.getChildAt(0),detail=(TextView)card.getChildAt(1);
            title.setText(item.name);title.setTextColor(isEnabled(position)?TEXT:MUTED);
            detail.setText(isEnabled(position)?item.detail:"Indisponible");detail.setVisibility(detail.length()==0?View.GONE:View.VISIBLE);
            return card;
        }
    }
}
