package fr.lemegageek.rhythmbox;

import android.app.Activity;
import android.app.ActivityOptions;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

/** Standard browser Custom Tab. No WebView, cookie access, JavaScript bridge or browser scraping. */
public final class SunoBrowser {
    public static final String ACTION_RETURN="fr.lemegageek.rhythmbox.SUNO_BROWSER_MUSIC";
    private static final String EXTRA_NONCE="fr.lemegageek.rhythmbox.SUNO_BROWSER_NONCE";
    private static final String SESSION="android.support.customtabs.extra.SESSION";
    private static final String SERVICE="android.support.customtabs.action.CustomTabsService";
    private static final Object LOCK=new Object();
    private SunoBrowser(){}
    private static SharedPreferences preferences(Context context){return context.getSharedPreferences("suno-browser-v1",Context.MODE_PRIVATE);}
    /** True means a toolbar action was supplied; false means use Suno's normal Android share action. */
    public static boolean open(Activity activity,SunoBrowserProtocol.Destination page){
        String url=SunoBrowserProtocol.destination(page);
        Intent ordinary=new Intent(Intent.ACTION_VIEW,Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE);
        ResolveInfo resolved=activity.getPackageManager().resolveActivity(ordinary,0);
        String provider=resolved!=null&&resolved.activityInfo!=null?resolved.activityInfo.packageName:null;
        boolean custom=provider!=null&&activity.getPackageManager().resolveService(new Intent(SERVICE).setPackage(provider),0)!=null;
        if(custom){
            SunoBrowserProtocol.Ticket ticket=SunoBrowserProtocol.create(System.currentTimeMillis());
            synchronized(LOCK){
                if(!preferences(activity).edit().clear().putString("nonce",ticket.nonce).putLong("created_ms",ticket.createdMillis).commit())throw new IllegalStateException("Impossible de préparer le retour depuis Suno.");
            }
            Intent callback=new Intent(activity,MainActivity.class).setAction(ACTION_RETURN).putExtra(EXTRA_NONCE,ticket.nonce)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            int flags=PendingIntent.FLAG_CANCEL_CURRENT|(Build.VERSION.SDK_INT>=31?PendingIntent.FLAG_MUTABLE:0);
            // API 35+ otherwise drops the creator's activity-launch privileges.
            // This opt-in applies only to this explicit, expiring user-selection capability.
            Bundle launchOptions=Build.VERSION.SDK_INT>=34?ActivityOptions.makeBasic()
                .setPendingIntentCreatorBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED).toBundle():null;
            PendingIntent pending=PendingIntent.getActivity(activity,7341,callback,flags,launchOptions);
            Bundle action=new Bundle();action.putInt("android.support.customtabs.customaction.ID",0);
            Bitmap icon=Bitmap.createBitmap(48,48,Bitmap.Config.ARGB_8888);Drawable glyph=UiIcons.icon("music",Color.WHITE);glyph.setBounds(0,0,48,48);glyph.draw(new Canvas(icon));
            action.putParcelable("android.support.customtabs.customaction.ICON",icon);
            action.putString("android.support.customtabs.customaction.DESCRIPTION","Écouter dans Rhythmbox");
            action.putParcelable("android.support.customtabs.customaction.PENDING_INTENT",pending);
            Bundle extras=new Bundle();extras.putBinder(SESSION,null);
            Intent tab=new Intent(ordinary).setPackage(provider).putExtras(extras)
                .putExtra("android.support.customtabs.extra.ACTION_BUTTON_BUNDLE",action)
                .putExtra("android.support.customtabs.extra.TINT_ACTION_BUTTON",true)
                .putExtra("android.support.customtabs.extra.SHARE_MENU_ITEM",true);
            try{activity.startActivity(tab);return true;}
            catch(ActivityNotFoundException unavailable){pending.cancel();clear(activity);}
        }
        clear(activity);
        activity.startActivity(ordinary);
        return false;
    }
    public static final class Selection {
        public final String url,title;
        private Selection(String url,String title){this.url=url;this.title=title;}
    }
    /** Consume only our explicit, pending, unexpired capability; clear all incoming extras immediately. */
    public static Selection consume(Context context,Intent intent)throws Exception{
        String nonce=null,url=null,title=null;
        try{
            if(intent==null||!ACTION_RETURN.equals(intent.getAction()))throw new IllegalArgumentException("Retour Suno non reconnu.");
            nonce=intent.getStringExtra(EXTRA_NONCE);url=intent.getDataString();title=intent.getStringExtra(Intent.EXTRA_SUBJECT);
        }finally{if(intent!=null){intent.setData(null);intent.replaceExtras((Bundle)null);}}
        synchronized(LOCK){
            SharedPreferences saved=preferences(context);
            SunoBrowserProtocol.Ticket ticket=SunoBrowserProtocol.restore(saved.getString("nonce",null),saved.getLong("created_ms",-1));
            long now=System.currentTimeMillis();
            if(!ticket.validAt(now)){saved.edit().clear().commit();throw new IllegalArgumentException("Rouvre Suno depuis Rhythmbox pour choisir un morceau.");}
            String music=ticket.consume(nonce,url,now);
            if(!saved.edit().clear().commit())throw new IllegalStateException("Retour Suno interrompu. Rouvre Suno depuis Rhythmbox.");
            return new Selection(music,SunoBrowserProtocol.title(title,music));
        }
    }
    private static void clear(Context context){synchronized(LOCK){preferences(context).edit().clear().commit();}}
}
