package fr.lemegageek.rhythmbox;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import com.spotify.android.appremote.api.ConnectionParams;
import com.spotify.android.appremote.api.Connector;
import com.spotify.android.appremote.api.SpotifyAppRemote;
import com.spotify.protocol.client.CallResult;
import com.spotify.protocol.client.Subscription;
import com.spotify.protocol.types.Capabilities;
import com.spotify.protocol.types.Empty;
import com.spotify.protocol.types.PlayerRestrictions;
import com.spotify.protocol.types.PlayerState;
import com.spotify.protocol.types.Track;

/** Official App Remote control. Spotify owns authentication and all audio.
 * No notification access, Web API, browser automation or audio capture is used.
 * Connecting observes playback; explicit transport actions change it.
 */
public final class SpotifyController {
    public static final String SPOTIFY_PACKAGE="com.spotify.music";
    public static final String REDIRECT_URI="fr.lemegageek.rhythmbox://spotify-callback";
    public interface Listener {void onState(State state);}
    interface Dispatcher {
        void post(Runnable action);
        default void postDelayed(Runnable action,long delayMs) {}
        default void remove(Runnable action) {}
    }
    interface Result {void done(boolean accepted);}
    interface ReadResult {void done(Readout value);}
    interface Observer {void changed(Readout value);void lost();}
    interface Connection {void connected(Remote remote);void failed(String code);}
    interface Gateway {
        String clientId();void configure(String clientId);boolean enabled();void setEnabled(boolean enabled);
        boolean installed();void connect(boolean authorize,Connection callback);
    }
    interface Remote {
        boolean connected();void observe(Observer observer);void close();
        void perform(Command command,long value,String uri,Result callback);
        void readState(ReadResult callback);
    }
    enum Command {PLAY,PAUSE,NEXT,PREVIOUS,SEEK,SHUFFLE,REPEAT,PLAY_URI}
    static final class Readout {
        final String id,title,artist,album;final Bitmap cover;
        final boolean playing,canNext,canPrevious,canSeek,canShuffle,shuffled,canRepeat,canPlayOnDemand,capabilitiesKnown;
        final int repeatMode,repeatCapabilities;final long position,duration,observedAt,playerRevision;final float speed;
        Readout(String id,String title,String artist,String album,Bitmap cover,boolean playing,long position,long duration,
                boolean canNext,boolean canPrevious,boolean canSeek,boolean canShuffle,boolean shuffled,
                int repeatCapabilities,int repeatMode,boolean canPlayOnDemand,boolean capabilitiesKnown,float speed,long observedAt){
            this(id,title,artist,album,cover,playing,position,duration,canNext,canPrevious,canSeek,canShuffle,shuffled,
                repeatCapabilities,repeatMode,canPlayOnDemand,capabilitiesKnown,speed,observedAt,0);
        }
        Readout(String id,String title,String artist,String album,Bitmap cover,boolean playing,long position,long duration,
                boolean canNext,boolean canPrevious,boolean canSeek,boolean canShuffle,boolean shuffled,
                int repeatCapabilities,int repeatMode,boolean canPlayOnDemand,boolean capabilitiesKnown,float speed,long observedAt,long playerRevision){
            this.id=text(id);this.title=text(title);this.artist=text(artist);this.album=text(album);this.cover=cover;
            this.playing=playing;this.position=Math.max(0,position);this.duration=Math.max(0,duration);
            this.canNext=canNext;this.canPrevious=canPrevious;this.canSeek=canSeek;this.canShuffle=canShuffle;
            this.shuffled=shuffled;this.repeatCapabilities=repeatCapabilities;this.canRepeat=repeatCapabilities!=0;this.repeatMode=repeatMode;
            this.canPlayOnDemand=canPlayOnDemand;this.capabilitiesKnown=capabilitiesKnown;this.speed=speed;this.observedAt=observedAt;this.playerRevision=playerRevision;
        }
        static Readout empty(){return new Readout("","","","",null,false,0,0,false,false,false,false,false,0,0,false,false,0,0);}
    }
    public static final class State {
        public final String source="spotify",id,title,artist,album,status;
        public final Bitmap cover;
        public final boolean hasAccess,available,playing,loading,canPlay,canPause,canNext,canPrevious,canSeek;
        public final boolean shufflePossible,shuffled,repeatPossible,canRepeatTrack,canRepeatContext,canPlayOnDemand,capabilitiesKnown;
        public final int repeatMode;public final long position,duration,sessionGeneration,playerRevision;
        private final long observedAt;private final float speed;
        State(Readout value,boolean connected,boolean connecting,String status,long generation){
            available=hasAccess=connected;loading=connecting;this.status=status;sessionGeneration=generation;
            playerRevision=connected?value.playerRevision:0;
            id=connected?value.id:"";title=connected?value.title:"";artist=connected?value.artist:"";album=connected?value.album:"";
            cover=connected?value.cover:null;playing=connected&&value.playing;
            boolean track=connected&&!id.isEmpty();canPlay=canPause=track;
            canNext=track&&value.canNext;canPrevious=track&&value.canPrevious;canSeek=track&&value.canSeek;
            shufflePossible=track&&value.canShuffle;shuffled=track&&value.shuffled;
            repeatPossible=track&&value.canRepeat;canRepeatTrack=track&&(value.repeatCapabilities&1)!=0;canRepeatContext=track&&(value.repeatCapabilities&2)!=0;repeatMode=track?value.repeatMode:0;
            canPlayOnDemand=connected&&value.canPlayOnDemand;capabilitiesKnown=connected&&value.capabilitiesKnown;
            duration=track?value.duration:0;position=track?(duration>0?Math.min(value.position,duration):value.position):0;
            observedAt=value.observedAt;speed=value.speed;
        }
        public long positionNow(){
            if(!playing||observedAt<=0||speed<=0)return position;
            double predicted=position+Math.max(0,SystemClock.elapsedRealtime()-observedAt)*(double)speed;
            long result=Double.isFinite(predicted)?(long)Math.min(Long.MAX_VALUE,Math.max(0,predicted)):position;
            return duration>0?Math.min(result,duration):result;
        }
    }
    private static String text(String value){return value==null?"":value.substring(0,Math.min(value.length(),2048));}
    public static boolean validClientId(String value){return value!=null&&value.matches("[a-fA-F0-9]{32}");}
    private final Gateway gateway;private final Dispatcher dispatcher;private final Listener listener;
    private Remote remote;private boolean started,connecting;private long epoch,generation,publication,commandSerial,readRequestSerial;
    private Readout readout=Readout.empty();
    private boolean awaitingConsent,authorizationRequired;
    private Runnable timeout;
    private String connectionProblem="";
    private volatile State current=new State(Readout.empty(),false,false,"Spotify déconnecté",0);

    public SpotifyController(Context context,Listener listener){this(new AndroidGateway(context),androidDispatcher(),listener);}
    SpotifyController(Gateway gateway,Dispatcher dispatcher,Listener listener){
        if(gateway==null||dispatcher==null||listener==null)throw new IllegalArgumentException("Contrôleur Spotify incomplet.");
        this.gateway=gateway;this.dispatcher=dispatcher;this.listener=listener;
    }
    private static Dispatcher androidDispatcher(){
        Handler handler=new Handler(Looper.getMainLooper());
        return new Dispatcher(){
            public void post(Runnable action){handler.post(action);}
            public void postDelayed(Runnable action,long delayMs){handler.postDelayed(action,delayMs);}
            public void remove(Runnable action){handler.removeCallbacks(action);}
        };
    }
    public State state(){return current;}
    public String clientId(){return gateway.clientId();}
    public boolean configured(){return validClientId(clientId());}
    public synchronized boolean needsAuthorization(){return authorizationRequired;}
    public boolean isSpotifyInstalled(){return gateway.installed();}
    public synchronized void configure(String value){
        String id=value==null?"":value.trim();if(!id.isEmpty()&&!validClientId(id))throw new IllegalArgumentException("Le Client ID Spotify doit comporter 32 caractères hexadécimaux.");
        detach();clearConnectionProblem();gateway.configure(id);gateway.setEnabled(false);publish("Spotify déconnecté");
    }
    public synchronized void start(){
        if(started){refresh();return;}started=true;
        if(connecting)return;
        if(gateway.enabled())beginConnect(false);else refresh();
    }
    /** Spotify moves our Activity off-screen while it presents its consent screen. */
    public synchronized void background(){
        started=false;
        if(connecting && awaitingConsent)return;
        stop();
    }
    /** Disconnect local control without implicitly changing Spotify playback. */
    public synchronized void stop(){started=false;detach();publish("Commandes Spotify fermées.");}
    public synchronized void disconnect(){gateway.setEnabled(false);detach();clearConnectionProblem();publish("Spotify déconnecté");}
    public synchronized boolean connect(){return beginConnect(true);}
    private boolean beginConnect(boolean authorize){
        if(!started)return false;
        if(!configured()){publish("Spotify est indisponible dans cette version de Rhythmbox.");return false;}
        if(!gateway.installed()){publish("Installe l’application Spotify sur ce téléphone.");return false;}
        if(remote!=null&&remote.connected()){publish("Spotify connecté");return true;}
        if(connecting)return false;
        if(remote!=null)detach();
        clearConnectionProblem();
        awaitingConsent=authorize;
        connecting=true;long expected=++epoch;publish(authorize?"Autorisation dans Spotify…":"Connexion à Spotify…");
        timeout=()->connectionFailed(expected,"ConnectionTimeout");
        dispatcher.postDelayed(timeout,120000L);
        try{gateway.connect(authorize,new Connection(){
            public void connected(Remote fresh){dispatcher.post(()->accept(expected,fresh));}
            public void failed(String code){dispatcher.post(()->connectionFailed(expected,code));}
        });}catch(RuntimeException error){connectionFailed(expected,"ConnectionError");return false;}
        return true;
    }
    private void clearConnectionProblem(){authorizationRequired=false;connectionProblem="";}
    private synchronized void connectionFailed(long expected,String code){
        if(expected!=epoch||!connecting)return;
        detach();
        authorizationRequired="UserNotAuthorizedException".equals(code);
        if(authorizationRequired){
            gateway.setEnabled(false);
            connectionProblem="Spotify attend l’autorisation de piloter la lecture.";
        }else if("NotLoggedInException".equals(code)){
            connectionProblem="Connecte-toi dans l’application Spotify.";
        }else if("OfflineModeException".equals(code)){
            connectionProblem="Spotify est hors connexion.";
        }else if("CouldNotFindSpotifyApp".equals(code)){
            connectionProblem="Installe l’application Spotify sur ce téléphone.";
        }else{
            connectionProblem="Connexion à Spotify impossible. Réessayer.";
        }
        publish(connectionProblem);
    }
    private synchronized void accept(long expected,Remote fresh){
        if(fresh==null)return;
        if(expected!=epoch||!connecting){fresh.close();return;}
        if(!fresh.connected()){fresh.close();connectionFailed(expected,"Disconnected");return;}
        cancelTimeout();
        gateway.setEnabled(true);
        clearConnectionProblem();
        awaitingConsent=false;
        if(!started){fresh.close();detach();publish("Spotify autorisé");return;}
        connecting=false;remote=fresh;generation++;final long bound=generation;readout=Readout.empty();
        publish("Spotify connecté");
        try{fresh.observe(new Observer(){
            public void changed(Readout value){dispatcher.post(()->{synchronized(SpotifyController.this){
                if(!started||remote!=fresh||bound!=generation)return;
                if(value!=null&&value.playerRevision<readout.playerRevision)return;
                readout=value==null?Readout.empty():value;publish("Lecture dans l’application Spotify officielle.");
            }});}
            public void lost(){dispatcher.post(()->{synchronized(SpotifyController.this){
                if(remote!=fresh||bound!=generation)return;detach();publish("La connexion Spotify est terminée. Reconnecte-toi.");
            }});}
        });}catch(RuntimeException error){detach();publish("L’état Spotify est indisponible. Reconnecte-toi.");}
    }
    private void cancelTimeout(){if(timeout!=null){dispatcher.remove(timeout);timeout=null;}}
    private void detach(){cancelTimeout();epoch++;commandSerial++;connecting=false;awaitingConsent=false;generation++;readout=Readout.empty();Remote old=remote;remote=null;if(old!=null)try{old.close();}catch(RuntimeException ignored){}}
    public synchronized void refresh(){
        if(!started)return;
        if(remote!=null&&!remote.connected()){detach();publish("La connexion Spotify est terminée. Reconnecte-toi.");}
        else if(remote!=null)publish("Lecture dans l’application Spotify officielle.");
        else if(!connecting)publish(!connectionProblem.isEmpty()?connectionProblem:
            configured()?"Spotify déconnecté":"Spotify est indisponible dans cette version de Rhythmbox.");
    }
    private void publish(String status){
        State next=new State(readout,remote!=null&&!connecting,connecting,status,generation);current=next;long serial=++publication;
        dispatcher.post(()->{synchronized(SpotifyController.this){if(serial==publication)listener.onState(next);}});
    }
    public boolean resume(){return resume(null);}
    public boolean resume(Runnable rejected){return command(Command.PLAY,0,null,rejected,null);}
    public boolean pause(){return pause(null);}
    public boolean pause(Runnable verified){return command(Command.PAUSE,0,null,null,verified);}
    public boolean next(){return next(null);}
    public boolean next(Runnable rejected){return command(Command.NEXT,0,null,rejected,null);}
    public boolean previous(){return previous(null);}
    public boolean previous(Runnable rejected){return command(Command.PREVIOUS,0,null,rejected,null);}
    public boolean seekTo(long position){return command(Command.SEEK,position,null);}
    public boolean setShuffle(boolean value){return command(Command.SHUFFLE,value?1:0,null);}
    public boolean setRepeat(int mode){return command(Command.REPEAT,mode,null);}
    public boolean cycleRepeat(){State state=current;for(int step=1;step<=3;step++){int mode=(state.repeatMode+step)%3;if(mode==0||mode==1&&state.canRepeatTrack||mode==2&&state.canRepeatContext)return setRepeat(mode);}return false;}
    public boolean playUri(String input){return playUri(input,null);}
    public boolean playUri(String input,Runnable rejected){return command(Command.PLAY_URI,0,SpotifyUri.parse(input),rejected,null);}
    private synchronized boolean command(Command command,long value,String uri){
        return command(command,value,uri,null,null);
    }
    private synchronized boolean command(Command command,long value,String uri,Runnable rejected,Runnable pauseVerified){
        if(!started||remote==null||!remote.connected()){refresh();return false;}
        State state=current;
        // App Remote Pause can cancel an in-flight Play before the first Track
        // arrives. The visible pause button remains track-gated; source handoff
        // may pause any established SDK connection without inventing metadata.
        boolean allowed=command==Command.PLAY?state.canPlay:command==Command.PAUSE?true:
            command==Command.NEXT?state.canNext:command==Command.PREVIOUS?state.canPrevious:
            command==Command.SEEK?state.canSeek:command==Command.SHUFFLE?state.shufflePossible:
            command==Command.REPEAT?state.repeatPossible:true;
        if(!allowed){publish("Cette commande n’est pas disponible dans Spotify pour le moment.");return false;}
        if(command==Command.PLAY_URI&&uri.startsWith("spotify:track:")&&(!state.capabilitiesKnown||!state.canPlayOnDemand)){
            publish(state.capabilitiesKnown?"La lecture d’un morceau précis nécessite Spotify Premium.":"Spotify vérifie les possibilités de ce compte. Réessaie dans un instant.");return false;
        }
        if(command==Command.SEEK){if(value<0)return false;if(state.duration>0)value=Math.min(value,state.duration);}
        if(command==Command.REPEAT&&(value<0||value>2||value==1&&!state.canRepeatTrack||value==2&&!state.canRepeatContext))return false;
        final Remote target=remote;final long expected=generation,serial=++commandSerial;
        try{
            target.perform(command,value,uri,accepted->dispatcher.post(()->{synchronized(SpotifyController.this){
                if(!started||remote!=target||expected!=generation)return;
                // A later mode/seek command must not swallow this start's
                // failure. Its captured UI intent decides whether it matters.
                if(!accepted&&rejected!=null)reconcile(target,expected,rejected,false);
                else if(accepted&&command==Command.PAUSE)reconcile(target,expected,pauseVerified,true);
                if(!accepted&&serial==commandSerial)publish("Spotify n’a pas confirmé cette commande. Vérification de son état…");
            }}));
            // Only subscribed PlayerState updates may assert that playback changed.
            publish(command==Command.PAUSE?"Pause demandée à Spotify…":"Commande envoyée à Spotify…");return true;
        }catch(RuntimeException error){
            // Transport failure after entering Remote may follow an actual
            // send. Keep the start fence until a fresh read settles it.
            if(rejected!=null)reconcile(target,expected,rejected,false);
            else if(command==Command.PAUSE)reconcile(target,expected,pauseVerified,true);
            publish("Spotify n’a pas confirmé cette commande. Vérification de son état…");return true;
        }
    }

    private void reconcile(Remote target,long expected,Runnable settled,boolean requirePaused){
        final long queryCommand=commandSerial,baseline=readout.playerRevision,readRequest=++readRequestSerial;
        try{target.readState(value->dispatcher.post(()->{synchronized(SpotifyController.this){
            // A query requested before a newer Play/Pause cannot confirm it.
            if(!started||remote!=target||expected!=generation||queryCommand!=commandSerial||readRequest!=readRequestSerial||!target.connected())return;
            Readout fresh=value!=null&&value.playerRevision>readout.playerRevision?value:readout;
            if(fresh.playerRevision<=baseline)return; // no proof from a cached state/error
            readout=fresh;publish(requirePaused?"Lecture dans l’application Spotify officielle.":"Commande non confirmée ; état Spotify actualisé.");
            if(settled!=null&&(!requirePaused||!fresh.playing))settled.run();
        }}));}catch(RuntimeException ignored){/* Unknown outcome keeps the pending-start fence. */}
    }

    static Readout sdkReadout(PlayerState state,Bitmap cover,boolean onDemand,boolean known,long observedAt){
        return sdkReadout(state,cover,onDemand,known,observedAt,0);
    }
    static Readout sdkReadout(PlayerState state,Bitmap cover,boolean onDemand,boolean known,long observedAt,long playerRevision){
        Track track=state==null?null:state.track;
        if(track==null)return new Readout("","","","",null,false,0,0,false,false,false,false,false,0,0,onDemand,known,0,0,playerRevision);
        PlayerRestrictions restrictions=state.playbackRestrictions;
        return new Readout(track.uri,track.name,track.artist==null?"":track.artist.name,
            track.album==null?"":track.album.name,cover,!state.isPaused,state.playbackPosition,track.duration,
            restrictions!=null&&restrictions.canSkipNext,restrictions!=null&&restrictions.canSkipPrev,restrictions!=null&&restrictions.canSeek,
            restrictions!=null&&restrictions.canToggleShuffle,state.playbackOptions!=null&&state.playbackOptions.isShuffling,
            (restrictions!=null&&restrictions.canRepeatTrack?1:0)|(restrictions!=null&&restrictions.canRepeatContext?2:0),state.playbackOptions==null?0:state.playbackOptions.repeatMode,
            onDemand,known,state.playbackSpeed,observedAt,playerRevision);
    }

    /** Actual official SDK boundary, separate from the state-machine test seam. */
    private static final class AndroidGateway implements Gateway {
        final Context context;final android.content.SharedPreferences preferences;
        AndroidGateway(Context context){this.context=context;preferences=context.getSharedPreferences("spotify_app_remote",Context.MODE_PRIVATE);}
        public String clientId(){String override=preferences.getString("client_id","");if(!override.isEmpty())return override;int resource=context.getResources().getIdentifier("spotify_app_remote_client_id","string",context.getPackageName());return resource==0?"":context.getString(resource).trim();}
        public void configure(String id){preferences.edit().putString("client_id",id).apply();}
        public boolean enabled(){return preferences.getBoolean("enabled",false);}
        public void setEnabled(boolean value){preferences.edit().putBoolean("enabled",value).apply();}
        public boolean installed(){return SpotifyAppRemote.isSpotifyInstalled(context);}
        public void connect(boolean authorize,Connection callback){
            SpotifyAppRemote.setDebugMode(false);
            ConnectionParams params=new ConnectionParams.Builder(clientId()).setRedirectUri(REDIRECT_URI).showAuthView(authorize).build();
            SpotifyAppRemote.connect(context,params,new Connector.ConnectionListener(){
                public void onConnected(SpotifyAppRemote app){callback.connected(new SdkRemote(app));}
                public void onFailure(Throwable failure){callback.failed(failure==null?"AppRemoteError":failure.getClass().getSimpleName());}
            });
        }
    }
    private static final class SdkRemote implements Remote {
        final SpotifyAppRemote app;Observer observer;Subscription<PlayerState> states;Subscription<Capabilities> capabilities;
        PlayerState latest;Bitmap cover;String coverKey="";boolean closed,known,onDemand;long imageGeneration,playerObservedAt,playerRevision,revisionCounter;
        SdkRemote(SpotifyAppRemote app){this.app=app;}
        public boolean connected(){return !closed&&app.isConnected();}
        public void observe(Observer callback){
            observer=callback;
            capabilities=app.getUserApi().subscribeToCapabilities();
            capabilities.setEventCallback(value->{if(closed)return;known=value!=null;onDemand=value!=null&&value.canPlayOnDemand;emit();});
            capabilities.setErrorCallback(error->{if(!closed){known=false;onDemand=false;emit();}});
            states=app.getPlayerApi().subscribeToPlayerState();
            states.setEventCallback(value->{synchronized(SdkRemote.this){if(closed)return;latest=value;playerRevision=++revisionCounter;playerObservedAt=SystemClock.elapsedRealtime();updateCover();emit();}});
            states.setLifecycleCallback(new Subscription.LifecycleCallback(){
                public void onStart(){}
                public void onStop(){if(!closed&&observer!=null)observer.lost();}
            });
            states.setErrorCallback(error->{if(!closed&&observer!=null)observer.lost();});
        }
        private void emit(){
            if(!closed&&observer!=null)observer.changed(sdkReadout(latest,cover,onDemand,known,playerObservedAt,playerRevision));
        }
        private void updateCover(){
            Track track=latest==null?null:latest.track;String key=track==null||track.imageUri==null?"":text(track.imageUri.raw);
            if(key.equals(coverKey))return;coverKey=key;cover=null;final long request=++imageGeneration;if(key.isEmpty())return;
            app.getImagesApi().getImage(track.imageUri).setResultCallback(bitmap->{
                if(closed||request!=imageGeneration)return;
                try{if(bitmap!=null&&!bitmap.isRecycled()&&bitmap.getWidth()>0&&bitmap.getHeight()>0){
                    double scale=Math.min(1.,512./Math.max(bitmap.getWidth(),bitmap.getHeight()));
                    Bitmap scaled=Bitmap.createScaledBitmap(bitmap,Math.max(1,(int)(bitmap.getWidth()*scale)),Math.max(1,(int)(bitmap.getHeight()*scale)),true);
                    cover=scaled.copy(Bitmap.Config.ARGB_8888,false);emit();
                }}catch(RuntimeException|OutOfMemoryError ignored){cover=null;}
            }).setErrorCallback(error->{/* Missing artwork never switches to a scraper. */});
        }
        public void close(){closed=true;observer=null;imageGeneration++;if(states!=null)states.cancel();if(capabilities!=null)capabilities.cancel();SpotifyAppRemote.disconnect(app);}
        public synchronized void readState(ReadResult callback){
            if(!connected()){callback.done(null);return;}
            final long baseline=playerRevision;
            app.getPlayerApi().getPlayerState().setResultCallback(value->{synchronized(SdkRemote.this){
                if(!connected()){callback.done(null);return;}
                if(playerRevision>baseline){callback.done(sdkReadout(latest,cover,onDemand,known,playerObservedAt,playerRevision));return;}
                // Reserve a distinct revision without replacing subscription
                // data. Controller accepts this result only if no later
                // transport command/session invalidated the read request.
                Track track=value==null?null:value.track;
                String image=track==null||track.imageUri==null?"":text(track.imageUri.raw);
                callback.done(value==null?null:sdkReadout(value,image.equals(coverKey)?cover:null,onDemand,known,SystemClock.elapsedRealtime(),++revisionCounter));
            }}).setErrorCallback(error->callback.done(null));
        }
        public void perform(Command command,long value,String uri,Result callback){
            if(!connected()){callback.done(false);return;}CallResult<Empty> result;
            switch(command){
                case PLAY:result=app.getPlayerApi().resume();break;case PAUSE:result=app.getPlayerApi().pause();break;
                case NEXT:result=app.getPlayerApi().skipNext();break;case PREVIOUS:result=app.getPlayerApi().skipPrevious();break;
                case SEEK:result=app.getPlayerApi().seekTo(value);break;case SHUFFLE:result=app.getPlayerApi().setShuffle(value!=0);break;
                case REPEAT:result=app.getPlayerApi().setRepeat((int)value);break;case PLAY_URI:result=app.getPlayerApi().play(uri);break;
                default:callback.done(false);return;
            }
            result.setResultCallback(ignored->callback.done(true)).setErrorCallback(error->callback.done(false));
        }
    }
}
