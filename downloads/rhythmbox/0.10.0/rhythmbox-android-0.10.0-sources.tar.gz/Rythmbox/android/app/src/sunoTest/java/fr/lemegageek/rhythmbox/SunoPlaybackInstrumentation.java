package fr.lemegageek.rhythmbox;

import android.app.Instrumentation;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import org.json.JSONArray;
import org.json.JSONObject;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Separate-UID, no-Internet real codec test with an in-memory rights server. */
public final class SunoPlaybackInstrumentation extends Instrumentation {
    private static final String SONG="00000000-0000-4000-8000-000000000001";
    private static final String URL="https://d2lwuy8qc234o3.cloudfront.net/1/clip/"+SONG+".m4a";
    private int checks,failures;private final JSONArray scenarios=new JSONArray();
    private interface Checked {void run() throws Exception;}
    private void yes(boolean value,String why){checks++;if(!value)throw new AssertionError(why);}
    @Override public void onCreate(Bundle arguments){super.onCreate(arguments);start();}
    @Override public void onStart(){
        try{
            yes(getContext().getPackageName().equals("fr.lemegageek.rhythmbox.sunotest"),"Separate test package");
            yes(getContext().checkSelfPermission("android.permission.INTERNET")==PackageManager.PERMISSION_DENIED,"No Internet permission");
            scenario("AAC-MP4 encrypted native playback",()->audio("aac.m4a",false));
            scenario("Opus-MP4 encrypted native playback",()->audio("opus.mp4",true));
            scenario("Video-only MP4 rejected before start",this::videoOnly);
            scenario("Blocked prepare cancellation",this::cancelledPrepare);
        }catch(Throwable failure){failures++;try{scenarios.put(new JSONObject().put("scenario","runner").put("ok",false).put("error",failure.getClass().getSimpleName()+": "+failure.getMessage()));}catch(Exception ignored){}}
        Bundle result=new Bundle();
        try{result.putString("report",new JSONObject().put("assertions",checks).put("failures",failures).put("scenarios",scenarios).put("package",getContext().getPackageName()).put("network_permission",false).put("production_app_data_accessed",false).put("audio_volume",0).put("encrypted_test_data_in_memory_only",true).toString());}
        catch(Exception impossible){result.putString("report","{\"failures\":1}");}
        finish(failures==0?-1:0,result);
    }
    private void scenario(String name,Checked action){
        try{action.run();scenarios.put(new JSONObject().put("scenario",name).put("ok",true));}
        catch(Throwable failure){failures++;try{scenarios.put(new JSONObject().put("scenario",name).put("ok",false).put("error",failure.getClass().getSimpleName()+": "+failure.getMessage()));}catch(Exception ignored){}}
    }
    private byte[] fixture(String name) throws IOException {
        try(InputStream input=getContext().getAssets().open("suno-fixtures/"+name);ByteArrayOutputStream output=new ByteArrayOutputStream()){
            byte[] block=new byte[8192];int n;while((n=input.read(block))!=-1){output.write(block,0,n);if(output.size()>1024*1024)throw new IOException("Synthetic fixture exceeds1MiB");}return output.toByteArray();
        }
    }
    private JSONObject track() throws Exception{return new JSONObject().put("id","suno:"+SONG).put("stream_uri",URL).put("stream_encoding","1.0.0");}
    private final class Player implements Closeable {
        final HandlerThread thread=new HandlerThread("suno-codec-test");final Handler handler;
        final CountDownLatch prepared=new CountDownLatch(1),seeked=new CountDownLatch(1);MediaPlayer value;int errorWhat,errorExtra;
        Player() throws Exception {thread.start();handler=new Handler(thread.getLooper());call(()->{
            value=new MediaPlayer();value.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());value.setSurface(null);value.setVolume(0,0);
            value.setOnPreparedListener(p->prepared.countDown());value.setOnSeekCompleteListener(p->seeked.countDown());
            value.setOnErrorListener((p,what,extra)->{errorWhat=what;errorExtra=extra;prepared.countDown();return true;});
        });}
        void call(Checked action) throws Exception {
            CountDownLatch done=new CountDownLatch(1);AtomicReference<Throwable> failure=new AtomicReference<>();handler.post(()->{try{action.run();}catch(Throwable error){failure.set(error);}finally{done.countDown();}});
            if(!done.await(8,TimeUnit.SECONDS))throw new AssertionError("Codec operation timed out");
            if(failure.get()!=null)throw new Exception("Codec operation failed",failure.get());
        }
        void prepare(SunoMediaDataSource source) throws Exception {call(()->{value.setDataSource(source);value.prepareAsync();});}
        int position() throws Exception {int[] out={0};call(()->out[0]=value.getCurrentPosition());return out[0];}
        boolean playing() throws Exception {boolean[] out={false};call(()->out[0]=value.isPlaying());return out[0];}
        boolean hasAudio() throws Exception {boolean[] out={false};call(()->{MediaPlayer.TrackInfo[] tracks=value.getTrackInfo();if(tracks!=null)for(MediaPlayer.TrackInfo item:tracks)if(item.getTrackType()==MediaPlayer.TrackInfo.MEDIA_TRACK_TYPE_AUDIO)out[0]=true;});return out[0];}
        public void close(){try{call(()->{if(value!=null){value.release();value=null;}});}catch(Exception ignored){}thread.quitSafely();}
    }
    private void audio(String name,boolean optional) throws Exception {
        Fake server=new Fake(fixture(name));SunoAudio.Cancellation token=new SunoAudio.Cancellation();SunoMediaDataSource source=SunoMediaDataSource.open(track(),server,token);
        try(Player player=new Player()){
            player.prepare(source);yes(player.prepared.await(8,TimeUnit.SECONDS),"Real decoder answers");
            if(optional&&player.errorExtra==MediaPlayer.MEDIA_ERROR_UNSUPPORTED){scenarios.put(new JSONObject().put("codec",name).put("supported",false).put("reason","Android reports unsupported codec"));return;}
            yes(player.errorWhat==0,"Real decoder prepared, error="+player.errorWhat+"/"+player.errorExtra);yes(player.hasAudio(),"Decoded container has audio");
            int[] duration={0};player.call(()->duration[0]=player.value.getDuration());yes(duration[0]>=5000,"Decoded duration matches synthetic clip");
            player.call(()->player.value.start());SystemClock.sleep(300);yes(player.playing(),"Muted player is running");yes(player.position()>0,"Actual audio clock advances");
            player.call(()->player.value.pause());yes(!player.playing(),"Pause effective");int paused=player.position();SystemClock.sleep(200);yes(Math.abs(player.position()-paused)<100,"Pause clock stable");
            player.call(()->player.value.start());SystemClock.sleep(200);yes(player.playing(),"Resume effective");
            player.call(()->player.value.seekTo(1500,MediaPlayer.SEEK_CLOSEST));yes(player.seeked.await(4,TimeUnit.SECONDS),"Seek acknowledged");yes(player.position()>=1300,"Random-read seek reached requested time");
            player.call(()->player.value.pause());yes(server.rightsCalls==1&&server.mediaCalls>0,"Real codec reads through one guest grant");
            scenarios.put(new JSONObject().put("codec",name).put("supported",true).put("duration_ms",duration[0]).put("rights_requests",server.rightsCalls).put("media_ranges",server.mediaCalls));
        }finally{source.close();token.close();server.close();}
        boolean failed=false;try{source.readAt(0,new byte[1],0,1);}catch(IOException expected){failed=true;}yes(failed,"Closed source rejects later read");
    }
    private void videoOnly() throws Exception {
        Fake server=new Fake(fixture("no-audio.mp4"));SunoMediaDataSource source=SunoMediaDataSource.open(track(),server,new SunoAudio.Cancellation());
        try(Player player=new Player()){
            player.prepare(source);yes(player.prepared.await(8,TimeUnit.SECONDS),"Video-only container inspected");yes(player.errorWhat==0,"Container opens for track inspection");yes(!player.hasAudio(),"No audio track: integration rejects before start");yes(!player.playing(),"Non-audio file never starts");
        }finally{source.close();server.close();}
    }
    private void cancelledPrepare() throws Exception {
        Fake server=new Fake(fixture("aac.m4a"));SunoAudio.Cancellation token=new SunoAudio.Cancellation();SunoMediaDataSource source=SunoMediaDataSource.open(track(),server,token);server.blockMedia=true;
        try(Player player=new Player()){
            player.prepare(source);yes(server.entered.await(4,TimeUnit.SECONDS),"Real MediaPlayer has an in-flight data read");
            CountDownLatch ui=new CountDownLatch(1);new Handler(Looper.getMainLooper()).post(ui::countDown);yes(ui.await(500,TimeUnit.MILLISECONDS),"Android main thread remains responsive");
            long start=SystemClock.elapsedRealtime();source.close();yes(SystemClock.elapsedRealtime()-start<250,"Data source close never waits for blocked codec/network");
            yes(server.finished.await(3,TimeUnit.SECONDS),"Cancellation disconnects blocked data read");
        }finally{source.close();token.close();server.released.countDown();server.close();}
    }
    private static final class Reply implements SunoAudio.Response {
        final int status;final Map<String,String> headers;final byte[] bytes;final String url;InputStream stream;Closeable registration;
        Reply(int status,Map<String,String> headers,byte[] bytes,String url){this.status=status;this.headers=headers;this.bytes=bytes;this.url=url;}
        public int status(){return status;}public String url(){return url;}public String header(String name){return headers.get(name);}
        public InputStream body(){return stream!=null?stream:new ByteArrayInputStream(bytes);}
        public void close() throws IOException {if(registration!=null)registration.close();}
    }
    private static final class Fake implements SunoAudio.Transport,Closeable {
        final byte[] key=new byte[16],iv=new byte[16],encrypted;final JSONObject rights;volatile int rightsCalls,mediaCalls;volatile boolean blockMedia;
        final CountDownLatch entered=new CountDownLatch(1),released=new CountDownLatch(1),finished=new CountDownLatch(1);
        Fake(byte[] plain) throws Exception {
            SecureRandom random=new SecureRandom();random.nextBytes(key);random.nextBytes(iv);
            // Keep this tiny synthetic counter far from the wrap boundary.
            iv[0]=1;String guest="synthetic-android-guest-only";byte[] wrapping=MessageDigest.getInstance("SHA-256").digest(guest.getBytes(StandardCharsets.UTF_8));
            rights=new JSONObject().put("glt",guest).put("key",wrap(key,wrapping,random)).put("iv",wrap(iv,wrapping,random));Arrays.fill(wrapping,(byte)0);
            Cipher cipher=Cipher.getInstance("AES/CTR/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(key,"AES"),new IvParameterSpec(iv));encrypted=cipher.doFinal(plain);Arrays.fill(plain,(byte)0);
        }
        static String wrap(byte[] value,byte[] key,SecureRandom random) throws Exception {
            byte[] nonce=new byte[12];random.nextBytes(nonce);Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,nonce));cipher.updateAAD(SONG.getBytes(StandardCharsets.US_ASCII));byte[] data=cipher.doFinal(value),frame=new byte[nonce.length+data.length];System.arraycopy(nonce,0,frame,0,nonce.length);System.arraycopy(data,0,frame,nonce.length,data.length);String out=Base64.getEncoder().encodeToString(frame);Arrays.fill(nonce,(byte)0);Arrays.fill(data,(byte)0);Arrays.fill(frame,(byte)0);return out;
        }
        public SunoAudio.Response open(SunoAudio.Request request,SunoAudio.Cancellation cancellation) throws IOException {
            Map<String,String> headers=new HashMap<>();int status=200;byte[] bytes;
            if(request.url.equals(SunoAudio.RIGHTS_URL)){rightsCalls++;bytes=rights.toString().getBytes(StandardCharsets.UTF_8);headers.put("Content-Type","application/json");}
            else if(request.url.equals(URL)){
                headers.put("Content-Type","audio/mp4");
                if(request.method.equals("HEAD")){bytes=new byte[0];headers.put("Content-Length",Integer.toString(encrypted.length));return new Reply(200,headers,bytes,request.url);}
                Matcher range=Pattern.compile("bytes=([0-9]+)-([0-9]+)").matcher(request.headers.get("Range"));if(!range.matches())throw new IOException("Unexpected test range");int start=Integer.parseInt(range.group(1)),end=Integer.parseInt(range.group(2));if(start<0||end>=encrypted.length)throw new IOException("Test range outside fixture");bytes=Arrays.copyOfRange(encrypted,start,end+1);headers.put("Content-Range","bytes "+start+"-"+end+"/"+encrypted.length);status=206;mediaCalls++;
            }else throw new IOException("Unexpected test destination");
            headers.put("Content-Length",Integer.toString(bytes.length));Reply reply=new Reply(status,headers,bytes,request.url);
            if(blockMedia&&request.url.equals(URL)){
                reply.registration=cancellation.register(released::countDown);reply.stream=new InputStream(){
                    private int blocked() throws IOException {entered.countDown();try{released.await(6,TimeUnit.SECONDS);cancellation.check();throw new IOException("Synthetic block timed out");}catch(InterruptedException interrupted){Thread.currentThread().interrupt();throw new IOException("Synthetic block interrupted");}finally{finished.countDown();}}
                    public int read() throws IOException{return blocked();}public int read(byte[] buffer,int offset,int size) throws IOException{return blocked();}
                };
            }
            return reply;
        }
        public void close(){released.countDown();Arrays.fill(key,(byte)0);Arrays.fill(iv,(byte)0);Arrays.fill(encrypted,(byte)0);}
    }
}
