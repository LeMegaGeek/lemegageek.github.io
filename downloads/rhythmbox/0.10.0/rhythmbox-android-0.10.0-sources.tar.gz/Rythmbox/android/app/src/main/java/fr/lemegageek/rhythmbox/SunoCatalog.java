package fr.lemegageek.rhythmbox;

import org.json.JSONArray;
import org.json.JSONObject;
import javax.net.ssl.HttpsURLConnection;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.CookieHandler;
import java.net.URI;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Public share-page metadata only. No JavaScript execution, account session,
 * private API, audio request, download/unlock or credit action occurs here.
 * Cookies and pCloud credentials are never accepted or discovered. */
public final class SunoCatalog {
    public static final int MAX_HTML_BYTES=4*1024*1024,MAX_TOTAL_BYTES=16*1024*1024;
    public static final int MAX_REQUESTS=100,MAX_REDIRECTS=3,MAX_TRACKS=5000,MAX_RECORDS=20000,MAX_NODES=200000,MAX_DEPTH=64;
    private static final String UUID="[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}";
    private static final Pattern PAGE=Pattern.compile("^/(song|playlist)/("+UUID+")/?$"),SHORT=Pattern.compile("^/s/[A-Za-z0-9_-]{6,128}/?$"),ID=Pattern.compile(UUID);
    private static final Pattern MEDIA=Pattern.compile("^/1/clip/("+UUID+")\\.m4a$"),COVER=Pattern.compile("^/[A-Za-z0-9_-]+\\.(?:jpeg|jpg|png|webp)$");
    private static final Pattern PUSH=Pattern.compile("\\s*self\\.__next_f\\.push\\(");
    private static final Set<String> PAGE_HOSTS=new HashSet<>(Arrays.asList("suno.com")),MEDIA_HOSTS=new HashSet<>(Arrays.asList("d2lwuy8qc234o3.cloudfront.net")),COVER_HOSTS=new HashSet<>(Arrays.asList("cdn1.suno.ai","cdn2.suno.ai"));
    private SunoCatalog(){}
    public static final class CatalogException extends Exception {public CatalogException(String message){super(message);}}
    private static CatalogException fail(String text){return new CatalogException(text);}

    /** Transport returns an individual unauthenticated page/redirect response.
     * The reader validates every destination and charges every fetch. */
    public interface PageTransport {Page fetch(String url,long deadlineNanos) throws Exception;}
    public static final class Page {
        public final int status;public final String location,contentType,encoding;public final byte[] body;
        public Page(String html) throws Exception {this(200,null,"text/html","identity",utf8(html));}
        public Page(int status,String location,String contentType,String encoding,byte[] body){this.status=status;this.location=location;this.contentType=contentType;this.encoding=encoding;this.body=body==null?null:body.clone();}
    }
    private static byte[] utf8(String value) throws CatalogException {
        if(value==null)throw fail("Texte de page Suno absent.");
        try{ByteBuffer bytes=StandardCharsets.UTF_8.newEncoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).encode(CharBuffer.wrap(value));byte[] out=new byte[bytes.remaining()];bytes.get(out);return out;}
        catch(CharacterCodingException error){throw fail("Texte Suno non valide.");}
    }
    private static String decode(byte[] bytes,int start,int count) throws CatalogException {
        try{return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes,start,count)).toString();}
        catch(CharacterCodingException error){throw fail("Texte Suno non valide.");}
    }
    private static URI https(String value,Set<String> hosts) throws CatalogException {
        if(value==null||value.isEmpty()||value.length()>4096)throw fail("Adresse Suno non valide.");
        for(int i=0;i<value.length();i++){char c=value.charAt(i);if(c<=32||c==127||c=='\\')throw fail("Adresse Suno non valide.");}
        try{URI uri=new URI(value);String host=uri.getHost();if(!"https".equalsIgnoreCase(uri.getScheme())||host==null||!hosts.contains(host.toLowerCase(Locale.ROOT))||uri.getRawUserInfo()!=null||(uri.getPort()!=-1&&uri.getPort()!=443)||uri.getRawFragment()!=null)throw fail("Adresse HTTPS Suno non autorisée.");return uri;}
        catch(CatalogException error){throw error;}catch(Exception error){throw fail("Adresse HTTPS Suno non autorisée.");}
    }
    public static String canonicalLink(String value) throws Exception {
        if(value!=null){for(int i=0;i<value.length();i++)if(value.charAt(i)<=32||value.charAt(i)==127)throw fail("Adresse Suno non valide.");int fragment=value.indexOf('#');if(fragment>=0)value=value.substring(0,fragment);}
        URI uri=https(value,PAGE_HOSTS);String path=uri.getRawPath();if(path==null||(!PAGE.matcher(path).matches()&&!SHORT.matcher(path).matches()))throw fail("Coller un lien Suno de morceau ou de playlist.");
        return "https://suno.com"+(path.endsWith("/")?path.substring(0,path.length()-1):path);
    }
    public static boolean validStreamUri(String value,String songId){
        try{URI uri=https(value,MEDIA_HOSTS);Matcher m=MEDIA.matcher(uri.getRawPath());return m.matches()&&(songId==null||songId.equals(m.group(1)));}catch(Exception error){return false;}
    }
    public static boolean validCoverUri(String value){try{return value!=null&&!value.isEmpty()&&COVER.matcher(https(value,COVER_HOSTS).getRawPath()).matches();}catch(Exception error){return false;}}
    private static String cover(Object value){return value instanceof String&&validCoverUri((String)value)?(String)value:"";}
    /** Recognition deliberately keeps malformed Suno markers on the Suno path;
     * callers must validate them, never fall back to a pCloud account. */
    public static boolean isSunoTrack(JSONObject value){if(value==null)return false;Object service=value.opt("service"),id=value.opt("id");return "suno".equals(service)||(id instanceof String&&((String)id).startsWith("suno:"));}
    private static Object nullable(Object value){return value==JSONObject.NULL?null:value;}
    private static String rawString(Object value) throws CatalogException {if(!(value instanceof String))throw fail("Métadonnée Suno non valide.");return (String)value;}
    private static String strip(String value){int a=0,b=value.length();while(a<b&&(Character.isWhitespace(value.charAt(a))||Character.isSpaceChar(value.charAt(a))))a++;while(b>a&&(Character.isWhitespace(value.charAt(b-1))||Character.isSpaceChar(value.charAt(b-1))))b--;return value.substring(a,b);}
    private static String text(Object value,String fallback) throws CatalogException {
        value=nullable(value);if(value==null)return fallback;String s=rawString(value);if(s.codePointCount(0,s.length())>4096)throw fail("Métadonnée Suno trop longue.");
        for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c<32&&c!='\t'&&c!='\n'&&c!='\r')throw fail("Métadonnée Suno non valide.");}
        utf8(s);if(s.matches("\\$[A-Za-z0-9]+"))return fallback;s=strip(s);return s.isEmpty()?fallback:s;
    }
    private static double duration(Object value) throws CatalogException {if(!(value instanceof Number))throw fail("Durée du morceau Suno non valide.");double n=((Number)value).doubleValue();if(Double.isNaN(n)||Double.isInfinite(n)||n<0||n>86400)throw fail("Durée du morceau Suno non valide.");return n;}
    /** Canonical metadata copy; stream_encoding must be explicit even if null. */
    public static JSONObject validateTrack(JSONObject raw) throws Exception {
        if(raw==null)throw fail("Morceau Suno absent.");String identifier=rawString(raw.opt("id"));if(!identifier.startsWith("suno:")||!ID.matcher(identifier.substring(5)).matches())throw fail("Identifiant du morceau Suno non valide.");String songId=identifier.substring(5);
        if(raw.has("service")&&!"suno".equals(raw.opt("service")))throw fail("Service du morceau Suno contradictoire.");
        for(String key:new String[]{"pcloud_account_userid","pcloud_fileid","media_path","local_uri"})if(raw.has(key))throw fail("Origine du morceau Suno contradictoire.");
        String source=canonicalLink(rawString(raw.opt("source_url")));if(!source.equals("https://suno.com/song/"+songId))throw fail("La page ne correspond pas au morceau Suno.");
        String stream=rawString(raw.opt("stream_uri"));if(!validStreamUri(stream,songId))throw fail("Flux audio Suno non autorisé.");
        if(!raw.has("stream_encoding"))throw fail("Encodage du flux Suno absent.");Object encoding=nullable(raw.opt("stream_encoding"));if(encoding!=null&&!"1.0.0".equals(encoding))throw fail("Encodage du flux Suno non reconnu.");
        String image=raw.has("cover_uri")?rawString(raw.opt("cover_uri")):"";if(!image.isEmpty()&&!validCoverUri(image))throw fail("Pochette Suno non autorisée.");
        return new JSONObject().put("id",identifier).put("service","suno").put("title",text(raw.opt("title"),"Morceau Suno")).put("artist",text(raw.opt("artist"),"")).put("album",text(raw.opt("album"),"")).put("source_url",source).put("stream_uri",stream).put("stream_encoding",encoding==null?JSONObject.NULL:encoding).put("duration",duration(raw.opt("duration"))).put("cover_uri",image);
    }
    private static String[] route(String url) throws Exception {Matcher m=PAGE.matcher(new URI(url).getRawPath());return m.matches()?new String[]{m.group(1),m.group(2)}:new String[]{null,null};}

    /** Strict JSON, unlike JSONObject's deliberately lenient JavaScript-like
     * tokenizer. Bounds are enforced before recursive org.json construction. */
    private static final class Json {
        final String input;int at,nodes;Json(String input){this.input=input;}
        void white(){while(at<input.length()&&" \t\r\n".indexOf(input.charAt(at))>=0)at++;}
        Object parse(int depth) throws Exception {
            white();if(depth>MAX_DEPTH||++nodes>MAX_NODES||at>=input.length())throw fail("Structure JSON Suno trop complexe ou incomplète.");char c=input.charAt(at);
            if(c=='"')return string();
            if(c=='{'){at++;JSONObject object=new JSONObject();Set<String> keys=new HashSet<>();white();if(take('}'))return object;for(;;){white();if(at>=input.length()||input.charAt(at)!='"')throw fail("Objet JSON Suno non valide.");String key=string();if(!keys.add(key))throw fail("Clé JSON Suno répétée.");white();need(':');object.put(key,parse(depth+1));white();if(take('}'))return object;need(',');}}
            if(c=='['){at++;JSONArray array=new JSONArray();white();if(take(']'))return array;for(;;){array.put(parse(depth+1));white();if(take(']'))return array;need(',');}}
            if(input.startsWith("true",at)){at+=4;return Boolean.TRUE;}if(input.startsWith("false",at)){at+=5;return Boolean.FALSE;}if(input.startsWith("null",at)){at+=4;return JSONObject.NULL;}
            int start=at;if(c=='-')at++;if(at>=input.length())throw fail("Nombre JSON Suno non valide.");if(input.charAt(at)=='0')at++;else{if(input.charAt(at)<'1'||input.charAt(at)>'9')throw fail("Nombre JSON Suno non valide.");while(at<input.length()&&digit(input.charAt(at)))at++;}
            boolean decimal=false;if(at<input.length()&&input.charAt(at)=='.'){decimal=true;at++;int first=at;while(at<input.length()&&digit(input.charAt(at)))at++;if(first==at)throw fail("Nombre JSON Suno non valide.");}
            if(at<input.length()&&(input.charAt(at)=='e'||input.charAt(at)=='E')){decimal=true;at++;if(at<input.length()&&(input.charAt(at)=='+'||input.charAt(at)=='-'))at++;int first=at;while(at<input.length()&&digit(input.charAt(at)))at++;if(first==at)throw fail("Nombre JSON Suno non valide.");}
            try{String token=input.substring(start,at);if(token.length()>128)throw fail("Nombre JSON Suno trop long.");if(!decimal)return Long.valueOf(token);double n=Double.parseDouble(token);if(Double.isNaN(n)||Double.isInfinite(n))throw fail("Nombre JSON Suno non fini.");return n;}catch(NumberFormatException error){throw fail("Nombre JSON Suno non valide.");}
        }
        static boolean digit(char c){return c>='0'&&c<='9';}
        boolean take(char c){if(at<input.length()&&input.charAt(at)==c){at++;return true;}return false;}
        void need(char c) throws CatalogException {if(!take(c))throw fail("Séparateur JSON Suno non valide.");}
        String string() throws Exception {
            need('"');StringBuilder out=new StringBuilder();boolean ended=false;while(at<input.length()){char c=input.charAt(at++);if(c=='"'){ended=true;break;}if(c<32)throw fail("Texte JSON Suno non valide.");if(c=='\\'){if(at>=input.length())throw fail("Texte JSON Suno incomplet.");char e=input.charAt(at++);switch(e){case '"':case '\\':case '/':out.append(e);break;case 'b':out.append('\b');break;case 'f':out.append('\f');break;case 'n':out.append('\n');break;case 'r':out.append('\r');break;case 't':out.append('\t');break;case 'u':if(at+4>input.length())throw fail("Échappement JSON Suno incomplet.");int code=0;for(int i=0;i<4;i++){int d=Character.digit(input.charAt(at++),16);if(d<0)throw fail("Échappement JSON Suno non valide.");code=code*16+d;}out.append((char)code);break;default:throw fail("Échappement JSON Suno non valide.");}}else out.append(c);}
            if(!ended)throw fail("Texte JSON Suno incomplet.");String value=out.toString();utf8(value);return value;
        }
        Object full() throws Exception {Object v=parse(0);white();if(at!=input.length())throw fail("Données supplémentaires dans le JSON Suno.");return v;}
    }
    private static final class Html {
        String canonical;final List<String> scripts=new ArrayList<>();
        Html(String html) throws Exception {
            int at=0;while(at<html.length()){int start=html.indexOf('<',at);if(start<0)break;if(html.startsWith("<!--",start)){int end=html.indexOf("-->",start+4);at=end<0?html.length():end+3;continue;}
                int tagAt=start+1;boolean closing=tagAt<html.length()&&html.charAt(tagAt)=='/';if(closing)tagAt++;int nameStart=tagAt;while(tagAt<html.length()&&(Character.isLetterOrDigit(html.charAt(tagAt))||html.charAt(tagAt)=='-'||html.charAt(tagAt)==':'))tagAt++;if(tagAt==nameStart){at=start+1;continue;}
                String name=html.substring(nameStart,tagAt).toLowerCase(Locale.ROOT);int end=tagEnd(html,tagAt);if(end<0)break;at=end+1;if(closing)continue;
                if(name.equals("script")){int close=findScriptEnd(html,at);if(close<0)break;if(scripts.size()>=MAX_RECORDS)throw fail("Trop de blocs de page Suno.");scripts.add(html.substring(at,close));int closeEnd=tagEnd(html,close+2);at=closeEnd<0?html.length():closeEnd+1;}
                else if(name.equals("link")){Map<String,String> attrs=attributes(html.substring(tagAt,end));if("canonical".equals(attrs.get("rel"))){String href=attrs.get("href");if(canonical!=null&&!canonical.equals(href))throw fail("Deux identités de page Suno différentes.");canonical=href;}}
            }
        }
        static int tagEnd(String s,int at){char quote=0;for(int i=at;i<s.length();i++){char c=s.charAt(i);if(quote!=0){if(c==quote)quote=0;}else if(c=='\''||c=='"')quote=c;else if(c=='>')return i;}return -1;}
        static int findScriptEnd(String s,int at){for(int i=at;i+8<=s.length();i++){if(s.regionMatches(true,i,"</script",0,8)){int next=i+8;if(next==s.length()||Character.isWhitespace(s.charAt(next))||s.charAt(next)=='>')return i;}}return -1;}
        static Map<String,String> attributes(String raw){Map<String,String> out=new HashMap<>();int at=0;while(at<raw.length()){while(at<raw.length()&&(Character.isWhitespace(raw.charAt(at))||raw.charAt(at)=='/'))at++;int begin=at;while(at<raw.length()&&!Character.isWhitespace(raw.charAt(at))&&"=/>".indexOf(raw.charAt(at))<0)at++;if(begin==at){at++;continue;}String key=raw.substring(begin,at).toLowerCase(Locale.ROOT);while(at<raw.length()&&Character.isWhitespace(raw.charAt(at)))at++;String value="";if(at<raw.length()&&raw.charAt(at)=='='){at++;while(at<raw.length()&&Character.isWhitespace(raw.charAt(at)))at++;if(at<raw.length()&&(raw.charAt(at)=='\''||raw.charAt(at)=='"')){char q=raw.charAt(at++);begin=at;while(at<raw.length()&&raw.charAt(at)!=q)at++;value=raw.substring(begin,at);if(at<raw.length())at++;}else{begin=at;while(at<raw.length()&&!Character.isWhitespace(raw.charAt(at)))at++;value=raw.substring(begin,at);}}out.put(key,entities(value));}return out;}
        static String entities(String value){Matcher m=Pattern.compile("&(#x[0-9a-fA-F]+|#[0-9]+|amp|quot|apos|lt|gt);").matcher(value);StringBuffer out=new StringBuffer();while(m.find()){String n=m.group(1),replacement=m.group();try{if(n.startsWith("#")){int cp=Integer.parseInt(n.substring(n.startsWith("#x")?2:1),n.startsWith("#x")?16:10);if(Character.isValidCodePoint(cp)&&!(cp>=0xd800&&cp<=0xdfff))replacement=new String(Character.toChars(cp));}else replacement=n.equals("amp")?"&":n.equals("quot")?"\"":n.equals("apos")?"'":n.equals("lt")?"<":">";}catch(Exception ignored){}m.appendReplacement(out,Matcher.quoteReplacement(replacement));}m.appendTail(out);return out.toString();}
    }
    private static List<Object> flight(List<String> scripts) throws Exception {
        List<String> chunks=new ArrayList<>();for(String script:scripts){int at=0;List<String> literals=new ArrayList<>();while(at<script.length()){Matcher m=PUSH.matcher(script);m.region(at,script.length());if(!m.lookingAt())break;Json parser=new Json(script);parser.at=m.end();Object value=parser.parse(0);if(parser.at>=script.length()||script.charAt(parser.at)!=')')break;at=parser.at+1;while(at<script.length()&&(Character.isWhitespace(script.charAt(at))||script.charAt(at)==';'))at++;if(value instanceof JSONArray){JSONArray a=(JSONArray)value;if(a.length()==2&&a.opt(0) instanceof Long&&((Long)a.opt(0))==1L&&a.opt(1) instanceof String)literals.add((String)a.opt(1));}}if(at==script.length())chunks.addAll(literals);}
        StringBuilder joined=new StringBuilder();for(String chunk:chunks){joined.append(chunk);if(joined.length()>MAX_HTML_BYTES)throw fail("Données Suno trop volumineuses.");}byte[] data=utf8(joined.toString());if(data.length>MAX_HTML_BYTES)throw fail("Données Suno trop volumineuses.");List<Object> records=new ArrayList<>();int at=0,count=0,nodes=0;
        while(at<data.length){if(++count>MAX_RECORDS)throw fail("Trop de blocs de données Suno.");int begin=at;while(at<data.length&&((data[at]>='0'&&data[at]<='9')||(data[at]>='a'&&data[at]<='f')))at++;if(at>=data.length||data[at++]!=':')throw fail("Format de données Suno non reconnu.");if(at<data.length&&data[at]=='T'){at++;int length=0,digits=0;while(at<data.length&&data[at]!=','){int digit=Character.digit((char)data[at++],16);if(digit<0||++digits>8)throw fail("Bloc de texte Suno non reconnu.");length=length*16+digit;if(length>MAX_HTML_BYTES)throw fail("Bloc de texte Suno trop long.");}if(digits==0||at>=data.length||data[at++]!=','||length>data.length-at)throw fail("Bloc de texte Suno incomplet.");at+=length;continue;}
            int end=at;while(end<data.length&&data[end]!='\n')end++;if(at<end&&(data[at]=='['||data[at]=='{')){Json parser=new Json(decode(data,at,end-at));parser.nodes=nodes;records.add(parser.full());nodes=parser.nodes;}at=end+1;
        }return records;
    }
    private static final class Node {final Object value;final int depth;Node(Object value,int depth){this.value=value;this.depth=depth;}}
    private static List<JSONObject> queries(List<Object> records) throws Exception {
        List<JSONObject> queries=new ArrayList<>();Deque<Node> pending=new ArrayDeque<>();pending.push(new Node(records,0));int count=0;
        while(!pending.isEmpty()){Node node=pending.pop();if(node.depth>MAX_DEPTH||++count>MAX_NODES)throw fail("Structure de données Suno trop complexe.");Object value=node.value;if(value instanceof JSONObject){JSONObject object=(JSONObject)value;Object state=object.opt("dehydratedState");if(state instanceof JSONObject){Object rows=((JSONObject)state).opt("queries");if(rows instanceof JSONArray){JSONArray a=(JSONArray)rows;for(int i=0;i<a.length();i++)if(a.opt(i) instanceof JSONObject)queries.add(a.getJSONObject(i));}}Iterator<String> it=object.keys();while(it.hasNext())pending.push(new Node(object.opt(it.next()),node.depth+1));}else if(value instanceof JSONArray){JSONArray array=(JSONArray)value;for(int i=0;i<array.length();i++)pending.push(new Node(array.opt(i),node.depth+1));}else if(value instanceof List){for(Object item:(List<?>)value)pending.push(new Node(item,node.depth+1));}}
        return queries;
    }
    private static boolean matches(JSONObject query,String entity,String field,String identity){Object key=query.opt("queryKey");if(!(key instanceof JSONArray))return false;JSONArray a=(JSONArray)key;if(a.length()!=1||!(a.opt(0) instanceof JSONObject))return false;JSONObject k=a.optJSONObject(0);return entity.equals(k.opt("entity"))&&identity.equals(k.opt(field));}
    private static Object data(JSONObject query){Object state=query.opt("state");return state instanceof JSONObject?nullable(((JSONObject)state).opt("data")):null;}
    private static Object songData(List<JSONObject> queries,String id) throws Exception {Object found=null;for(JSONObject q:queries)if(matches(q,"clips","clipId",id)){Object next=data(q);if(found!=null&&!equalJson(found,next))throw fail("Deux données différentes pour le même morceau Suno.");found=next;}return found;}
    private static boolean equalJson(Object a,Object b) throws Exception {if(a==b)return true;if(a==null||b==null)return false;if(a instanceof JSONObject&&b instanceof JSONObject){JSONObject x=(JSONObject)a,y=(JSONObject)b;if(x.length()!=y.length())return false;Iterator<String> keys=x.keys();while(keys.hasNext()){String key=keys.next();if(!y.has(key)||!equalJson(x.opt(key),y.opt(key)))return false;}return true;}if(a instanceof JSONArray&&b instanceof JSONArray){JSONArray x=(JSONArray)a,y=(JSONArray)b;if(x.length()!=y.length())return false;for(int i=0;i<x.length();i++)if(!equalJson(x.opt(i),y.opt(i)))return false;return true;}return a.equals(b);}
    private static Object alias(JSONObject object,String first,String second){return object.has(first)?object.opt(first):object.opt(second);}
    private static JSONObject track(Object raw,String id) throws Exception {
        if(!(raw instanceof JSONObject))throw fail("Identité ou état du morceau Suno non reconnu.");JSONObject song=(JSONObject)raw;if(!id.equals(song.opt("id"))||!"song_schema".equals(alias(song,"entity_type","entityType"))||!"complete".equals(song.opt("status")))throw fail("Identité ou état du morceau Suno non reconnu.");
        Object media=alias(song,"media_urls","mediaUrls"),encoding=null;String stream=null;if(media instanceof JSONArray){JSONArray a=(JSONArray)media;for(int i=0;i<a.length();i++){Object item=a.opt(i);if(!(item instanceof JSONObject))continue;JSONObject m=(JSONObject)item;Object enc=nullable(m.opt("encoding")),url=m.opt("url");if(m.has("encoding")&&"progressive".equals(m.opt("delivery"))&&"m4a-opus".equals(alias(m,"content_type","contentType"))&&(enc==null||"1.0.0".equals(enc))&&url instanceof String&&validStreamUri((String)url,id)){stream=(String)url;encoding=enc;break;}}}
        if(stream==null)throw fail("La page Suno ne fournit pas de flux audio public compatible.");Object metadata=song.opt("metadata");Object length=metadata instanceof JSONObject?((JSONObject)metadata).opt("duration"):null;if(!(metadata instanceof JSONObject)||!((JSONObject)metadata).has("duration"))length=0L;
        Object image=alias(song,"image_large_url","imageLargeUrl");if(image==null||image==JSONObject.NULL||"".equals(image))image=alias(song,"image_url","imageUrl");
        JSONObject out=new JSONObject().put("id","suno:"+id).put("service","suno").put("title",text(song.opt("title"),"Morceau Suno")).put("artist",text(alias(song,"display_name","displayName"),text(song.opt("handle"),""))).put("album","").put("stream_uri",stream).put("stream_encoding",encoding==null?JSONObject.NULL:encoding).put("duration",duration(length)).put("cover_uri",cover(image)).put("source_url","https://suno.com/song/"+id);return validateTrack(out);
    }
    private static final class Parsed {final String url;final List<JSONObject> queries;Parsed(String url,List<JSONObject> queries){this.url=url;this.queries=queries;}}
    private static final class Reader {
        final PageTransport transport;final long deadline=System.nanoTime()+90_000_000_000L;int requests,total;
        Reader(PageTransport transport){this.transport=transport;}
        void budget() throws CatalogException {if(System.nanoTime()>=deadline||requests>=MAX_REQUESTS)throw fail("Limite de requêtes ou de temps Suno atteinte.");requests++;}
        Parsed get(String input) throws Exception {
            String url=canonicalLink(input);String[] original=route(url);Page page=null;
            for(int redirects=0;;redirects++){budget();try{page=transport.fetch(url,deadline);}catch(CatalogException error){throw error;}catch(Exception error){throw fail("Connexion à la page publique Suno impossible.");}if(page==null)throw fail("Réponse de page Suno absente.");if(Arrays.asList(301,302,303,307,308).contains(page.status)){if(redirects>=MAX_REDIRECTS||page.location==null)throw fail("Trop de redirections Suno ou destination absente.");try{url=canonicalLink(new URI(url).resolve(page.location).toString());}catch(Exception error){throw fail("Redirection Suno non autorisée.");}String[] next=route(url);if(original[1]!=null&&(!original[0].equals(next[0])||!original[1].equals(next[1])))throw fail("La redirection change l’identité du lien Suno.");continue;}break;}
            if(page.status!=200)throw fail("Page Suno inaccessible. Aucun déverrouillage effectué.");String type=page.contentType==null?"":page.contentType.split(";",2)[0].trim();if(!"text/html".equalsIgnoreCase(type)||page.encoding!=null&&!"identity".equalsIgnoreCase(page.encoding))throw fail("Le lien Suno ne renvoie pas une page HTML compatible.");if(page.body==null||page.body.length>MAX_HTML_BYTES||(long)total+page.body.length>MAX_TOTAL_BYTES)throw fail("Pages Suno trop volumineuses.");total+=page.body.length;if(System.nanoTime()>deadline)throw fail("Délai de résolution Suno dépassé.");Html html=new Html(decode(page.body,0,page.body.length));String[] routed=route(url);
            if(html.canonical!=null){String declared=canonicalLink(html.canonical);if(route(declared)[0]==null)throw fail("Identité canonique Suno absente.");if(routed[0]==null){url=declared;routed=route(url);}else if(!declared.equals(url))throw fail("La page ne correspond pas au lien Suno fourni.");}
            if(routed[0]==null)throw fail("Le lien court Suno ne fournit pas de page canonique accessible.");List<JSONObject> queries=queries(flight(html.scripts));if(System.nanoTime()>deadline)throw fail("Délai de résolution Suno dépassé.");return new Parsed(url,queries);
        }
    }
    private static final class HttpPages implements PageTransport {
        public Page fetch(String url,long deadline) throws Exception {
            https(url,PAGE_HOSTS);if(CookieHandler.getDefault()!=null)throw fail("La lecture publique Suno ne partage aucune session de navigateur.");HttpsURLConnection c=null;
            try{c=(HttpsURLConnection)new URL(url).openConnection();c.setInstanceFollowRedirects(false);c.setAllowUserInteraction(false);c.setUseCaches(false);c.setRequestMethod("GET");c.setConnectTimeout(remaining(deadline));c.setReadTimeout(remaining(deadline));c.setRequestProperty("User-Agent","Mozilla/5.0");c.setRequestProperty("Accept","text/html");c.setRequestProperty("Accept-Encoding","identity");int status=c.getResponseCode();if(status!=200)return new Page(status,c.getHeaderField("Location"),c.getContentType(),c.getHeaderField("Content-Encoding"),new byte[0]);if(c.getContentLengthLong()>MAX_HTML_BYTES)throw fail("Page Suno trop volumineuse.");ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[65536];try(InputStream in=c.getInputStream()){for(;;){c.setReadTimeout(remaining(deadline));int n=in.read(buffer,0,Math.min(buffer.length,MAX_HTML_BYTES+1-out.size()));if(n<0)break;out.write(buffer,0,n);if(out.size()>MAX_HTML_BYTES)throw fail("Page Suno trop volumineuse.");}}return new Page(status,null,c.getContentType(),c.getHeaderField("Content-Encoding"),out.toByteArray());}
            catch(CatalogException error){throw error;}catch(Exception error){throw fail("Connexion à la page publique Suno impossible.");}finally{if(c!=null)c.disconnect();}
        }
        private int remaining(long deadline) throws CatalogException {long n=deadline-System.nanoTime();if(n<=0)throw fail("Délai de résolution Suno dépassé.");return (int)Math.max(1,Math.min(20000,(n+999999)/1000000));}
    }
    public static JSONObject resolve(String url) throws Exception {return resolve(url,new HttpPages());}
    public static JSONObject resolve(String url,PageTransport transport) throws Exception {
        if(transport==null)throw fail("Transport de page Suno absent.");Reader reader=new Reader(transport);Parsed parsed=reader.get(url);String[] route=route(parsed.url);String id=route[1];JSONArray tracks=new JSONArray(),playlists=new JSONArray();String manifestId,name;
        if("song".equals(route[0])){JSONObject track=track(songData(parsed.queries,id),id);tracks.put(track);name=track.getString("title");manifestId="suno:"+id;}
        else{String feedId="generic_playlist:"+id;List<JSONObject> matched=new ArrayList<>();for(JSONObject q:parsed.queries)if(matches(q,"feed","feedId",feedId))matched.add(q);if(matched.size()!=1)throw fail("La page Suno ne fournit pas le contenu de cette playlist.");Object d=data(matched.get(0));Object pages=d instanceof JSONObject?((JSONObject)d).opt("pages"):null;if(!(pages instanceof JSONArray)||((JSONArray)pages).length()==0)throw fail("Contenu de playlist Suno absent.");List<JSONObject> items=new ArrayList<>();Long expected=null;name=null;
            for(int i=0;i<((JSONArray)pages).length();i++){Object p=((JSONArray)pages).opt(i);Object f=p instanceof JSONObject?((JSONObject)p).opt("feed"):null;if(!(f instanceof JSONObject))throw fail("Identité de playlist Suno non reconnue.");JSONObject feed=(JSONObject)f;if(!feedId.equals(feed.opt("feedId"))||!"playlist".equals(feed.opt("feedContainerType"))||!id.equals(feed.opt("feedContainerId"))||!(feed.opt("items") instanceof JSONArray))throw fail("Identité de playlist Suno non reconnue.");String title=text(feed.opt("feedTitle"),"Playlist Suno");Object meta=feed.opt("feedMetadata"),count=meta instanceof JSONObject?((JSONObject)meta).opt("songCount"):null;if(!(count instanceof Integer||count instanceof Long)||((Number)count).longValue()<0||((Number)count).longValue()>MAX_TRACKS)throw fail("Nombre de morceaux de playlist Suno non reconnu.");long n=((Number)count).longValue();if(expected!=null&&(n!=expected||!title.equals(name)))throw fail("Pages de playlist Suno incohérentes.");name=title;expected=n;JSONArray entries=feed.getJSONArray("items");for(int j=0;j<entries.length();j++){Object item=entries.opt(j);if(!(item instanceof JSONObject))throw fail("Élément de playlist Suno non reconnu.");items.add((JSONObject)item);if(items.size()>MAX_TRACKS)throw fail("Playlist Suno trop volumineuse.");}}
            if(expected==null||items.size()!=expected)throw fail("La page publique Suno ne contient pas tous les morceaux ; playlist incomplète.");Set<String> seen=new HashSet<>();JSONArray ordered=new JSONArray();
            for(JSONObject item:items){Object identity=item.opt("contentId");if(!"clip".equals(item.opt("contentType"))||!(identity instanceof String)||!ID.matcher((String)identity).matches())throw fail("Élément de playlist Suno non reconnu.");String songId=(String)identity;Object embedded=nullable(item.opt("contentItem"));if(embedded!=null&&(!(embedded instanceof JSONObject)||!songId.equals(((JSONObject)embedded).opt("id"))))throw fail("Le morceau ne correspond pas à son entrée de playlist Suno.");ordered.put("suno:"+songId);if(!seen.add(songId))continue;Object song=songData(parsed.queries,songId);if(song==null)song=embedded;if(song==null){Parsed child=reader.get("https://suno.com/song/"+songId);song=songData(child.queries,songId);}tracks.put(track(song,songId));}
            manifestId="suno-playlist:"+id;playlists.put(new JSONObject().put("id",manifestId).put("name",name).put("track_ids",ordered));
        }
        return new JSONObject().put("version",1).put("id",manifestId).put("name",name).put("source_url",parsed.url).put("tracks",tracks).put("playlists",playlists);
    }
}
