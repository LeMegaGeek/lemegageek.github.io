package android.content;
public final class ContentUris {public static android.net.Uri withAppendedId(android.net.Uri uri,long id){return android.net.Uri.parse(uri.toString()+"/"+id);}}
