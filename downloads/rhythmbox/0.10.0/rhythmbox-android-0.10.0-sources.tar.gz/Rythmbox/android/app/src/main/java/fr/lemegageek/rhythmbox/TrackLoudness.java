package fr.lemegageek.rhythmbox;

/** Streaming K-weighted, gated integrated loudness. PCM is never retained.
 * Mono is measured as dual mono, matching the usual stereo playback output.
 * Peak is a 4x, 49-tap windowed-sinc estimate, not a certified true-peak meter.
 * A fixed gain is chosen for the complete track; there is no running AGC.
 */
public final class TrackLoudness {
    public static final String ALGORITHM = "k-gated-dualmono-4x49-v1";
    public static final double TARGET_LUFS = -18, MAX_BOOST_DB = 12;
    public static final double PEAK_CEILING_DB = -1, PEAK_MARGIN_DB = 1;
    private static final int BINS = 11001;
    public static final class Result {
        public final int sampleRate, channels;
        public final long frames;
        public final double integratedLufs, peak;
        public final boolean measured;
        public Result(int sampleRate,int channels,long frames,double integratedLufs,double peak,boolean measured) {
            if(sampleRate<8000||sampleRate>192000||(channels!=1&&channels!=2)||frames<0||
                    frames>43200L*sampleRate||!Double.isFinite(peak)||peak<0||peak>16||
                    measured&&(!Double.isFinite(integratedLufs)||integratedLufs< -100||integratedLufs>40||peak<=0))
                throw new IllegalArgumentException("Mesure de volume invalide");
            this.sampleRate=sampleRate;this.channels=channels;this.frames=frames;
            this.integratedLufs=integratedLufs;this.peak=peak;this.measured=measured;
        }
        public double peakDb(){return peak>0?20*Math.log10(peak):Double.NEGATIVE_INFINITY;}
        public double gainDb(){return measured?Math.max(-96,Math.min(MAX_BOOST_DB,
            Math.min(TARGET_LUFS-integratedLufs,PEAK_CEILING_DB-PEAK_MARGIN_DB-peakDb()))):0;}
    }
    private static final class Biquad {
        final double b0,b1,b2,a1,a2;double z1,z2;
        Biquad(double b0,double b1,double b2,double a1,double a2){this.b0=b0;this.b1=b1;this.b2=b2;this.a1=a1;this.a2=a2;}
        double next(double input){double out=input*b0+z1;z1=input*b1-out*a1+z2;z2=input*b2-out*a2;return out;}
    }
    private final int rate,channels,window,hop;
    private final double[] energyRing,energyBins=new double[BINS];
    private final long[] countBins=new long[BINS];
    private final Biquad[] shelf,highpass;
    private final double[][] history,coefficients=new double[4][13];
    private long frames;private int energyPosition,peakPosition;private double energySum,peak;
    private boolean finished;
    public TrackLoudness(int sampleRate,int channels) {
        if(sampleRate<8000||sampleRate>192000||(channels!=1&&channels!=2))
            throw new IllegalArgumentException("Analyse disponible pour les pistes mono ou stéréo de 8 à 192 kHz");
        this.rate=sampleRate;this.channels=channels;window=(int)Math.round(rate*.4);hop=(int)Math.round(rate*.1);
        energyRing=new double[window];shelf=new Biquad[channels];highpass=new Biquad[channels];history=new double[channels][13];
        double k=Math.tan(Math.PI*1681.974450955533/rate),vh=Math.pow(10,3.999843853973347/20),vb=Math.pow(vh,.4996667741545416);
        double q=.7071752369554196,a0=1+k/q+k*k;
        for(int c=0;c<channels;c++)shelf[c]=new Biquad((vh+vb*k/q+k*k)/a0,2*(k*k-vh)/a0,
            (vh-vb*k/q+k*k)/a0,2*(k*k-1)/a0,(1-k/q+k*k)/a0);
        k=Math.tan(Math.PI*38.13547087602444/rate);q=.5003270373238773;a0=1+k/q+k*k;
        for(int c=0;c<channels;c++)highpass[c]=new Biquad(1,-2,1,2*(k*k-1)/a0,(1-k/q+k*k)/a0);
        for(int j=0;j<49;j++){
            double x=(j-24)/4.0;
            coefficients[j%4][j/4]=(Math.abs(x)<1e-12?1:Math.sin(Math.PI*x)/(Math.PI*x))*.5*(1-Math.cos(2*Math.PI*j/48));
        }
    }
    public void addFrame(double left,double right) {
        if(finished)throw new IllegalStateException("Analyse déjà terminée");
        if(!Double.isFinite(left)||Math.abs(left)>8||channels==2&&(!Double.isFinite(right)||Math.abs(right)>8))
            throw new IllegalArgumentException("PCM invalide");
        if(frames>=43200L*rate)throw new IllegalArgumentException("Piste trop longue pour l’analyse");
        peak(left,right);
        double l=highpass[0].next(shelf[0].next(left));double energy=l*l;
        if(channels==2){double r=highpass[1].next(shelf[1].next(right));energy+=r*r;}else energy*=2;
        energySum+=energy-energyRing[energyPosition];energyRing[energyPosition]=energy;energyPosition=(energyPosition+1)%window;frames++;
        if(frames>=window&&(frames-window)%hop==0){
            double mean=Math.max(0,energySum/window),lufs=mean>0?-.691+10*Math.log10(mean):Double.NEGATIVE_INFINITY;
            if(lufs>=-70){int bin=Math.max(0,Math.min(BINS-1,(int)Math.floor((lufs+70)*100)));energyBins[bin]+=mean;countBins[bin]++;}
        }
    }
    private void peak(double left,double right){
        history[0][peakPosition]=left;if(channels==2)history[1][peakPosition]=right;
        peak=Math.max(peak,Math.max(Math.abs(left),channels==2?Math.abs(right):0));
        for(int c=0;c<channels;c++)for(int phase=0;phase<4;phase++){
            double sum=0;for(int t=0;t<13;t++){int p=peakPosition-t;if(p<0)p+=13;sum+=history[c][p]*coefficients[phase][t];}
            peak=Math.max(peak,Math.abs(sum));
        }
        peakPosition=(peakPosition+1)%13;
    }
    public Result finish(){
        if(finished)throw new IllegalStateException("Analyse déjà terminée");finished=true;
        for(int i=0;i<13;i++)peak(0,0);
        double energy=0;long count=0;for(int i=0;i<BINS;i++){energy+=energyBins[i];count+=countBins[i];}
        if(count==0||energy<=0||peak<=0)return new Result(rate,channels,frames,Double.NaN,peak,false);
        double threshold=energy/count/10;energy=0;count=0;
        for(int i=0;i<BINS;i++)if(countBins[i]>0&&energyBins[i]/countBins[i]>=threshold){energy+=energyBins[i];count+=countBins[i];}
        if(count==0)return new Result(rate,channels,frames,Double.NaN,peak,false);
        return new Result(rate,channels,frames,-.691+10*Math.log10(energy/count),peak,true);
    }
}
