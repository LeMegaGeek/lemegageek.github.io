package fr.lemegageek.rhythmbox;

import org.json.JSONObject;
import java.util.Base64;
import java.util.UUID;
import java.util.regex.Pattern;

/** Rules shared by the SAF transport and executable JVM tests. */
public final class FolderProtocol {
    private static final Pattern PERCENT_ESCAPE=Pattern.compile("%[0-9A-Fa-f]{2}");
    private FolderProtocol() {}
    /** Extension/MIME selection only; tree membership and audio-track checks
     * remain mandatory before reading and playback. Video is soundtrack-only. */
    public static boolean isSupportedMedia(String name,String mime) {
        if(mime!=null && mime.startsWith("audio/"))return true;
        return name!=null && name.toLowerCase(java.util.Locale.ROOT).matches(".*\\.(mp3|flac|ogg|opus|m4a|aac|wav|wma|aif|aiff|alac|m4v|mp4|mpg|mpeg|mov|mkv|avi|webm)");
    }
    public static String mediaPath(String value) {
        // Literal document names, not URLs: '100%' is valid, encoded bytes
        // stay forbidden so no provider can reinterpret them as separators.
        if(value==null || value.isEmpty() || value.codePointCount(0,value.length())>2048 || value.startsWith("/") || value.indexOf('\\')>=0 || PERCENT_ESCAPE.matcher(value).find() || value.indexOf(':')>=0)
            throw new IllegalArgumentException("Chemin musical hors du dossier choisi");
        for(int i=0;i<value.length();i++)if(value.charAt(i)<32 || value.charAt(i)==127)throw new IllegalArgumentException("Chemin musical invalide");
        for(String part:value.split("/",-1))if(part.isEmpty() || part.equals(".") || part.equals(".."))throw new IllegalArgumentException("Chemin musical hors du dossier choisi");
        return value;
    }
    public static byte[] key(JSONObject config) throws Exception {
        String encoded=config.getString("key");
        if(!encoded.matches("[A-Za-z0-9+/]{43}="))throw new IllegalArgumentException("Association avec le PC invalide");
        byte[] key=Base64.getDecoder().decode(encoded);
        if(key.length!=32)throw new IllegalArgumentException("Association avec le PC invalide");
        return key;
    }
    public static JSONObject pairing(JSONObject input) throws Exception {
        if(!(input.get("schema") instanceof Integer) || input.getInt("schema")!=1 || !"rhythmbox-pairing".equals(input.getString("kind")))
            throw new IllegalArgumentException("Ce fichier n’est pas une association Rhythmbox");
        UUID id=UUID.fromString(input.getString("library_id"));
        if(!id.toString().equals(input.getString("library_id")))throw new IllegalArgumentException("Identité d’association invalide");
        key(input);
        return new JSONObject().put("key",input.getString("key")).put("library_id",id.toString());
    }
}
