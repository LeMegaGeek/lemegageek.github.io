package fr.lemegageek.rhythmbox;

import java.util.Locale;

/** One explicitly authorized music account, never the pCloud app's default account. */
public final class PCloudAccount {
    public final String token, email, region, clientId, authType;
    public final long userid, musicFolderId;

    public PCloudAccount(String token, String email, String region, String clientId,
                         long userid, long musicFolderId) {
        this(token, email, region, clientId, userid, musicFolderId, "oauth");
    }

    public PCloudAccount(String token, String email, String region, String clientId,
                         long userid, long musicFolderId, String authType) {
        if (!"oauth".equals(authType) && !"direct".equals(authType))
            throw new IllegalArgumentException("Type d’autorisation pCloud invalide.");
        if (token == null || token.length() < 1 || token.length() > 4096 ||
                !token.matches("[\\x21-\\x7e]+"))
            throw new IllegalArgumentException("Autorisation pCloud invalide.");
        if ("direct".equals(authType) && token.length() > 64)
            throw new IllegalArgumentException("Autorisation pCloud invalide.");
        this.email = normalizedEmail(email);
        if (!"eu".equals(region) && !"us".equals(region))
            throw new IllegalArgumentException("Région pCloud invalide.");
        if (clientId == null || ("oauth".equals(authType) ?
                !clientId.matches("[A-Za-z0-9_-]{1,256}") : !clientId.isEmpty()))
            throw new IllegalArgumentException("Application pCloud non configurée.");
        if (userid <= 0 || musicFolderId < 0)
            throw new IllegalArgumentException("Identifiant pCloud invalide.");
        this.token = token;
        this.region = region;
        this.clientId = clientId;
        this.authType = authType;
        this.userid = userid;
        this.musicFolderId = musicFolderId;
    }

    public static String normalizedEmail(String email) {
        if (email == null || email.length() > 254 ||
                !email.matches("[^\\s@\\p{Cntrl}]+@[^\\s@\\p{Cntrl}]+\\.[^\\s@\\p{Cntrl}]+"))
            throw new IllegalArgumentException("Adresse du compte musical invalide.");
        return email.toLowerCase(Locale.ROOT);
    }

    public PCloudAccount withMusicFolder(long folderId) {
        if (folderId <= 0) throw new IllegalArgumentException("Choisis un dossier musical distinct de la racine pCloud.");
        return new PCloudAccount(token, email, region, clientId, userid, folderId, authType);
    }

    public boolean hasMusicFolder() { return musicFolderId > 0; }

    public static boolean sameAuthorization(PCloudAccount left, PCloudAccount right) {
        if (left == null || right == null) return left == right;
        return left.userid == right.userid && left.musicFolderId == right.musicFolderId &&
            left.email.equals(right.email) && left.region.equals(right.region) &&
            left.clientId.equals(right.clientId) && left.authType.equals(right.authType) &&
            java.security.MessageDigest.isEqual(left.token.getBytes(java.nio.charset.StandardCharsets.UTF_8),
                right.token.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }

    @Override public String toString() {
        return "PCloudAccount{userid=" + userid + ", region=" + region + ", token=<redacted>}";
    }
}
