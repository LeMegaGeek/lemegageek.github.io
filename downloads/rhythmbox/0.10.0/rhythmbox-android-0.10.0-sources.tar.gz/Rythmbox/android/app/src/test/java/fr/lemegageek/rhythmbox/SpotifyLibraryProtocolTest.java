package fr.lemegageek.rhythmbox;

import org.json.JSONObject;
import org.json.JSONArray;
import java.net.URI;
import java.util.Map;
import static fr.lemegageek.rhythmbox.SpotifyLibraryProtocol.*;

public final class SpotifyLibraryProtocolTest {
    private static int assertions;
    private static final String ID="3JyAtOlwPVz2vwINSIOc6h";
    private static void check(boolean condition){assertions++;if(!condition)throw new AssertionError("Case "+assertions);}
    interface Attempt{void run() throws Exception;}
    private static void reject(Attempt attempt) throws Exception {
        try{attempt.run();}catch(Exception expected){assertions++;return;}
        throw new AssertionError("Expected rejection "+(assertions+1));
    }
    private static JSONObject item(String type) throws Exception {
        return new JSONObject().put("id",ID).put("name","Titre").put("type",type)
            .put("artists",new JSONArray().put(new JSONObject().put("name","Artiste")));
    }
    private static JSONObject response(JSONArray items) throws Exception {
        return new JSONObject().put("items",items).put("next",JSONObject.NULL).put("offset",0);
    }
    public static void main(String[] args) throws Exception {
        String client="eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee";
        JSONObject p=pending(10000);
        check(p.getString("state").length()==43);
        check(!p.getString("verifier").equals(p.getString("state")));
        check(challenge("dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk").equals("E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM"));
        URI authorization=new URI(authUrl(client,p));
        Map<String,String> qp=parameters(authorization.getRawQuery());
        check("accounts.spotify.com".equals(authorization.getHost()));
        check(qp.get("redirect_uri").equals(REDIRECT));
        check(qp.get("scope").equals(SCOPES));
        check(qp.get("code_challenge_method").equals("S256"));
        check(!authorization.toString().contains(p.getString("verifier")));
        String ret=REDIRECT+"?state="+p.getString("state");
        check(code(ret+"&code=hello&ubi=y",p,10001).equals("hello"));
        check(code(ret+"&error=access_denied",p,10001).isEmpty());
        reject(()->code(ret+"&code=hello&code=world",p,10001));
        reject(()->code(ret+"&code=hello&error=no",p,10001));
        reject(()->code(ret+"&code=hello#",p,10001));
        reject(()->code(ret+"&code=%0a",p,10001));
        reject(()->code(ret.replace("github.io","github.io.evil")+"&code=h",p,10001));
        reject(()->code(ret.replace("https://","http://")+"&code=h",p,10001));
        reject(()->code(ret.replace("spotify/oauth","pcloud/oauth")+"&code=h",p,10001));
        reject(()->code(ret+"&code=h",pending(10000),10001));
        reject(()->code(ret+"&code=h",p,9999));
        reject(()->code(ret+"&code=h",p,610001));
        JSONObject reply=new JSONObject().put("access_token","a").put("refresh_token","r").put("expires_in",3600).put("token_type","Bearer").put("scope",SCOPES);
        JSONObject original=session(reply,null,1000);
        check(original.getLong("expires")==3601000);
        reply.remove("refresh_token");reply.remove("scope");
        check(session(reply,original,2000).getString("refresh").equals("r"));
        reject(()->session(reply,null,2000));
        reject(()->session(reply.put("scope","user-library-read"),original,2000));
        Query liked=new Query(Section.LIKED,"","Titres aimés");
        JSONObject track=item("track");
        JSONObject pageData=response(new JSONArray().put(new JSONObject().put("track",track)));
        Page likedPage=page(liked,0,pageData);
        check(liked.url(0).equals(API+"/me/tracks?limit=30&offset=0"));
        check(likedPage.items.get(0).uri().equals("spotify:track:"+ID));
        check(likedPage.items.get(0).detail.equals("Artiste"));
        check(likedPage.next==-1);
        Query playlists=new Query(Section.PLAYLISTS,"","Playlists");
        check(page(playlists,0,response(new JSONArray().put(item("playlist")))).items.get(0).type.equals("playlist"));
        Query collection=new Query(Section.PLAYLIST,ID,"Playlist");
        check(collection.path().equals("/playlists/"+ID+"/items"));
        check(collection.context().equals("spotify:playlist:"+ID));
        check(page(collection,0,response(new JSONArray().put(new JSONObject().put("item",track)))).items.size()==1);
        check(page(collection,0,response(new JSONArray().put(new JSONObject().put("track",track)))).items.size()==1);
        check(page(collection,0,response(new JSONArray().put(new JSONObject().put("item",item("episode"))))).items.isEmpty());
        Query albumList=new Query(Section.ALBUMS,"","Albums");
        check(page(albumList,0,response(new JSONArray().put(new JSONObject().put("album",item("album"))))).items.get(0).uri().equals("spotify:album:"+ID));
        Query album=new Query(Section.ALBUM,ID,"Album");
        check(album.path().equals("/albums/"+ID+"/tracks"));
        check(album.context().equals("spotify:album:"+ID));
        Query search=new Query(Section.SEARCH,"A & B / été","Résultats");
        check(parameters(new URI(search.url(0)).getRawQuery()).get("q").equals("A & B / été"));
        check(page(search,0,new JSONObject().put("tracks",response(new JSONArray().put(track)))).items.size()==1);
        check(!page(album,0,response(new JSONArray().put(item("track").put("is_playable",false)))).items.get(0).playable);
        check(page(album,0,response(new JSONArray().put(item("track").put("is_local",true)))).items.isEmpty());
        pageData.put("next",API+"/me/tracks?offset=30&limit=30");
        check(page(liked,0,pageData).next==30);
        reject(()->page(liked,0,pageData.put("next","https://example.com/v1/me/tracks?offset=30")));
        reject(()->page(liked,0,pageData.put("next",API+"/me/playlists?offset=30")));
        reject(()->page(liked,0,pageData.put("next",API+"/me/tracks?offset=0")));
        reject(()->new Query(Section.ALBUM,"../me/","").url(0));
        reject(()->new Query(Section.SEARCH,"hello\nworld","").url(0));
        reject(()->search.url(1001));
        System.out.println("PASS Spotify library protocol: "+assertions+" checks");
    }
}
