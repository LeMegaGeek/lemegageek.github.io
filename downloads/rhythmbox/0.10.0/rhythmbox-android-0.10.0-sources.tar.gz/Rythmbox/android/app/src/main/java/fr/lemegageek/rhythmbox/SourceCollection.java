package fr.lemegageek.rhythmbox;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

/** A source-specific playback queue. Never rewrite the original playlist or its bindings. */
final class SourceCollection {
    final String id;
    final String name;
    final JSONArray tracks;
    final boolean singleSong;

    SourceCollection(String id, String name, JSONArray tracks, boolean singleSong) {
        this.id = id;
        this.name = name;
        this.tracks = tracks;
        this.singleSong = singleSong;
    }

    static List<SourceCollection> fromLibrary(Library library, PCloudAccount account, boolean cloud)
            throws Exception {
        Set<String> linked = new HashSet<>();
        if (cloud && account != null && account.hasMusicFolder()) {
            JSONArray bindings = PCloudOfflineSelection.available(account, library.state);
            for (int i = 0; i < bindings.length(); i++) linked.add(bindings.getJSONObject(i).getString("id"));
        }
        Set<String> hidden = library.hidden();
        List<SourceCollection> choices = new ArrayList<>();
        JSONArray playlists = library.playlists();
        for (int p = 0; p < playlists.length(); p++) {
            JSONObject list = playlists.getJSONObject(p);
            String id = list.getString("id");
            boolean bound = linked.contains(id);
            JSONArray originals = list.getJSONArray("tracks"), selected = new JSONArray();
            for (int t = 0; t < originals.length(); t++) {
                JSONObject track = originals.getJSONObject(t);
                if (hidden.contains(track.optString("id")) || track.optBoolean("quarantined")) continue;
                if (track.has("demo_source") || "suno".equals(track.optString("service"))) continue;
                boolean remote = track.has("pcloud_fileid") || track.has("pcloud_account_userid");
                if (remote && track.has("pcloud_account_userid") && (account == null
                        || track.optLong("pcloud_account_userid") != account.userid
                        || track.has("pcloud_music_folderid") && track.optLong("pcloud_music_folderid") != account.musicFolderId)) continue;
                if (cloud ? remote || bound : !remote && track.has("media_path")) selected.put(track);
            }
            if (selected.length() > 0 || bound) {
                choices.add(new SourceCollection(id, list.optString("name", "Liste"), selected, false));
            }
        }
        return choices;
    }
}
