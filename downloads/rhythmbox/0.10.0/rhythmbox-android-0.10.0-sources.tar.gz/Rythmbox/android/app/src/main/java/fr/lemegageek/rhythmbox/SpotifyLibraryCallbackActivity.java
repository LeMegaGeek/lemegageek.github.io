package fr.lemegageek.rhythmbox;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;

/** The browser returns a PKCE code here. Only a navigation action reaches the main activity. */
public final class SpotifyLibraryCallbackActivity extends Activity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        Intent incoming=getIntent();
        String callback=Intent.ACTION_VIEW.equals(incoming.getAction())?incoming.getDataString():null;
        incoming.setData(null);incoming.replaceExtras((Bundle)null);setIntent(new Intent());
        if(callback==null || state!=null){finish();return;}
        TextView status=new TextView(this);
        status.setGravity(Gravity.CENTER);
        status.setText("Connexion à la bibliothèque Spotify…");
        setContentView(status);
        SpotifyLibraryClient client=new SpotifyLibraryClient(this);
        SpotifyLibraryClient.WORK.execute(()->{
            try{client.accept(callback);}catch(Exception ignored){ /* Errors after matching state are saved for the player. */ }
            runOnUiThread(()->{
                if(isFinishing() || isDestroyed()) return;
                Intent back=new Intent(this,MainActivity.class);
                back.setAction(SpotifyLibraryBrowser.ACTION_AUTH_RETURN);
                back.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(back); finish();
            });
        });
    }
}
