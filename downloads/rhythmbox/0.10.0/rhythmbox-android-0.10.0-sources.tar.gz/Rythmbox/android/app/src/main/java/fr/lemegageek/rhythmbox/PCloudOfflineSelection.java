package fr.lemegageek.rhythmbox;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** Pure selection gate shared by offline export and local playback lookup.
 * Library membership is insufficient: every chosen list must also have an
 * explicit binding to this account and music root. */
public final class PCloudOfflineSelection {
    private PCloudOfflineSelection(){}
    public static final class Selection {
        public final JSONArray tracks;public final int skipped;
        Selection(JSONArray tracks,int skipped){this.tracks=tracks;this.skipped=skipped;}
    }
    public static JSONArray available(PCloudAccount account,JSONObject library) throws Exception {
        JSONObject settings=library.optJSONObject("pcloud_native");JSONArray out=new JSONArray();if(settings==null)return out;
        if(settings.optLong("account_userid")!=account.userid||settings.optLong("music_folderid")!=account.musicFolderId)return out;
        JSONArray bindings=settings.getJSONArray("bindings"),lists=library.getJSONArray("playlists");Set<String> seen=new HashSet<>();Set<Long> collections=new HashSet<>();
        for(int i=0;i<bindings.length();i++){
            JSONObject row=bindings.getJSONObject(i);String id=row.getString("playlist_id");long cid=PCloudCollections.integer(row.get("collection_id"),false);
            if(row.optLong("account_userid")!=account.userid||row.optLong("music_folderid")!=account.musicFolderId||!seen.add(id)||!collections.add(cid))throw new IllegalArgumentException("Liaisons musicales ambiguës ou étrangères");
            JSONObject found=null;for(int j=0;j<lists.length();j++)if(id.equals(lists.getJSONObject(j).getString("id"))){if(found!=null)throw new IllegalArgumentException("Identité de liste ambiguë");found=lists.getJSONObject(j);}
            if(found!=null)out.put(new JSONObject().put("id",id).put("name",found.optString("name","Liste pCloud")).put("count",found.getJSONArray("tracks").length()));
        }return out;
    }
    public static Selection select(PCloudAccount account,JSONObject library,Set<String> selected) throws Exception {
        if(account==null||account.musicFolderId<=0||selected==null||selected.isEmpty()||selected.size()>1000)throw new IllegalArgumentException("Choisis au moins une liste pCloud pour le dossier hors ligne");
        JSONArray offered=available(account,library);Set<String> allowed=new HashSet<>();for(int i=0;i<offered.length();i++)allowed.add(offered.getJSONObject(i).getString("id"));
        if(!allowed.containsAll(selected))throw new IllegalArgumentException("Une liste n’est plus liée au compte et au dossier musical choisis");
        Set<String> hidden=new HashSet<>();JSONArray hiddenRows=library.optJSONArray("hidden");if(hiddenRows!=null)for(int i=0;i<hiddenRows.length();i++)hidden.add(hiddenRows.getString(i));
        Map<Long,JSONObject> files=new LinkedHashMap<>();Map<String,Long> paths=new LinkedHashMap<>();int skipped=0;JSONArray lists=library.getJSONArray("playlists");
        for(int i=0;i<lists.length();i++){
            JSONObject playlist=lists.getJSONObject(i);if(!selected.contains(playlist.getString("id")))continue;JSONArray tracks=playlist.getJSONArray("tracks");
            for(int j=0;j<tracks.length();j++){
                JSONObject track=tracks.getJSONObject(j);String id=track.getString("id");
                if(hidden.contains(id)||track.optBoolean("quarantined")||track.has("demo_source")||"suno".equals(track.optString("service"))||id.startsWith("suno:")||track.has("suno_id")||track.has("suno_source")||track.has("stream_uri")){skipped++;continue;}
                PCloudAudioCache.identity(account,track);long fid=PCloudAudioCache.positive(track,"pcloud_fileid");String path=track.getString("media_path");
                if(files.containsKey(fid)&&!path.equals(files.get(fid).getString("media_path"))||paths.containsKey(path)&&paths.get(path)!=fid)throw new IllegalArgumentException("Une référence musicale désigne plusieurs fichiers");
                files.put(fid,new JSONObject(track.toString()));paths.put(path,fid);
                if(files.size()>50000)throw new IllegalArgumentException("Trop de morceaux sélectionnés");
            }
        }return new Selection(new JSONArray(files.values()),skipped);
    }
    /** Preserve the original filename and extension; collisions create a new
     * readable name, never overwrite an existing document. */
    public static String alternateName(String original,int number) {
        if(number<2||number>10000)throw new IllegalArgumentException("Trop de fichiers portant le même nom");
        int dot=original.lastIndexOf('.');return dot>0?original.substring(0,dot)+" ("+number+")"+original.substring(dot):original+" ("+number+")";
    }
}
