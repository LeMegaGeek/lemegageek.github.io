package fr.lemegageek.rhythmbox;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

/** A user-launched browser may return one selected public music page, never its session. */
public final class SunoBrowserProtocol {
    public static final long MAX_AGE_MILLIS=60*60*1000;
    public enum Destination { SIGN_IN, LIBRARY, PLAYLISTS }
    private SunoBrowserProtocol(){}
    public static String destination(Destination page){
        if(page==null)throw invalid();
        return page==Destination.PLAYLISTS?"https://suno.com/me/playlists":"https://suno.com/me";
    }
    public static final class Ticket {
        public final String nonce;
        public final long createdMillis;
        private boolean consumed;
        private Ticket(String nonce,long createdMillis){this.nonce=nonce;this.createdMillis=createdMillis;}
        public synchronized boolean validAt(long now){return !consumed&&now>=createdMillis&&now-createdMillis<=MAX_AGE_MILLIS;}
        /** Invalid pages do not consume the music selection; a valid result cannot be replayed. */
        public synchronized String consume(String supplied,String currentPage,long now)throws Exception{
            if(!validAt(now)){consumed=true;throw invalid();}
            if(supplied==null||supplied.length()!=43||!MessageDigest.isEqual(nonce.getBytes(StandardCharsets.US_ASCII),supplied.getBytes(StandardCharsets.US_ASCII)))throw invalid();
            String music=musicPage(currentPage);
            consumed=true;
            return music;
        }
        @Override public String toString(){return "SunoBrowserTicket{nonce=<redacted>}";}
    }
    public static Ticket create(long now){
        if(now<0)throw invalid();
        byte[] random=new byte[32];new SecureRandom().nextBytes(random);
        return new Ticket(Base64.getUrlEncoder().withoutPadding().encodeToString(random),now);
    }
    public static Ticket restore(String nonce,long created){
        if(nonce==null||!nonce.matches("[A-Za-z0-9_-]{43}")||created<0)throw invalid();
        return new Ticket(nonce,created);
    }
    public static String musicPage(String value)throws Exception{
        if(value==null||value.length()>4096)throw pageRequired();
        try{
            URI uri=new URI(value);
            // Do not extract a nested Suno link from an unrelated, login or redirect page.
            if(!"https".equalsIgnoreCase(uri.getScheme())||!"suno.com".equalsIgnoreCase(uri.getHost())||uri.getRawUserInfo()!=null||uri.getPort()!=-1)throw pageRequired();
            return SunoShare.extract(SunoCatalog.canonicalLink(value));
        }catch(Exception failure){throw pageRequired();}
    }
    public static String title(String title,String music){
        String safe=title==null?"":title.replaceAll("[\\p{Cc}\\p{Cf}]","").trim();
        if(safe.length()>120)safe=safe.substring(0,120).trim();
        return safe.isEmpty()?(music!=null&&music.contains("/playlist/")?"Playlist Suno":"Morceau Suno"):safe;
    }
    private static IllegalArgumentException invalid(){return new IllegalArgumentException("Rouvre Suno depuis Rhythmbox pour choisir un morceau.");}
    private static IllegalArgumentException pageRequired(){return new IllegalArgumentException("Ouvre un morceau ou une playlist partageable dans Suno, puis choisis « Écouter dans Rhythmbox ». La page de ton compte et les favoris privés ne sont pas des morceaux partageables.");}
}
