package fr.lemegageek.rhythmbox;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Context;
import android.os.Bundle;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

/** Self-targeted, separate UID; no network permission and no real account is used. */
public final class PCloudAuthInstrumentation extends Instrumentation {
    private static final String TEST_PACKAGE = "fr.lemegageek.rhythmbox.authtest";
    private static final String EMAIL = "music-test@example.invalid";
    private static final String CLIENT = "isolated-test-client";
    private final AtomicInteger assertions = new AtomicInteger();
    private final JSONArray cases = new JSONArray();
    private Context context;
    private int failures;

    interface Checked { void run() throws Exception; }

    @Override public void onCreate(Bundle arguments) { super.onCreate(arguments); start(); }

    @Override public void onStart() {
        context = getTargetContext();
        try {
            check(TEST_PACKAGE.equals(context.getPackageName()), "isolated package");
            check(context.getApplicationInfo().uid != 0, "non-root application UID");
            check(context.checkSelfPermission("android.permission.INTERNET") != 0, "no network permission");
            test("encrypted_roundtrip_and_pending", this::encryptedRoundtrip);
            test("tamper_and_kind_binding", this::tamperAndKindBinding);
            test("multi_instance_atomic_io", this::concurrentStores);
            test("folder_selection_compare_and_save", this::folderSelection);
            test("direct_token_roundtrip_and_session_cas", this::directStore);
            test("direct_failed_login_revokes_new_token_only", this::directRevocation);
            test("browser_login_temporary_and_persistent_store", this::browserStore);
            test("browser_login_cancel_and_identity_revocation", this::browserRevocation);
            test("browser_network_recovery_preserves_request_and_grant", this::browserNetworkRecovery);
            test("valid_identity_and_replay", this::validIdentityAndReplay);
            test("wrong_state_identity_uid_and_expiry", this::rejectUnverified);
            test("cancel_during_identity_preserves_account", this::cancelDuringIdentity);
            test("new_pending_survives_old_callback", this::newPendingSurvives);
            test("new_authorization_survives_old_callback", this::newAuthorizationSurvives);
            test("disconnect_during_identity", this::disconnectDuringIdentity);
            test("verifier_error_is_redacted", this::redactedError);
        } catch (Throwable error) {
            failures++;
            addCase("harness_isolation", false, error.getClass().getSimpleName());
        } finally {
            try { PCloudOAuth.disconnect(context); } catch (Throwable ignored) { failures++; }
            // This alias is in the test application's own AndroidKeyStore UID only.
            try {
                KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
                keyStore.load(null);
                keyStore.deleteEntry("rhythmbox.pcloud.account.v1");
            } catch (Throwable ignored) { failures++; }
            Bundle result = new Bundle();
            try {
                result.putString("report", new JSONObject().put("package", TEST_PACKAGE)
                    .put("assertions", assertions.get()).put("failures", failures).put("cases", cases)
                    .put("network_permission", false).put("production_app_data_accessed", false).toString());
            } catch (Exception ignored) { result.putString("report", "report generation failed"); }
            result.putString("stream", "\nIsolated pCloud authorization tests: " +
                assertions.get() + " assertions, " + failures + " failures\n");
            finish(failures == 0 ? Activity.RESULT_OK : Activity.RESULT_CANCELED, result);
        }
    }

    private void test(String name, Checked task) {
        try { PCloudOAuth.disconnect(context); task.run(); addCase(name, true, ""); }
        catch (Throwable error) { failures++; addCase(name, false, error.getClass().getSimpleName()); }
    }

    private void addCase(String name, boolean passed, String errorClass) {
        try { cases.put(new JSONObject().put("name", name).put("passed", passed).put("error_class", errorClass)); }
        catch (Exception ignored) { failures++; }
    }

    private void check(boolean ok, String reason) {
        assertions.incrementAndGet();
        if (!ok) throw new AssertionError(reason);
    }

    private void rejected(Checked action) throws Exception {
        boolean rejected = false;
        try { action.run(); } catch (Exception expected) { rejected = true; }
        check(rejected, "authorization must be rejected");
    }

    private PCloudAccount account(String marker) { return new PCloudAccount("synthetic-" + marker, EMAIL, "eu", CLIENT, 12345, 0); }
    private PCloudAccountStore store() { return new PCloudAccountStore(context); }
    private File file(String kind) { return new File(context.getNoBackupFilesDir(), "pcloud-" + kind + "-v1.enc"); }
    private PCloudOAuthProtocol.Pending pending() {
        return PCloudOAuthProtocol.create(CLIENT, EMAIL, 12345, 0, System.currentTimeMillis());
    }
    private String callback(PCloudOAuthProtocol.Pending pending, String marker) {
        return PCloudOAuthProtocol.REDIRECT_URI + "#access_token=synthetic-" + marker +
            "&token_type=bearer&uid=12345&state=" + pending.state + "&hostname=eapi.pcloud.com&locationid=2";
    }
    private JSONObject identity(PCloudAccount account) throws Exception {
        return new JSONObject().put("result", 0).put("userid", account.userid).put("email", account.email);
    }
    private void currentIs(String marker) throws Exception {
        PCloudAccount loaded = store().load();
        check(loaded != null && loaded.token.equals(account(marker).token), "expected current authorization");
    }

    private void encryptedRoundtrip() throws Exception {
        check(store().load() == null && store().loadPending() == null, "empty is null");
        PCloudAccount expected = account("roundtrip");
        store().save(expected);
        PCloudAccount loaded = store().load();
        check(loaded.token.equals(expected.token) && loaded.email.equals(expected.email) &&
            loaded.userid == expected.userid && loaded.musicFolderId == 0, "account roundtrip");
        String first = new String(Files.readAllBytes(file("account").toPath()), StandardCharsets.UTF_8);
        check(!first.contains(expected.token) && !first.contains(EMAIL) && !first.contains(CLIENT), "no plaintext account");
        JSONObject envelope = new JSONObject(first);
        check(envelope.length() == 2 && envelope.has("iv") && envelope.has("data"), "ciphertext envelope only");
        store().save(expected);
        check(!first.equals(new String(Files.readAllBytes(file("account").toPath()), StandardCharsets.UTF_8)), "fresh GCM nonce");
        PCloudOAuthProtocol.Pending request = pending();
        store().savePending(request.json());
        PCloudOAuthProtocol.Pending restored = PCloudOAuthProtocol.pending(store().loadPending());
        check(restored.state.equals(request.state) && !restored.claimed && restored.expectedUserid == 12345, "pending roundtrip");
        String encrypted = new String(Files.readAllBytes(file("pending").toPath()), StandardCharsets.UTF_8);
        check(!encrypted.contains(request.state) && !encrypted.contains(EMAIL), "no plaintext pending state");
        check(file("account").getParentFile().equals(context.getNoBackupFilesDir()), "credentials excluded from backup");
        PCloudOAuth.disconnect(context);
        check(store().load() == null && store().loadPending() == null, "clear both records");
        checkNoTemporaryFiles();
    }

    private void tamperAndKindBinding() throws Exception {
        store().save(account("tamper"));
        byte[] original = Files.readAllBytes(file("account").toPath());
        JSONObject envelope = new JSONObject(new String(original, StandardCharsets.UTF_8));
        String data = envelope.getString("data");
        envelope.put("data", (data.charAt(0) == 'A' ? "B" : "A") + data.substring(1));
        Files.write(file("account").toPath(), envelope.toString().getBytes(StandardCharsets.UTF_8));
        rejected(() -> store().load());
        Files.write(file("account").toPath(), original);
        currentIs("tamper");
        store().savePending(pending().json());
        Files.write(file("pending").toPath(), original);
        rejected(() -> store().loadPending());
        currentIs("tamper");
    }

    private void concurrentStores() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        keyStore.deleteEntry("rhythmbox.pcloud.account.v1");
        int workers = 6, rounds = 15;
        CountDownLatch ready = new CountDownLatch(workers), start = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();
        List<Thread> threads = new ArrayList<>();
        for (int w = 0; w < workers; w++) {
            final int worker = w;
            Thread thread = new Thread(() -> {
                ready.countDown();
                try {
                    check(start.await(5, TimeUnit.SECONDS), "worker start");
                    for (int r = 0; r < rounds; r++) {
                        PCloudAccountStore local = store();
                        String marker = "parallel-" + worker + "-" + r;
                        local.save(account(marker));
                        PCloudAccount read = local.load();
                        check(read != null && read.token.startsWith("synthetic-parallel-") && read.userid == 12345, "whole concurrent account");
                        local.savePending(pending().json());
                        check(PCloudOAuthProtocol.pending(local.loadPending()).expectedUserid == 12345, "whole concurrent pending");
                    }
                } catch (Throwable error) { failure.compareAndSet(null, error); }
            }, "pcloud-store-isolation-" + w);
            threads.add(thread); thread.start();
        }
        check(ready.await(5, TimeUnit.SECONDS), "workers ready");
        start.countDown();
        for (Thread thread : threads) { thread.join(30000); check(!thread.isAlive(), "concurrent worker completed"); }
        check(failure.get() == null, "multi-instance key creation and AtomicFile operations");
        checkNoTemporaryFiles();
    }

    private void checkNoTemporaryFiles() {
        for (String kind : new String[] {"account", "pending"})
            for (String suffix : new String[] {".bak", ".new"})
                check(!new File(file(kind) + suffix).exists(), "no AtomicFile residue");
    }

    private void folderSelection() throws Exception {
        PCloudAccount initial = account("folder-old");
        store().save(initial);
        check(store().selectMusicFolder(initial, 700), "current authorization accepts folder");
        check(store().load().musicFolderId == 700, "folder persisted");
        check(!store().selectMusicFolder(initial, 701), "stale folder selection refused");
        PCloudAccount captured = store().load();
        store().save(account("folder-new"));
        check(!store().selectMusicFolder(captured, 702), "new token same userid is preserved");
        currentIs("folder-new");
        check(store().load().musicFolderId == 0, "new authorization folder unchanged");
        store().clear();
        check(!store().selectMusicFolder(initial, 703), "disconnected account cannot be restored");
        for (int i = 0; i < 12; i++) {
            store().save(initial);
            CountDownLatch start = new CountDownLatch(1);
            AtomicReference<Throwable> error = new AtomicReference<>();
            Thread selector = new Thread(() -> {
                try { start.await(); store().selectMusicFolder(initial, 704); }
                catch (Throwable failure) { error.compareAndSet(null, failure); }
            });
            Thread authorizer = new Thread(() -> {
                try { start.await(); store().save(account("folder-new")); }
                catch (Throwable failure) { error.compareAndSet(null, failure); }
            });
            selector.start(); authorizer.start(); start.countDown();
            selector.join(5000); authorizer.join(5000);
            check(!selector.isAlive() && !authorizer.isAlive() && error.get() == null, "folder/auth race completed");
            currentIs("folder-new");
            check(store().load().musicFolderId == 0, "concurrent folder lookup cannot restore old authorization");
        }
    }

    private void validIdentityAndReplay() throws Exception {
        PCloudOAuthProtocol.Pending request = pending();
        store().savePending(request.json());
        AtomicInteger calls = new AtomicInteger();
        PCloudOAuth.IdentityVerifier verifier = candidate -> { calls.incrementAndGet(); return identity(candidate); };
        PCloudAccount result = PCloudOAuth.consume(context, callback(request, "valid"), verifier);
        check(result.userid == 12345 && result.musicFolderId == 0, "identity verified before folder selection");
        currentIs("valid");
        check(store().loadPending() == null, "successful nonce consumed");
        rejected(() -> PCloudOAuth.consume(context, callback(request, "valid"), verifier));
        check(calls.get() == 1, "replay never verifies again");
    }

    private void rejectUnverified() throws Exception {
        store().save(account("baseline"));
        PCloudOAuthProtocol.Pending request = pending();
        store().savePending(request.json());
        AtomicInteger calls = new AtomicInteger();
        PCloudOAuth.IdentityVerifier verifier = candidate -> { calls.incrementAndGet(); return identity(candidate); };
        final PCloudOAuthProtocol.Pending first = request;
        rejected(() -> PCloudOAuth.consume(context, callback(first, "wrong-state").replace(first.state, pending().state), verifier));
        check(calls.get() == 0, "wrong state rejected before identity lookup");
        check(!PCloudOAuthProtocol.pending(store().loadPending()).claimed, "invalid state does not consume valid request");
        request = pending(); store().savePending(request.json());
        final PCloudOAuthProtocol.Pending second = request;
        rejected(() -> PCloudOAuth.consume(context, callback(second, "wrong-email"),
            candidate -> identity(candidate).put("email", "different@example.invalid")));
        check(store().loadPending() == null, "wrong identity consumes claimed nonce");
        currentIs("baseline");
        request = pending(); store().savePending(request.json());
        final PCloudOAuthProtocol.Pending third = request;
        rejected(() -> PCloudOAuth.consume(context, callback(third, "wrong-userinfo-uid"),
            candidate -> identity(candidate).put("userid", 99999)));
        currentIs("baseline");
        request = pending(); store().savePending(request.json());
        final PCloudOAuthProtocol.Pending fourth = request;
        rejected(() -> PCloudOAuth.consume(context, callback(fourth, "wrong-callback-uid").replace("uid=12345", "uid=99999"), verifier));
        check(calls.get() == 0, "pinned callback userid rejected before identity lookup");
        request = pending();
        store().savePending(request.json().put("created_ms", System.currentTimeMillis() - PCloudOAuthProtocol.MAX_AGE_MILLIS - 1000));
        final PCloudOAuthProtocol.Pending fifth = request;
        rejected(() -> PCloudOAuth.consume(context, callback(fifth, "expired"), verifier));
        check(calls.get() == 0, "expired request rejected before identity lookup");
        currentIs("baseline");
    }

    private final class BlockedIdentity {
        final CountDownLatch entered = new CountDownLatch(1), release = new CountDownLatch(1);
        final AtomicReference<Throwable> error = new AtomicReference<>();
        final Thread worker;
        BlockedIdentity(PCloudOAuthProtocol.Pending request, String marker) {
            worker = new Thread(() -> {
                try {
                    PCloudOAuth.consume(context, callback(request, marker), candidate -> {
                        entered.countDown();
                        if (!release.await(10, TimeUnit.SECONDS)) throw new IllegalStateException();
                        return identity(candidate);
                    });
                } catch (Throwable failure) { error.set(failure); }
            }, "pcloud-blocked-fake-identity");
        }
        void start() throws Exception { worker.start(); check(entered.await(5, TimeUnit.SECONDS), "fake identity entered"); }
        void finishRejected() throws Exception {
            release.countDown(); worker.join(10000);
            check(!worker.isAlive() && error.get() != null, "old callback rejected after identity returns");
        }
    }

    private void cancelDuringIdentity() throws Exception {
        store().save(account("baseline"));
        PCloudOAuthProtocol.Pending request = pending(); store().savePending(request.json());
        BlockedIdentity blocked = new BlockedIdentity(request, "cancelled");
        try {
            blocked.start(); PCloudOAuth.cancel(context); blocked.finishRejected();
            currentIs("baseline"); check(store().loadPending() == null, "cancel clears nonce");
        } finally { blocked.release.countDown(); }
    }

    private void newPendingSurvives() throws Exception {
        store().save(account("baseline"));
        PCloudOAuthProtocol.Pending old = pending(); store().savePending(old.json());
        BlockedIdentity blocked = new BlockedIdentity(old, "old");
        try {
            blocked.start(); PCloudOAuthProtocol.Pending newer = pending(); store().savePending(newer.json());
            blocked.finishRejected(); currentIs("baseline");
            check(PCloudOAuthProtocol.pending(store().loadPending()).state.equals(newer.state), "new pending nonce survives");
        } finally { blocked.release.countDown(); }
    }

    private void newAuthorizationSurvives() throws Exception {
        PCloudOAuthProtocol.Pending old = pending(); store().savePending(old.json());
        BlockedIdentity blocked = new BlockedIdentity(old, "old");
        try {
            blocked.start(); PCloudOAuthProtocol.Pending newer = pending(); store().savePending(newer.json());
            PCloudOAuth.consume(context, callback(newer, "newer"), this::identity);
            blocked.finishRejected(); currentIs("newer");
            check(store().loadPending() == null, "old callback cannot restore consumed nonce");
        } finally { blocked.release.countDown(); }
    }

    private void disconnectDuringIdentity() throws Exception {
        store().save(account("baseline"));
        PCloudOAuthProtocol.Pending request = pending(); store().savePending(request.json());
        BlockedIdentity blocked = new BlockedIdentity(request, "disconnected");
        try {
            blocked.start(); PCloudOAuth.disconnect(context); blocked.finishRejected();
            check(store().load() == null && store().loadPending() == null, "disconnect cannot be undone by late callback");
        } finally { blocked.release.countDown(); }
    }

    private void redactedError() throws Exception {
        store().save(account("baseline"));
        PCloudOAuthProtocol.Pending request = pending(); store().savePending(request.json());
        try {
            PCloudOAuth.consume(context, callback(request, "error-secret"), candidate -> {
                throw new IllegalStateException(candidate.token + candidate.email);
            });
            throw new AssertionError("expected rejection");
        } catch (IllegalStateException expected) {
            check(!expected.toString().contains("synthetic-error-secret") && !expected.toString().contains(EMAIL), "verifier exception redacted");
        }
        currentIs("baseline");
    }
    private JSONObject directPending(String state) throws Exception {
        return new JSONObject().put("auth_type","direct").put("state",state).put("created_ms",System.currentTimeMillis());
    }
    private void directStore() throws Exception {
        PCloudAccount old=account("before-direct");store().save(old);
        JSONObject pending=directPending("first-direct-nonce");
        PCloudAccount expected=store().beginDirect(pending);
        check(PCloudAccount.sameAuthorization(old,expected),"direct begin captures prior authorization");
        PCloudAccount direct=new PCloudAccount("synthetic-direct-token",EMAIL,"eu","",12345,303,"direct");
        check(!store().saveDirect(directPending("foreign-nonce"),expected,direct),"wrong direct nonce rejected");
        check(PCloudAccount.sameAuthorization(old,store().load()),"old account survives invalid direct nonce");
        check(store().saveDirect(pending,expected,direct),"matching direct attempt committed");
        PCloudAccount loaded=store().load();
        check(loaded.authType.equals("direct")&&loaded.clientId.isEmpty()&&loaded.musicFolderId==303,"direct auth type/root survives Keystore roundtrip");
        check(store().loadPending()==null,"direct nonce consumed once");
        check(!store().saveDirect(pending,expected,direct),"direct nonce replay rejected");
        String encrypted=new String(Files.readAllBytes(new File(context.getNoBackupFilesDir(),"pcloud-account-v1.enc").toPath()),StandardCharsets.UTF_8);
        check(!encrypted.contains("synthetic-direct-token")&&!encrypted.contains(EMAIL),"direct token and email encrypted");
        pending=directPending("cancel-direct-nonce");expected=store().beginDirect(pending);store().cancelDirect(pending);
        check(!store().saveDirect(pending,expected,direct),"canceled direct attempt never restores account");
        pending=directPending("old-direct-nonce");expected=store().beginDirect(pending);PCloudOAuthProtocol.Pending oauth=pending();store().savePending(oauth.json());
        check(!store().saveDirect(pending,expected,direct),"direct attempt cannot consume newer OAuth session");
        store().cancelDirect(pending);check(PCloudOAuthProtocol.pending(store().loadPending()).state.equals(oauth.state),"cancel direct preserves newer OAuth session");
        pending=directPending("cas-direct-nonce");expected=store().beginDirect(pending);store().save(account("new-authorization"));
        check(!store().saveDirect(pending,expected,direct),"direct account CAS rejects changed authorization");
        check(store().load().token.equals("synthetic-new-authorization"),"new authorization survives old direct response");
        pending=directPending("expired-direct").put("created_ms",System.currentTimeMillis()-PCloudOAuthProtocol.MAX_AGE_MILLIS-1000);expected=store().beginDirect(pending);
        check(!store().saveDirect(pending,expected,direct),"expired direct attempt rejected");
        pending=directPending("future-direct").put("created_ms",System.currentTimeMillis()+60000);expected=store().beginDirect(pending);
        check(!store().saveDirect(pending,expected,direct),"future direct timestamp rejected");
        pending=directPending("disconnect-direct");expected=store().beginDirect(pending);PCloudOAuth.disconnect(context);
        check(!store().saveDirect(pending,expected,direct)&&store().load()==null,"disconnect prevents late direct response");
    }

    private void directRevocation() throws Exception {
        PCloudAccount old=account("prior-direct-login");store().save(old);
        for(int failureMode=0;failureMode<3;failureMode++){
            store().save(old);PCloudDirectLogin.Session session=PCloudDirectLogin.begin(context);final int mode=failureMode;
            List<String> methods=new ArrayList<>();List<String> revoked=new ArrayList<>();
            PCloudDirectLoginProtocol.Transport transport=(region,method,params,secret)->{
                methods.add(method);
                if(method.equals("logout")){revoked.add(params.get("auth"));return new JSONObject().put("result",0);}
                JSONObject info=new JSONObject().put("result",0).put("userid",12345).put("email",EMAIL).put("auth","synthetic-new-direct-token");
                if(secret==null){
                    if(mode==0)info.put("email","wrong@example.invalid");
                    else if(mode==1)PCloudDirectLogin.cancel(context,session);
                    else store().save(account("newer-authorized-account"));
                }
                return info;
            };
            char[] password="synthetic-test-password".toCharArray();
            rejected(()->PCloudDirectLogin.login(context,session,EMAIL,password,"eu",transport));
            check(methods.size()==3&&methods.get(2).equals("logout"),"failed direct authorization revokes after two identity calls");
            check(revoked.size()==1&&revoked.get(0).equals("synthetic-new-direct-token"),"only the newly issued direct token is revoked");
            check(store().load().token.equals(mode==2?"synthetic-newer-authorized-account":old.token),"previous/newer authorization survives failed direct login");
            boolean cleared=true;for(char c:password)cleared&=c=='\0';check(cleared,"direct password cleared after identity/cancel/CAS failure");
            PCloudDirectLogin.cancel(context,session);
        }
    }

    private final class BrowserTransport implements PCloudDirectLoginProtocol.Transport {
        final List<String> methods=new ArrayList<>();
        final List<String> revoked=new ArrayList<>();
        boolean remember,pending,wrongIdentity,cancelInIdentity;
        int pollInterruptions,identityInterruptions;
        PCloudDeviceLogin.Session session;
        @Override public JSONObject request(String region,String method,java.util.Map<String,String> params,char[] secret) throws Exception {
            check(secret==null,"browser authorization has no password/code");methods.add(method);
            if(method.equals("getrequestid"))return new JSONObject().put("result",0).put("request_id","synthetic-private-browser-request").put("expires",java.time.format.DateTimeFormatter.RFC_1123_DATE_TIME.format(java.time.Instant.now().plusSeconds(600).atZone(java.time.ZoneOffset.UTC)));
            if(method.equals("pcloud_oauth2_token")&&pollInterruptions-->0)throw new java.net.SocketTimeoutException("synthetic private poll interruption");
            if(method.equals("pcloud_oauth2_token"))return pending?new JSONObject().put("result",6002):new JSONObject().put("result",0).put("token","synthetic-browser-token").put("userid",12345).put("locationid",2).put("rememberme",remember);
            if(method.equals("userinfo")){
                if(identityInterruptions-->0)throw new java.io.IOException("synthetic private identity interruption");
                if(cancelInIdentity)PCloudDeviceLogin.cancel(context,session,this);
                return new JSONObject().put("result",0).put("userid",12345).put("email",wrongIdentity?"wrong@example.invalid":EMAIL);
            }
            if(method.equals("logout")){revoked.add(params.get("auth"));return new JSONObject().put("result",0);}
            throw new AssertionError(method);
        }
    }
    private void browserStore() throws Exception {
        PCloudAccount old=account("before-browser").withMusicFolder(303);store().save(old);
        BrowserTransport transport=new BrowserTransport();PCloudDeviceLogin.Session session=PCloudDeviceLogin.begin(context,EMAIL,transport);transport.session=session;
        check(!store().loadPending().toString().contains("synthetic-private-browser-request"),"request capability is never persisted with local nonce");
        transport.pending=true;check(PCloudDeviceLogin.poll(context,session,transport).pending,"pending browser flow never establishes identity");
        check(PCloudAccount.sameAuthorization(old,store().load()),"pending flow preserves previous account");
        transport.pending=false;PCloudAccount temporary=PCloudDeviceLogin.poll(context,session,transport).account;
        check(!store().isPersistent(temporary)&&temporary.musicFolderId==303,"provider remember-me=false retained in RAM with selected root");
        check(!new File(context.getNoBackupFilesDir(),"pcloud-account-v1.enc").exists(),"old persistent authorization removed for temporary browser session");
        check(PCloudAccount.sameAuthorization(temporary,new PCloudAccountStore(context).load()),"temporary grant shared across store instances only in process");
        check(store().selectMusicFolder(temporary,404),"temporary folder selection succeeds");
        PCloudAccount chosen=store().load();check(chosen.musicFolderId==404&&!store().isPersistent(chosen),"folder selection never persists temporary grant");
        check(!new File(context.getNoBackupFilesDir(),"pcloud-account-v1.enc").exists(),"temporary folder choice writes no auth file");
        JSONObject request=directPending("persistence-mode-cas");PCloudAccount expected=store().beginDirect(request);store().save(chosen);
        check(!store().saveDirect(request,expected,temporary,false),"CAS detects persistence-mode change even with same token/identity");
        check(store().isPersistent(chosen),"new persistent choice survives older temporary attempt");
        BrowserTransport lasting=new BrowserTransport();lasting.remember=true;PCloudDeviceLogin.Session persistent=PCloudDeviceLogin.begin(context,EMAIL,lasting);lasting.session=persistent;
        PCloudAccount saved=PCloudDeviceLogin.poll(context,persistent,lasting).account;
        check(store().isPersistent(saved)&&new File(context.getNoBackupFilesDir(),"pcloud-account-v1.enc").exists(),"remember-me=true persists encrypted grant");
        check(saved.musicFolderId==404,"persistent browser renewal preserves current root");
        PCloudOAuth.disconnect(context);check(store().load()==null,"disconnect has no fallback to prior account");
    }
    private void browserRevocation() throws Exception {
        for(int mode=0;mode<2;mode++){
            PCloudAccount old=account("browser-baseline");store().save(old);BrowserTransport transport=new BrowserTransport();
            PCloudDeviceLogin.Session session=PCloudDeviceLogin.begin(context,EMAIL,transport);transport.session=session;
            transport.wrongIdentity=mode==0;transport.cancelInIdentity=mode==1;
            rejected(()->PCloudDeviceLogin.poll(context,session,transport));
            check(transport.revoked.size()==1&&transport.revoked.get(0).equals("synthetic-browser-token"),"wrong identity/cancel revokes only new browser grant");
            check(PCloudAccount.sameAuthorization(old,store().load()),"browser failure preserves previous authorization");
            PCloudDeviceLogin.cancel(context,session);
        }
    }

    private void browserNetworkRecovery() throws Exception {
        PCloudAccount old=account("network-baseline").withMusicFolder(303);store().save(old);
        BrowserTransport transport=new BrowserTransport();transport.remember=true;
        PCloudDeviceLogin.Session session=PCloudDeviceLogin.begin(context,EMAIL,transport);transport.session=session;
        transport.pending=true;check(PCloudDeviceLogin.poll(context,session,transport).pending,"browser initially pending");
        transport.pending=false;transport.pollInterruptions=1;
        try{PCloudDeviceLogin.poll(context,session,transport);throw new AssertionError("expected poll interruption");}catch(PCloudDeviceLoginProtocol.NetworkFailure expected){check(expected.phase.equals("poll-network"),"poll interruption classified");}
        check(store().loadPending()!=null&&PCloudAccount.sameAuthorization(old,store().load()),"poll IO preserves local nonce and previous account");
        transport.identityInterruptions=1;
        try{PCloudDeviceLogin.poll(context,session,transport);throw new AssertionError("expected identity interruption");}catch(PCloudDeviceLoginProtocol.NetworkFailure expected){check(expected.phase.equals("identity-network"),"identity interruption classified");}
        check(transport.revoked.isEmpty()&&PCloudAccount.sameAuthorization(old,store().load()),"unverified grant retained only in memory across identity IO");
        PCloudAccount recovered=PCloudDeviceLogin.poll(context,session,transport).account;
        check(recovered.userid==12345&&recovered.musicFolderId==303&&store().isPersistent(recovered),"return to app completes same verified persistent authorization");
        check(java.util.Collections.frequency(transport.methods,"getrequestid")==1&&java.util.Collections.frequency(transport.methods,"pcloud_oauth2_token")==3&&java.util.Collections.frequency(transport.methods,"userinfo")==2,"network retry never replaces request or re-polls consumed grant");
        PCloudDeviceLogin.cancel(context,session,transport);
        check(transport.revoked.isEmpty()&&PCloudAccount.sameAuthorization(recovered,store().load()),"late cancel cannot revoke or restore a committed account");
        store().save(old);BrowserTransport cancelled=new BrowserTransport();PCloudDeviceLogin.Session abandoned=PCloudDeviceLogin.begin(context,EMAIL,cancelled);cancelled.session=abandoned;cancelled.identityInterruptions=1;
        try{PCloudDeviceLogin.poll(context,abandoned,cancelled);}catch(PCloudDeviceLoginProtocol.NetworkFailure expected){}
        PCloudDeviceLogin.cancel(context,abandoned,cancelled);PCloudDeviceLogin.cancel(context,abandoned,cancelled);
        check(cancelled.revoked.size()==1&&cancelled.revoked.get(0).equals("synthetic-browser-token"),"cancel during network pause revokes only held new token once");
        check(PCloudAccount.sameAuthorization(old,store().load()),"cancelled network recovery preserves prior account");
        rejected(()->PCloudDeviceLogin.poll(context,abandoned,cancelled));
    }

}
