package fr.lemegageek.rhythmbox;

import android.content.Context;
import android.media.MediaDataSource;
import org.json.JSONObject;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

/** Called from an isolated instrumentation worker, never its main/UI thread.
 * Uses synthesized RAM audio and the normal renderer; no capture or permission.
 */
public final class PcmAudioPlayerProbe {
    private static int assertions;
    private static void check(boolean condition, String message) {
        assertions++;
        if (!condition) throw new AssertionError(message);
    }
    private static void await(CountDownLatch event, int seconds, String message) throws Exception {
        check(event.await(seconds, TimeUnit.SECONDS), message);
    }
    private static final class Memory extends MediaDataSource {
        final byte[] bytes;
        final AtomicInteger closes = new AtomicInteger();
        Memory(byte[] bytes) { this.bytes = bytes; }
        @Override public int readAt(long position, byte[] target, int offset, int size) {
            if (position < 0 || position >= bytes.length) return -1;
            int count = (int) Math.min(size, bytes.length - position);
            System.arraycopy(bytes, (int) position, target, offset, count);
            return count;
        }
        @Override public long getSize() { return bytes.length; }
        @Override public void close() { closes.incrementAndGet(); }
    }
    private static byte[] wave(int channels) {
        int rate = 48000, frames = rate * 3, bytes = frames * channels * 2;
        ByteBuffer out = ByteBuffer.allocate(44 + bytes).order(ByteOrder.LITTLE_ENDIAN);
        out.put(new byte[]{'R','I','F','F'}).putInt(bytes + 36)
            .put(new byte[]{'W','A','V','E','f','m','t',' '}).putInt(16)
            .putShort((short) 1).putShort((short) channels).putInt(rate)
            .putInt(rate * channels * 2).putShort((short) (channels * 2)).putShort((short) 16)
            .put(new byte[]{'d','a','t','a'}).putInt(bytes);
        for (int i = 0; i < frames; i++) {
            for (int channel = 0; channel < channels; channel++) {
                double frequency = channel == 0 ? 468.75 : 3000;
                double amplitude = channel == 0 ? .4 : .1;
                out.putShort((short) Math.round(amplitude * 32767 * Math.sin(2 * Math.PI * frequency * i / rate)));
            }
        }
        return out.array();
    }

    public static JSONObject run(Context context) throws Exception {
        JSONObject report = new JSONObject();
        try { return runProbe(context, report); }
        catch (Exception | AssertionError failure) {
            return report.put("assertions", assertions).put("ok", false)
                .put("error_type", failure.getClass().getSimpleName())
                .put("error", String.valueOf(failure.getMessage()));
        }
    }

    private static JSONObject runProbe(Context context, JSONObject report) throws Exception {
        assertions = 0;
        Memory source = new Memory(wave(2));
        PcmAudioPlayer player = new PcmAudioPlayer(PcmAudioPlayer.borrowedMediaDataSource(source));
        CountDownLatch prepared = new CountDownLatch(1), sought = new CountDownLatch(1), complete = new CountDownLatch(1);
        AtomicReference<Exception> error = new AtomicReference<>();
        player.setOnPreparedListener(p -> prepared.countDown());
        player.setOnSeekCompleteListener(p -> sought.countDown());
        player.setOnCompletionListener(p -> complete.countDown());
        player.setOnErrorListener((p, failure) -> { error.set(failure); prepared.countDown(); sought.countDown(); complete.countDown(); });
        StereoSpectrum.Snapshot measured;
        try {
            player.prepareAsync();
            await(prepared, 8, "real native codec prepares");
            check(error.get() == null, "codec preparation succeeds: " + error.get());
            check(player.getAudioSessionId() > 0, "nonzero own audio session");
            check(player.getDuration() >= 2950 && player.getDuration() <= 3050, "extractor duration retained");
            check(player.getCurrentPosition() == 0, "prepared source starts at zero before playback");
            check(!player.getSpectrum().available, "preparation has no fabricated playback spectrum");
            player.start();
            long until = android.os.SystemClock.elapsedRealtime() + 2500;
            do {
                measured = player.getSpectrum();
                if (measured.available && player.getCurrentPosition() >= 160) break;
                Thread.sleep(10);
            } while (android.os.SystemClock.elapsedRealtime() < until && error.get() == null);
            check(error.get() == null && player.isPlaying(), "real renderer plays without codec error");
            check(measured.available && measured.channels == 2, "real accepted PCM produces stereo snapshot");
            check(Math.abs(measured.leftDominantHz - 468.75) < 1, "real left decoded spectrum");
            check(Math.abs(measured.rightDominantHz - 3000) < 1, "real right decoded spectrum");
            check(Math.abs(measured.leftRmsDb - measured.rightRmsDb - 12.0412) < .15, "decoded channel levels remain independent");
            report.put("left_hz", measured.leftDominantHz).put("right_hz", measured.rightDominantHz)
                .put("left_rms_db", measured.leftRmsDb).put("right_rms_db", measured.rightRmsDb);
            int beforePause = player.getCurrentPosition();
            check(beforePause > 100, "AudioTrack playback head advances native position");
            player.pause();
            check(!player.isPlaying() && !player.getSpectrum().available, "pause stops spectrum instead of inventing motion");
            int paused = player.getCurrentPosition(); Thread.sleep(120);
            int afterPause = player.getCurrentPosition();
            report.put("pause_before_ms", beforePause).put("pause_paused_ms", paused)
                .put("pause_after_ms", afterPause).put("pause_diff_ms", afterPause - paused);
            check(Math.abs(afterPause - paused) < 40, "pause freezes playback clock");
            player.seekTo(1200);
            check(player.getCurrentPosition() == 1200, "paused seek immediately reports requested time");
            await(sought, 3, "paused seek flushes and completes");
            check(error.get() == null && Math.abs(player.getCurrentPosition() - 1200) < 30, "seek uses requested source time");
            check(!player.getSpectrum().available, "seek has discarded old spectrum");
            player.start();
            await(complete, 5, "EOS completes after the accepted audio queue drains");
            check(error.get() == null && !player.isPlaying(), "completion is not a decoder error");
            check(player.getCurrentPosition() >= 2950, "completion is after source tail, not initial decoder EOS");
            int completedPosition = player.getCurrentPosition(); Thread.sleep(120);
            report.put("completion_ms", completedPosition).put("completion_after_ms", player.getCurrentPosition());
            check(player.getCurrentPosition() == completedPosition, "completed source retains final playback position");
        } finally { player.release(); }
        check(!player.getSpectrum().available, "release invalidates spectrum");
        check(source.closes.get() == 0, "borrowed Suno-like source remains available to fallback owner");
        source.close();

        Memory owned = new Memory(wave(1));
        PcmAudioPlayer ownedPlayer = new PcmAudioPlayer(PcmAudioPlayer.mediaDataSource(owned));
        CountDownLatch ownedPrepared = new CountDownLatch(1);
        ownedPlayer.setOnPreparedListener(p -> ownedPrepared.countDown());
        ownedPlayer.setOnErrorListener((p, failure) -> ownedPrepared.countDown());
        ownedPlayer.prepareAsync();
        await(ownedPrepared, 8, "owned source opens");
        ownedPlayer.release();
        long untilClosed = android.os.SystemClock.elapsedRealtime() + 2000;
        while (owned.closes.get() == 0 && android.os.SystemClock.elapsedRealtime() < untilClosed) Thread.sleep(10);
        check(owned.closes.get() == 1, "owned source closes exactly once");

        Memory surround = new Memory(wave(6));
        PcmAudioPlayer unsupported = new PcmAudioPlayer(PcmAudioPlayer.borrowedMediaDataSource(surround));
        CountDownLatch rejected = new CountDownLatch(1);
        AtomicReference<Exception> rejection = new AtomicReference<>();
        unsupported.setOnPreparedListener(p -> rejected.countDown());
        unsupported.setOnErrorListener((p, failure) -> { rejection.set(failure); rejected.countDown(); });
        try {
            unsupported.prepareAsync();
            await(rejected, 8, "multichannel source returns a terminal preparation result");
            check(rejection.get() instanceof PcmAudioPlayer.UnsupportedAudioException, "unsupported layout permits explicit compatibility fallback");
            check(!unsupported.getSpectrum().available, "unsupported layout has no misleading analyzer");
        } finally { unsupported.release(); }
        check(surround.closes.get() == 0, "unsupported decoder preserves borrowed fallback source");
        surround.close();
        return report.put("assertions", assertions).put("ok", true)
            .put("no_microphone_or_global_capture", true).put("no_network", true);
    }
}
