package fr.lemegageek.rhythmbox;
/** Synthetic identity source for the separate offline host-test classpath. */
public final class PCloudAccountStore {
    public static PCloudAccount synthetic;public PCloudAccountStore(android.content.Context context){}public PCloudAccount load(){return synthetic;}
}
