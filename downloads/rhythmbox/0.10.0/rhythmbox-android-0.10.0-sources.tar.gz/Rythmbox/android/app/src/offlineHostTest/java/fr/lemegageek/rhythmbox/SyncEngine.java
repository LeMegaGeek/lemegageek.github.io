package fr.lemegageek.rhythmbox;
/** Guard only: account-cache tests must never enter a shared link. */
public final class SyncEngine {
    public SyncEngine(org.json.JSONObject config){throw new AssertionError("Unexpected link origin");}
    public void validateConfig(){}public java.util.List<org.json.JSONObject> heads(){return null;}public void upload(org.json.JSONObject row){}public org.json.JSONArray importMedia(){return null;}public java.io.File mediaFile(long id,java.io.File cache){return null;}
}
