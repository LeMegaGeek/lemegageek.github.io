Spotify Android App Remote SDK 0.8.0
Official distribution: https://github.com/spotify/android-sdk/releases/tag/v0.8.0-appremote_v2.1.0-auth
Upstream repository LICENSE/NOTICE are reproduced in this folder (Apache-2.0). The binary SDK is fetched from the official release with a pinned SHA-256; Spotify service access separately requires the Spotify Developer Terms: https://developer.spotify.com/terms and policy: https://developer.spotify.com/policy .

Gson 2.11.0, Copyright 2008 Google Inc., Apache-2.0.
https://github.com/google/gson/tree/gson-parent-2.11.0

Rhythmbox application code retains its existing GPL-2.0-or-later license. This notice does not relicense the Spotify SDK or assert that its binary sources are included.
