package fr.lemegageek.rhythmbox;

public final class SunoBrowserProtocolTest {
    private static int checks;
    private interface Op {void run()throws Exception;}
    private static void yes(boolean condition,String why){checks++;if(!condition)throw new AssertionError(why);}
    private static void no(Op work,String why)throws Exception{boolean rejected=false;try{work.run();}catch(Exception expected){rejected=true;yes(!String.valueOf(expected.getMessage()).contains("SECRET"),"rejection does not echo external secrets");}yes(rejected,why);}
    public static void main(String[] args)throws Exception{
        String song="https://suno.com/song/11111111-1111-4111-8111-111111111111",playlist="https://suno.com/playlist/22222222-2222-4222-8222-222222222222";long now=1234567;
        yes(SunoBrowserProtocol.destination(SunoBrowserProtocol.Destination.SIGN_IN).equals("https://suno.com/me"),"official sign-in entry point");
        yes(SunoBrowserProtocol.destination(SunoBrowserProtocol.Destination.LIBRARY).equals("https://suno.com/me"),"library entry point");
        yes(SunoBrowserProtocol.destination(SunoBrowserProtocol.Destination.PLAYLISTS).equals("https://suno.com/me/playlists"),"playlist entry point");
        no(()->SunoBrowserProtocol.destination(null),"unknown destinations rejected");
        SunoBrowserProtocol.Ticket ticket=SunoBrowserProtocol.create(now);
        yes(ticket.nonce.matches("[A-Za-z0-9_-]{43}"),"256-bit random capability");
        yes(!ticket.nonce.equals(SunoBrowserProtocol.create(now).nonce),"fresh browser sessions use different capabilities");
        yes(!ticket.toString().contains(ticket.nonce),"capability not printed");
        no(()->ticket.consume("SECRET",song,now),"arbitrary external invocation rejected");
        no(()->ticket.consume(ticket.nonce,"https://suno.com/me?token=SECRET",now),"private account page is not a catalogue");
        yes(ticket.consume(ticket.nonce,song+"?si=SECRET#detail",now+1).equals(song),"explicit music selection strips tracking and fragment");
        no(()->ticket.consume(ticket.nonce,song,now+2),"valid return consumed exactly once");
        SunoBrowserProtocol.Ticket restored=SunoBrowserProtocol.restore(SunoBrowserProtocol.create(now).nonce,now);
        yes(restored.consume(restored.nonce,playlist,now+SunoBrowserProtocol.MAX_AGE_MILLIS).equals(playlist),"persisted state survives normal activity restart");
        SunoBrowserProtocol.Ticket expired=SunoBrowserProtocol.create(now);
        no(()->expired.consume(expired.nonce,song,now+SunoBrowserProtocol.MAX_AGE_MILLIS+1),"expired return rejected");
        no(()->expired.consume(expired.nonce,song,now),"expired ticket cannot revive after a clock reversal");
        SunoBrowserProtocol.Ticket future=SunoBrowserProtocol.create(now);
        no(()->future.consume(future.nonce,song,now-1),"clock reversal rejected");
        for(String input:new String[]{"https://evil.invalid/?next="+song,"https://suno.com.evil.invalid/song/11111111-1111-4111-8111-111111111111","https://SECRET@suno.com/song/11111111-1111-4111-8111-111111111111","https://suno.com:444/song/11111111-1111-4111-8111-111111111111","http://suno.com/song/11111111-1111-4111-8111-111111111111","javascript:SECRET",song+"/../private","https://suno.com/playlist/liked","https://accounts.google.com/SECRET",null})no(()->SunoBrowserProtocol.musicPage(input),"unrelated, authentication and private routes rejected");
        yes(SunoBrowserProtocol.musicPage("https://suno.com/s/ABCdef123").equals("https://suno.com/s/ABCdef123"),"official short share resolves through existing bounded resolver");
        yes(SunoBrowserProtocol.title("  A\nB\u202e  ",song).equals("AB"),"plain confirmation title strips controls");
        yes(SunoBrowserProtocol.title(null,playlist).equals("Playlist Suno"),"private page title not needed");
        yes(SunoBrowserProtocol.title(new String(new char[200]).replace('\0','a'),song).length()==120,"title bounded");
        no(()->SunoBrowserProtocol.restore("bad",now),"malformed persisted capability rejected");
        System.out.println("PASS: "+checks+" Suno browser capability/URI/title assertions; no browser, account or network");
    }
}
