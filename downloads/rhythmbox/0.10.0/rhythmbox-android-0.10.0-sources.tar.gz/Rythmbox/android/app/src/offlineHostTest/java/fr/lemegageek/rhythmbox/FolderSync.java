package fr.lemegageek.rhythmbox;
/** Guard only: account-cache tests must never enter another origin. */
public final class FolderSync {
    public FolderSync(android.content.Context context,org.json.JSONObject config){throw new AssertionError("Unexpected folder origin");}
    public void validateConfig(){}public java.util.List<org.json.JSONObject> heads(){return null;}public void upload(org.json.JSONObject row){}public org.json.JSONArray importMedia(){return null;}public java.io.File mediaFile(String path,java.io.File cache){return null;}
}
