package fr.lemegageek.rhythmbox;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;

/** Original-audio copies in Music/Rhythmbox, never arbitrary document trees.
 * API29+ uses new app-owned MediaStore rows and IS_PENDING; API26–28 uses the
 * app's external Music/Rhythmbox directory without a storage permission.
 * No existing file is overwritten or deleted. Resume is per completed file.
 */
public final class PCloudOfflineAudio {
    private static final Object SETTINGS_LOCK=new Object();private static final ReentrantLock RUN_LOCK=new ReentrantLock();
    private static final String MUSIC=Environment.DIRECTORY_MUSIC+"/Rhythmbox/";
    public static final class Cancellation {
        private final PCloudAudioCache.Cancellation network;
        public Cancellation(){this(()->true);}public Cancellation(java.util.function.BooleanSupplier active){network=new PCloudAudioCache.Cancellation(active);}
        public void cancel(){network.cancel();}public boolean isCancelled(){return network.isCancelled();}
        public void check() throws Cancelled {if(isCancelled()||Thread.currentThread().isInterrupted())throw new Cancelled();}
    }
    public static final class Cancelled extends java.io.IOException {Cancelled(){super("Copie audio interrompue ; les morceaux terminés sont conservés");}}
    public interface Progress {void update(String phase,int completed,int total,long bytes,long totalBytes);}
    public static final class Report {public final int copied,reused,skipped;public final long bytes;Report(int copied,int reused,int skipped,long bytes){this.copied=copied;this.reused=reused;this.skipped=skipped;this.bytes=bytes;}}
    private final Context context;private final ContentResolver resolver;private long lastProgressSaved;private String lastPhase="";
    public PCloudOfflineAudio(Context context){this.context=context.getApplicationContext();resolver=this.context.getContentResolver();}
    private static File settingsFile(Context context){return new File(context.getNoBackupFilesDir(),"pcloud-offline-audio-v1.json");}
    public static String folderDescription(){return Build.VERSION.SDK_INT>=29?"Music/Rhythmbox · arborescence des albums conservée":"Dossier Musique de l’application/Rhythmbox · Android 8–9";}
    public static JSONObject settings(Context context) throws Exception {synchronized(SETTINGS_LOCK){File file=settingsFile(context);if(!file.exists())return new JSONObject().put("schema",1).put("enabled",false).put("playlist_ids",new JSONArray()).put("entries",new JSONObject());
        if(file.length()>16L*1024*1024||Files.isSymbolicLink(file.toPath()))throw new java.io.IOException("Réglages hors ligne illisibles");JSONObject value=new JSONObject(new String(Files.readAllBytes(file.toPath()),StandardCharsets.UTF_8));if(value.getInt("schema")!=1||value.has("tree_uri"))throw new java.io.IOException("Réglages hors ligne incompatibles");return value;}}
    private static Set<String> selected(JSONObject value) throws Exception {JSONArray rows=value.getJSONArray("playlist_ids");if(rows.length()>1000)throw new IllegalArgumentException("Trop de listes hors ligne");Set<String> out=new HashSet<>();for(int i=0;i<rows.length();i++)if(!out.add(rows.getString(i)))throw new IllegalArgumentException("Sélection ambiguë");return out;}
    public static JSONArray availablePlaylists(Context context) throws Exception {PCloudAccount account=new PCloudAccountStore(context).load();return account==null?new JSONArray():PCloudOfflineSelection.available(account,new Library(context).state);}
    public static void configure(Context context,Set<String> playlistIds) throws Exception {
        PCloudAccount account=new PCloudAccountStore(context).load();if(account==null)throw new IllegalStateException("Connecte le compte musical pCloud");PCloudOfflineSelection.select(account,new Library(context).state,playlistIds);
        synchronized(SETTINGS_LOCK){JSONObject old=settings(context);boolean same=old.optLong("account_userid")==account.userid&&old.optLong("music_folderid")==account.musicFolderId&&account.region.equals(old.optString("account_region"));
            JSONObject next=new JSONObject().put("schema",1).put("enabled",true).put("account_userid",account.userid).put("account_region",account.region).put("music_folderid",account.musicFolderId).put("playlist_ids",new JSONArray(new java.util.TreeSet<>(playlistIds))).put("entries",same&&old.optJSONObject("entries")!=null?old.getJSONObject("entries"):new JSONObject());if(old.has("pending"))next.put("pending",old.getJSONObject("pending"));PCloudAudioCache.write(settingsFile(context),next);
        }
    }
    public static void disable(Context context) throws Exception {synchronized(SETTINGS_LOCK){JSONObject value=settings(context);value.put("enabled",false);PCloudAudioCache.write(settingsFile(context),value);}}
    private static String scope(JSONObject value) throws Exception {String region=value.getString("account_region");if(!"eu".equals(region)&&!"us".equals(region))throw new IllegalArgumentException("Région du compte hors ligne invalide");return value.optBoolean("enabled")+":"+region+":"+value.getLong("account_userid")+":"+value.getLong("music_folderid")+":"+new java.util.TreeSet<>(selected(value));}
    private boolean valid(PCloudAccount account,String scope,Cancellation cancellation){try{return !cancellation.isCancelled()&&PCloudAccount.sameAuthorization(account,new PCloudAccountStore(context).load())&&scope.equals(scope(settings(context)));}catch(Exception ignored){return false;}}
    private void check(PCloudAccount account,String scope,Cancellation cancellation) throws Exception {cancellation.check();if(!valid(account,scope,cancellation))throw new IllegalStateException("Le compte, le dossier musical ou les listes hors ligne ont changé ; relance la copie");}
    private void record(String expectedScope,String key,JSONObject row) throws Exception {synchronized(SETTINGS_LOCK){JSONObject current=settings(context);if(!expectedScope.equals(scope(current)))throw new IllegalStateException("Les réglages hors ligne ont changé pendant la copie");current.getJSONObject("entries").put(key,row);JSONObject pending=current.optJSONObject("pending");if(pending!=null&&pending.optString("operation_id").equals(row.optString("operation_id")))current.remove("pending");PCloudAudioCache.write(settingsFile(context),current);}}
    private void pending(String expectedScope,JSONObject row) throws Exception {synchronized(SETTINGS_LOCK){JSONObject current=settings(context);if(!expectedScope.equals(scope(current)))throw new IllegalStateException("Les réglages hors ligne ont changé pendant la copie");current.put("pending",row);PCloudAudioCache.write(settingsFile(context),current);}}
    private void clearPending(String operation) throws Exception {synchronized(SETTINGS_LOCK){JSONObject current=settings(context),pending=current.optJSONObject("pending");if(pending!=null&&operation.equals(pending.optString("operation_id"))){current.remove("pending");PCloudAudioCache.write(settingsFile(context),current);}}}
    private void progress(Progress callback,String phase,int completed,int total,long bytes,long totalBytes){long now=System.currentTimeMillis();if(!phase.equals(lastPhase)||now-lastProgressSaved>=1000||"completed".equals(phase)||"interrupted".equals(phase)){lastProgressSaved=now;lastPhase=phase;try{synchronized(SETTINGS_LOCK){JSONObject value=settings(context),status=value.optJSONObject("last_status");if(status==null)status=new JSONObject();if(!"interrupted".equals(phase)||!status.has("completed"))status.put("completed",completed).put("total",total).put("bytes",bytes).put("total_bytes",totalBytes);status.put("phase",phase).put("at_ms",now);value.put("last_status",status);PCloudAudioCache.write(settingsFile(context),value);}}catch(Exception ignored){}}if(callback!=null)try{callback.update(phase,completed,total,bytes,totalBytes);}catch(RuntimeException ignored){}}
    private void summary(int copied,int reused,int skipped,int unsupported) throws Exception {synchronized(SETTINGS_LOCK){JSONObject value=settings(context),status=value.optJSONObject("last_status");if(status==null)status=new JSONObject();status.put("copied",copied).put("reused",reused).put("skipped",skipped);if(unsupported>0)status.put("skipped_reason","Vidéos ou formats audio non attestés : conservés pour la lecture dans Rhythmbox, sans copie audio publique.");else status.remove("skipped_reason");value.put("last_status",status);PCloudAudioCache.write(settingsFile(context),value);}}
    private static String relativeDirectory(String path) throws Exception {String valid=FolderProtocol.mediaPath(path);int slash=valid.lastIndexOf('/');return MUSIC+(slash<0?"":valid.substring(0,slash+1));}
    private File fallbackRoot() throws Exception {File music=context.getExternalFilesDir(Environment.DIRECTORY_MUSIC);if(music==null)throw new java.io.IOException("Stockage musical du téléphone indisponible");File root=new File(music,"Rhythmbox");if(!root.isDirectory()&&!root.mkdirs())throw new java.io.IOException("Dossier musical indisponible");if(Files.isSymbolicLink(root.toPath()))throw new java.io.IOException("Dossier musical invalide");return root;}
    private File fallbackParent(String path) throws Exception {File current=fallbackRoot();String valid=FolderProtocol.mediaPath(path);int slash=valid.lastIndexOf('/');if(slash>=0)for(String part:valid.substring(0,slash).split("/")){current=new File(current,part);if(!current.isDirectory()&&!current.mkdir())throw new java.io.IOException("Un fichier occupe un dossier d’album ; aucun remplacement effectué");if(Files.isSymbolicLink(current.toPath()))throw new java.io.IOException("Dossier d’album symbolique refusé");}return current;}
    private File fallbackFile(JSONObject row) throws Exception {File root=fallbackRoot(),file=new File(root,FolderProtocol.mediaPath(row.getString("relative_file")));if(!file.getCanonicalFile().toPath().startsWith(root.getCanonicalFile().toPath())||Files.isSymbolicLink(file.toPath())||!Files.isRegularFile(file.toPath(),LinkOption.NOFOLLOW_LINKS))return null;return file;}
    private Uri mediaUri(JSONObject row) throws Exception {Uri uri=Uri.parse(row.getString("uri"));if(!"content".equals(uri.getScheme())||!MediaStore.AUTHORITY.equals(uri.getAuthority())||!uri.getPath().matches("/[a-z0-9_]+/audio/media/[1-9][0-9]*"))throw new IllegalArgumentException("Copie musicale hors de MediaStore");return uri;}
    private boolean mediaOwned(JSONObject row,boolean pending) throws Exception {
        Uri uri=mediaUri(row);String[] columns={MediaStore.MediaColumns.DISPLAY_NAME,MediaStore.MediaColumns.RELATIVE_PATH,MediaStore.MediaColumns.OWNER_PACKAGE_NAME,MediaStore.MediaColumns.IS_PENDING,MediaStore.MediaColumns.SIZE};
        String relative=validatedRelative(row.getString("relative_path"));
        try(Cursor cursor=resolver.query(uri,columns,null,null,null)){if(cursor==null)throw new java.io.IOException("Stockage musical Android indisponible ; la reprise de la copie reste enregistrée");return cursor.moveToFirst()&&(pending||row.getString("name").equals(cursor.getString(0)))&&relative.equals(cursor.getString(1))&&context.getPackageName().equals(cursor.getString(2))&&(cursor.getInt(3)!=0)==pending&&(pending||cursor.isNull(4)||cursor.getLong(4)==row.getLong("size"));}
    }
    private InputStream open(JSONObject row,boolean pending) throws Exception {
        if("mediastore".equals(row.optString("storage"))){if(Build.VERSION.SDK_INT<29||!mediaOwned(row,pending))return null;return resolver.openInputStream(mediaUri(row));}
        if(!"app-music".equals(row.optString("storage")))return null;File file=fallbackFile(row);return file==null?null:new FileInputStream(file);
    }
    private boolean matches(JSONObject row,Cancellation cancellation,boolean pending) throws Exception {
        MessageDigest digest=MessageDigest.getInstance("SHA-256");long bytes=0;try(InputStream input=open(row,pending)){if(input==null)return false;byte[] block=new byte[65536];int n;while((n=input.read(block))!=-1){cancellation.check();bytes+=n;if(bytes>row.getLong("size"))return false;digest.update(block,0,n);}}return bytes==row.getLong("size")&&PCloudAudioCache.hex(digest.digest()).equals(row.getString("sha256"));
    }
    private static String validatedRelative(String relative) {if(!relative.startsWith(MUSIC)||!relative.endsWith("/"))throw new IllegalArgumentException("Dossier musical Android invalide");FolderProtocol.mediaPath(relative.substring(0,relative.length()-1));return relative;}
    private String mediaName(Uri uri) throws Exception {try(Cursor cursor=resolver.query(uri,new String[]{MediaStore.MediaColumns.DISPLAY_NAME},null,null,null)){if(cursor==null||!cursor.moveToFirst())throw new java.io.IOException("Copie Android nouvellement créée introuvable");return cursor.getString(0);}}
    private String unusedMediaName(String original,String relative) throws Exception {
        Set<String> occupied=new HashSet<>();Uri collection=MediaStore.setIncludePending(MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY));
        try(Cursor cursor=resolver.query(collection,new String[]{MediaStore.MediaColumns.DISPLAY_NAME},MediaStore.MediaColumns.RELATIVE_PATH+"=?",new String[]{validatedRelative(relative)},null)){if(cursor==null)throw new java.io.IOException("Les noms du dossier musical ne peuvent pas être vérifiés");if(cursor.moveToFirst())do{occupied.add(cursor.getString(0));}while(cursor.moveToNext());}
        String name=original;for(int number=2;occupied.contains(name);number++)name=PCloudOfflineSelection.alternateName(original,number);return name;
    }
    static String audioMime(JSONObject metadata){String value=metadata.optString("contenttype","").split(";",2)[0].trim();if(value.matches("(?i)audio/[a-z0-9!#$&^_.+\\-]+"))return value;if(value.toLowerCase(java.util.Locale.ROOT).startsWith("video/"))return null;String name=metadata.optString("name").toLowerCase(java.util.Locale.ROOT);if(name.endsWith(".mp3"))return "audio/mpeg";if(name.endsWith(".flac"))return "audio/flac";if(name.endsWith(".m4a"))return "audio/mp4";if(name.endsWith(".aac"))return "audio/aac";if(name.endsWith(".ogg")||name.endsWith(".oga")||name.endsWith(".opus"))return "audio/ogg";if(name.endsWith(".wav"))return "audio/wav";if(name.endsWith(".wma"))return "audio/x-ms-wma";if(name.endsWith(".aif")||name.endsWith(".aiff"))return "audio/aiff";if(name.endsWith(".alac"))return "audio/alac";return null;}
    private void recoverPending(Cancellation cancellation) throws Exception {
        cancellation.check();JSONObject config=settings(context),row=config.optJSONObject("pending");if(row==null)return;String operation=row.getString("operation_id");UUID.fromString(operation);
        if("mediastore".equals(row.optString("storage"))&&Build.VERSION.SDK_INT>=29){
            if(!row.has("uri")){
                // The durable intent precedes insert: recover the narrow
                // insert→receipt crash window by its unpredictable own name.
                String name=row.getString("intent_name"),relative=validatedRelative(row.getString("relative_path"));if(!name.matches("\\.rhythmbox-"+operation+"\\.[A-Za-z0-9]{1,12}"))throw new java.io.IOException("Intent de copie interrompue invalide");
                Uri collection=MediaStore.setIncludePending(MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY));try(Cursor cursor=resolver.query(collection,new String[]{MediaStore.MediaColumns._ID},MediaStore.MediaColumns.DISPLAY_NAME+"=? AND "+MediaStore.MediaColumns.RELATIVE_PATH+"=? AND "+MediaStore.MediaColumns.OWNER_PACKAGE_NAME+"=? AND "+MediaStore.MediaColumns.IS_PENDING+"=1",new String[]{name,relative,context.getPackageName()},null)){if(cursor==null)throw new java.io.IOException("Stockage musical Android indisponible ; la reprise de la copie reste enregistrée");if(cursor.moveToFirst()){long id=cursor.getLong(0);if(cursor.moveToNext())throw new java.io.IOException("Intent de copie ambigu");row.put("uri",android.content.ContentUris.withAppendedId(MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY),id).toString());}}
            }
            if(row.has("uri")&&mediaOwned(row,true)){cancellation.check();if(resolver.delete(mediaUri(row),null,null)!=1)throw new java.io.IOException("Impossible de reprendre la copie audio interrompue");}
            else if(row.has("uri")&&row.has("sha256")&&matches(row,cancellation,false)&&row.optString("scope").equals(scope(config))){record(scope(config),row.getString("key"),row);return;}
        }else if("app-music".equals(row.optString("storage"))){
            String temporary=row.optString("partial_relative");if(!temporary.isEmpty()){File file=fallbackFile(new JSONObject().put("relative_file",temporary));if(file!=null&&file.getName().equals(".rhythmbox-"+operation+".partial")){cancellation.check();if(!file.delete())throw new java.io.IOException("Impossible de reprendre la copie temporaire");}}
            if(row.has("relative_file")&&row.has("sha256")&&matches(row,cancellation,false)&&row.optString("scope").equals(scope(config))){record(scope(config),row.getString("key"),row);return;}
        }clearPending(operation);
    }
    private JSONObject export(File file,JSONObject track,JSONObject metadata,PCloudAccount account,String pinnedScope,Cancellation cancellation,Progress callback,int completed,int total) throws Exception {
        String path=FolderProtocol.mediaPath(track.getString("media_path")),original=FolderProtocol.mediaPath(metadata.getString("name")),name=original,relative=relativeDirectory(path),operation=UUID.randomUUID().toString(),mime=audioMime(metadata);if(mime==null)throw new IllegalArgumentException("Cette vidéo ou ce format non attesté reste disponible pour la lecture, sans copie dans le dossier audio public");if(original.indexOf('/')>=0||!path.substring(path.lastIndexOf('/')+1).equals(original))throw new IllegalArgumentException("Nom du morceau musical incohérent");
        JSONObject row=new JSONObject().put("operation_id",operation).put("scope",pinnedScope).put("key",PCloudAudioCache.sha256(PCloudAudioCache.identity(account,track))).put("size",file.length()).put("version",PCloudAudioCache.version(metadata)).put("identity",PCloudAudioCache.identity(account,track)).put("metadata",metadata);Uri inserted=null;File pendingFile=null;boolean published=false,insertAttempted=false;
        try{
            OutputStream stream;
            if(Build.VERSION.SDK_INT>=29){String extension=original.lastIndexOf('.')>=0?original.substring(original.lastIndexOf('.')):".audio";if(!extension.matches("\\.[A-Za-z0-9]{1,12}"))extension=".audio";name=".rhythmbox-"+operation+extension;row.put("storage","mediastore").put("name",name).put("intent_name",name).put("relative_path",relative);pending(pinnedScope,row);
                ContentValues values=new ContentValues();values.put(MediaStore.MediaColumns.DISPLAY_NAME,name);values.put(MediaStore.MediaColumns.MIME_TYPE,mime);values.put(MediaStore.MediaColumns.RELATIVE_PATH,relative);values.put(MediaStore.MediaColumns.IS_PENDING,1);
                insertAttempted=true;inserted=resolver.insert(MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY),values);if(inserted==null)throw new java.io.IOException("Android n’a pas pu créer la copie musicale");row.put("uri",inserted.toString()).put("name",mediaName(inserted));pending(pinnedScope,row);if(!mediaOwned(row,true))throw new java.io.IOException("La copie Android est hors du dossier musical prévu");stream=resolver.openOutputStream(inserted,"w");
            }else{File parent=fallbackParent(path);pendingFile=new File(parent,".rhythmbox-"+operation+".partial");String temporary=fallbackRoot().toPath().relativize(pendingFile.toPath()).toString().replace(File.separatorChar,'/');row.put("storage","app-music").put("partial_relative",temporary);pending(pinnedScope,row);if(!pendingFile.createNewFile()){pendingFile=null;throw new java.io.IOException("Copie temporaire indisponible");}stream=new FileOutputStream(pendingFile);}
            MessageDigest digest=MessageDigest.getInstance("SHA-256");long bytes=0;try(InputStream input=new FileInputStream(file);OutputStream output=stream){if(output==null)throw new java.io.IOException("Dossier musical en lecture seule");byte[] block=new byte[65536];int n;while((n=input.read(block))!=-1){check(account,pinnedScope,cancellation);bytes+=n;if(bytes>file.length())throw new java.io.IOException("Le fichier musical a changé");output.write(block,0,n);digest.update(block,0,n);progress(callback,"copying",completed,total,bytes,file.length());}output.flush();}if(bytes!=file.length())throw new java.io.IOException("La copie audio est incomplète");row.put("sha256",PCloudAudioCache.hex(digest.digest()));check(account,pinnedScope,cancellation);
            if(Build.VERSION.SDK_INT>=29){if(!matches(row,cancellation,true))throw new java.io.IOException("La vérification du fichier Android a échoué");pending(pinnedScope,row);ContentValues display=new ContentValues();display.put(MediaStore.MediaColumns.DISPLAY_NAME,unusedMediaName(original,relative));if(resolver.update(inserted,display,null,null)!=1)throw new java.io.IOException("Android n’a pas pu nommer la copie musicale");row.put("name",mediaName(inserted));pending(pinnedScope,row);ContentValues ready=new ContentValues();ready.put(MediaStore.MediaColumns.IS_PENDING,0);check(account,pinnedScope,cancellation);if(!mediaOwned(row,true)||resolver.update(inserted,ready,null,null)!=1)throw new java.io.IOException("Android n’a pas pu terminer la copie musicale");published=true;
            }else{row.put("relative_file",row.getString("partial_relative"));if(!matches(row,cancellation,false))throw new java.io.IOException("La vérification du fichier Android a échoué");File parent=pendingFile.getParentFile(),destination=new File(parent,name);for(int number=2;Files.exists(destination.toPath(),LinkOption.NOFOLLOW_LINKS);number++){name=PCloudOfflineSelection.alternateName(original,number);destination=new File(parent,name);}String relativeFile=fallbackRoot().toPath().relativize(destination.toPath()).toString().replace(File.separatorChar,'/');row.put("relative_file",relativeFile).put("name",name);pending(pinnedScope,row);check(account,pinnedScope,cancellation);Files.move(pendingFile.toPath(),destination.toPath());pendingFile=null;published=true;}
            return row;
        }finally{
            // Only an unpublished row created by this invocation is eligible
            // for cleanup. Old receipts, user files and published audio stay.
            boolean cleaned=false;if(!published&&inserted!=null&&Build.VERSION.SDK_INT>=29)try{if(mediaOwned(row,true))cleaned=resolver.delete(inserted,null,null)==1;}catch(Exception ignored){}
            if(pendingFile!=null)cleaned=pendingFile.delete();if(!published&&(cleaned||!insertAttempted&&pendingFile==null))try{clearPending(operation);}catch(Exception ignored){}
        }
    }
    public Report sync(Cancellation cancellation,Progress callback) throws Exception {
        if(cancellation==null)throw new IllegalArgumentException("Annulation requise");if(!RUN_LOCK.tryLock())throw new IllegalStateException("Une copie audio hors ligne est déjà en cours");
        try{
            recoverPending(cancellation);
            JSONObject config=settings(context);if(!config.optBoolean("enabled"))throw new IllegalStateException("Choisis les listes à conserver sur le téléphone");String pinnedScope=scope(config);PCloudAccount account=new PCloudAccountStore(context).load();if(account==null||account.userid!=config.optLong("account_userid")||account.musicFolderId!=config.optLong("music_folderid")||!account.region.equals(config.optString("account_region")))throw new IllegalStateException("Reconnecte le compte et le dossier musical associés aux copies hors ligne");
            Library library=new Library(context);PCloudOfflineSelection.Selection selection=PCloudOfflineSelection.select(account,library.state,selected(config));String fingerprint=library.fingerprint();PCloudAudioCache cache=new PCloudAudioCache(new File(context.getNoBackupFilesDir(),"pcloud-audio-v1"));
            PCloudCollections client=new PCloudCollections(account,java.util.Collections.emptySet(),java.util.Collections.emptySet());client.setRequestGuard(()->valid(account,pinnedScope,cancellation));client.setIndexObserver(index->cache.observeIndex(account,index));summary(0,0,selection.skipped,0);progress(callback,"connecting",0,selection.tracks.length(),0,0);client.verifyAccount();Map<Long,JSONObject> index=client.indexMusic();int copied=0,reused=0,unsupported=0,total=selection.tracks.length();long written=0,plannedBytes=0;for(int i=0;i<total;i++){JSONObject row=index.get(selection.tracks.getJSONObject(i).getLong("pcloud_fileid"));if(row!=null&&audioMime(row)!=null)plannedBytes+=row.getLong("size");}progress(callback,"planning",0,total,0,plannedBytes);
            for(int i=0;i<total;i++){
                check(account,pinnedScope,cancellation);if(!java.util.Objects.equals(fingerprint,library.currentFingerprint()))throw new IllegalStateException("Les listes ont changé pendant la copie ; relance pour reprendre les fichiers restants");JSONObject track=selection.tracks.getJSONObject(i);JSONObject metadata=index.get(track.getLong("pcloud_fileid"));if(metadata==null||!metadata.getString("media_path").equals(track.getString("media_path")))throw new IllegalStateException("Un morceau n’appartient plus au dossier musical choisi ; actualise les listes");
                if(audioMime(metadata)==null){unsupported++;summary(copied,reused,selection.skipped+unsupported,unsupported);progress(callback,"copying",i+1,total,written,plannedBytes);continue;}
                String key=PCloudAudioCache.sha256(PCloudAudioCache.identity(account,track));JSONObject prior=config.getJSONObject("entries").optJSONObject(key);if(prior!=null&&PCloudAudioCache.version(metadata).equals(prior.optString("version"))&&matches(prior,cancellation,false)){reused++;progress(callback,"copying",i+1,total,written,0);continue;}
                final int completed=i;progress(callback,"downloading",i,total,0,metadata.getLong("size"));File file;try(java.io.Closeable lock=cache.lockDownload(account,track,cancellation.network)){file=cache.findVersion(account,track,metadata);if(file==null){PCloudCollections.DownloadedMedia downloaded=client.downloadedMedia(track,cache.directory(),(done,size)->progress(callback,"downloading",completed,total,done,size),cancellation.network);file=downloaded.file;metadata=downloaded.metadata;cache.remember(account,track,file,metadata);}}
                check(account,pinnedScope,cancellation);if(audioMime(metadata)==null){unsupported++;summary(copied,reused,selection.skipped+unsupported,unsupported);continue;}JSONObject row=export(file,track,metadata,account,pinnedScope,cancellation,callback,i,total);check(account,pinnedScope,cancellation);record(pinnedScope,key,row);config.getJSONObject("entries").put(key,row);copied++;written+=file.length();progress(callback,"copying",i+1,total,written,0);
            }summary(copied,reused,selection.skipped+unsupported,unsupported);progress(callback,"completed",total,total,written,written);return new Report(copied,reused,selection.skipped+unsupported,written);
        }catch(Exception failure){progress(callback,"interrupted",0,0,0,0);throw failure;}finally{RUN_LOCK.unlock();}
    }
    public File cachedFile(PCloudAccount account,JSONObject track,PCloudAudioCache cache,Cancellation cancellation) throws Exception {
        JSONObject config=settings(context);if(!config.optBoolean("enabled")||account.userid!=config.optLong("account_userid")||account.musicFolderId!=config.optLong("music_folderid")||!account.region.equals(config.optString("account_region")))return null;String pinnedScope=scope(config);PCloudAudioCache.identity(account,track);PCloudOfflineSelection.Selection selection=PCloudOfflineSelection.select(account,new Library(context).state,selected(config));boolean chosen=false;for(int i=0;i<selection.tracks.length();i++)if(PCloudAudioCache.identity(account,selection.tracks.getJSONObject(i)).equals(PCloudAudioCache.identity(account,track)))chosen=true;if(!chosen)return null;
        JSONObject row=config.getJSONObject("entries").optJSONObject(PCloudAudioCache.sha256(PCloudAudioCache.identity(account,track)));if(row==null||!PCloudAudioCache.identity(account,track).equals(row.optString("identity")))return null;JSONObject metadata=row.getJSONObject("metadata");
        // The private-cache registry must also accept this exported revision;
        // a freshly observed removal/replacement never revives an old copy.
        if(!cache.acceptsVersion(account,track,metadata))return null;
        File output=new File(cache.directory(),PCloudCollections.cacheName(metadata,account)),partial=new File(cache.directory(),output.getName()+"-"+UUID.randomUUID()+".partial");boolean success=false;
        try(InputStream input=open(row,false);FileOutputStream sink=new FileOutputStream(partial)){if(input==null)return null;MessageDigest digest=MessageDigest.getInstance("SHA-256");byte[] block=new byte[65536];long bytes=0;int n;while((n=input.read(block))!=-1){check(account,pinnedScope,cancellation);bytes+=n;if(bytes>row.getLong("size"))return null;sink.write(block,0,n);digest.update(block,0,n);}if(bytes!=row.getLong("size")||!row.getString("sha256").equals(PCloudAudioCache.hex(digest.digest())))return null;sink.getFD().sync();check(account,pinnedScope,cancellation);if(!partial.renameTo(output))throw new java.io.IOException("Cache musical indisponible");cache.remember(account,track,output,metadata);success=true;return output;}finally{if(!success)partial.delete();}
    }
}
