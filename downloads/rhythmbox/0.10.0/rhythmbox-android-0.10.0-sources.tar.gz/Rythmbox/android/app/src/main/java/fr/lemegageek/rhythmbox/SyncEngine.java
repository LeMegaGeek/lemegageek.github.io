package fr.lemegageek.rhythmbox;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Only three unauthenticated, capability-scoped pCloud methods exist here. */
public final class SyncEngine {
    private final JSONObject config;
    private final String host;
    private Map<Long,JSONObject> media = new LinkedHashMap<>();
    public SyncEngine(JSONObject config) throws Exception {
        this.config = config;
        String region=config.optString("region","eu");
        if (!region.equals("eu") && !region.equals("us")) throw new IllegalArgumentException("Région invalide");
        host=region.equals("eu")?"eapi.pcloud.com":"api.pcloud.com";
    }
    public static String code(String input) throws Exception {
        String result = input.trim();
        if(result.startsWith("https://")) {
            URL url = new URL(result); String h=url.getHost().toLowerCase(java.util.Locale.ROOT);
            if(!(h.equals("pcloud.link") || h.endsWith(".pcloud.link") || h.equals("pcloud.com") || h.endsWith(".pcloud.com")) || url.getUserInfo()!=null || url.getPort()!=-1)
                throw new IllegalArgumentException("Le lien doit appartenir à pCloud");
            String q=url.getQuery(), fragment=url.getRef(); result="";
            if(q!=null) for(String item:q.split("&")) if(item.startsWith("code=")) result=java.net.URLDecoder.decode(item.substring(5),"UTF-8");
            if(result.isEmpty() && fragment!=null) for(String item:fragment.split("&")) if(item.startsWith("code=")) result=java.net.URLDecoder.decode(item.substring(5),"UTF-8");
        }
        if(!result.matches("[A-Za-z0-9_-]{5,256}")) throw new IllegalArgumentException("Code de lien pCloud invalide");
        return result;
    }
    private String configuredCode(String field) throws Exception { return code(config.getString(field)); }
    private byte[] key() throws Exception {
        String encoded=config.getString("key");
        if(!encoded.matches("[A-Za-z0-9+/]{43}=")) throw new IllegalArgumentException("Clé Base64 invalide");
        byte[] key=java.util.Base64.getDecoder().decode(encoded);
        if(key.length!=32) throw new IllegalArgumentException("La clé partagée doit contenir 32 octets"); return key;
    }
    public void validateConfig() throws Exception { configuredCode("read_code"); configuredCode("upload_code"); if(!config.optString("media_code","").isEmpty())configuredCode("media_code"); key(); }
    private String mediaCapability() throws Exception { if(config.optString("media_code","").isEmpty())throw new IllegalStateException("Ajoute un lien musique dans les réglages pour importer ou écouter");return configuredCode("media_code"); }
    private static HttpURLConnection connection(URL url) throws Exception {
        if(!url.getProtocol().equals("https") || url.getUserInfo()!=null || url.getPort()!=-1)
            throw new IllegalArgumentException("Adresse distante refusée");
        HttpURLConnection connection=(HttpURLConnection)url.openConnection();
        connection.setInstanceFollowRedirects(false); connection.setConnectTimeout(15000); connection.setReadTimeout(30000);
        connection.setRequestProperty("User-Agent","RhythmboxCompanion/0.1"); return connection;
    }
    private static byte[] read(HttpURLConnection connection, int limit) throws Exception {
        int status=connection.getResponseCode();
        if(status!=200) throw new IllegalStateException("pCloud : réponse HTTP " + status);
        if(connection.getContentLengthLong()>limit) throw new IllegalArgumentException("Réponse pCloud trop volumineuse");
        try(InputStream in=connection.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] buffer=new byte[16384]; int count;
            while((count=in.read(buffer))!=-1) { if(out.size()+count>limit) throw new IllegalArgumentException("Réponse trop volumineuse"); out.write(buffer,0,count); }
            return out.toByteArray();
        } finally { connection.disconnect(); }
    }
    private JSONObject api(String method, Map<String,String> params) throws Exception {
        if(!java.util.Arrays.asList("showpublink","getpublinkdownload").contains(method)) throw new IllegalArgumentException("Méthode interdite");
        StringBuilder query=new StringBuilder();
        for(Map.Entry<String,String> item:params.entrySet()) {
            if(query.length()>0) query.append('&'); query.append(item.getKey()).append('=').append(URLEncoder.encode(item.getValue(),"UTF-8"));
        }
        JSONObject result=new JSONObject(new String(read(connection(new URL("https://"+host+"/"+method+"?"+query)),8*1024*1024),StandardCharsets.UTF_8));
        if(result.optInt("result",-1)!=0) throw new IllegalStateException("pCloud : erreur " + result.optInt("result",-1)); return result;
    }
    private static void walk(JSONObject node, Map<Long,JSONObject> files, int depth) throws Exception {
        if(depth>32 || files.size()>50000) throw new IllegalArgumentException("Dossier partagé trop volumineux");
        if(!node.optBoolean("isfolder",false) && node.optLong("fileid",0)>0) files.put(node.getLong("fileid"),node);
        JSONArray children=node.optJSONArray("contents"); if(children!=null) for(int i=0;i<children.length();i++) walk(children.getJSONObject(i),files,depth+1);
    }
    private Map<Long,JSONObject> listing(String capability) throws Exception {
        JSONObject response=api("showpublink",java.util.Collections.singletonMap("code",capability));
        Map<Long,JSONObject> files=new LinkedHashMap<>(); walk(response.getJSONObject("metadata"),files,0); return files;
    }
    private URL downloadUrl(String capability,long id,Map<Long,JSONObject> membership) throws Exception {
        if(!membership.containsKey(id)) throw new IllegalArgumentException("Le titre n’appartient pas au partage autorisé");
        Map<String,String> params=new LinkedHashMap<>(); params.put("code",capability); params.put("fileid",Long.toString(id));
        JSONObject result=api("getpublinkdownload",params);
        String cdn=result.getJSONArray("hosts").getString(0),path=result.getString("path");
        return validatedDownload(cdn,path);
    }
    static URL validatedDownload(String cdn,String path) throws Exception {
        if(!cdn.matches("[A-Za-z0-9.-]+\\.pcloud\\.com") || !path.startsWith("/") || path.startsWith("//") || path.indexOf('\\')>=0 || path.indexOf('\r')>=0 || path.indexOf('\n')>=0 || path.indexOf('#')>=0)
            throw new IllegalArgumentException("Serveur de téléchargement refusé");
        URL resultUrl=new URL("https://"+cdn+path);
        if(!resultUrl.getHost().equalsIgnoreCase(cdn) || resultUrl.getUserInfo()!=null || resultUrl.getPort()!=-1) throw new IllegalArgumentException("Adresse média refusée");
        return resultUrl;
    }
    public List<JSONObject> heads() throws Exception {
        String readCode=configuredCode("read_code"); Map<Long,JSONObject> files=listing(readCode);
        Map<String,JSONObject> snapshots=new LinkedHashMap<>(); int count=0;
        for(Map.Entry<Long,JSONObject> item:files.entrySet()) {
            String name=item.getValue().optString("name");
            if(!name.matches("rb-sync-[0-9a-fA-F-]{36}\\.rbx")) continue;
            if(++count>1000) throw new IllegalArgumentException("Plus de 1000 révisions : archivage manuel nécessaire");
            byte[] envelope=read(connection(downloadUrl(readCode,item.getKey(),files)),8*1024*1024);
            JSONObject snapshot=new JSONObject(new String(Crypto.open(key(),envelope),StandardCharsets.UTF_8)); Library.validate(snapshot);
            if(!name.equals("rb-sync-"+snapshot.getString("id")+".rbx")) throw new IllegalArgumentException("Identité de révision incohérente");
            addSnapshot(snapshots,snapshot);
        }
        return historyHeads(snapshots);
    }
    static void addSnapshot(Map<String,JSONObject> snapshots,JSONObject snapshot) throws Exception {
        String id=snapshot.getString("id");
        if(snapshots.containsKey(id) && !canonical(snapshots.get(id)).equals(canonical(snapshot))) throw new IllegalArgumentException("Deux révisions divergentes portent le même identifiant");
        snapshots.put(id,snapshot);
    }
    static List<JSONObject> historyHeads(Map<String,JSONObject> snapshots) throws Exception {
        Set<String> parentIds=new HashSet<>();
        for(JSONObject snapshot:snapshots.values()){JSONArray parents=snapshot.getJSONArray("parents");for(int i=0;i<parents.length();i++)parentIds.add(parents.getString(i));}
        Set<String> done=new HashSet<>();for(String id:snapshots.keySet()) visit(id,snapshots,new HashSet<>(),done);
        List<JSONObject> heads=new ArrayList<>(); for(Map.Entry<String,JSONObject> item:snapshots.entrySet()) if(!parentIds.contains(item.getKey())) heads.add(item.getValue());
        if(!snapshots.isEmpty() && heads.isEmpty()) throw new IllegalArgumentException("Historique cyclique invalide"); return heads;
    }
    private static void visit(String id,Map<String,JSONObject> snapshots,Set<String> active,Set<String> done) throws Exception {
        if(done.contains(id) || !snapshots.containsKey(id)) return;
        if(!active.add(id)) throw new IllegalArgumentException("Historique de révisions cyclique");
        JSONArray parents=snapshots.get(id).getJSONArray("parents");for(int i=0;i<parents.length();i++)visit(parents.getString(i),snapshots,active,done);
        active.remove(id);done.add(id);
    }
    private static String canonical(Object value) throws Exception {
        if(value instanceof JSONObject){JSONObject object=(JSONObject)value;java.util.TreeSet<String> keys=new java.util.TreeSet<>();java.util.Iterator<String> iterator=object.keys();while(iterator.hasNext())keys.add(iterator.next());StringBuilder out=new StringBuilder("{");for(String name:keys){if(out.length()>1)out.append(',');out.append(JSONObject.quote(name)).append(':').append(canonical(object.get(name)));}return out.append('}').toString();}
        if(value instanceof JSONArray){JSONArray array=(JSONArray)value;StringBuilder out=new StringBuilder("[");for(int i=0;i<array.length();i++){if(i>0)out.append(',');out.append(canonical(array.get(i)));}return out.append(']').toString();}
        if(value instanceof String)return JSONObject.quote((String)value);return String.valueOf(value);
    }
    public void upload(JSONObject snapshot) throws Exception {
        Library.validate(snapshot); byte[] payload=Crypto.seal(key(),snapshot.toString().getBytes(StandardCharsets.UTF_8));
        if(payload.length>8*1024*1024) throw new IllegalArgumentException("Bibliothèque trop volumineuse");
        String boundary="rbx"+java.util.UUID.randomUUID().toString().replace("-","");
        HttpURLConnection connection=connection(new URL("https://"+host+"/uploadtolink?code="+configuredCode("upload_code")+"&nopartial=1"));
        connection.setRequestMethod("POST"); connection.setDoOutput(true); connection.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
        byte[] prefix=("--"+boundary+"\r\nContent-Disposition: form-data; name=\"file\"; filename=\"rb-sync-"+snapshot.getString("id")+".rbx\"\r\nContent-Type: application/octet-stream\r\n\r\n").getBytes(StandardCharsets.US_ASCII);
        byte[] suffix=("\r\n--"+boundary+"--\r\n").getBytes(StandardCharsets.US_ASCII);
        connection.setFixedLengthStreamingMode(prefix.length+payload.length+suffix.length);
        try(java.io.OutputStream out=connection.getOutputStream()) { out.write(prefix); out.write(payload); out.write(suffix); }
        JSONObject response=new JSONObject(new String(read(connection,1024*1024),StandardCharsets.UTF_8));
        if(response.optInt("result",-1)!=0) throw new IllegalStateException("Dépôt pCloud refusé : "+response.optInt("result",-1));
    }
    public JSONArray importMedia() throws Exception {
        media=listing(mediaCapability()); JSONArray result=new JSONArray();
        for(Map.Entry<Long,JSONObject> item:media.entrySet()) {
            JSONObject source=item.getValue();
            if(source.optInt("category")!=3 && !FolderProtocol.isSupportedMedia(source.optString("name"),source.optString("contenttype"))) continue;
            result.put(new JSONObject().put("id","pcloud:"+item.getKey()).put("title",source.optString("title",source.optString("name","Sans titre")))
                .put("artist",source.optString("artist","")).put("album",source.optString("album","")).put("pcloud_fileid",item.getKey()));
        }
        return result;
    }
    public File mediaFile(long id, File cacheDir) throws Exception {
        String capability=mediaCapability(); Map<Long,JSONObject> files=listing(capability);
        URL url=downloadUrl(capability,id,files); // Membership checked anew, including for cached files.
        File output=new File(cacheDir,"audio-"+id+".cache");
        for(File old:cacheDir.listFiles()) if(old.getName().startsWith("audio-") && !old.equals(output)) old.delete();
        if(output.exists()) return output;
        HttpURLConnection connection=connection(url); int status=connection.getResponseCode();
        if(status!=200) { connection.disconnect(); throw new IllegalStateException("Téléchargement audio : HTTP "+status); }
        final long limit=256L*1024*1024;
        if(connection.getContentLengthLong()>limit) { connection.disconnect(); throw new IllegalArgumentException("Morceau supérieur à 256 Mio"); }
        File temp=new File(cacheDir,output.getName()+".partial"); boolean success=false;
        try(InputStream in=connection.getInputStream(); FileOutputStream out=new FileOutputStream(temp)) {
            byte[] buffer=new byte[65536]; long total=0; int size;
            while((size=in.read(buffer))!=-1) { total+=size; if(total>limit) throw new IllegalArgumentException("Morceau trop volumineux"); out.write(buffer,0,size); }
            out.getFD().sync(); success=true;
        } finally { connection.disconnect(); if(!success) temp.delete(); }
        if(!temp.renameTo(output)) { temp.delete(); throw new IllegalStateException("Cache audio indisponible"); } return output;
    }
}
