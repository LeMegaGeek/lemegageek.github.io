package fr.lemegageek.rhythmbox;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Reinstates only an explicitly enabled account-bound periodic job. */
public final class PCloudSyncBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent){String action=intent==null?null:intent.getAction();if(!Intent.ACTION_BOOT_COMPLETED.equals(action)&&!Intent.ACTION_MY_PACKAGE_REPLACED.equals(action))return;try{PCloudSyncController.schedule(context);}catch(Exception ignored){PCloudSyncController.cancelJob(context);}}
}
