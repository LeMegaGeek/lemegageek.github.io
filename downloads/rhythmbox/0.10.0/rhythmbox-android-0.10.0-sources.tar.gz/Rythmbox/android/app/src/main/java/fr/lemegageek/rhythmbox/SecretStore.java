package fr.lemegageek.rhythmbox;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import org.json.JSONObject;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Secrets are app-private, backup-disabled and encrypted by a non-exportable Android Keystore key. */
public final class SecretStore {
    private final String alias;
    private final File file;
    public SecretStore(Context context) { this(context, "rhythmbox.capabilities.v1", "capabilities.enc"); }
    SecretStore(Context context, String alias, String filename) {
        this.alias = alias;
        this.file = new File(context.getNoBackupFilesDir(), filename);
    }
    private SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore"); store.load(null);
        if (!store.containsAlias(alias)) {
            KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build());
            generator.generateKey();
        }
        return (SecretKey) store.getKey(alias, null);
    }
    public JSONObject load() throws Exception {
        if (!file.exists()) return new JSONObject();
        JSONObject record = new JSONObject(new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8));
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(record.getString("iv"), Base64.NO_WRAP)));
        cipher.updateAAD(alias.getBytes(StandardCharsets.US_ASCII));
        return new JSONObject(new String(cipher.doFinal(Base64.decode(record.getString("data"), Base64.NO_WRAP)), StandardCharsets.UTF_8));
    }
    public void save(JSONObject values) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, key());
        cipher.updateAAD(alias.getBytes(StandardCharsets.US_ASCII));
        JSONObject record = new JSONObject().put("iv", Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP))
            .put("data", Base64.encodeToString(cipher.doFinal(values.toString().getBytes(StandardCharsets.UTF_8)), Base64.NO_WRAP));
        Library.writeAtomic(file, record.toString());
    }
}
