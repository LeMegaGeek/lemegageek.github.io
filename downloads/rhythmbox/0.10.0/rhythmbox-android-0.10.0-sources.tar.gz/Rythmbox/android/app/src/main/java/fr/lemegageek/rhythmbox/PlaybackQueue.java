package fr.lemegageek.rhythmbox;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Set;

/** Queue edits preserve the playing occurrence and cannot reintroduce hidden entries. */
final class PlaybackQueue {
    static final class Selection {
        final JSONArray tracks;final int selected;final boolean currentRemoved;
        Selection(JSONArray tracks,int selected,boolean currentRemoved){this.tracks=tracks;this.selected=selected;this.currentRemoved=currentRemoved;}
    }
    static Selection excluding(JSONArray queue,int selected,Set<String> hidden) {
        JSONArray kept=new JSONArray();int next=-1;boolean removed=false;
        for(int i=0;i<queue.length();i++) {
            JSONObject track=queue.optJSONObject(i);if(track==null)continue;
            if(hidden.contains(track.optString("id"))){if(i==selected)removed=true;continue;}
            if(i==selected)next=kept.length();kept.put(track);
        }
        return new Selection(kept,next,removed);
    }
}
