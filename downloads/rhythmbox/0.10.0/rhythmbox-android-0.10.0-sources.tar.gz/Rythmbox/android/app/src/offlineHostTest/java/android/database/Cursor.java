package android.database;
public interface Cursor extends java.io.Closeable {
    boolean moveToFirst();boolean moveToNext();String getString(int index);long getLong(int index);int getInt(int index);boolean isNull(int index);void close();
}
