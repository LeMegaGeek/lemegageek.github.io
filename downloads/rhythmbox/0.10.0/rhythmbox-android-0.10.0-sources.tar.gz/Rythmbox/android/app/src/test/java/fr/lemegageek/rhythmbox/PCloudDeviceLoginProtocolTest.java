package fr.lemegageek.rhythmbox;

import org.json.JSONObject;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/** Provider browser-capability contract; no account/network/browser is used. */
public final class PCloudDeviceLoginProtocolTest {
    static int checks;
    static final long NOW=Instant.parse("2026-10-31T10:00:00Z").toEpochMilli();
    static final String EMAIL="music@example.test",ID="private-request-fixture",DEVICE="rhythmbox-android-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
    interface Check{void run() throws Exception;}
    static void yes(boolean value,String name){checks++;if(!value)throw new AssertionError(name);}
    static void reject(Check action,String name) throws Exception{checks++;try{action.run();}catch(Exception expected){return;}throw new AssertionError("Accepted: "+name);}
    static String expires(long millis){return DateTimeFormatter.RFC_1123_DATE_TIME.format(Instant.ofEpochMilli(millis).atZone(ZoneOffset.UTC));}
    static final class Fake implements PCloudDirectLoginProtocol.Transport {
        final List<String> methods=new ArrayList<>();final List<Map<String,String>> params=new ArrayList<>();
        JSONObject begin=new JSONObject(),poll=new JSONObject(),identity=new JSONObject();String identityRegion="eu";
        Fake() throws Exception{
            begin.put("result",0).put("request_id",ID).put("expires",expires(NOW+3600000));
            poll.put("result",0).put("token","new-web-token").put("locationid",2).put("userid",7).put("rememberme",false);
            identity.put("result",0).put("userid",7).put("email",EMAIL);
        }
        public JSONObject request(String region,String method,Map<String,String> parameters,char[] secret) throws Exception{
            yes(secret==null,"browser flow never handles a password or OTP");methods.add(method);params.add(parameters);
            if(method.equals("getrequestid")){yes(region.equals("eu")&&parameters.isEmpty(),"anonymous request ID with no credentials");return begin;}
            if(method.equals("pcloud_oauth2_token")){yes(region.equals("eu")&&parameters.size()==3&&parameters.get("typelogin").equals("1")&&parameters.get("timeout").equals("1")&&parameters.get("request_id").equals(ID),"short private capability poll only");return poll;}
            if(method.equals("userinfo")){yes(region.equals(identityRegion)&&parameters.equals(Collections.singletonMap("auth","new-web-token")),"returned account token verified on actual region");return identity;}
            if(method.equals("logout")){yes(parameters.equals(Collections.singletonMap("auth","new-web-token")),"only failed new token revoked");return new JSONObject().put("result",0);}
            throw new AssertionError(method);
        }
    }
    static PCloudDeviceLoginProtocol.Request begin(Fake fake,PCloudAccount previous) throws Exception{return PCloudDeviceLoginProtocol.begin(EMAIL,previous,DEVICE,"0.5.1","16",NOW,fake);}
    public static void main(String[] args) throws Exception{
        Fake fake=new Fake();PCloudDeviceLoginProtocol.Request request=begin(fake,null);String url=request.browserUrl();
        yes(url.startsWith("https://my.pcloud.com/webview/authentication?"),"official provider page only");
        yes(url.contains("clientid=rhythmbox-musique")&&!url.contains("pcloud-cli")&&!url.contains("client_id="),"own app identity and no borrowed OAuth client ID");
        yes(url.contains("device=Rhythmbox+Musique+Android")&&url.contains("osversion=Android+16")&&url.contains("os=10")&&url.contains("appversion=0.5.1"),"honest Android device with documented Console protocol lifecycle");
        yes(!request.toString().contains(ID)&&!request.toString().contains(EMAIL),"private capability and expected email redacted");
        yes(request.expiresMillis==NOW+900000&&request.validAt(NOW)&&!request.validAt(NOW+900000)&&!request.validAt(NOW-1),"server expiry capped to15minutes, no past/future clock reuse");
        fake.poll=new JSONObject().put("result",6002);PCloudDeviceLoginProtocol.Poll pending=PCloudDeviceLoginProtocol.poll(request,NOW+1,fake);
        yes(pending.pending&&pending.account==null&&!pending.persistent,"pending is not successful authorization");
        fake.poll=new JSONObject().put("result",0).put("token","new-web-token").put("locationid",2).put("userid",7).put("rememberme",false);
        PCloudDeviceLoginProtocol.Poll result=PCloudDeviceLoginProtocol.poll(request,NOW+2,fake);
        yes(!result.pending&&!result.persistent&&result.account.authType.equals("direct")&&result.account.clientId.isEmpty()&&result.account.userid==7,"provider temporary authorization preserved as direct session token");
        yes(!result.toString().contains("new-web-token"),"poll result token redacted");
        Fake lasting=new Fake();lasting.poll.put("rememberme",true);yes(PCloudDeviceLoginProtocol.poll(begin(lasting,null),NOW+1,lasting).persistent,"provider remember-me choice accepted");
        Fake noRemember=new Fake();noRemember.poll.remove("rememberme");yes(!PCloudDeviceLoginProtocol.poll(begin(noRemember,null),NOW+1,noRemember).persistent,"missing remember-me defaults to temporary");
        PCloudAccount previous=new PCloudAccount("prior","music@example.test","eu","",7,123,"direct");Fake renewed=new Fake();yes(PCloudDeviceLoginProtocol.poll(begin(renewed,previous),NOW+1,renewed).account.musicFolderId==123,"same music account retains selected root");
        Fake us=new Fake();us.poll.put("locationid",1);us.identityRegion="us";yes(PCloudDeviceLoginProtocol.poll(begin(us,null),NOW+1,us).account.region.equals("us"),"US identity verified on returned region");
        Fake euZero=new Fake();euZero.poll.put("locationid",0);yes(PCloudDeviceLoginProtocol.poll(begin(euZero,null),NOW+1,euZero).account.region.equals("eu"),"provider SDK location0 EU compatibility");
        for(String field:new String[]{"email","userid"}){Fake wrong=new Fake();if(field.equals("email"))wrong.identity.put(field,"personal@example.test");else wrong.identity.put(field,8);reject(()->PCloudDeviceLoginProtocol.poll(begin(wrong,null),NOW+1,wrong),"wrong actual identity");yes(wrong.methods.get(wrong.methods.size()-1).equals("logout"),"wrong identity revokes new token");}
        Fake wrongUid=new Fake();wrongUid.poll.put("userid",8);reject(()->PCloudDeviceLoginProtocol.poll(begin(wrongUid,previous),NOW+1,wrongUid),"old music UID cannot change silently");yes(!wrongUid.methods.contains("userinfo")&&wrongUid.methods.contains("logout"),"unexpected UID stops before file/account reads and revokes");
        for(Object bad:new Object[]{"true",1,JSONObject.NULL}){Fake malformed=new Fake();malformed.poll.put("rememberme",bad);reject(()->PCloudDeviceLoginProtocol.poll(begin(malformed,null),NOW+1,malformed),"ambiguous persistence choice");yes(malformed.methods.contains("logout"),"malformed grant revoked");}
        for(Object bad:new Object[]{"0",0.5,true}){Fake malformed=new Fake();malformed.poll.put("result",bad);reject(()->PCloudDeviceLoginProtocol.poll(begin(malformed,null),NOW+1,malformed),"malformed provider status");}
        Fake expired=new Fake();expired.begin.put("expires",expires(NOW));reject(()->begin(expired,null),"already expired request");
        Fake malformedDate=new Fake();malformedDate.begin.put("expires","not-a-date");reject(()->begin(malformedDate,null),"invalid server expiry");
        Fake malformedId=new Fake();malformedId.begin.put("request_id","private\r\ninjection");reject(()->begin(malformedId,null),"header/control injection capability");
        Fake expiredPoll=new Fake();PCloudDeviceLoginProtocol.Request expiring=begin(expiredPoll,null);int before=expiredPoll.methods.size();reject(()->PCloudDeviceLoginProtocol.poll(expiring,NOW+900000,expiredPoll),"expired poll");yes(before==expiredPoll.methods.size(),"expired capability never sent again");
        Fake rejected=new Fake();rejected.poll=new JSONObject().put("result",4000).put("error","PRIVATE"+ID);try{PCloudDeviceLoginProtocol.poll(begin(rejected,null),NOW+1,rejected);throw new AssertionError("rate limit accepted");}catch(IllegalStateException expected){yes(!expected.toString().contains(ID)&&!expected.toString().contains("PRIVATE"),"provider response redacted");}yes(rejected.methods.equals(Arrays.asList("getrequestid","pcloud_oauth2_token")),"no blind retry after provider rejection");
        final PCloudDirectLoginProtocolTest.Http[] captured={null};PCloudDeviceLoginProtocol.HttpTransport http=new PCloudDeviceLoginProtocol.HttpTransport(u->{captured[0]=new PCloudDirectLoginProtocolTest.Http(u,new JSONObject().put("result",6002));return captured[0];});
        http.request("eu","pcloud_oauth2_token",Collections.singletonMap("request_id",ID),null);
        yes(captured[0].getURL().toString().equals("https://eapi.pcloud.com/pcloud_oauth2_token")&&!captured[0].getInstanceFollowRedirects()&&!captured[0].getUseCaches(),"HTTPS fixed-host POST with no capability in URL and no redirects/cache");
        yes(captured[0].body.toString("UTF-8").contains("request_id="+ID)&&captured[0].getRequestProperty("Authorization")==null,"capability remains in POST body without another account's token");
        reject(()->http.request("eu","listfolder",Collections.emptyMap(),null),"login transport cannot browse account files");
        networkRecovery();
        System.out.println("PASS : "+checks+" pCloud browser-device login assertions (identity, own app, pending, expiry, remember-me, revocation)");
    }
    static void networkRecovery() throws Exception {
        Fake fake=new Fake();final List<String> calls=new ArrayList<>();final int[] pollCalls={0},identityCalls={0};
        PCloudDirectLoginProtocol.Transport transport=(region,method,params,secret)->{
            calls.add(method);
            if(method.equals("pcloud_oauth2_token")&&++pollCalls[0]==2)throw new java.net.SocketTimeoutException("PRIVATE "+ID);
            if(method.equals("userinfo")&&++identityCalls[0]==1)throw new java.io.IOException("PRIVATE new-web-token");
            return fake.request(region,method,params,secret);
        };
        PCloudDeviceLoginProtocol.Request request=PCloudDeviceLoginProtocol.begin(EMAIL,null,DEVICE,"0.5.2","16",NOW,transport);
        fake.poll=new JSONObject().put("result",6002);yes(PCloudDeviceLoginProtocol.poll(request,NOW+1,transport).pending,"initial browser step pending");
        try{PCloudDeviceLoginProtocol.poll(request,NOW+2,transport);throw new AssertionError("missing network failure");}catch(PCloudDeviceLoginProtocol.NetworkFailure retry){yes(retry.phase.equals("poll-network")&&!retry.toString().contains(ID)&&!retry.toString().contains("PRIVATE"),"transient poll error safely classified");}
        yes(request.validAt(NOW+3),"interrupted poll preserves same private capability");
        fake.poll=new JSONObject().put("result",0).put("token","new-web-token").put("locationid",2).put("userid",7).put("rememberme",true);
        try{PCloudDeviceLoginProtocol.poll(request,NOW+3,transport);throw new AssertionError("missing identity network failure");}catch(PCloudDeviceLoginProtocol.NetworkFailure retry){yes(retry.phase.equals("identity-network")&&!retry.toString().contains("new-web-token"),"identity IO safely classified without token");}
        yes(!calls.contains("logout"),"network interruption never revokes unverified grant needed for retry");
        PCloudDeviceLoginProtocol.Poll recovered=PCloudDeviceLoginProtocol.poll(request,NOW+4,transport);
        yes(recovered.account.userid==7&&recovered.persistent,"same request recovers after browser return");
        yes(Collections.frequency(calls,"getrequestid")==1&&pollCalls[0]==3&&identityCalls[0]==2,"userinfo retry never requests a new capability or polls consumed grant again");
        PCloudDeviceLoginProtocol.complete(request,recovered);yes(PCloudDeviceLoginProtocol.cancel(request,transport)==null,"cancel after committed ownership never revokes stored token");
        Fake terminal=new Fake();terminal.poll=new JSONObject().put("result",4000);PCloudDeviceLoginProtocol.Request denied=begin(terminal,null);
        try{PCloudDeviceLoginProtocol.poll(denied,NOW+1,terminal);throw new AssertionError("provider rejection accepted");}catch(PCloudDeviceLoginProtocol.LoginFailure failure){yes(!(failure instanceof PCloudDeviceLoginProtocol.NetworkFailure)&&failure.phase.equals("poll-api")&&failure.code==4000,"provider code stays terminal and actionable");}
        int count=terminal.methods.size();reject(()->PCloudDeviceLoginProtocol.poll(denied,NOW+2,terminal),"terminal provider error cannot auto-cycle");yes(count==terminal.methods.size(),"no provider call after terminal failure");
        for(boolean expire:new boolean[]{false,true}){
            Fake held=new Fake();final List<String> methods=new ArrayList<>();
            PCloudDirectLoginProtocol.Transport interrupted=(region,method,params,secret)->{methods.add(method);if(method.equals("userinfo"))throw new java.net.SocketTimeoutException("PRIVATE");return held.request(region,method,params,secret);};
            PCloudDeviceLoginProtocol.Request waiting=PCloudDeviceLoginProtocol.begin(EMAIL,null,DEVICE,"0.5.2","16",NOW,interrupted);
            try{PCloudDeviceLoginProtocol.poll(waiting,NOW+1,interrupted);}catch(PCloudDeviceLoginProtocol.NetworkFailure expected){}
            if(expire)reject(()->PCloudDeviceLoginProtocol.poll(waiting,NOW+900001,interrupted),"retained grant expires with request");
            else{PCloudDeviceLoginProtocol.Cleanup cleanup=PCloudDeviceLoginProtocol.cancel(waiting,interrupted);yes(cleanup!=null,"cancel owns retained unverified grant");cleanup.run();cleanup.run();}
            yes(Collections.frequency(methods,"logout")==1,"cancel/expiry revokes retained new grant once");
            reject(()->PCloudDeviceLoginProtocol.poll(waiting,NOW+2,interrupted),"cancelled/expired grant cannot restore an account");
        }
        PCloudDeviceLoginProtocol.HttpTransport timeout=new PCloudDeviceLoginProtocol.HttpTransport(url->{throw new java.net.SocketTimeoutException("PRIVATE "+ID);});
        try{timeout.request("eu","pcloud_oauth2_token",Collections.emptyMap(),null);throw new AssertionError("timeout accepted");}catch(PCloudDeviceLoginProtocol.NetworkFailure retry){yes(retry.phase.equals("poll-network")&&!retry.toString().contains(ID),"actual HTTP IO preserves safe transient classification");}
        PCloudDeviceLoginProtocol.HttpTransport tls=new PCloudDeviceLoginProtocol.HttpTransport(url->{throw new javax.net.ssl.SSLHandshakeException("PRIVATE "+ID);});
        try{tls.request("eu","pcloud_oauth2_token",Collections.emptyMap(),null);throw new AssertionError("TLS error accepted");}catch(PCloudDeviceLoginProtocol.LoginFailure failure){yes(!(failure instanceof PCloudDeviceLoginProtocol.NetworkFailure)&&failure.phase.equals("poll-tls")&&!failure.toString().contains(ID),"TLS validation errors remain terminal, no fallback");}
    }

}
