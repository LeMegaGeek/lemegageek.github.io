package fr.lemegageek.rhythmbox;

import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Direct pCloud login. Only the password-free verified auth token can become account state. */
public final class PCloudDirectLoginProtocol {
    public static final String SESSION_SECONDS="2592000";
    private static final int MAX_RESPONSE=1024*1024;
    public interface Transport { JSONObject request(String region,String method,Map<String,String> parameters,char[] password) throws Exception; }
    public static final class Challenge {
        private final String token;
        final String email,region;
        final PCloudAccount previous;
        public final int type;
        public final boolean hasDevices;
        private final long createdMillis;
        private Challenge(String token,String email,String region,PCloudAccount previous,int type,boolean hasDevices){
            if(token==null||token.isEmpty()||token.length()>4096||!token.matches("[\\x21-\\x7e]+"))throw failure();
            this.token=token;this.email=email;this.region=region;this.previous=previous;
            this.type=type;this.hasDevices=hasDevices;
            this.createdMillis=System.currentTimeMillis();
        }
        boolean valid(){long now=System.currentTimeMillis();return now>=createdMillis&&now-createdMillis<=15*60*1000;}
        @Override public String toString(){return "PCloudTwoFactor{token=<redacted>}";}
    }
    static class DirectFailure extends IllegalStateException { DirectFailure(String message){super(message);} }
    public static final class TwoFactorRequired extends DirectFailure {
        public final Challenge challenge;
        public final boolean retry;
        private TwoFactorRequired(Challenge challenge){this(challenge,false);}
        private TwoFactorRequired(Challenge challenge,boolean retry){super(retry?"Code de sécurité incorrect. Réessaie avec un nouveau code.":"Saisis le code de sécurité pCloud reçu sur tes appareils ou ton application d’authentification.");this.challenge=challenge;this.retry=retry;}
    }
    private PCloudDirectLoginProtocol(){}
    public static String host(String region){
        if("eu".equals(region))return "eapi.pcloud.com";
        if("us".equals(region))return "api.pcloud.com";
        throw new IllegalArgumentException("Choisis la région de ton compte pCloud : Europe ou États-Unis.");
    }
    private static Map<String,String> sessionParameters(){
        Map<String,String> out=new LinkedHashMap<>();out.put("getauth","1");out.put("device","Rhythmbox Musique Android");
        out.put("authexpire",SESSION_SECONDS);out.put("authinactiveexpire",SESSION_SECONDS);return out;
    }
    public static PCloudAccount login(String email,char[] password,String region,PCloudAccount previous,Transport transport) throws Exception {
        try{
            String normalized=PCloudAccount.normalizedEmail(email);host(region);
            if(password==null||password.length==0||password.length>4096)throw new IllegalArgumentException("Saisis le mot de passe du compte musical pCloud.");
            Map<String,String> params=sessionParameters();params.put("username",normalized);params.put("logout","1");
            return verified(transport.request(region,"userinfo",Collections.unmodifiableMap(params),password),normalized,region,previous,transport);
        }catch(TwoFactorRequired challenge){throw challenge;}
        catch(DirectFailure safe){throw safe;}
        catch(Exception ignored){throw failure();}
        finally{if(password!=null)Arrays.fill(password,'\0');}
    }
    /** The challenge and one-time code stay in memory only; no device is trusted automatically. */
    public static PCloudAccount twoFactor(Challenge challenge,char[] code,Transport transport) throws Exception {
        try{
            if(challenge==null||!challenge.valid()||code==null||code.length<1||code.length>128)throw new IllegalArgumentException("Saisis le code de sécurité pCloud.");
            for(char c:code)if(c<33||c>126)throw new IllegalArgumentException("Code de sécurité pCloud invalide.");
            Map<String,String> params=sessionParameters();params.put("token",challenge.token);params.put("trustdevice","0");
            JSONObject response=transport.request(challenge.region,"tfa_login",Collections.unmodifiableMap(params),code);
            long result=integer(response,"result");
            if(result==2012||result==2074||result==2092)throw new TwoFactorRequired(challenge,true);
            return verified(response,challenge.email,challenge.region,challenge.previous,transport);
        }catch(TwoFactorRequired again){throw again;}
        catch(DirectFailure safe){throw safe;}
        catch(Exception ignored){throw failure();}
        finally{if(code!=null)Arrays.fill(code,'\0');}
    }
    /** Called only by an explicit user click; never sends SMS/notifications automatically. */
    public static void sendCode(Challenge challenge,boolean sms,Transport transport) throws Exception {
        try{
            if(challenge==null||!challenge.valid()||(sms?challenge.type!=1:!challenge.hasDevices))throw failure();
            JSONObject response=transport.request(challenge.region,sms?"tfa_sendcodeviasms":"tfa_sendcodeviasysnotification",Collections.singletonMap("token",challenge.token),null);
            if(integer(response,"result")!=0)throw failure();
        }catch(Exception ignored){throw new DirectFailure("pCloud n’a pas pu envoyer le code. Réessaie depuis la connexion du compte musical.");}
    }
    private static long integer(JSONObject value,String name) throws Exception {
        Object raw=value.get(name);if(!(raw instanceof Integer||raw instanceof Long))throw failure();return ((Number)raw).longValue();
    }
    private static PCloudAccount verified(JSONObject response,String email,String region,PCloudAccount previous,Transport transport) throws Exception {
        long result=integer(response,"result");
        if(result==2297){
            long type=integer(response,"tfatype");Object devices=response.get("hasdevices");
            if((type!=1&&type!=2)||!(devices instanceof Boolean))throw failure();
            throw new TwoFactorRequired(new Challenge(response.getString("token"),email,region,previous,(int)type,(Boolean)devices));
        }
        if(result==1022)throw new DirectFailure("pCloud exige une vérification sur sa page officielle. Utilise la connexion dans le navigateur proposée par Rhythmbox.");
        if(result==2306)throw new DirectFailure("pCloud demande de vérifier ton adresse e-mail. Ouvre le message de vérification pCloud, puis reconnecte le compte dans Rhythmbox.");
        if(result==2321)throw new DirectFailure("Cette région ne correspond pas au compte pCloud. Choisis Europe ou États-Unis, puis réessaie.");
        if(result==4000)throw new DirectFailure("pCloud limite les tentatives de connexion. Attends avant de réessayer.");
        if(result!=0)throw new DirectFailure("pCloud a refusé la connexion. Vérifie le compte musical, le mot de passe ou le code de sécurité.");
        String token=response.getString("auth");
        if(token.isEmpty()||token.length()>64||!token.matches("[\\x21-\\x7e]+"))throw failure();
        boolean accepted=false;
        try{
            long uid=integer(response,"userid");
            if(uid<=0||!email.equals(PCloudAccount.normalizedEmail(response.getString("email"))))throw failure();
            if(previous!=null&&previous.email.equals(email)&&previous.region.equals(region)&&previous.userid!=uid)throw failure();
            long folder=previous!=null&&previous.userid==uid&&previous.email.equals(email)&&previous.region.equals(region)?previous.musicFolderId:0;
            PCloudAccount account=new PCloudAccount(token,email,region,"",uid,folder,"direct");
            JSONObject identity=transport.request(region,"userinfo",Collections.singletonMap("auth",token),null);
            if(integer(identity,"result")!=0||integer(identity,"userid")!=uid||!email.equals(PCloudAccount.normalizedEmail(identity.getString("email"))))throw failure();
            accepted=true;return account;
        }finally{if(!accepted)revoke(region,token,previous,transport);}
    }
    static void revoke(String region,String token,PCloudAccount previous,Transport transport){
        if(previous!=null&&java.security.MessageDigest.isEqual(token.getBytes(StandardCharsets.UTF_8),previous.token.getBytes(StandardCharsets.UTF_8)))return;
        try{transport.request(region,"logout",Collections.singletonMap("auth",token),null);}catch(Exception ignored){/* Best effort: never expose tokens or replace the original failure. */}
    }
    static DirectFailure failure(){return new DirectFailure("Connexion au compte musical pCloud impossible ou identité différente. Aucun autre compte n’a été utilisé.");}

    /** HTTPS POST bodies only: no password/token URL, redirects, response dump or exception cause. */
    public static final class HttpTransport implements Transport {
        interface ConnectionFactory {HttpURLConnection open(URL url) throws Exception;}
        private final ConnectionFactory connections;
        public HttpTransport(){this(url->(HttpURLConnection)url.openConnection());}
        HttpTransport(ConnectionFactory connections){this.connections=connections;}
        @Override public JSONObject request(String region,String method,Map<String,String> parameters,char[] secret) throws Exception {
            String host=host(region);
            if(!"userinfo".equals(method)&&!"logout".equals(method)&&!"tfa_login".equals(method)&&!"tfa_sendcodeviasms".equals(method)&&!"tfa_sendcodeviasysnotification".equals(method))throw failure();
            if(parameters.containsKey("password")||parameters.containsKey("code")||parameters.containsKey("access_token"))throw failure();
            HttpURLConnection connection=null;byte[] body=null;
            try{
                StringBuilder form=new StringBuilder();
                for(Map.Entry<String,String> e:parameters.entrySet()){
                    if(form.length()>0)form.append('&');form.append(URLEncoder.encode(e.getKey(),"UTF-8")).append('=').append(URLEncoder.encode(e.getValue(),"UTF-8"));
                }
                if(secret!=null){if(form.length()>0)form.append('&');form.append("tfa_login".equals(method)?"code=":"password=").append(URLEncoder.encode(new String(secret),"UTF-8"));}
                body=form.toString().getBytes(StandardCharsets.UTF_8);
                connection=connections.open(new URL("https://"+host+"/"+method));
                connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(15000);connection.setReadTimeout(30000);connection.setUseCaches(false);
                connection.setRequestMethod("POST");connection.setDoOutput(true);connection.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
                connection.setRequestProperty("Accept","application/json");connection.setRequestProperty("Cookie","");connection.setFixedLengthStreamingMode(body.length);
                try(java.io.OutputStream output=connection.getOutputStream()){output.write(body);}
                if(connection.getResponseCode()!=200||connection.getContentLengthLong()>MAX_RESPONSE)throw failure();
                try(InputStream input=connection.getInputStream();ByteArrayOutputStream output=new ByteArrayOutputStream()){
                    byte[] buffer=new byte[8192];int count;while((count=input.read(buffer))!=-1){if(output.size()+count>MAX_RESPONSE)throw failure();output.write(buffer,0,count);}
                    return new JSONObject(new String(output.toByteArray(),StandardCharsets.UTF_8));
                }
            }catch(Exception ignored){throw failure();}
            finally{if(body!=null)Arrays.fill(body,(byte)0);if(connection!=null)connection.disconnect();}
        }
    }
}
