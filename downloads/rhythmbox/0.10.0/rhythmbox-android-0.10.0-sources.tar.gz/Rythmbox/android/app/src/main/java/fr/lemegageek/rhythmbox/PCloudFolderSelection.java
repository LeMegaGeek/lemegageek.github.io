package fr.lemegageek.rhythmbox;

/** A folder lookup is authorized by the unchanged account that started it.
 * The candidate scope may be checked remotely before that choice is saved;
 * only the original complete authorization may still approve the request.
 * Persisting the choice remains PCloudAccountStore.selectMusicFolder's CAS.
 */
public final class PCloudFolderSelection {
    private final PCloudAccount expected;
    public final PCloudAccount candidate;

    public PCloudFolderSelection(PCloudAccount expected, long folderId) {
        if (expected == null)
            throw new IllegalArgumentException("Connecte d’abord le compte musical pCloud.");
        this.expected = expected;
        this.candidate = expected.withMusicFolder(folderId);
    }

    public boolean valid(PCloudAccount current) {
        return PCloudAccount.sameAuthorization(expected, current);
    }
}
