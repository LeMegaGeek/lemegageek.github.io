package fr.lemegageek.rhythmbox;

import android.service.notification.NotificationListenerService;

/** Optional Android authorization bridge for local MediaSessions only.
 * No notification-posted/removed callback, content inspection, ranking query,
 * active-notification query, notification storage or network operation exists.
 * API31+ manifest filters additionally disable all four notification types.
 */
public final class SpotifyNotificationListener extends NotificationListenerService {
    @Override public void onListenerConnected(){SpotifyController.notificationAccessChanged();}
    @Override public void onListenerDisconnected(){SpotifyController.notificationAccessChanged();}
}
