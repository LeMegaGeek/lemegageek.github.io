package fr.lemegageek.rhythmbox;

import android.content.Context;
import android.content.ContentResolver;
import android.content.UriPermission;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Uses only the two document trees deliberately granted by Android's picker. */
public final class FolderSync {
    private final ContentResolver resolver;
    private final JSONObject config;
    private static final int MAX=8*1024*1024;
    public FolderSync(Context context,JSONObject config){this.resolver=context.getContentResolver();this.config=config;}
    private Uri tree(String field,boolean write) throws Exception {
        String raw=config.optString(field,"");
        if(raw.isEmpty())throw new IllegalStateException(field.equals("media_tree")?"Choisis d’abord le dossier musique dans Réglages":"Choisis d’abord le dossier des playlists dans Réglages");
        Uri tree=Uri.parse(raw);
        if(!"content".equals(tree.getScheme()) || !DocumentsContract.isTreeUri(tree))throw new IllegalArgumentException("Dossier Android invalide");
        boolean granted=false;
        for(UriPermission permission:resolver.getPersistedUriPermissions())if(permission.getUri().equals(tree) && permission.isReadPermission() && (!write || permission.isWritePermission()))granted=true;
        if(!granted)throw new IllegalStateException("L’accès au dossier a expiré. Choisis-le à nouveau dans Réglages.");
        return tree;
    }
    public void validateConfig() throws Exception {FolderProtocol.key(config);tree("playlist_tree",true);}
    private static final class Document {
        final Uri uri; final String name,mime,id;
        Document(Uri uri,String name,String mime,String id){this.uri=uri;this.name=name;this.mime=mime;this.id=id;}
        boolean directory(){return DocumentsContract.Document.MIME_TYPE_DIR.equals(mime);}
    }
    private List<Document> children(Uri tree,String parent) throws Exception {
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,parent);
        List<Document> result=new ArrayList<>();
        String[] fields={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE};
        try(Cursor cursor=resolver.query(children,fields,null,null,null)){
            if(cursor==null)throw new IllegalStateException("Le fournisseur ne permet pas de parcourir ce dossier");
            while(cursor.moveToNext()){
                if(result.size()>=50000)throw new IllegalArgumentException("Dossier trop volumineux");
                String id=cursor.getString(0),name=cursor.getString(1),mime=cursor.getString(2);
                if(id==null || name==null || name.isEmpty() || name.indexOf('/')>=0 || name.indexOf('\\')>=0 || name.equals(".") || name.equals(".."))throw new IllegalArgumentException("Nom de document ambigu");
                result.add(new Document(DocumentsContract.buildDocumentUriUsingTree(tree,id),name,mime,id));
            }
        }
        return result;
    }
    private byte[] read(Uri uri,int limit) throws Exception {
        try(InputStream input=resolver.openInputStream(uri);ByteArrayOutputStream output=new ByteArrayOutputStream()){
            if(input==null)throw new IllegalStateException("Document indisponible");
            byte[] buffer=new byte[16384];int count;
            while((count=input.read(buffer))!=-1){if(output.size()+count>limit)throw new IllegalArgumentException("Document trop volumineux");output.write(buffer,0,count);}
            return output.toByteArray();
        }
    }
    public List<JSONObject> heads() throws Exception {
        Uri tree=tree("playlist_tree",false);Map<String,JSONObject> snapshots=new LinkedHashMap<>();int count=0;
        for(Document document:children(tree,DocumentsContract.getTreeDocumentId(tree))){
            if(document.directory() || !document.name.matches("rb-sync-[0-9a-f-]{36}\\.rbx"))continue;
            if(++count>1000)throw new IllegalArgumentException("Plus de 1000 révisions : archivage manuel nécessaire");
            JSONObject snapshot=new JSONObject(new String(Crypto.open(FolderProtocol.key(config),read(document.uri,MAX)),StandardCharsets.UTF_8));
            Library.validate(snapshot);
            if(!document.name.equals("rb-sync-"+snapshot.getString("id")+".rbx"))throw new IllegalArgumentException("Identité de révision incohérente");
            SyncEngine.addSnapshot(snapshots,snapshot);
        }
        return SyncEngine.historyHeads(snapshots);
    }
    public void upload(JSONObject snapshot) throws Exception {
        validateConfig();Library.validate(snapshot);Uri tree=tree("playlist_tree",true);
        byte[] envelope=Crypto.seal(FolderProtocol.key(config),snapshot.toString().getBytes(StandardCharsets.UTF_8));
        if(envelope.length>MAX)throw new IllegalArgumentException("Bibliothèque trop volumineuse");
        String name="rb-sync-"+snapshot.getString("id")+".rbx";
        String parentId=DocumentsContract.getTreeDocumentId(tree);
        for(Document document:children(tree,parentId))if(document.name.equals(name))throw new IllegalStateException("Cette révision existe déjà ; aucune donnée n’a été écrasée");
        Uri parent=DocumentsContract.buildDocumentUriUsingTree(tree,parentId),temporary=null;
        boolean complete=false;
        try{
            temporary=DocumentsContract.createDocument(resolver,parent,"application/octet-stream",".rb-pending-"+UUID.randomUUID()+".partial");
            if(temporary==null || !tree.getAuthority().equals(temporary.getAuthority()))throw new IllegalStateException("Le fournisseur n’autorise pas la création de révisions");
            // Rebuild with the selected tree rather than trusting an arbitrary provider URI.
            temporary=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getDocumentId(temporary));
            try(OutputStream output=resolver.openOutputStream(temporary,"w")){if(output==null)throw new IllegalStateException("Dossier en lecture seule");output.write(envelope);output.flush();}
            if(!MessageDigest.isEqual(envelope,read(temporary,MAX)))throw new IllegalStateException("La vérification de l’écriture a échoué");
            Uri renamed=DocumentsContract.renameDocument(resolver,temporary,name);
            if(renamed==null)throw new IllegalStateException("Ce fournisseur ne permet pas de finaliser une révision ; choisis un dossier compatible");
            temporary=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getDocumentId(renamed));
            String actual=displayName(temporary);
            if(!name.equals(actual))throw new IllegalStateException("Le fournisseur a renommé la révision ; aucun remplacement n’a été effectué");
            complete=true;
        }finally{if(!complete && temporary!=null)try{DocumentsContract.deleteDocument(resolver,temporary);}catch(Exception ignored){}}
    }
    private String displayName(Uri uri) throws Exception {
        try(Cursor cursor=resolver.query(uri,new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME},null,null,null)){
            if(cursor==null || !cursor.moveToFirst())throw new IllegalStateException("Document nouvellement créé introuvable");return cursor.getString(0);
        }
    }
    private void walkMedia(Uri tree,String parent,String prefix,int depth,Map<String,Document> files,java.util.Set<String> visited,int[] visitedCount) throws Exception {
        if(depth>32 || !visited.add(parent) || files.size()>50000)throw new IllegalArgumentException("Dossier musique cyclique ou trop volumineux");
        for(Document document:children(tree,parent)){
            if(++visitedCount[0]>50000)throw new IllegalArgumentException("Dossier musique trop volumineux");
            String path=prefix+document.name;
            FolderProtocol.mediaPath(path);
            if(document.directory())walkMedia(tree,document.id,path+"/",depth+1,files,visited,visitedCount);
            else if(audio(document)){
                if(files.put(path,document)!=null)throw new IllegalArgumentException("Plusieurs fichiers portent le même chemin relatif");
            }
        }
    }
    public JSONArray importMedia() throws Exception {
        Uri tree=tree("media_tree",false);Map<String,Document> files=new LinkedHashMap<>();
        walkMedia(tree,DocumentsContract.getTreeDocumentId(tree),"",0,files,new java.util.HashSet<>(),new int[]{0});
        JSONArray result=new JSONArray();
        for(Map.Entry<String,Document> entry:files.entrySet())result.put(new JSONObject().put("id","media:"+hex(MessageDigest.getInstance("SHA-256").digest(entry.getKey().getBytes(StandardCharsets.UTF_8)))).put("media_path",entry.getKey()).put("title",entry.getValue().name).put("artist","").put("album",""));
        return result;
    }
    private Document mediaDocument(Uri tree,String path) throws Exception {
        String[] parts=FolderProtocol.mediaPath(path).split("/");String parent=DocumentsContract.getTreeDocumentId(tree);Document found=null;
        java.util.Set<String> visited=new java.util.HashSet<>();visited.add(parent);
        for(int i=0;i<parts.length;i++){
            found=null;
            for(Document child:children(tree,parent))if(child.name.equals(parts[i])){if(found!=null)throw new IllegalArgumentException("Chemin musical ambigu");found=child;}
            if(found==null || (i<parts.length-1 && !found.directory()) || (i==parts.length-1 && found.directory()))throw new IllegalStateException("Ce morceau est absent du dossier musique choisi");
            if(!visited.add(found.id))throw new IllegalArgumentException("Chemin musical cyclique");parent=found.id;
        }
        if(found==null || !audio(found))throw new IllegalArgumentException("Ce document n’est pas un fichier audio du dossier musique");
        return found;
    }
    private static boolean audio(Document document){return !document.directory() && FolderProtocol.isSupportedMedia(document.name,document.mime);}
    public File mediaFile(String path,File cacheDir) throws Exception {
        Uri tree=tree("media_tree",false);Document document=mediaDocument(tree,path);
        // Read directly through SAF; no remote URL and no filesystem path from a playlist.
        String digest=hex(MessageDigest.getInstance("SHA-256").digest((tree.toString()+"\n"+path).getBytes(StandardCharsets.UTF_8)));
        File output=new File(cacheDir,"audio-"+digest+".cache"),partial=new File(cacheDir,output.getName()+".partial");
        File[] cached=cacheDir.listFiles();if(cached!=null)for(File old:cached)if(old.getName().startsWith("audio-")&&!old.equals(output))old.delete();
        // Do not reuse an unchecked cached revision after the provider replaces a file.
        boolean success=false;
        try(InputStream input=resolver.openInputStream(document.uri);FileOutputStream out=new FileOutputStream(partial)){
            if(input==null)throw new IllegalStateException("Morceau indisponible");
            byte[] buffer=new byte[65536];long total=0;int count;
            while((count=input.read(buffer))!=-1){total+=count;if(total>256L*1024*1024)throw new IllegalArgumentException("Morceau supérieur à 256 Mio");out.write(buffer,0,count);}out.getFD().sync();success=true;
        }finally{if(!success)partial.delete();}
        if(!partial.renameTo(output)){partial.delete();throw new IllegalStateException("Cache audio indisponible");}return output;
    }
    private static String hex(byte[] data){StringBuilder out=new StringBuilder();for(byte value:data)out.append(String.format(java.util.Locale.ROOT,"%02x",value&255));return out.toString();}
}
