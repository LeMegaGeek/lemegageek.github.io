package fr.lemegageek.rhythmbox;

/** Foreground playback intent arbitration, independent of Android and Spotify.
 *
 * Dispatching Play is not proof of playback. A subsequent native choice must
 * therefore account for an in-flight Spotify start even while the last player
 * state says Paused. Only a new authoritative PlayerState revision, from the
 * expected session, may confirm the requested pause. Status/artwork/capability
 * republishes must retain that revision and cannot release the native action.
 *
 * The UI performs the returned effects and owns the actual queue/Runnables.
 * A native intent remains authoritative until another explicit Spotify intent
 * or clear(), so an old delayed Playing event cannot steal playback back.
 */
public final class PlaybackOwnership {
    private enum Owner {NONE,NATIVE,SPOTIFY}

    public static final class Decision {
        public final long generation;
        public final boolean pauseSpotify,suspendNative,startNative,resumeNative,spotifySelected;
        private Decision(long generation,boolean pauseSpotify,boolean suspendNative,
                boolean startNative,boolean resumeNative,boolean spotifySelected){
            this.generation=generation;this.pauseSpotify=pauseSpotify;
            this.suspendNative=suspendNative;this.startNative=startNative;
            this.resumeNative=resumeNative;this.spotifySelected=spotifySelected;
        }
    }

    private Owner owner=Owner.NONE;
    private long generation,expectedSession=-1,pauseBaseline=-1,lastPauseSession=-1,lastPauseRevision=-1;
    private long observedSession=-1,highestPlayerRevision=-1;
    private boolean spotifyStartPending,nativeActionPending,nativeStarted,resumeAfterPause,awaitingPause;
    private long spotifyStartGeneration=-1;
    private final java.util.LinkedHashSet<Long> unresolvedStarts=new java.util.LinkedHashSet<>();
    private boolean spotifyMayBePlaying;
    private long playingSession=-1,playingRevision=-1;

    private Decision decision(boolean pause,boolean suspend,boolean start,boolean resume,boolean spotify){
        return new Decision(generation,pause,suspend,start,resume,spotify);
    }
    private Decision none(){return decision(false,false,false,false,false);}

    public synchronized long generation(){return generation;}
    public synchronized boolean awaitingPause(){return awaitingPause;}
    public synchronized long pendingSpotifyStart(){return spotifyStartPending?spotifyStartGeneration:-1;}

    /** Call before dispatching an explicit Spotify Play/URI/resuming command. */
    public synchronized Decision spotifyIntent(){
        generation++;owner=Owner.SPOTIFY;
        unresolvedStarts.add(generation);updateStartFence();
        nativeActionPending=nativeStarted=resumeAfterPause=awaitingPause=false;
        resetPause();
        return decision(false,true,false,false,true);
    }

    /** Explicit Spotify pause/stop cancels a queued native action, without Play. */
    public synchronized Decision spotifyPauseIntent(){
        generation++;owner=Owner.SPOTIFY;
        nativeActionPending=nativeStarted=resumeAfterPause=awaitingPause=false;
        resetPause();
        return decision(false,false,false,false,true);
    }

    /** Settle only this start, after synchronous rejection or a fresh SDK read.
     * This never starts/resumes Native and is never itself a Pause acknowledgement.
     */
    public synchronized void spotifyRejected(long expectedGeneration){
        unresolvedStarts.remove(expectedGeneration);updateStartFence();
    }

    /** Only an actual post-Pause SDK read can settle all preceding starts. */
    public synchronized void spotifyPauseConfirmed(long throughGeneration){
        unresolvedStarts.removeIf(value->value<=throughGeneration);updateStartFence();
    }

    /** Select a new native/Suno queue. Store its Runnable under this token. */
    public synchronized Decision nativeIntent(long session,long playerRevision,
            boolean available,boolean playing,boolean loading){
        if(available&&playerRevision>0&&(session!=observedSession||playerRevision>=highestPlayerRevision))
            observeAudioRisk(session,playerRevision,playing,loading);
        boolean mayStillStart=spotifyStartPending||spotifyMayBePlaying;
        generation++;owner=Owner.NATIVE;
        nativeActionPending=true;nativeStarted=resumeAfterPause=false;
        resetPause();
        if(available&&playerRevision>0)rememberRevision(session,playerRevision);
        if(mayStillStart||available&&(playing||loading)){
            awaitingPause=true;expectedSession=session;pauseBaseline=playerRevision;
            lastPauseSession=session;lastPauseRevision=playerRevision;
            return decision(true,true,false,false,false);
        }
        awaitingPause=false;nativeActionPending=false;nativeStarted=true;
        return decision(false,false,true,false,false);
    }

    /** Explicit native pause/stop invalidates any delayed automatic start/resume. */
    public synchronized void nativePaused(){
        generation++;owner=Owner.NATIVE;
        nativeActionPending=nativeStarted=resumeAfterPause=awaitingPause=false;
        resetPause();
    }

    /** Observe state, not RPC acceptance. Revisions must describe real PlayerState. */
    public synchronized Decision onSpotifyState(long session,long playerRevision,
            boolean available,boolean playing,boolean loading){
        if(!available)return none();
        if(playerRevision<1||session==observedSession&&playerRevision<highestPlayerRevision)return none();
        rememberRevision(session,playerRevision);
        observeAudioRisk(session,playerRevision,playing,loading);
        if(playing){
            unresolvedStarts.clear();updateStartFence();
            if(owner!=Owner.NATIVE){
                owner=Owner.SPOTIFY;spotifyStartPending=false;
                return decision(false,true,false,false,true);
            }
            // A command sent for an older Spotify intent may have reached the
            // client after nativeIntent's initial Pause. Pause that late start
            // again, retaining the newer native queue and its position.
            if(nativeStarted){nativeStarted=false;resumeAfterPause=true;}
            awaitingPause=true;
            if(lastPauseSession!=session||playerRevision>lastPauseRevision){
                expectedSession=session;pauseBaseline=playerRevision;
                lastPauseSession=session;lastPauseRevision=playerRevision;
                return decision(true,true,false,false,false);
            }
            return none();
        }
        if(owner!=Owner.NATIVE||!awaitingPause||loading)return none();
        boolean fresh=playerRevision>0&&(session!=expectedSession||playerRevision>pauseBaseline);
        if(!fresh)return none();
        unresolvedStarts.clear();updateStartFence();
        awaitingPause=false;resetPause();
        if(nativeActionPending){
            nativeActionPending=false;nativeStarted=true;
            return decision(false,false,true,false,false);
        }
        if(resumeAfterPause){
            resumeAfterPause=false;nativeStarted=true;
            return decision(false,false,false,true,false);
        }
        return none();
    }

    /** Failure/timeout never invents a pause acknowledgement or starts audio. */
    public synchronized boolean timeout(long expectedGeneration){
        if(generation!=expectedGeneration||owner!=Owner.NATIVE||!awaitingPause)return false;
        nativeActionPending=nativeStarted=resumeAfterPause=awaitingPause=false;
        resetPause();
        return true;
    }

    /** End the foreground scope; stale UI closures are invalidated. */
    public synchronized void clear(){
        generation++;owner=Owner.NONE;unresolvedStarts.clear();updateStartFence();
        spotifyMayBePlaying=false;playingSession=playingRevision=-1;
        nativeActionPending=nativeStarted=resumeAfterPause=awaitingPause=false;
        observedSession=highestPlayerRevision=-1;
        resetPause();
    }

    private void rememberRevision(long session,long revision){
        if(session!=observedSession){observedSession=session;highestPlayerRevision=revision;}
        else highestPlayerRevision=Math.max(highestPlayerRevision,revision);
    }
    private void updateStartFence(){
        spotifyStartPending=!unresolvedStarts.isEmpty();spotifyStartGeneration=-1;
        for(long value:unresolvedStarts)spotifyStartGeneration=value;
    }
    private void observeAudioRisk(long session,long revision,boolean playing,boolean loading){
        if(playing){spotifyMayBePlaying=true;playingSession=session;playingRevision=revision;}
        else if(!loading&&(!spotifyMayBePlaying||session!=playingSession||revision>playingRevision))
            spotifyMayBePlaying=false;
    }
    private void resetPause(){expectedSession=pauseBaseline=lastPauseSession=lastPauseRevision=-1;}
}
