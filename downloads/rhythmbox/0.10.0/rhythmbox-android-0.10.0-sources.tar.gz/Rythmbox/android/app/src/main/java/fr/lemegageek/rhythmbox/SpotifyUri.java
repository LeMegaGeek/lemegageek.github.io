package fr.lemegageek.rhythmbox;

import java.net.URI;
import java.util.regex.Pattern;

/** Strict Spotify music references; no networking, short-link expansion or scraping. */
public final class SpotifyUri {
    private static final Pattern ID=Pattern.compile("[A-Za-z0-9]{22}");
    private SpotifyUri(){}
    public static String parse(String value){
        if(value==null||value.length()>2048)throw invalid();
        String input=value.trim(),type,id;
        if(input.startsWith("spotify:")){
            String[] parts=input.split(":",-1);if(parts.length!=3)throw invalid();type=parts[1];id=parts[2];
        }else{
            final URI uri;try{uri=new URI(input);}catch(Exception error){throw invalid();}
            if(!"https".equals(uri.getScheme())||!"open.spotify.com".equals(uri.getHost())||uri.getRawUserInfo()!=null||uri.getPort()!=-1||uri.getRawFragment()!=null)throw invalid();
            String path=uri.getRawPath();if(path==null||path.contains("%"))throw invalid();
            String[] parts=path.split("/",-1);int first=parts.length==4&&parts[1].matches("intl-[a-z]{2}")?2:1;
            if(parts.length!=first+2)throw invalid();type=parts[first];id=parts[first+1];
        }
        if(!type.equals("track")&&!type.equals("album")&&!type.equals("playlist")&&!type.equals("artist"))throw invalid();
        if(!ID.matcher(id).matches())throw invalid();return "spotify:"+type+":"+id;
    }
    public static String link(String uri){return "https://open.spotify.com/"+parse(uri).substring(8).replace(':','/');}
    private static IllegalArgumentException invalid(){return new IllegalArgumentException("Utilise un lien open.spotify.com ou une URI Spotify de morceau, album, artiste ou playlist.");}
}
