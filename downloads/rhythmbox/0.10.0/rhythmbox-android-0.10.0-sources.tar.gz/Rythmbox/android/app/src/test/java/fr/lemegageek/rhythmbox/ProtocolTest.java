package fr.lemegageek.rhythmbox;

import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** Executable tests for wire validation and access boundaries; no Android runtime or network. */
public final class ProtocolTest {
    interface Check {void run() throws Exception;}
    static int checks=0;
    static void expectReject(Check check,String label) throws Exception {checks++;try{check.run();}catch(Exception expected){return;}throw new AssertionError("Accepted: "+label);}
    static void assertTrue(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
    static JSONObject fixture(String path) throws Exception{return new JSONObject(new String(Files.readAllBytes(Paths.get(path)),StandardCharsets.UTF_8));}
    static JSONObject revision(String id,String...parents) throws Exception{return new JSONObject().put("id",id).put("parents",new JSONArray(parents));}
    public static void main(String[] args) throws Exception {
        JSONObject base=fixture(args[0]);Library.validate(base);checks++;
        JSONObject arbitraryId=fixture(args[0]);arbitraryId.getJSONArray("playlists").getJSONObject(0).put("id","stable-id-from-pc");Library.validate(arbitraryId);checks++;
        JSONObject folder=fixture(args[0]);folder.getJSONArray("playlists").getJSONObject(0).getJSONArray("tracks").getJSONObject(0).put("media_path","Album/01 - Lumière.flac");Library.validate(folder);checks++;
        String percentPath="Chromeo 100%/11 100%.mp3";
        JSONObject percent=fixture(args[0]);percent.getJSONArray("playlists").getJSONObject(0).getJSONArray("tracks").getJSONObject(0).put("media_path",percentPath);
        byte[] percentKey=new byte[32];
        JSONObject percentRoundtrip=new JSONObject(new String(Crypto.open(percentKey,Crypto.seal(percentKey,percent.toString().getBytes(StandardCharsets.UTF_8))),StandardCharsets.UTF_8));
        Library.validate(percentRoundtrip);
        assertTrue(percentRoundtrip.getJSONArray("playlists").getJSONObject(0).getJSONArray("tracks").getJSONObject(0).getString("media_path").equals(percentPath),"literal percent survives encrypted wire roundtrip");
        for(String path:new String[]{"../outside.mp3","/absolute.mp3","album//song.mp3","album/%2e%2e/song","album/%252e%252e/song","album/a%2fb.mp3","https://outside.test/song"}){JSONObject invalid=fixture(args[0]);invalid.getJSONArray("playlists").getJSONObject(0).getJSONArray("tracks").getJSONObject(0).put("media_path",path);expectReject(()->Library.validate(invalid),"wire media_path");}
        JSONObject offset=fixture(args[0]).put("created","2026-10-28T08:00:00.123456+00:00");Library.validate(offset);checks++;
        JSONObject invalidDate=fixture(args[0]).put("created","not-a-date");expectReject(()->Library.validate(invalidDate),"invalid snapshot date");
        for(Object invalid:new Object[]{"123",123.0,0,-1,true}) {
            JSONObject bad=fixture(args[0]);bad.getJSONArray("playlists").getJSONObject(0).getJSONArray("tracks").getJSONObject(0).put("pcloud_fileid",invalid);
            expectReject(()->Library.validate(bad),"fileid type/range "+invalid);
        }
        JSONObject bad=fixture(args[0]);bad.getJSONArray("playlists").getJSONObject(0).getJSONArray("tracks").getJSONObject(0).put("uri","file:///private/example");
        expectReject(()->Library.validate(bad),"local URI field");
        JSONObject nul=fixture(args[0]);nul.getJSONArray("playlists").getJSONObject(0).put("name","nul\u0000byte");expectReject(()->Library.validate(nul),"NUL text");
        JSONObject count=fixture(args[0]);JSONArray huge=new JSONArray();JSONObject track=count.getJSONArray("playlists").getJSONObject(0).getJSONArray("tracks").getJSONObject(0);
        for(int i=0;i<25001;i++)huge.put(track);
        count.put("playlists",new JSONArray().put(new JSONObject().put("id","a").put("name","a").put("tracks",huge)).put(new JSONObject().put("id","b").put("name","b").put("tracks",huge)));
        expectReject(()->Library.validate(count),"total count across lists");
        assertTrue(SyncEngine.code("https://my.pcloud.com/#page=publink&code=Ab_cd-12").equals("Ab_cd-12"),"fragment code");
        assertTrue(SyncEngine.code("https://e.pcloud.link/publink/show?code=Abcd123").equals("Abcd123"),"regional public link");
        for(String input:new String[]{"https://pcloud.com.evil.test/?code=abcde","https://evilpcloud.com/?code=abcde","https://user@pcloud.com/?code=abcde","http://pcloud.com/?code=abcde","abc","abcde&auth=secret","https://pc.cd/abcde"})expectReject(()->SyncEngine.code(input),"untrusted capability "+input);
        assertTrue(SyncEngine.validatedDownload("c123.pcloud.com","/abc/file.mp3?download=1").getProtocol().equals("https"),"valid CDN");
        for(String host:new String[]{"pcloud.com.evil.test","localhost","127.0.0.1","c123.pcloud.com:443","c123.pcloud.com@evil.test"})expectReject(()->SyncEngine.validatedDownload(host,"/file"),"untrusted CDN");
        for(String path:new String[]{"//evil.test/file","/foo\\evil","/foo\r\nLocation: x","/foo#fragment","relative/file"})expectReject(()->SyncEngine.validatedDownload("c123.pcloud.com",path),"unsafe path");
        JSONObject config=new JSONObject().put("region","eu").put("read_code","abcde").put("upload_code","fghij").put("key",java.util.Base64.getEncoder().encodeToString(new byte[32]));
        new SyncEngine(config).validateConfig();checks++;
        Map<String,JSONObject> graph=new LinkedHashMap<>();String a=UUID.randomUUID().toString(),b=UUID.randomUUID().toString(),c=UUID.randomUUID().toString();
        SyncEngine.addSnapshot(graph,revision(a));SyncEngine.addSnapshot(graph,revision(b,a));assertTrue(SyncEngine.historyHeads(graph).size()==1,"linear history");
        SyncEngine.addSnapshot(graph,revision(c,a));assertTrue(SyncEngine.historyHeads(graph).size()==2,"concurrent heads preserved");
        expectReject(()->SyncEngine.addSnapshot(graph,revision(a,b)),"duplicate divergent id");
        graph.put(a,revision(a,a));expectReject(()->SyncEngine.historyHeads(graph),"self parent under valid other heads");
        graph.clear();graph.put(a,revision(a,b));graph.put(b,revision(b,a));graph.put(c,revision(c));expectReject(()->SyncEngine.historyHeads(graph),"cycle under unrelated head");
        expectReject(()->Crypto.open(new byte[32],new byte[8*1024*1024+1]),"oversized envelope");
        System.out.println("PASS : "+checks+" protocol/security assertions (validation, capabilities, CDN, history)");
    }
}
