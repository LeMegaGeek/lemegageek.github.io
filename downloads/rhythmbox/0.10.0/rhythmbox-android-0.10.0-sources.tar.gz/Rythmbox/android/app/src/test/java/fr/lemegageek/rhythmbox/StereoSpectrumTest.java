package fr.lemegageek.rhythmbox;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public final class StereoSpectrumTest {
    private static int assertions;
    private static void check(boolean value, String label) {
        assertions++;
        if (!value) throw new AssertionError(label);
    }
    private static ByteBuffer tone(int frames, int channels, boolean floating) {
        ByteBuffer pcm = ByteBuffer.allocate(frames * channels * (floating ? 4 : 2))
            .order(ByteOrder.LITTLE_ENDIAN);
        for (int frame = 0; frame < frames; frame++) {
            double l = .5 * Math.sin(2 * Math.PI * 468.75 * frame / 48000);
            double r = .125 * Math.sin(2 * Math.PI * 3000 * frame / 48000);
            if (floating) { pcm.putFloat((float) l); if (channels == 2) pcm.putFloat((float) r); }
            else { pcm.putShort((short) Math.round(l * 32767)); if (channels == 2) pcm.putShort((short) Math.round(r * 32767)); }
        }
        return (ByteBuffer) pcm.flip();
    }
    public static void main(String[] args) {
        for (boolean floating : new boolean[]{false, true}) {
            StereoSpectrum meter = new StereoSpectrum(48000, 2);
            check(!meter.atFrame(0).available, "no fabricated initial spectrum");
            ByteBuffer pcm = tone(8192, 2, floating);
            if (floating) meter.acceptPcmFloat(pcm); else meter.acceptPcm16(pcm);
            check(!meter.atFrame(2047).available, "queued future PCM is not displayed");
            StereoSpectrum.Snapshot first = meter.atFrame(2048);
            check(first.available && first.framePosition == 2048, "first played window");
            StereoSpectrum.Snapshot result = meter.atFrame(8192);
            check(result.channels == 2 && result.sampleRate == 48000, "stereo format retained");
            check(Math.abs(result.leftDominantHz - 468.75) < 1, "left frequency remains independent");
            check(Math.abs(result.rightDominantHz - 3000) < 1, "right frequency remains independent");
            check(Math.abs(result.leftRmsDb + 9.0309) < .02, "left RMS calibrated");
            check(Math.abs((result.leftRmsDb - result.rightRmsDb) - 12.0412) < .02,
                  "independent levels retain 12 dB difference");
            check(Math.abs(result.leftPeakDb + 6.0206) < .02, "peak calibrated");
            float[] bands = result.leftBands(); bands[0] = 999;
            check(result.leftBands()[0] != 999, "snapshot arrays immutable to consumers");
            float[] centers = result.bandCentersHz();
            check(centers.length == StereoSpectrum.BAND_COUNT && centers[0] > 20 && centers[31] < 20000,
                  "bounded logarithmic frequency scale");
            meter.reset();
            check(!meter.atFrame(100000).available, "seek reset discards old measurements");
        }
        StereoSpectrum mono = new StereoSpectrum(48000, 1);
        mono.acceptPcm16(tone(4096, 1, false));
        StereoSpectrum.Snapshot value = mono.atFrame(4096);
        check(value.channels == 1 && value.leftRmsDb == value.rightRmsDb, "mono is declared, not invented stereo");
        check(value.leftDominantHz == value.rightDominantHz, "mono duplication is exact");
        StereoSpectrum silence = new StereoSpectrum(48000, 2);
        silence.acceptPcm16(ByteBuffer.allocate(8192));
        check(silence.atFrame(2048).leftRmsDb == StereoSpectrum.FLOOR_DB, "silence remains at floor");
        check(silence.atFrame(2048).leftDominantHz == 0, "silence has no invented frequency");
        boolean invalid = false;
        try { silence.acceptPcmFloat((ByteBuffer) ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putFloat(Float.NaN).putFloat(0).flip()); }
        catch (IllegalArgumentException expected) { invalid = true; }
        check(invalid, "non-finite source PCM rejected");
        StereoSpectrum opposite = new StereoSpectrum(48000, 2);
        ByteBuffer phase = ByteBuffer.allocate(4096 * 8).order(ByteOrder.LITTLE_ENDIAN);
        for (int i = 0; i < 4096; i++) {
            float sample = (float) (.3 * Math.sin(2 * Math.PI * 1500 * i / 48000));
            phase.putFloat(sample).putFloat(-sample);
        }
        opposite.acceptPcmFloat((ByteBuffer) phase.flip());
        StereoSpectrum.Snapshot antiPhase = opposite.atFrame(4096);
        check(antiPhase.leftRmsDb > -15 && antiPhase.rightRmsDb > -15,
              "opposite phases are never cancelled by a mono mix");
        check(Math.abs(antiPhase.leftRmsDb - antiPhase.rightRmsDb) < .001,
              "equal opposite phases retain both channel levels");
        check(Math.abs(antiPhase.leftDominantHz - 1500) < 1 && antiPhase.rightDominantHz == antiPhase.leftDominantHz,
              "both phase-opposite spectra remain measurable");
        StereoSpectrum oneSide = new StereoSpectrum(48000, 2);
        ByteBuffer isolated = ByteBuffer.allocate(4096 * 8).order(ByteOrder.LITTLE_ENDIAN);
        for (int i = 0; i < 4096; i++)
            isolated.putFloat(0).putFloat((float) (.2 * Math.sin(2 * Math.PI * 3000 * i / 48000)));
        oneSide.acceptPcmFloat((ByteBuffer) isolated.flip());
        check(oneSide.atFrame(4096).leftRmsDb == StereoSpectrum.FLOOR_DB, "right signal never leaks into left RMS");
        check(oneSide.atFrame(4096).rightRmsDb > -20, "right-only signal remains present");
        // Regression: at 48 kHz these narrow log bands contain no integer FFT
        // bin. Each must still measure an actual tone centred in its passband.
        for (int band : new int[]{1, 2, 4}) {
            StereoSpectrum bass = new StereoSpectrum(48000, 2);
            bass.acceptPcmFloat(ByteBuffer.allocate(StereoSpectrum.FFT_SIZE * 8));
            float frequency = bass.atFrame(StereoSpectrum.FFT_SIZE).bandCentersHz()[band];
            bass.reset();
            ByteBuffer lowTone = ByteBuffer.allocate(StereoSpectrum.FFT_SIZE * 8).order(ByteOrder.LITTLE_ENDIAN);
            for (int i = 0; i < StereoSpectrum.FFT_SIZE; i++)
                lowTone.putFloat((float) (.5 * Math.sin(2 * Math.PI * frequency * i / 48000))).putFloat(0);
            bass.acceptPcmFloat((ByteBuffer) lowTone.flip());
            StereoSpectrum.Snapshot measured = bass.atFrame(StereoSpectrum.FFT_SIZE);
            check(Math.abs(measured.leftBands()[band] + 6.0206) < 1,
                  "bass bar " + (band + 1) + " measures its real half-scale tone");
            check(measured.rightBands()[band] == StereoSpectrum.FLOOR_DB,
                  "bass measurement never invents a signal in the silent channel");
        }
        // A centred impulse has energy throughout the displayed range. No band
        // may be permanently empty, including at the highest accepted rate.
        for (int rate : new int[]{8000, 44100, 48000, 96000, 192000}) {
            StereoSpectrum broadband = new StereoSpectrum(rate, 2);
            ByteBuffer impulse = ByteBuffer.allocate(StereoSpectrum.FFT_SIZE * 8).order(ByteOrder.LITTLE_ENDIAN);
            for (int i = 0; i < StereoSpectrum.FFT_SIZE; i++)
                impulse.putFloat(i == StereoSpectrum.FFT_SIZE / 2 ? .5f : 0).putFloat(0);
            broadband.acceptPcmFloat((ByteBuffer) impulse.flip());
            StereoSpectrum.Snapshot measured = broadband.atFrame(StereoSpectrum.FFT_SIZE);
            for (int band = 0; band < StereoSpectrum.BAND_COUNT; band++) {
                check(measured.leftBands()[band] > -70,
                      "broadband impulse reaches bar " + (band + 1) + " at " + rate + " Hz");
                check(measured.rightBands()[band] == StereoSpectrum.FLOOR_DB,
                      "silent channel stays silent in every band at " + rate + " Hz");
            }
            broadband.reset();
            broadband.acceptPcmFloat(ByteBuffer.allocate(StereoSpectrum.FFT_SIZE * 8));
            for (float band : broadband.atFrame(StereoSpectrum.FFT_SIZE).leftBands())
                check(band == StereoSpectrum.FLOOR_DB, "no residual or fabricated bass after silence reset");
        }
        System.out.println("PASS " + assertions + " stereo PCM assertions");
    }
}
