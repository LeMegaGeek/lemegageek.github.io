#!/usr/bin/env bash
set -euo pipefail
rbx_suno_android="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$rbx_suno_android/.."
rbx_suno_json="${RBX_JSON_TEST_JAR:-$rbx_suno_android/.toolchain/json-test.jar}"
rbx_suno_platform="${RBX_ANDROID_PLATFORM:-$rbx_suno_android/.toolchain/android-36/android.jar}"
rbx_suno_output="$rbx_suno_android/build/suno-audio-host-tests"
mkdir -p "$rbx_suno_output"
/usr/bin/python3 scripts/generate_suno_audio_fixture.py "$rbx_suno_output/fixture.json"
javac --release 8 -Xlint:-options -encoding UTF-8 -classpath "$rbx_suno_json:$rbx_suno_platform" -d "$rbx_suno_output" \
  android/app/src/main/java/fr/lemegageek/rhythmbox/SunoAudio.java \
  android/app/src/main/java/fr/lemegageek/rhythmbox/SunoMediaDataSource.java \
  android/app/src/test/java/fr/lemegageek/rhythmbox/SunoAudioTest.java
java -cp "$rbx_suno_output:$rbx_suno_json" fr.lemegageek.rhythmbox.SunoAudioTest "$rbx_suno_output/fixture.json"
