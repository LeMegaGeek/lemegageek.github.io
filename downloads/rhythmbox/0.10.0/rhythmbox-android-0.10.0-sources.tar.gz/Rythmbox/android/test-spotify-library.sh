#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
test_dir=build/spotify-library-host-tests
src=app/src/main/java/fr/lemegageek/rhythmbox
mkdir -p "$test_dir"
json_jar="${RBX_JSON_TEST_JAR:-.toolchain/json-test.jar}"
javac --release 8 -Xlint:-options -encoding UTF-8 -classpath "$json_jar" -d "$test_dir" "$src/SpotifyLibraryProtocol.java" app/src/test/java/fr/lemegageek/rhythmbox/SpotifyLibraryProtocolTest.java
java -cp "$test_dir:$json_jar" fr.lemegageek.rhythmbox.SpotifyLibraryProtocolTest
