#!/usr/bin/env bash
set -euo pipefail
rbx_android_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$rbx_android_dir"
rbx_json_jar="${RBX_JSON_TEST_JAR:-$rbx_android_dir/.toolchain/json-test.jar}"
if [[ ! -f "$rbx_json_jar" ]]; then
  printf '%s\n' 'Préparer le JAR org.json avec prepare-toolchain.sh ou RBX_JSON_TEST_JAR.' >&2
  exit 1
fi
mkdir -p build/pcloud-native-host-tests
javac --release 8 -Xlint:-options -encoding UTF-8 -classpath "$rbx_json_jar" -d build/pcloud-native-host-tests \
  app/src/main/java/fr/lemegageek/rhythmbox/PCloudAccount.java \
  app/src/main/java/fr/lemegageek/rhythmbox/PCloudFolderSelection.java \
  app/src/main/java/fr/lemegageek/rhythmbox/FolderProtocol.java \
  app/src/main/java/fr/lemegageek/rhythmbox/PCloudCollections.java \
  app/src/main/java/fr/lemegageek/rhythmbox/PCloudAudioCache.java \
  app/src/main/java/fr/lemegageek/rhythmbox/PCloudOfflineSelection.java \
  app/src/main/java/fr/lemegageek/rhythmbox/PCloudNativeSync.java \
  app/src/main/java/fr/lemegageek/rhythmbox/MediaOrigin.java \
  app/src/test/java/fr/lemegageek/rhythmbox/MediaOriginTest.java \
  app/src/test/java/fr/lemegageek/rhythmbox/PCloudCollectionsTest.java \
  app/src/test/java/fr/lemegageek/rhythmbox/PCloudFolderSelectionTest.java \
  app/src/test/java/fr/lemegageek/rhythmbox/PCloudVideoSyncTest.java
java -cp "build/pcloud-native-host-tests:$rbx_json_jar" fr.lemegageek.rhythmbox.PCloudCollectionsTest
java -cp "build/pcloud-native-host-tests:$rbx_json_jar" fr.lemegageek.rhythmbox.PCloudFolderSelectionTest
java -cp "build/pcloud-native-host-tests:$rbx_json_jar" fr.lemegageek.rhythmbox.PCloudVideoSyncTest
java -cp "build/pcloud-native-host-tests:$rbx_json_jar" fr.lemegageek.rhythmbox.MediaOriginTest
rbx_platform="${RBX_ANDROID_PLATFORM:-$rbx_android_dir/.toolchain/android-36/android.jar}"
javac --release 8 -Xlint:-options -encoding UTF-8 -classpath "$rbx_json_jar:$rbx_platform:build/pcloud-native-host-tests" -d build/pcloud-native-host-tests \
  app/src/main/java/fr/lemegageek/rhythmbox/Library.java \
  app/src/main/java/fr/lemegageek/rhythmbox/SecretStore.java \
  app/src/main/java/fr/lemegageek/rhythmbox/PCloudAccountStore.java \
  app/src/main/java/fr/lemegageek/rhythmbox/PCloudOAuthProtocol.java \
  app/src/main/java/fr/lemegageek/rhythmbox/PCloudSyncController.java \
  app/src/main/java/fr/lemegageek/rhythmbox/PCloudSyncJobService.java \
  app/src/main/java/fr/lemegageek/rhythmbox/PCloudOfflineAudio.java \
  app/src/main/java/fr/lemegageek/rhythmbox/PCloudSyncBootReceiver.java \
  app/src/test/java/fr/lemegageek/rhythmbox/PCloudSyncControllerTest.java
java -cp "build/pcloud-native-host-tests:$rbx_json_jar:$rbx_platform" fr.lemegageek.rhythmbox.PCloudSyncControllerTest
