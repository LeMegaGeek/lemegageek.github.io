#!/usr/bin/env bash
set -euo pipefail
rbx_android_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$rbx_android_dir"
rbx_output="build/playback-ownership-host-tests"
mkdir -p "$rbx_output"
javac --release 8 -Xlint:-options -encoding UTF-8 -d "$rbx_output" \
  app/src/main/java/fr/lemegageek/rhythmbox/PlaybackOwnership.java \
  app/src/test/java/fr/lemegageek/rhythmbox/PlaybackOwnershipTest.java
java -cp "$rbx_output" fr.lemegageek.rhythmbox.PlaybackOwnershipTest
