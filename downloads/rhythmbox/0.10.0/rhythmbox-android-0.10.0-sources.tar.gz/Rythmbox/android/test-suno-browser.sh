#!/usr/bin/env bash
set -euo pipefail
rbx_suno_browser_root="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$rbx_suno_browser_root"
rbx_suno_browser_json="${RBX_JSON_TEST_JAR:-$rbx_suno_browser_root/.toolchain/json-test.jar}"
mkdir -p build/suno-browser-host-tests
javac --release 8 -encoding UTF-8 -classpath "$rbx_suno_browser_json" -d build/suno-browser-host-tests \
  app/src/main/java/fr/lemegageek/rhythmbox/SunoCatalog.java \
  app/src/main/java/fr/lemegageek/rhythmbox/SunoShare.java \
  app/src/main/java/fr/lemegageek/rhythmbox/SunoBrowserProtocol.java \
  app/src/main/java/fr/lemegageek/rhythmbox/SpotifyUri.java \
  app/src/main/java/fr/lemegageek/rhythmbox/SharedMusic.java \
  app/src/test/java/fr/lemegageek/rhythmbox/SharedMusicTest.java \
  app/src/test/java/fr/lemegageek/rhythmbox/SunoBrowserProtocolTest.java
java -cp "build/suno-browser-host-tests:$rbx_suno_browser_json" fr.lemegageek.rhythmbox.SunoBrowserProtocolTest
java -cp "build/suno-browser-host-tests:$rbx_suno_browser_json" fr.lemegageek.rhythmbox.SharedMusicTest
