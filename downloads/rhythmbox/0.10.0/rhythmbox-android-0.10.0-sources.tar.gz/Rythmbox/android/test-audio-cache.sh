#!/usr/bin/env bash
set -euo pipefail
rbx_audio_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$rbx_audio_dir"
rbx_audio_json="${RBX_JSON_TEST_JAR:-$rbx_audio_dir/.toolchain/json-test.jar}"
rbx_audio_stage="$(mktemp -d /tmp/rb-audio-cache-host-XXXXXX)"
javac --release 8 -Xlint:-options -encoding UTF-8 -classpath "$rbx_audio_json" -d "$rbx_audio_stage" \
  app/src/main/java/fr/lemegageek/rhythmbox/PCloudAccount.java \
  app/src/main/java/fr/lemegageek/rhythmbox/FolderProtocol.java \
  app/src/main/java/fr/lemegageek/rhythmbox/PCloudCollections.java \
  app/src/main/java/fr/lemegageek/rhythmbox/PCloudNativeSync.java \
  app/src/main/java/fr/lemegageek/rhythmbox/PCloudAudioCache.java \
  app/src/main/java/fr/lemegageek/rhythmbox/PCloudOfflineSelection.java \
  app/src/test/java/fr/lemegageek/rhythmbox/PCloudCollectionsTest.java \
  app/src/test/java/fr/lemegageek/rhythmbox/PCloudAudioCacheTest.java \
  app/src/test/java/fr/lemegageek/rhythmbox/PCloudAudioConcurrencyTest.java
java -cp "$rbx_audio_stage:$rbx_audio_json" fr.lemegageek.rhythmbox.PCloudCollectionsTest
java -cp "$rbx_audio_stage:$rbx_audio_json" fr.lemegageek.rhythmbox.PCloudAudioCacheTest
java -cp "$rbx_audio_stage:$rbx_audio_json" fr.lemegageek.rhythmbox.PCloudAudioConcurrencyTest
rbx_offline_stage="$rbx_audio_stage/offline-provider"
mkdir "$rbx_offline_stage"
mapfile -t rbx_offline_fixtures < <(rg --files app/src/offlineHostTest/java -g '*.java' | sort)
javac --release 8 -Xlint:-options -encoding UTF-8 -classpath "$rbx_audio_stage:$rbx_audio_json" -d "$rbx_offline_stage" \
  "${rbx_offline_fixtures[@]}" app/src/main/java/fr/lemegageek/rhythmbox/MediaOrigin.java \
  app/src/main/java/fr/lemegageek/rhythmbox/PCloudOfflineAudio.java app/src/main/java/fr/lemegageek/rhythmbox/SyncConnection.java
java -cp "$rbx_offline_stage:$rbx_audio_stage:$rbx_audio_json" fr.lemegageek.rhythmbox.PCloudOfflineAudioHostTest
printf 'Audio cache test classes: %s\n' "$rbx_audio_stage"
