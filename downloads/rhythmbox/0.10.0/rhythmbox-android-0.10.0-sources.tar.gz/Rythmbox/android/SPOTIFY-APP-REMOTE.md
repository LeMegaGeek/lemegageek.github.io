# Spotify Android App Remote — 0.9.0 / code 18

Rhythmbox commande l’application Spotify officielle installée sur le même
appareil. Le SDK **App Remote 0.8.0** est réellement compilé et inclus dans le
DEX, avec **Gson 2.11.0**. Il ne s’agit ni d’une imitation du SDK, ni d’une
WebView, ni d’un client audio Spotify non officiel. La bibliothèque, les listes
pCloud, le cache et le lecteur PCM de Rhythmbox restent indépendants.

## Enregistrement préalable

L'application **Rhythmbox Musique LeMegaGeek** utilise le Client ID public `f1bd3215379f4fb0a3bd88e96443b78e`, sans Client Secret dans l'APK. La 0.9.0 change d'identité Android :

- paquet et espace de noms : `fr.lemegageek.rhythmbox` ;
- redirection exacte : `fr.lemegageek.rhythmbox://spotify-callback` ;
- empreinte SHA-1 de la signature réellement distribuée, distincte selon APK debug, APK signé localement et éventuelle distribution Google Play.

Le 4 novembre 2026, le tableau de bord Spotify a confirmé la nouvelle redirection et deux signatures pour `fr.lemegageek.rhythmbox` : APK de livraison `EC:E6:46:DB:A7:58:A9:D2:0F:1A:67:A2:72:CC:C7:C5:78:3A:E5:74` et debug existant `18:C6:EB:AF:C2:D2:EB:2E:7D:FA:DF:E2:A9:E2:A4:0F:CF:FC:1F:11`. Aucun droit supplémentaire du compte n’a été demandé. La connexion physique du nouveau paquet doit être validée séparément ; les preuves historiques de `fr.denis.rhythmbox` ne suffisent pas à la prouver. L’enregistrement reste en mode Développement et les utilisateurs admis chez Spotify sont distincts des testeurs Google Play. Une future distribution Google Play doit conserver la signature de cette nouvelle identité ou enregistrer explicitement sa nouvelle empreinte.

Le Client ID peut être fourni dans la ressource `spotify_app_remote_client_id` ou dans **Services → Spotify → Configuration App Remote…**. Aucun mot de passe, cookie ou jeton Spotify n'est demandé par le code original de Rhythmbox. Le SDK gère l'autorisation avec l'application officielle installée.

Voir [le guide officiel](https://developer.spotify.com/documentation/android/tutorials/getting-started) et [les empreintes](https://developer.spotify.com/documentation/android/tutorials/application-fingerprints). Les sections de validation ci-dessous conservent les limites et preuves des versions antérieures.

## Utilisation et garanties techniques

**Lire un lien Spotify…** accepte les liens HTTPS `open.spotify.com` de morceau,
album, artiste et playlist, ainsi que les URI `spotify:…` correspondantes. Les
identifiants sont validés et les paramètres de suivi sont retirés. Les liens
courts, redirections, domaines ressemblants et références non musicales sont
refusés ; aucune page du catalogue n’est aspirée. La lecture d’un morceau précis
est autorisée seulement quand `UserApi` annonce `canPlayOnDemand`. Les autres
contextes restent soumis aux restrictions appliquées par Spotify.

Les commandes communes proposent lecture/pause, précédent/suivant, position,
shuffle et répétition lorsque le SDK annonce ces capacités. Le titre, l’artiste,
l’album, la position et la pochette viennent des abonnements `PlayerState` et
`ImagesApi`. Une commande envoyée ou son résultat RPC ne suffit pas à annoncer
une lecture : seul l’état observé le confirme. Les anciens callbacks, connexions
ou images ne peuvent pas remplacer l’état d’une nouvelle session.

Un lancement Spotify demandé suspend d’abord le lecteur natif. Un lancement
natif attend un nouvel état PlayerState confirmant la pause Spotify ; un simple message de commande, une pochette ou une actualisation des capacités ne suffit pas. Une commande Spotify encore en vol est prise en compte même si l’ancien état affiche une pause. Un ancien événement de lecture ne peut pas voler la place d’un choix natif plus récent : Spotify est remis en pause et la file native est conservée avec sa position ou son chargement en cours. L’observation
d’une lecture Spotify suspend la lecture native quand l’activité Rhythmbox est
active. **Ce contrôle n’est pas une surveillance permanente de Spotify lorsque
l’interface Rhythmbox n’est plus active.** Le passage en arrière-plan déconnecte
le SDK sans envoyer une pause implicite — notamment pendant la confirmation
Spotify. L’application Spotify peut continuer sa lecture indépendamment.

Aucun accès Android aux notifications n’est nécessaire dans cette version. Le
service historique n’est plus déclaré ni compilé dans l’application principale.
Les fixtures MediaSession sous `spotifyFrameworkTest` restent des tests
historiques isolés de la 0.7, pas des preuves du nouveau SDK.

Spotify assure le décodage, le réseau, son cache, ses téléchargements, la qualité
et ses traitements audio. Rhythmbox ne reçoit pas son PCM, ne télécharge pas ses
morceaux et ne lui applique ni analyseur stéréo ni normalisation. L’analyseur
Rhythmbox reste réservé à son propre lecteur natif. L’usage du SDK ne dispense
pas de respecter les [conditions Spotify](https://developer.spotify.com/terms)
et la [politique développeur](https://developer.spotify.com/policy).

## Dépendances, licences et reproductibilité

Exécuter `bash android/prepare-spotify.sh` depuis la racine, puis les commandes de
build habituelles. `spotify-dependencies.json` épingle les URL officielles et les
SHA-256. Le téléchargement et chaque build vérifient les octets ; l’extraction
borne le seul `classes.jar` de l’AAR. Les fichiers restent sous `.toolchain/`,
exclus des archives de sources. Le build ne télécharge pas silencieusement une
nouvelle version.

Les textes LICENSE/NOTICE du tag officiel Spotify et la licence Apache 2.0 de
Gson sont conservés dans les assets `third-party-licenses/`, accessibles dans
**Réglages → Licences Spotify SDK et Gson**. Ils sont inclus dans l’APK et les
sources. Le code original de Rhythmbox conserve GPL-2.0-or-later ; ces notices ne
relicencient pas le SDK. Les conditions du service Spotify restent distinctes.
L’archive de sources inclut le verrou, le script de récupération et nos sources ;
elle ne prétend pas contenir les sources internes du binaire App Remote.

## Validation

`bash android/test-spotify-controller.sh` compile contre le véritable SDK et
vérifie la machine d’état avec des frontières de compte et Android simulées :
consentement explicite, reconnexion silencieuse, absence de configuration,
application absente, callbacks tardifs, capacités, URI, refus et positions. Des
objets réels `PlayerState`, `Track`, `PlayerRestrictions` du SDK vérifient aussi
la correspondance des modèles, y compris les capacités reçues avant le premier
morceau et l’ancrage de position conservé pendant le chargement d’image.

Ces tests hôtes et un APK compilé ne prouvent pas la connexion au vrai compte
Spotify ni la lecture sur le Motorola. Cette preuve doit être obtenue après
enregistrement des bons Client ID et empreintes. Aucun téléphone n’a été
réinitialisé, désinstallé ou modifié pour ces tests.

## Réconciliation des commandes — 0.8.1

Un échec asynchrone du SDK peut être une réponse perdue après un envoi. Il ne
constitue donc ni un refus certain de démarrer, ni une confirmation de pause.
Les commandes pouvant démarrer Spotify portent désormais un callback propre à
l’intention utilisateur. Après leur échec, Rhythmbox demande un véritable
`PlayerApi.getPlayerState()` avant de solder le risque correspondant. Une
réponse absente, inchangée, d’une ancienne connexion ou antérieure à une nouvelle
commande ne peut pas déverrouiller la lecture native. Les lectures concurrentes
sont ordonnées et ne remplacent pas les données d’abonnement du SDK avant
validation ; leurs révisions sont distinctes des révisions d’images/capacités.

Une pause réussie est également vérifiée par cette lecture officielle, même si
Spotify ne réémet pas une notification pour une pause sans changement. Les
risques de démarrage sont suivis par intention : un nouvel essai refusé avant
envoi n’efface pas une commande antérieure dont l’issue reste inconnue. Choisir
successivement deux morceaux natifs, annuler une attente ou perdre la connexion
SDK ne prouve pas que Spotify est arrêté. Le dernier état Playing connu est
conservé jusqu’à un état Paused réel plus récent dans le périmètre d’interaction
au premier plan ; les limites d’arrière-plan indiquées plus haut restent valables.

Le script existant `test-spotify-controller.sh` exécute aussi
`SpotifyOwnershipTest`, qui compose les véritables Controller et Ownership avec
des callbacks SDK contrôlés : URI/reprise, commande de mode intercalée, lectures
périmées, événements Playing/Paused tardifs, choix natifs A/B, perte de contrôle,
refus préflight, arrêt/navigation et exception de transport après envoi. Les
contrôles hôtes ciblés passent (91 Controller, 42 jonction, 39 Ownership). Ils ne
remplacent pas les essais de connexion et de lecture avec le vrai compte.
