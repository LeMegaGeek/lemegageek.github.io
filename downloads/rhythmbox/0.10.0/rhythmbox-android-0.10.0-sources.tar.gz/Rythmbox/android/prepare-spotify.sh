#!/usr/bin/env bash
set -euo pipefail
rbx_android_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
python3 "$rbx_android_dir/../scripts/android_spotify_dependencies.py" --fetch
