# Spotify — version 0.8.1

La lecture reste assurée par les logiciels officiels Spotify. Rhythmbox apporte
sa barre de lecture et affiche leurs métadonnées ; aucun mot de passe Spotify
n'est demandé dans Rhythmbox. Les listes Spotify ne sont pas exportées vers
pCloud et les morceaux Spotify ne sont pas téléchargés par notre cache musical.

## Linux : Soloist

Installer le binaire de son architecture depuis la
[page officielle de téléchargement](https://developer.spotify.com/documentation/soloist/reference/downloads-and-updates),
par exemple dans `~/.local/bin/soloist`. Le binaire Spotify est séparé des
archives de Rhythmbox : nous ne le redistribuons pas.

Dans **Spotify → Réglages**, saisir sa clé personnelle
obtenue sur [Spotify for Developers](https://developer.spotify.com/dashboard/soloist).
Spotify Premium est requis pour créer cette clé. **Enregistrer la clé dans le
trousseau** utilise Secret Service ; l'absence ou le verrouillage du trousseau
ne provoque aucun enregistrement en clair. Ne pas mettre cette clé dans un
rapport, un dépôt ou un message.

Cliquer **Démarrer Spotify**. Au premier appairage, ouvrir l'application Spotify
officielle sur le même réseau et sélectionner l'appareil **Rhythmbox Musique**.
Revenir ensuite dans Rhythmbox et utiliser la barre commune. La page Spotify
affiche la file de lecture courante, avec ses morceaux précédents et suivants,
sans autorisation Web API supplémentaire. Les paramètres restent dans la
fenêtre **Réglages**. **Lire un lien** permet aussi d'ouvrir un morceau, album
ou playlist Spotify dans Soloist.

### Playlists et bibliothèque Spotify

**Connecter ma bibliothèque** ouvre le consentement officiel Spotify. Ce
parcours est distinct de la clé Soloist et sert uniquement à afficher les
playlists, titres aimés, albums enregistrés et résultats de recherche. Choisir
une liste à gauche puis un morceau dans le tableau permet de le lire avec
Soloist, piloté par la barre du bas de Rhythmbox.

Les seuls accès demandés sont `playlist-read-private`,
`playlist-read-collaborative` et `user-library-read`. Aucun droit de modification
des listes ni de pilotage Web API n'est demandé. Le jeton est conservé dans un
élément propre du trousseau Secret Service ; aucun cookie de navigateur, jeton
d'un autre logiciel ou Client Secret n'est copié. **Déconnecter ma bibliothèque**
retire cet élément local. Une révocation côté Spotify peut se faire depuis les
applications autorisées du compte.

L'enregistrement public utilise le Client ID
`f1bd3215379f4fb0a3bd88e96443b78e` et le retour exact
`http://127.0.0.1:8766/spotify/callback`. OAuth utilise PKCE et une valeur
`state` unique ; le récepteur n'écoute que sur la boucle locale pendant la
connexion. Un port occupé produit un message explicite au lieu d'utiliser un
retour non enregistré. La connexion se fait hors du thread de l'interface.

L'application Spotify est actuellement en mode développement : le compte doit
être admis dans son enregistrement développeur. L'API Spotify actuelle réserve
la lecture des éléments d'une playlist à son propriétaire ou à ses
collaborateurs. Une playlist suivie peut donc apparaître sans que l'API
autorise l'affichage de ses morceaux ; elle reste ouvrable dans Soloist.
L'interface signale cette limitation sans prétendre qu'une liste refusée est
vide.

Soloist conserve sa session dans `~/.local/share/rhythmbox/spotify-soloist/`.
Son cache distinct est limité à 512 Mio dans
`~/.cache/rhythmbox/spotify-soloist/`. La fermeture du greffon termine uniquement
le processus Soloist qu'il a lancé, ce qui coupe son son sans arrêter un autre
client Spotify. La lecture d'un état ne démarre jamais le lecteur.

Le protocole WebSocket écoute uniquement sur `127.0.0.1`, sur un port attribué
par le système. Il n'est pas exposé sur le réseau. Le protocole officiel ne
possède pas d'authentification client intégrée ; l'adresse locale ne constitue
pas une isolation contre les autres processus du même utilisateur.

Le CLI Soloist actuel n'accepte sa clé qu'avec `--api-key` : elle peut donc être
visible dans les arguments du processus par un outil disposant des droits
nécessaires. Rhythmbox n'enregistre pas cette ligne de commande ni les messages
bruts du processus. Les nouvelles versions du binaire peuvent être exigées par
Spotify ; le code de sortie 10 demande une mise à jour depuis leur site.

## Android : App Remote — identité LeMegaGeek 0.9.0

La 0.8.0 embarque le SDK officiel **Spotify App Remote 0.8.0** et Gson 2.11.0.
Installer et connecter l'application Spotify officielle du téléphone. Le
nouveau parcours n'utilise plus l'accès global aux notifications Android.
Une ancienne autorisation éventuelle peut être retirée dans Android ; Rhythmbox
ne modifie pas lui-même les autorisations du téléphone.

L’identité Android 0.9.0 est distincte de l’ancien paquet ; les données de celui-ci restent conservées. L’enregistrement développeur de Rhythmbox doit déclarer :

- l'API/SDK **Android** ;
- le retour exact `fr.lemegageek.rhythmbox://spotify-callback` ;
- le package `fr.lemegageek.rhythmbox` et les empreintes SHA-1 des signatures des
  installations autorisées. La signature Google Play est différente de la clé
  d'upload et de la clé debug.

Seul le **Client ID public** est configuré dans l'application. Aucun Client
Secret ne doit être intégré dans une application Android. Si l'enregistrement
n'est pas configuré, l'interface indique ce prérequis au lieu d'annoncer une
connexion réussie.

Dans **Services → Spotify**, lancer la connexion officielle App Remote et
confirmer le consentement dans Spotify. Rhythmbox peut ensuite envoyer un lien
Spotify et recevoir les changements d'état, la position, la pochette et les
capacités. Les boutons indisponibles restent désactivés. Les restrictions Free
ou Premium restent celles de Spotify. Le SDK ne retourne pas de jeton Web API à
Rhythmbox dans ce parcours.

Les abonnements à l'état sont détachés lorsque l'activité s'arrête ; le retour
à l'application tente une reconnexion silencieuse après un consentement
explicite. Une révocation ou une session expirée exige une nouvelle connexion
officielle. Ne pas confondre une demande envoyée et une lecture confirmée : le
lecteur natif attend la confirmation de pause Spotify avant de démarrer.

## Audio, distribution et validation

Les deux intégrations officielles ne fournissent pas de PCM à Rhythmbox.
Sous Linux, la 0.8.1 ajoute un analyseur à partir du seul flux de sortie système
du processus Soloist lancé par Rhythmbox. Les mesures gauche/droite sont calculées
en mémoire ; aucun fichier audio n'est enregistré. L'identité du processus et
les deux canaux doivent être vérifiés avant de publier les mesures. L'absence
de signal valide laisse l'analyseur indisponible, sans animation simulée.
Ce parcours exige PipeWire ou PulseAudio et leurs outils de capture par flux.
Il ne capture ni le microphone ni le mélange des autres applications.

Sur Android, App Remote reste une interface de commande ; l'audio Spotify
n'est pas analysé par Rhythmbox. La normalisation Spotify reste gérée par Spotify
sur les deux plateformes. La bibliothèque, pCloud et Suno conservent leur
analyseur et leur traitement natifs.
La politique Spotify impose aussi le respect de ses contenus et de son
attribution. Une interface de commande officielle n'autorise pas à elle seule
la reproduction de toute l'expérience Spotify ou tous les usages multiservices.

Le code original Rhythmbox reste GPL-2.0-or-later. Les notices des dépendances
SDK/Gson et les conditions de service Spotify sont distinctes ; l'archive de
sources contient les outils permettant de récupérer les dépendances officielles
épinglées, sans clés personnelles ni binaire Soloist.

Les tests de protocole ou de SDK simulé prouvent les échanges et les
transitions de notre code, pas une autorisation de compte ni une lecture réelle
Spotify. Les essais avec compte et appareil sont consignés séparément dans les
preuves de version. Ne pas publier une affirmation de test physique sur la
seule base d'un build ou d'un serveur de simulation.

Références : [Soloist](https://developer.spotify.com/documentation/soloist),
[App Remote Android](https://developer.spotify.com/documentation/android),
[empreintes Android](https://developer.spotify.com/documentation/android/tutorials/application-fingerprints),
[politique Spotify](https://developer.spotify.com/policy).
