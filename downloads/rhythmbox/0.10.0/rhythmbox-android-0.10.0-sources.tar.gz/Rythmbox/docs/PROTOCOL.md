# Protocole des playlists, version 1

Enveloppe binaire : `RBX1` (4 octets ASCII), nonce aléatoire de 12 octets,
puis AES-256-GCM (texte chiffré suivi du tag de 16 octets). Données associées
authentifiées : ASCII `rhythmbox-playlists-v1`. Clé aléatoire de 32 octets,
représentée en Base64 standard dans les paramètres privés. Taille maximale
de l'enveloppe : 8 Mio. Ne jamais réutiliser un nonce avec la même clé.

Le texte clair est un JSON UTF-8 :

```json
{
  "schema": 1,
  "id": "11111111-1111-4111-8111-111111111111",
  "parents": [],
  "device": "22222222-2222-4222-8222-222222222222",
  "created": "2026-10-28T08:00:00Z",
  "playlists": [{
    "id": "identifiant-stable",
    "name": "Ma playlist",
    "tracks": [{
      "id": "pcloud:42",
      "title": "Titre",
      "artist": "Artiste",
      "album": "Album",
      "pcloud_fileid": 42
    }]
  }]
}
```

`pcloud_fileid` est facultatif ; tous les champs texte du morceau sont requis.
Le mode dossiers accepte aussi `media_path`, chemin relatif POSIX de 2 048
caractères maximum dans le dossier musique explicitement sélectionné. Les
composants vides, `.` et `..`, chemins absolus, séparateurs inverses,
séquences d'échappement `%HH` (deux chiffres hexadécimaux), deux-points et
caractères de contrôle sont refusés, sans décodage d'URL. Un `%` littéral est
accepté, par exemple `Chromeo/Fancy Footwork/11 100%.mp3`. Seule la conversion
finale vers une URI de fichier encode ce caractère en `%25` ; le chemin
échangé reste littéral. Les anciens clients qui refusaient tout `%` doivent
être mis à jour avant de recevoir une révision contenant ces noms.
L'identifiant d'un média importé depuis ce dossier est
`media:` suivi du SHA-256 hexadécimal de son chemin relatif UTF-8.
Aucun chemin absolu local, URL arbitraire ou secret de connexion n'est autorisé.
L'identifiant du snapshot et celui de l'appareil sont des UUID. Le nom d'objet
est `rb-sync-<id>.rbx` et doit correspondre à l'identifiant authentifié.

Bornes : 1 000 parents, 1 000 playlists, 50 000 entrées au total. Identifiant
playlist : 128 caractères ; nom : 1 024 ; champs texte des morceaux : 2 048.
Les identifiants pCloud sont des entiers strictement positifs sur 63 bits. L'ordre et les
doublons des morceaux dans une liste sont conservés.

Chaque objet est un état complet, portant les identifiants de ses parents.
Les objets qui ne sont parents d'aucun autre objet sont les variantes
courantes. Les identifiants ambigus et les cycles sont refusés. Le bureau
fusionne avec sa base précédente ; deux modifications concurrentes d'une
même liste produisent deux listes, dont une copie « conflit » à identifiant
stable. Aucune absence de playlist n'est interprétée comme un ordre de
suppression. Android présente les variantes avant un import explicite.

Le mode dossier écrit directement ces enveloppes dans le seul répertoire
de playlists choisi et lit les mêmes fichiers avec Android SAF. La clé
d'association est transférée séparément, par fichier privé hors pCloud ; ce
fichier contient `{schema:1,kind:"rhythmbox-pairing",key,library_id}`.

API pCloud du mode avancé : `showpublink`, `getpublinkdownload`, `uploadtolink`.
Les deux premières sont limitées aux capacités configurées, et le téléchargement
requiert la présence de l'identifiant dans le résultat du partage. Aucun token
de compte, navigation racine ou suppression distante n'est utilisé.

Les vecteurs dans `tests/fixtures/protocol-v1.*` contiennent une clé de test
publique et des données fictives ; ils servent à vérifier l'interopérabilité,
jamais à configurer une vraie synchronisation.
