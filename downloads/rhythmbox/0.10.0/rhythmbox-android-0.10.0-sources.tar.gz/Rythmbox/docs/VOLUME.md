# Uniformiser le volume

L’option **Uniformiser le volume** réduit les écarts de niveau entre les morceaux
lus par le lecteur natif. Elle est **désactivée par défaut** et reste indépendante
du greffon pCloud. Elle ne change ni les fichiers d’origine ni leurs tags.

## Activer l’option

- **Linux : Préférences → Général → Uniformiser le volume.** Le réglage prend
  effet au prochain morceau. L’analyse peut précéder le début de la lecture.
- **Android : Réglages → Lecture → Uniformiser le volume.** Le lecteur indique
  l’analyse en cours, le gain appliqué ou la conservation du volume d’origine.

Sur Linux, le **fondu enchaîné** et cette uniformisation ne sont pas proposés
ensemble. Si le fondu est actif, la case d’uniformisation est indisponible avec
une explication. Désactiver le fondu dans **Lecture**, puis fermer et rouvrir
Rhythmbox pour utiliser le moteur compatible. Pour réactiver le fondu, désactiver
d’abord l’uniformisation dans **Général**.

## Ce qui est analysé

La première écoute peut demander une analyse complète. Les écoutes suivantes
réutilisent les mesures en cache lorsque l’identité et les caractéristiques du
fichier correspondent encore. Un fichier remplacé ou modifié doit être mesuré
à nouveau. Une analyse annulée ou terminée pour un ancien morceau ne doit pas
modifier le morceau suivant.

Le cache de volume contient uniquement des mesures et des empreintes dans
l’espace privé de l’application. Il ne contient pas de copie audio normalisée,
de mot de passe ou de jeton. Les caches audio habituels de lecture restent
distincts. Cette analyse ne demande aucune autorisation de microphone.

| Source | Linux | Android |
|---|---|---|
| Fichier musical local mono ou stéréo | Pris en charge, y compris une copie locale de la musique pCloud | Pris en charge après préparation du fichier pour lecture |
| Vidéo contenant une piste audio mono ou stéréo | Analyse et écoute de la piste audio seule | Analyse et écoute de la piste audio seule |
| Morceau Suno importé comme fichier local | Même traitement qu’un autre fichier local | Même traitement qu’un autre fichier local |
| Flux Suno en ligne | Le relais HTTP n’est pas analysé par le helper local ; volume d’origine conservé | Analyse par une source de lecture en mémoire, sans enregistrer l’audio Suno |
| Piste multicanale ou disposition de canaux non prise en charge | Volume d’origine conservé | Volume d’origine conservé |
| Spotify externe | Cette option ne modifie pas son traitement audio | Cette option ne modifie pas son traitement audio |

Un silence, une piste trop courte, un format non mesurable ou un échec d’analyse
conserve le volume d’origine. L’interface ne doit alors pas annoncer un gain
normalisé. La préparation des fichiers pCloud relève de la lecture existante ;
cette option ne lance pas de synchronisation de listes.

## Un gain fixe par morceau

La cible est **−18 LUFS**, avec une amplification maximale de **+12 dB** et une
réduction du gain si les pics mesurés risquent de saturer. Un morceau limité par
ses pics ou par le plafond d’amplification peut donc rester sous la cible.
La référence commune mesure le mono comme une écoute stéréo dupliquée.

Le gain choisi reste constant pendant le morceau, hors changement explicite du
réglage. Le traitement ne remonte pas automatiquement les passages calmes et
ne baisse pas les passages forts à chaque instant. Les commandes habituelles
de volume restent utilisables.

Linux utilise les mesures de niveau intégré et de crête vraie du fichier.
Android estime les crêtes et ajoute une marge de protection. Ces mesures
concernent le signal traité par le lecteur ; elles ne mesurent pas les effets
supplémentaires éventuels du matériel. Le traitement natif remplace le passage
ReplayGain lorsqu’il est actif afin de ne pas additionner deux corrections.

## Particularités Android

L’atténuation utilise le volume du lecteur. Pour une amplification positive,
le candidat emploie uniquement l’étage de gain de **DynamicsProcessing**, avec
égaliseurs, compresseur et limiteur désactivés. Il faut **Android 9 / API 28 ou
ultérieur**, une session mono ou stéréo compatible et un effet effectivement
disponible sur l’appareil.

Sur Android 8 / API 26–27, l’atténuation reste possible. Une piste nécessitant
une amplification conserve son niveau d’origine ; le lecteur signale alors
que l’amplification est indisponible. Le même repli s’applique si l’effet est
absent, refuse le contrôle ou ne confirme pas la configuration attendue.

## Spotify

Spotify Android possède son propre réglage de normalisation pour les comptes
Premium, dans **Paramètres et confidentialité → Lecture**. Les commandes
multimédias de Rhythmbox ne pilotent pas ce réglage.
[Aide officielle Spotify](https://support.spotify.com/us/article/volume-normalization/).

Spotify indique que son **lecteur Web n’utilise pas la normalisation du niveau
sonore**. L’intégration Firefox dans Rhythmbox ne transforme donc pas l’option
native en normalisation Spotify.
[Précisions officielles Spotify](https://support.spotify.com/us/artists/article/loudness-normalization/).

## État de validation

**Linux : 65 tests unitaires et 79 contrôles natifs ont réussi.** Les contrôles
du véritable pipeline GStreamer couvrent notamment le gain dès le premier
buffer, les copies du même signal à deux amplitudes, le mono, les tags ReplayGain,
la piste audio d’une vidéo, les pics et les annulations. La dynamique du morceau
et le volume choisi par l’utilisateur sont conservés. La mise à jour sélective
a été installée par six remplacements atomiques avec sauvegarde, sans redémarrer
Rhythmbox ni activer le réglage de l’utilisateur. Elle sera chargée à sa prochaine
ouverture. Le helper installé a aussi été vérifié sur un fichier synthétique.
Voir [la validation d’installation](../dist/native-volume-install-validation.json),
[le rapport natif](../dist/native-loudness-validation.json)
et [les empreintes et contrôles unitaires](../dist/native-loudness-source-validation.json).

**Android 0.6.2 / code 11 : 1 769 assertions hôtes et neuf comparaisons FFmpeg
ont réussi.** Un APK de test isolé a ensuite passé **71 assertions dans six
scénarios, sans échec**, sur l’émulateur Android API 36. La sortie réelle de
DynamicsProcessing et du volume du lecteur a été mesurée sur des sons synthétiques :

| Gain demandé | Gain observé sur la sortie |
|---|---|
| +5,9938 dB | +5,98 dB |
| +12 dB | +11,99 dB |
| −12,0064 dB | −12,01 dB |

Dans ces essais, désactiver l’effet rétablit les niveaux RMS initiaux et le
volume système reste inchangé. Aucun microphone n’a été ouvert. Ces preuves
concernent le chemin audio de l’émulateur et les médias de test ; elles ne
valident pas tous les matériels ni la normalisation d’un vrai flux Suno en ligne.
Voir [le rapport natif Android](../dist/android-volume-native-validation.json)
et [les comparaisons de mesure](../dist/android-volume-source/ffmpeg-comparison.json).
L’APK debug exact a également passé **cinq contrôles de l’interface complète** :
réglage désactivé par défaut, activation mémorisée après arrêt du processus et
relance, lecture de la démo native avec gain annoncé de +6,2 dB, touche
multimédia Pause et retour au statut désactivé après bascule sur OFF.
Ces essais restent distincts des mesures de décodage et d’effet.
Voir [le rapport UI Android](../dist/android-volume-ui/validation.json).

**Motorola sous LineageOS, 2 novembre 2026 : douze contrôles fonctionnels ont
réussi.** Le téléphone exécute LineageOS
`23.2-20261101-UNOFFICIAL-cuscoi`, API 36. Le code 10 présent sur cette nouvelle
installation était signé avec la même clé de développement que le code 11 ;
la mise à jour vers l’APK debug exact ci-dessus a donc réussi avec `install -r`,
sans désinstallation ni `pm clear`, en conservant `firstInstallTime`.

Les essais avec la démo ont vérifié la mémorisation du réglage, l’avancement
de la lecture, pause/reprise dans l’application, les commandes multimédias
Pause, Suivant et Précédent, puis le retour au statut d’origine après OFF.
DynamicsProcessing a accepté le gain affiché de **+6,2 dB**. Le réglage initial
désactivé a été rétabli et le volume musical système est resté à 10.
Un contrôle distinct a retiré la carte Rhythmbox des applications récentes
pendant la lecture : la session multimédia et le service de lecture ont disparu,
sans `force-stop` pour ce contrôle de fermeture.

Ces essais du téléphone ne constituent pas une mesure PCM ou acoustique du
gain final. Ils n’ont ajouté aucune permission, utilisé aucune capture audio
globale et n’ont pas testé de vrai compte pCloud, Spotify ou flux Suno.
Les mesures précises du tableau précédent restent celles de l’émulateur.
Voir [la mise à jour sur LineageOS](../dist/android-lineage-20261102/installation.json),
[les contrôles fonctionnels](../dist/android-lineage-20261102/functional-validation.json)
et [le contrôle de fermeture](../dist/android-lineage-20261102/closure-validation.json).

Le code 11 reste un candidat local, avec APK debug testé sur émulateur et sur
ce Motorola, et AAB release signé et validé localement. Aucune publication
Google Play ni reprise des essais de synchronisation pCloud n’a eu lieu lors
de ces contrôles.

Les contrôles du helper seul figurent dans
`dist/linux-loudness-helper-validation.json`. La revue des API et des limites
est conservée dans `dist/audio-normalization-primary-review-20261101.json`.
