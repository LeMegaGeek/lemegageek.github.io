# Préparer pCloud pour Rhythmbox et Android

État du 3 novembre 2026 : **Android 0.7.0/code 14, révision locale r4, est installé sur le Motorola LineageOS.** Le pont Linux → pCloud → Android puis Android → pCloud → Linux a été observé sur Test après une récupération initiale explicite ; Test a retrouvé ses deux références d’origine et Mon top ses 363 références audio partagées. Les deux copies originales de Test ont été publiées dans Music/Rhythmbox et vérifiées par relecture SHA-256. La lecture depuis une copie publique a été démontrée en écartant temporairement son cache technique privé, avec le réseau laissé activé : ce n’est pas un essai global en mode avion. Les preuves précises figurent ci-dessous. La dernière diffusion en test fermé consignée ici reste Android 0.4.0/code 4 ; ces essais n’ont pas publié la 0.7.0 sur Google Play. Ne fournir aucun mot de passe, code, jeton ou adresse privée de retour dans une conversation.

## Compte musical indépendant : connexion sur la page pCloud

Le parcours suit le [client Console officiel 3.x](https://github.com/pCloud/console-client/blob/92b0ec353710537e20149ff4f5cb366ee697c443/src/wrapper/weblogin.rs) et [pclsync](https://github.com/pCloud/pclsync/blob/31c17faea8bd6fe0cd67d2bf58adafdc7e00f4bf/ptools.c). Rhythmbox demande un identifiant temporaire avec `getrequestid`, ouvre `/webview/authentication`, puis récupère uniquement l’autorisation de cette tentative avec `pcloud_oauth2_token`. La page officielle gère le mot de passe, les éventuels CAPTCHA et les vérifications du compte. Aucun mot de passe ni code n’est saisi dans le nouveau formulaire principal de Rhythmbox.

L’application se présente comme **rhythmbox-musique**, avec un nom de dispositif Rhythmbox et un identifiant aléatoire. Elle n’emprunte ni identifiant pcloud-cli, ni secret d’application, ni cookie de pCloud Drive ou du navigateur. Le paramètre fournisseur `os=10` choisit l’écran de confirmation du parcours Console utilisé avec un navigateur autonome ; la plateforme réelle est indiquée séparément. Le `request_id` est une capacité privée gardée en mémoire, au plus quinze minutes et au plus jusqu’à son expiration serveur. Les erreurs et journaux ne le recopient pas.

La réponse n’établit une connexion que si `userinfo` confirme l’adresse attendue et le même identifiant utilisateur. Les hôtes restent limités aux API officielles Europe / États-Unis. Le jeton de session est envoyé dans le corps POST `auth` des demandes. Il n’est exporté ni avec la bibliothèque, ni dans une association, ni dans les playlists.

**Le choix de mémorisation sur la page pCloud est respecté.** Avec `rememberme=true`, Linux garde le jeton dans Secret Service et Android dans AndroidKeyStore. Sinon, seul le processus en cours le conserve en mémoire et l’ancienne autorisation persistante du même compte est retirée. Après fermeture complète, il faut se reconnecter. La durée effective du jeton web dépend de pCloud ; aucune expiration de trente jours n’est promise pour ce parcours.

Le compte doit rester exclusivement musical, y compris les partages auxquels il accède. **Le jeton donne les droits du compte entier.** Les contrôles locaux de dossier et de playlists limitent le comportement de Rhythmbox sans créer une permission limitée à un dossier côté serveur. La quarantaine reste locale, hors du dossier de musique et des dossiers synchronisés.

### Parcours à essayer

1. Dans **pCloud / Compte musical**, vérifier l’adresse du compte musical puis choisir **Connecter ce compte sur pCloud…** (Android : **Connecter mon compte musical…**).
2. Sur la page officielle, utiliser ce même compte et terminer ses vérifications. Choisir de rester connecté si la connexion doit survivre à un redémarrage. Revenir dans Rhythmbox après la confirmation de pCloud. Une identité différente est refusée ; l’autorisation précédente est préservée. Une tentative peut être annulée depuis l’application.
3. Choisir explicitement **My Music**, distinct de la racine. Le sélecteur lit seulement les noms de dossiers appartenant au compte avec `nofiles=1`, `noshares=1`. Après sélection, l’index est borné à ce sous-arbre.
4. Autoriser la lecture des playlists puis choisir celles à importer ou à associer. [`collection_list`](https://docs.pcloud.com/methods/collection/collection_list.html) et [`collection_details`](https://docs.pcloud.com/methods/collection/collection_details.html) peuvent retirer des références indisponibles, même pendant une lecture ; les fichiers audio ne sont pas supprimés.
5. Commencer par une petite collection de test pour vérifier les ajouts, retraits de références, ordre et conflits dans les deux sens. L’arrière-plan n’utilise ensuite que les identifiants de listes sélectionnés. Aucun fichier musical n’est téléversé ou supprimé par la synchronisation de listes.

Le correctif Android 0.6.1 concerne l’étape 3 : l’ancien contrôle comparait le compte portant le dossier candidat au compte encore enregistré sans dossier. Il refusait donc le premier choix avant sa sauvegarde. Le candidat vérifie maintenant que l’autorisation d’origine reste identique pendant le contrôle distant, puis enregistre le dossier avec la comparaison de version existante. Un changement concurrent de compte, de jeton ou de dossier reste bloquant. La simple consultation des noms de listes ou de titres sur l’ancienne 0.5.2 ne démontrait pas l’enregistrement du dossier. La reprise du 2 novembre apporte une preuve distincte : My Music et les deux listes importées sont toujours présents après arrêt et relance du processus Android, sans avertissement de connexion temporaire. Voir [la persistance Android](../dist/pcloud-resume-20261102/android-persistence.json).

### Méthodes précédentes

La connexion par mot de passe de 0.5.0 a été refusée : code 1022 sur Linux et refus signalé sur Android. Aucun code de sécurité n’a été reçu. L’analyse du JavaScript public pCloud montre un parcours de préparation et de connexion plus complet que cet ancien appel `userinfo`. Elle ne prouve pas précisément la cause du refus ; le code 1022 ne doit pas être transformé arbitrairement en code e-mail ou CAPTCHA.

L’application OAuth **Rhythmbox Musique LeMegaGeek** a été approuvée le 1er novembre 2026. La console indique l’identifiant public **HA4srpzRXF7**, l’accès **Specific folder only** (appelé **Private** dans le courriel), les permissions d’écriture et le parcours implicite activé. Le champ de retour était encore vide au contrôle. Les App Links et la page `https://lemegageek.github.io/rhythmbox/pcloud/oauth/callback.html` appartiennent à ce parcours enregistré ; ils ne sont pas requis par la connexion principale actuelle.

Les connexions directes Linux et Android restent en place. Aucun jeton n’a été migré et aucun nouveau consentement OAuth n’a établi l’accès à My Music ou aux collections existantes. L’approbation du dossier propre à l’application ne réduit pas rétroactivement les droits des jetons directs du compte musical. Ce compte reste donc dédié à la musique pendant la préparation de cette méthode OAuth distincte.

### Automatisation, conflits et récupération

Les candidats disposent d’une synchronisation bidirectionnelle des références et de leur ordre, avec une base de comparaison et des copies de conflit. Sur Linux ouvert, les changements locaux attendent un bref délai et les changements distants sont recherchés chaque minute. Sur Android au premier plan, les délais préparés sont environ une minute et trois secondes après une modification locale. Après liaison initiale d’une liste et consentement, l’automatisation Android s’active si aucun choix préalable ne l’a désactivée ; son interrupteur reste disponible.

Android programme aussi un travail persistant d’au moins quinze minutes, sur réseau non facturé avec batterie suffisante ; l’OS peut le retarder. L’interface l’appelle « en Wi-Fi ». Seules les collections choisies sont concernées. Ces passages n’ajoutent aucune notification ; la notification multimédia éventuelle concerne la lecture.

Cette cadence attendue doit être distinguée du défaut observé avec le code 12 : sur le Motorola, le travail d’arrière-plan a été relancé puis annulé environ toutes les 22 secondes avec le motif **job rescheduled by app**. La correction **code 13 / 0.6.4** avait été installée sur le Motorola le 2 novembre. Les 387 assertions pCloud ciblées et la compilation des 42 sources SDK 36 ont passé. Un passage réel en arrière-plan a committé, terminé normalement, puis est resté en attente pendant 75 secondes sans redémarrage immédiat. Son délai a été anticipé pour le test ; le réseau et la batterie satisfaisaient les contraintes, sans changement de réglages système. Un intervalle périodique complet sans intervention n’a pas été observé. Voir [la preuve du passage contrôlé](../dist/pcloud-resume-20261102/android-code13-background.json). Voir [la boucle observée sur le téléphone](../dist/pcloud-resume-20261102/android-code12-background-loop.json).

Un journal privé précède les écritures distantes ; les états locaux ne sont validés que si leur base n’a pas changé (CAS). Une interruption bloque les nouvelles écritures. La récupération explicite relit les collections journalisées et en garde des copies à vérifier, sans rejouer automatiquement les opérations. Si une création a perdu sa réponse avant d’enregistrer son identifiant, l’utilisateur choisit explicitement la collection à rattacher.

Les références uniquement cloud sont conservées. Linux continue à lire sa musique locale. Sur Android 0.7.0, seuls les titres marqués comme issus du compte musical utilisent cette autorisation pour télécharger les octets originaux, dans un cache privé limité à **512 Mio au total et 256 Mio par fichier**, avec contrôle de taille et préchargement du morceau suivant. Une copie valide peut être réutilisée sans nouvel appel pCloud ou CDN. Région, compte, dossier, identifiant, chemin et version connue bornent sa réutilisation ; un nouvel index vérifié invalide les versions remplacées ou les références déplacées ou supprimées. Les titres locaux restent lus depuis le dossier Android choisi, même lorsque le compte est connecté ; un échec local ne déclenche pas de recherche cloud par nom. Choisir ce dossier local ne désactive pas la synchronisation du compte.

### Conserver les originaux choisis sur Android · 0.7.0

Dans **Réglages → Musique pCloud sur ce téléphone → Choisir les listes à conserver…**, sélectionner uniquement les listes liées au compte musical et à son dossier. Les titres masqués, en quarantaine, Suno ou de démonstration sont exclus ; les vidéos et conteneurs sans attestation audio sont comptés comme non copiés et conservent leur lecture habituelle. Les copies sont des originaux, sans conversion ni normalisation sur disque.

Sous **API 29 et ultérieur**, MediaStore Audio publie les morceaux dans **Music/Rhythmbox/** en conservant l’arborescence d’artistes et d’albums, **sans sélecteur de destination ni permission de stockage générale**. Sous API 26–28, le repli utilise le dossier externe Musique propre à l’application dans Rhythmbox ; cette branche n’a pas été essayée sur un appareil physique. La relecture SHA-256 précède la publication ; les noms existants sont préservés, avec un suffixe tel que **Titre (2).flac** en cas de collision. L’annulation conserve les morceaux terminés et le journal privé permet de reprendre fichier par fichier. Désactiver l’option ne supprime pas les copies publiques déjà publiées.

Sur le Motorola, la r4 a copié les **deux titres de Test**, soit **17 861 086 octets**, dans **Music/Rhythmbox/Muse/Showbiz/**. Les deux fichiers publics ont été relus avec les SHA-256 des originaux. Une seconde synchronisation a retrouvé les mêmes URI avec **0 copie et 2 réutilisations**, sans doublon, choix de dossier ou nouvelle permission. Voir [le contrôle MediaStore réel](../dist/pcloud-resume-20261103/android-code14-r4-offline-ui.json).

Un essai distinct a temporairement écarté le cache technique privé du premier titre. Le lecteur l’a reconstruit depuis la copie publique avec le même SHA-256, a indiqué **Dossier musical hors ligne** et a affiché des mesures PCM G/D réelles. Les fichiers publics sont restés intacts et la sauvegarde technique temporaire a été nettoyée. **Le réseau est resté activé : ce contrôle valide le parcours de copie locale et de lecture, pas une déconnexion globale en mode avion ni l’absence de tout trafic.** Voir [la lecture depuis Music/Rhythmbox](../dist/pcloud-resume-20261103/android-code14-r4-offline-playback.json).

### Validation disponible et essais restants

Les preuves historiques restent séparées par candidat dans `dist/pcloud-native-qa/`. La préparation Android 0.5.2 avait passé 183 assertions hôtes ciblant le réseau, 383 assertions dans seize scénarios d’instrumentation API 36 et dix contrôles UI sur son APK debug exact. Le candidat 0.6.0/code 9 a ensuite passé 1 694 assertions hôtes et les essais Services consignés dans son archive. Le correctif de dossier 0.6.1 ajoute 45 assertions, les suites pCloud ciblées passent 295 assertions et la suite complète du code 10 a passé 1 739 assertions. Le code 12 diagnostic a ensuite passé 1 861 assertions hôtes. Ces contrôles synthétiques restent distincts des preuves réelles et n’attestent pas à eux seuls une connexion ou une sauvegarde de dossier sur le téléphone.

**Android, reprise réelle du 2 novembre :** après relance du processus, le compte musical dédié et My Music sont conservés et la bibliothèque contient Mon top avec 309 titres et Test avec deux titres. Un retrait de référence dans l’interface Android a ensuite été envoyé et validé automatiquement sur pCloud, sans synchronisation manuelle. La référence et l’ordre ont été rétablis sur pCloud, puis Android a récupéré automatiquement cet état après relance. La collection Test d’origine **4906504** conserve ses deux références **110914868773**, **110914740857**, dans cet ordre. Aucun fichier musical n’a été déplacé ou supprimé et aucune collection QA n’a été créée. L’état final ne contient que Test et Mon top, l’automatisation reste activée et aucun journal n’est en attente. Voir [l’aller-retour réel](../dist/pcloud-resume-20261102/android-code12-outbound-diagnostic.json) et [l’état final restauré](../dist/pcloud-resume-20261102/android-code12-clean-final-state.json). La correction de la boucle d’arrière-plan a ensuite passé le contrôle réel distinct du code 13 décrit ci-dessus.

**Linux, historique des 1er et 2 novembre :** My Music et les publications de Mon top et Test avaient été observés ; une application locale non confirmée restait à vérifier. Le rapport `dist/pcloud-device-login-validation.json` précède ces publications. Le 2 novembre, un appel `userinfo` a seulement confirmé l’identité attendue à partir de l’autorisation propre à Rhythmbox dans son trousseau, sans exposer le jeton, accéder aux collections ou ouvrir l’application. Voir [la vérification d’identité historique](../dist/pcloud-resume-20261102/linux-live-identity.json). Cette étape est distincte du cycle applicatif complet réussi le lendemain.

**Pont réel du 3 novembre :** Test partait de deux références A/B. La première tentative a nécessité le bouton public Linux **Vérifier après une synchronisation interrompue**, après un ajout concurrent de C pendant un lot ayant capturé A/B. Cette étape était une récupération manuelle. La propagation de Test A/B/C vers la collection pCloud puis la base committée Android, et le retour A/B après retrait de C dans l’interface Android, ont ensuite été automatiques, sans clic de synchronisation manuelle. Test a retrouvé son contenu initial et Mon top ses 363 références audio partagées. Aucune nouvelle collection ni opération sur les fichiers musicaux n’a été effectuée par ces échanges de références. Voir [le côté Linux](../dist/pcloud-resume-20261103/bridge-native-automatic.json) et [le côté Android](../dist/pcloud-resume-20261103/bridge-android-automatic.json). Ce parcours comprend une intervention manuelle initiale ; il ne prouve pas un cycle physique entièrement sans intervention.

La cause Linux a ensuite été corrigée dans `rb_adapter.py` : un même ensemble de favoris parcouru dans un autre ordre et une modification concurrente de Test ne doivent pas déclencher cette récupération. La correction a passé **219 tests unitaires et une revue indépendante**, puis a été installée. Voir [le gel et ses tests](../dist/pcloud-resume-20261103/linux-outgoing-favorites-source.json) et [l’installation](../dist/pcloud-resume-20261103/linux-outgoing-favorites-install.json). Le [dernier état après démarrage normal](../dist/pcloud-resume-20261103/final-state-validation.json) n’a aucune transaction en attente ; aucun nouveau cycle physique complet de cette correction n’est revendiqué.

Une ancienne liste de conflit redondante de 309 références a été sauvegardée en M3U puis retirée après vérification que toutes ses références appartenaient déjà à Mon top natif. La liste native a conservé **366 références, dont 363 audio partagées et 3 locales seules**, et Test ses deux références. Ce nettoyage n’a déplacé ou supprimé aucun fichier audio et n’a effectué aucune mutation cloud. Voir [le contrôle de cette liste historique](../dist/pcloud-resume-20261103/legacy-top-conflict-cleanup.json).

La r4 est identifiée par [son installation de même signature](../dist/pcloud-resume-20261103/android-code14-r4-install.json), avec conservation de la bibliothèque et de la première date d’installation, sans effacement ni nouvelle permission. Les contrôles de lecture r3 — cache après mise à jour, morceau suivant, recherche de position, pause/reprise/arrêt et mesures PCM G/D — restent [consignés séparément](../dist/pcloud-resume-20261103/android-code14-r3-playback-ui.json). La r4 ne change que le libellé de cet analyseur avant le traitement du niveau.

Restent à observer un intervalle Android périodique complet sans intervention, une déconnexion globale en mode avion et l’exécution physique sous API 26–28. Ces essais ne constituent pas une publication Google Play. La politique publique et les déclarations doivent correspondre au candidat avant son déploiement en test fermé. Les contrôles de dossier restent des garde-fous du client, sans restriction nouvelle des droits du jeton côté serveur.


## Où apparaissent les listes ?

| Mode | Objet partagé | Visible dans le lecteur officiel pCloud ? |
|---|---|---|
| Dossiers ou liens historiques, disponibles dans Android 0.4 | Révisions de playlists chiffrées `.rbx` entre Rhythmbox et Android | Non ; le lecteur officiel ne lit pas ce format |
| Compte musical, candidats Android avec listes liées | Collections natives explicitement liées | Oui ; le pont Linux → pCloud → Android puis Android → pCloud → Linux est observé le 3 novembre sur Test, après récupération initiale explicite et avec retour à ses deux références initiales. Un intervalle Android périodique complet sans intervention reste à observer |
| Import historique d’un lien de collection | Copie en lecture seule puis échanges `.rbx` | La copie locale ne met pas à jour la collection officielle |

Une collection créée sur le site pCloud n’est synchronisée automatiquement avec Rhythmbox que si elle est explicitement liée dans le nouveau mode compte, autorisé et activé. La seule présence de fichiers `.rbx` ne crée pas cette liaison.

## Mode historique : choisir les dossiers sur le PC

Le greffon **pCloud** se configure par le bouton **pCloud** du Rhythmbox
modifié, ou dans **Greffons → pCloud → Configurer**. L'interface, les pochettes,
l'analyseur et la quarantaine appartiennent à l'application et restent
utilisables sans ce greffon.

Deux dossiers ont des rôles distincts :

| Champ | Choix préparé sur ce poste | Usage |
|---|---|---|
| **Dossier musique utilisé par Rhythmbox** | `/home/denis/Musique/Bibliothèque` | Morceaux utilisés pour l'écoute et références relatives des listes |
| **Dossier des listes chiffrées** | `/home/denis/pCloudDrive/Playlists-Rhythmbox` | Échange Rhythmbox et Android ; un dossier existant déjà choisi est conservé |

La liaison historique de la copie locale de musique utilisait **`/Ma musique`** dans le compte,
visible dans `/home/denis/pCloudDrive/Ma musique`. Il n'y a pas de sous-dossier
`Bibliothèque` dans ce chemin distant. Cette liaison a été vérifiée dans le
client officiel avant le transfert vers le compte musical dédié. Elle ne prouve pas les chemins ou identifiants du nouveau compte **My Music** : il faut sélectionner ce dernier dans la connexion directe et reconstruire les correspondances. Le montage du client pCloud peut continuer à utiliser un autre compte.

On peut choisir la **copie locale synchronisée par pCloud**, ou le dossier
musique du lecteur pCloudDrive. La copie locale permet d'écouter sans dépendre
du montage. Le dossier des playlists est distinct de la musique et doit être
accessible par les appareils associés. Un autre dossier local convient aussi
si sa réplication pCloud a déjà été configurée séparément.

Les options repliées d'emplacements indiquent le lecteur pCloud et les autres
racines synchronisées pour protéger les exports privés et la quarantaine. Ce
chemin de protection n'est pas un deuxième choix de bibliothèque. Les valeurs
du greffon ne créent ni ne changent les liaisons du client pCloud.

Cocher les playlists voulues, puis enregistrer ou synchroniser. La clé est
générée automatiquement ; région et liens de partage restent facultatifs
dans ce mode. Rhythmbox écrit les manifestes chiffrés dans le dossier choisi.
Le client pCloud officiel assure leur transfert ; vérifier son état pour
confirmer que les fichiers ont atteint le cloud. Le greffon n'envoie aucun
fichier audio et ne parcourt pas les autres dossiers du compte.

La quarantaine se règle dans **Quarantaine → Choisir le dossier de
quarantaine…**, dans l'application. Sa destination doit rester hors de toutes
les racines synchronisées, y compris les copies locales. Si une source est
retirée d'une copie locale répliquée, le client pCloud peut propager ce retrait
vers le cloud ; le dialogue de confirmation le précise. Les déplacements
faits directement depuis le montage pCloudDrive sont refusés.

Après un déplacement ou un ajout de morceaux, utiliser **Actualiser la
bibliothèque**. Cette commande réanalyse le dossier musical ; elle est
distincte de la synchronisation des playlists.

## Mode historique : une seule liste Mon top

**Mon top** reste la liste automatique de Rhythmbox : elle regroupe les
morceaux notés au moins quatre étoiles. Si elle est cochée dans le greffon,
un changement de note déclenche la synchronisation après un bref délai.
Le greffon réutilise cette liste et ne crée pas de copie « pCloud · Mon top ».

Lors d'une synchronisation, un favori ajouté sur un autre appareil devient
un favori local. Un morceau déjà noté quatre étoiles garde cette note. Le
retrait d'un favori précédemment partagé retire sa note de favori ; les
favoris locaux jamais partagés restent conservés. Une référence distante
sans fichier local accessible ne provoque aucun retrait de note. Les notes
modifiées sont sauvegardées avant application ; l'historique d'écoute et les
commentaires restent conservés.

## Mode historique : associer Android sans recopier une clé

Cliquer **Associer Android…**, choisir un emplacement privé hors de pCloud pour le fichier d'association, puis le transférer au téléphone par un canal privé. Dans les réglages Android, sélectionner ce fichier avec **Associer avec le PC**, puis choisir le dossier playlists et le dossier musique avec les sélecteurs système.

Le fournisseur de fichiers Android doit rendre les dossiers disponibles au sélecteur et autoriser les opérations demandées. Si pCloud ne propose pas de dossier sélectionnable sur le téléphone, ce mode nécessite un dossier synchronisé exposé par un fournisseur compatible ; la connexion avancée par liens reste disponible. Cette limite est affichée dans l'application. Aucun essai sur téléphone n'a encore confirmé la compatibilité du fournisseur pCloud.

Le fichier d'association contient une clé privée et n'appartient pas aux playlists synchronisées. Ne pas le placer dans pCloud. Les appareils associés lisent les mêmes révisions et conservent les modifications concurrentes.

## Mode historique : connexion avancée par liens

Les sections suivantes concernent uniquement cette option, repliée dans les paramètres.

## Préparer le dossier d'échange

Créer un nouveau dossier vide, par exemple `Rhythmbox-Echanges`, dédié uniquement aux manifestes chiffrés. Il est distinct des dossiers de documents et des répertoires contenant la musique en clair.

Créer un lien de lecture de ce dossier et un lien de dépôt vers ce même dossier. Les interfaces pCloud et les offres disponibles peuvent différer ; la documentation API décrit la création d'un [lien de dépôt](https://docs.pcloud.com/methods/upload_links/createuploadlink.html) vers un dossier possédé par le compte, avec limites optionnelles de taille, de nombre de fichiers et de durée.

Vérifier que les deux liens concernent le dossier vide choisi. Ne pas partager une racine, un dossier de sauvegarde ou un dossier déjà rempli de documents personnels. Ne pas rendre ce lien public dans un message ou un dépôt de sources : il donne accès à l'objet partagé à toute personne qui le possède.

Pour vérifier le périmètre, placer uniquement un objet témoin sans donnée privée dans ce dossier et confirmer sa visibilité via le lien. Les autres dossiers du compte ne doivent pas apparaître dans ce partage. Le client ne doit pas proposer une navigation vers le reste du compte.

## Appairer le bureau et Android

Choisir la région API du compte : `api.pcloud.com` pour les États-Unis ou `eapi.pcloud.com` pour l'Europe. Fournir les deux capacités dans la configuration privée prévue par le client.

Créer une clé aléatoire de 32 octets avec la fonction d'appairage du projet, puis transférer cette même clé au second appareil par un canal privé. Ne pas inventer une phrase courte comme clé et ne pas déposer la clé dans le dossier synchronisé. Le format exact de configuration et la commande d'appairage de la version livrée sont décrits par son README et son interface.

Une clé incorrecte doit produire une erreur de déchiffrement visible et ne jamais écraser une liste locale. Les deux liens ne suffisent pas à déchiffrer les playlists sans cette clé. Inversement, la clé ne donne aucun accès au compte pCloud en dehors des objets obtenus via les liens.

## Importer une liste pCloud existante

Une playlist du lecteur musical officiel pCloud est une collection native, différente d'un fichier M3U ou d'un manifeste du projet. Créer volontairement un lien vers la seule collection à importer, puis le fournir à la fonction d'import. Le [lien de collection](https://docs.pcloud.com/methods/public_links/getcollectionpublink.html) est une image à jour de cette collection et n'exige pas de jeton global pour sa consultation.

Ce partage expose les métadonnées et fichiers désignés aux détenteurs du lien. Une collection contenant des éléments qui ne doivent pas être partagés ne convient pas. Le chiffrement du dossier d'échange ne chiffre pas le contenu rendu public par un autre lien de collection.

Dans ce mode historique, l’import est en lecture seule pour la collection pCloud. Les modifications faites dans Rhythmbox ou Android sont échangées sous forme de manifestes chiffrés du projet ; elles ne modifient pas automatiquement la collection officielle et ne demandent aucun jeton de compte. La connexion au compte musical décrite en tête de document est un mode distinct de la préparation 0.5.

Les collections système doivent rester intactes. Tout import incomplet ou référence devenue inaccessible doit être signalé, sans considérer silencieusement une liste partielle comme une réussite.

## Premier essai

Commencer avec une petite playlist de test, sans données sensibles. Vérifier le nombre de pistes et leur ordre sur le bureau puis sur Android. Modifier la liste sur un appareil et confirmer que l'autre récupère la nouvelle révision. Créer ensuite deux modifications concurrentes et confirmer que les deux variantes sont conservées jusqu'à résolution.

Tester une mauvaise clé et un fichier chiffré altéré : les clients doivent refuser les données. Révoquer un lien et confirmer que les prochaines requêtes échouent explicitement. Les données déjà téléchargées restent présentes sur l'appareil ; elles ne sont pas effacées par une révocation distante.

Les liens réels et un appareil Android sont nécessaires pour valider la synchronisation de bout en bout. La simple compilation ou un essai d'API simulée ne suffit pas. Voir [les garanties et limites de confidentialité](SECURITY.md) et le compte rendu de validation du projet.
