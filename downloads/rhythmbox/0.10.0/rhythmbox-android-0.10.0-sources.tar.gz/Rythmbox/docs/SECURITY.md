# Confidentialité de la synchronisation pCloud

Analyse mise à jour le 31 octobre 2026. Android 0.4.0, code 4, reste diffusé en test fermé. Les préparations 0.5.0 et 0.5.1 ont été essayées sur téléphone : le formulaire de mot de passe a échoué, puis le retour de la page pCloud n’a pas confirmé la connexion dans l’application. La préparation 0.5.2, code 7, corrige le traitement du réseau et de la reprise. La connexion Linux au vrai compte musical est vérifiée ; la connexion Android et la synchronisation complète des listes dans les deux sens restent à démontrer.

## Compte musical : page officielle et autorisation propre

Le parcours principal crée une demande anonyme `getrequestid`, ouvre la page officielle `/webview/authentication`, puis attend son résultat avec `pcloud_oauth2_token`. L’identifiant client public transmis est **rhythmbox-musique**, avec un dispositif et une version propres ; aucun identifiant ou secret de pcloud-cli n’est emprunté. `os=10` choisit le mode de confirmation Console du fournisseur pour un navigateur autonome. Le protocole et les paramètres sont issus du client officiel pCloud ; la connexion Linux a été confirmée sur le compte réel, tandis que le retour Android reste à vérifier.

La page pCloud traite le mot de passe, les CAPTCHA et les facteurs de sécurité. Le client ne les lit pas. Le `request_id`, qui permet de récupérer l’autorisation, reste privé et uniquement en mémoire pendant au plus quinze minutes et jusqu’à son expiration serveur si elle est plus courte. Aucun cookie ou jeton d’une autre application n’est découvert, copié ou réutilisé. Les requêtes sont des POST HTTPS bornés aux hôtes API pCloud autorisés ; aucune redirection réseau n’est suivie. Le jeton de session est envoyé dans le corps POST `auth`, jamais dans une URL, un journal ou au serveur CDN audio.

`userinfo` confirme ensuite l’adresse attendue et le même identifiant utilisateur avant l’enregistrement. Les annulations et réponses tardives ne doivent pas remplacer une connexion plus récente ; un nouveau jeton rejeté est révoqué au mieux. Sur Linux, le trousseau est acquitté seulement après sauvegarde des métadonnées de compte ; une fermeture avant cet acquittement restaure l’autorisation précédente. Android compare la session et le compte précédent avant sa validation atomique.

Le choix `rememberme` du fournisseur est respecté : vrai autorise un jeton dans Secret Service sous Linux ou dans un fichier AES-GCM AndroidKeyStore exclu des sauvegardes ; faux le garde seulement en mémoire et retire l’ancien jeton persistant de cette installation. Le choix d’un dossier ne transforme pas une autorisation temporaire en autorisation persistante. Une fermeture complète du processus exige alors une nouvelle connexion. La durée effective du jeton web dépend de pCloud.

**Le jeton possède les droits du compte entier.** Un dossier choisi ou une liste de méthodes ne borne pas ses droits côté serveur. Le compte doit rester exclusivement musical, y compris ses partages accessibles ; les contrôles locaux ne constituent pas une garantie de permission serveur limitée à My Music. Les méthodes mot de passe historiques et OAuth sont distinctes. L’option OAuth d’application enregistrée reste en attente de validation ; elle n’est pas un prérequis de ce parcours principal.

Le sélecteur de dossier est une exception explicite à l’accès au sous-arbre déjà choisi : à la demande de l’utilisateur, il lit des en-têtes de dossiers, éventuellement depuis la racine, avec [`listfolder`](https://docs.pcloud.com/methods/folder/listfolder.html), `nofiles=1` et `noshares=1`. Il ne demande aucun fichier à ce stade et exige des dossiers appartenant au compte. La racine ne peut pas être enregistrée comme dossier musical. Après sélection, l’index récursif est borné au dossier non racine choisi et chaque identifiant de fichier est contrôlé contre cet index. Ces contrôles sont des protections du code, sans garantie supplémentaire sur le jeton.

L’inventaire des en-têtes de playlists requiert une action explicite et un accord préalable. [`collection_list`](https://docs.pcloud.com/methods/collection/collection_list.html) peut créer les collections système au premier appel et retirer des références indisponibles, même sans demander les fichiers. [`collection_details`](https://docs.pcloud.com/methods/collection/collection_details.html) peut aussi retirer ces références. Cette conséquence du service est annoncée avant lecture ; elle ne correspond pas à une suppression de fichier audio. L’arrière-plan ne lance aucun inventaire général et n’utilise que les identifiants des collections choisies. Les collections système et celles non autorisées sont refusées pour les mutations du client.

Pour les connexions persistantes, Linux conserve les jetons dans Secret Service ; Android utilise des fichiers distincts chiffrés AES-GCM avec une clé AndroidKeyStore, dans `noBackupFilesDir`. Aucun repli en clair n’est prévu. Ils sont séparés de l’association PC/Android et ne sont inclus ni dans les révisions `.rbx`, ni dans les exports de bibliothèque. La déconnexion retire l’autorisation locale de Rhythmbox ; elle ne révoque pas automatiquement l’autorisation distante et ne déconnecte pas les autres applications pCloud.

L’état OAuth aléatoire de 256 bits expire au bout de quinze minutes et est consommé une seule fois. Sous Android, il est chiffré séparément pour les rotations et la mort du processus. Le seul callback est le lien HTTPS exact `https://lemegageek.github.io/rhythmbox/pcloud/oauth/callback.html`, avec vérification de domaine et résolution vers l’activité attendue avant le départ. API 31+ contrôle aussi l’état de vérification et l’autorisation d’ouverture des liens ; API 26–30 repose sur la résolution publique du lien par Android, sans API cachée. Une résolution vers un navigateur, un sélecteur ou une autre application fait refuser le départ. Aucun schéma personnalisé ne relaie le callback. L’activité retire immédiatement l’URI de son Intent ; un simple indicateur de retour ne vaut jamais une identité authentifiée : l’application recharge le stockage vérifié.

La page HTTPS de secours et `/.well-known/assetlinks.json` ont été publiés par le commit de site `37d3d5525a49c766c6b651a7518654b6878f50ca`. Les associations contiennent les certificats publics Play et release possédés, aucun certificat debug. La page efface le fragment par sa première instruction JavaScript, utilise une CSP à empreintes et ne lit ni ne relaie les données du callback. Le domaine a été vérifié par Android API 36 avec le certificat release. Le client ID pCloud et l’enregistrement effectif de ce redirect chez pCloud restent nécessaires.

## Écritures, automatisation et récupération en 0.5

Seules les collections liées peuvent recevoir des ajouts/retraits de références et changements d’ordre ; aucun appel de suppression ou de téléversement de fichier musical n’est utilisé. Les conflits sont conservés dans des copies. Les références uniquement cloud ne sont pas effacées au motif qu’un fichier local manque. Linux conserve une écoute locale. Android récupère le média original avec `getfilelink`, sans conversion, dans un cache privé limité à 256 Mio par fichier, avec contrôle de taille et refus des redirections ou hôtes arbitraires. Seuls les titres marqués comme issus du compte utilisent cette autorisation et doivent correspondre au compte connecté. Les titres locaux continuent à utiliser le dossier Android autorisé, même avec un compte connecté ; aucun échec local ne provoque de recherche cloud par nom.

Un journal privé précède les mutations distantes. Les écritures locales sont conditionnées à la version de départ (CAS) et à l’identité courante du compte ; un ancien résultat ne doit pas rétablir un jeton ou une bibliothèque remplacés. Une annulation pendant la vérification d’identité empêche la conservation de ce résultat. Sous Linux, l’annulation du trousseau est transmise à Gio et n’immobilise pas la fermeture de l’interface. Le nettoyage d’une éventuelle écriture tardive vérifie qu’elle correspond encore au jeton de cette session et préserve une nouvelle autorisation.

Une opération dont la réponse est incertaine suspend les envois suivants. La récupération volontaire relit uniquement les collections journalisées et en conserve des copies de contrôle, sans rejouer la mutation. Une création dont l’identifiant n’a pas été reçu demande une sélection explicite avant récupération. Ces lectures restent soumises à l’accord sur le retrait éventuel de références par pCloud.

Sous Android, l’automatisation au premier plan vérifie environ chaque minute et temporise environ trois secondes après un changement local. Un travail persistant demande aussi un passage d’au moins quinze minutes sur réseau non facturé, batterie suffisante ; sa cadence effective appartient à Android. L’interface parle de Wi-Fi. Seuls les identifiants de collections déjà choisis sont concernés. Aucun nouveau canal ou notification de synchronisation n’est créé ; la notification de lecture multimédia reste indépendante. Linux prépare une recherche chaque minute lorsque Rhythmbox est ouvert, avec temporisation des modifications locales.

## Validation et limites des preuves actuelles

La suite Linux ciblée actuelle a exécuté 255 tests : 239 réussites et seize optatifs ignorés. Douze tests GTK de configuration ont réussi séparément, avec profils privés, sans réseau ni trousseau réel. Les rapports distinguent les contrôles simulés des opérations sur le vrai compte. La préparation Android 0.5.2 a passé 183 assertions hôtes ciblant le réseau, 383 assertions dans seize scénarios d’instrumentation API 36 et dix contrôles UI sur l’APK debug exact. L’instrumentation emploie un APK isolé sans permission réseau et un UID distinct, sans accéder aux données de l’application principale ; ces résultats ne prouvent pas une connexion fournisseur réelle.

Le rapport `dist/pcloud-device-login-validation.json` confirme la connexion Linux persistante au compte musical attendu et la vérification du dossier possédé My Music. Depuis ce premier relevé, Mon top a reçu ses références audio et Test a été publié avec deux morceaux ; `dist/pcloud-native-qa/new-local-playlists-installed.json` distingue cette publication réelle des tests isolés. Le 1er novembre, la récupération d’une réorganisation interrompue a relu uniquement Mon top (309 références), préservé les bases de fusion et n’a rejoué aucune écriture : voir `dist/pcloud-native-qa/morning-remote-mutation-recovery-20261101.json`. Son ordre distant est intermédiaire ; ce contrôle ne prouve donc pas un nouveau cycle complet après fermeture. Android 0.5.2 est installé sur le Motorola, mais sa connexion au compte et sa synchronisation réelles restent à confirmer. Les sources du candidat 0.6.0 conservent les classes d’authentification de 0.5.2 ; leurs tests et ceux de l’émulateur ne valent pas validation sur le téléphone. Aucun parcours OAuth enregistré complet ni essai d’exécution API 26 n’est attesté par ces preuves.

## Mode historique : dossiers sélectionnés

Sur Linux, l'utilisateur choisit un dossier réservé aux playlists, déjà synchronisé par pCloud ou situé dans pCloudDrive, et un dossier musical distinct. Une copie locale répliquée est acceptée ; la sélection n'est pas obligatoirement située sous le lecteur monté. Le moteur n'énumère que le premier pour les fichiers `rb-sync-UUID.rbx`, et n'importe le contenu audio du second que sur demande. Le transfert réseau de ce mode appartient au client pCloud officiel déjà installé. Le greffon ne lit pas ses identifiants et ne demande pas d'accès API au compte. Cette restriction est celle des accès effectués par le code ; le greffon s'exécute avec les droits locaux de Rhythmbox, sans bac à sable système supplémentaire. Le client pCloud officiel conserve ses propres accès et ses liaisons existantes.

Les fichiers sont ouverts relativement à des descripteurs de répertoire et avec `O_NOFOLLOW`. Les liens symboliques ne peuvent pas élargir la sélection. Un média reçu est identifié par un `media_path` relatif strict : pas de chemin absolu, composant vide, `.` ou `..`, séparateur inverse, séquence d'échappement `%HH`, deux-points ou caractère de contrôle. Un `%` littéral dans un titre comme `100%` est conservé ; les chemins reçus ne sont jamais décodés comme des URL. Les chemins absolus du PC ne sont jamais exportés. Les autres fichiers du dossier de playlists sont ignorés et ne sont ni modifiés ni envoyés.

Android utilise le [sélecteur système de documents](https://developer.android.com/training/data-storage/shared/documents-files) et conserve uniquement les autorisations accordées aux arbres choisis. Le dossier playlists nécessite lecture/écriture et le dossier musique lecture seule. Aucun accès général au stockage n'est demandé. Le fournisseur doit exposer un arbre et prendre en charge les opérations requises ; la compatibilité du fournisseur pCloud Android n'est pas prouvée dans cet environnement.

La clé est créée automatiquement dans la configuration privée du PC. L'association Android passe par un fichier choisi hors de toutes les racines pCloud connues, contenant uniquement version, type, clé et identifiant de bibliothèque. Ne pas déposer ce fichier dans le dossier de playlists. Le code refuse cet export dans les dossiers partagés déclarés. La synchronisation ne transmet ni ce fichier ni les chemins de configuration ni le journal de quarantaine.

## Mode historique par liens : frontière d’accès

Le propriétaire prépare un dossier pCloud vide réservé aux échanges de playlists, puis crée deux liens : un lien de lecture vers ce dossier et un lien de dépôt vers le même dossier. Les appareils reçoivent seulement ces liens et une clé de chiffrement indépendante. Ils ne reçoivent aucune session du compte personnel.

Le lien de lecture autorise la consultation du seul objet partagé et de ses descendants ; le lien de dépôt autorise l'ajout de fichiers au dossier désigné. La documentation de [showpublink](https://docs.pcloud.com/methods/public_links/showpublink.html) décrit la consultation sans authentification de compte, et [uploadtolink](https://docs.pcloud.com/methods/upload_links/uploadtolink.html) décrit le dépôt sans authentification. Un détenteur de ces capacités ne peut pas les transformer en jeton d'accès au compte.

Les liens sont des secrets. Leur possession donne les pouvoirs associés, même hors de l'application. Le dossier d'échange doit rester réservé aux manifestes chiffrés : ne pas y placer de document privé en clair. La taille, le nombre et les dates des objets restent visibles au service et aux détenteurs du lien de lecture. Le lien de dépôt peut être utilisé pour remplir son quota ; le propriétaire doit fixer des limites et le révoquer si nécessaire.

## Chiffrement des playlists `.rbx` des modes historiques

Les clients chiffrent les manifestes avec AES-256-GCM et une clé aléatoire de 32 octets, partagée entre les appareils autorisés. Chaque chiffrement exige un nouveau nonce aléatoire. L'authentification GCM permet de refuser un objet modifié ou une mauvaise clé avant de traiter son contenu.

L'enveloppe commune est `RBX1` suivi d'un nonce de 12 octets et du résultat AES-GCM (texte chiffré et tag de 16 octets). Les données associées authentifiées sont les octets UTF-8 de `rhythmbox-playlists-v1`. Le contenu JSON versionné et sa taille sont validés après déchiffrement. Ces paramètres doivent rester identiques sur Android et sur le bureau.

La clé ne doit jamais être placée dans le dossier pCloud d'échange, dans une URL de téléchargement, dans un journal ou dans le dépôt de sources. L'appairage entre appareils est un transfert explicite d'un secret. Les appareils autorisés peuvent déchiffrer et produire des playlists : cette clé commune n'authentifie pas une personne ou un appareil distinct.

Les révisions sont des objets immuables avec références aux parents. Une collision de noms lors d'un dépôt est renommée par pCloud ; elle ne doit pas remplacer silencieusement une autre révision. Les modifications concurrentes doivent conserver plusieurs branches et rester visibles jusqu'à leur résolution. Le chiffrement n'empêche ni la suppression d'objets par le propriétaire du compte ni la présentation d'un ancien état par le service ; il ne fournit pas, à lui seul, une protection contre le rejeu.

## Pourquoi la 0.4 publiée ne demande pas d’OAuth

La documentation publique de [l'autorisation OAuth pCloud](https://docs.pcloud.com/methods/oauth_2.0/authorize.html) ne décrit aucun droit limité à un dossier d'application ; son paramètre `permissions` ne documente qu'une permission supplémentaire, `manageshares`. Un choix de `folderid` dans une interface ne restreint pas un jeton du compte principal.

De plus, [les jetons OAuth](https://docs.pcloud.com/methods/oauth_2.0/index.html) sont documentés sans expiration. La 0.4 publiée ne demande donc pas ces jetons. La préparation 0.5 autorise une connexion explicite au compte musical dédié selon les limites décrites ci-dessus ; aucune version ne lit les jetons des autres installations pCloud du PC ou du téléphone.

## Validation des données et du réseau

Les clients doivent limiter les méthodes API aux capacités requises et valider les hôtes HTTPS. Aucune URL fournie par une playlist ne doit déclencher une requête avec des secrets de synchronisation. Un identifiant de fichier importé doit appartenir au partage autorisé ; les chemins locaux et les URL arbitraires restent hors du protocole distant.

Les objets trop volumineux, JSON invalides, signatures d'enveloppe incorrectes, références incohérentes ou contenus non authentifiés doivent être refusés avec une erreur visible. Aucun échec n'autorise une recherche sur la racine du compte. Les journaux doivent omettre codes de partage, clé et URL temporaires signées.

Ces règles se vérifient dans les deux implémentations. Les tests d'API simulée montrent le comportement du code ; l'essai avec les deux liens réels reste nécessaire pour confirmer l'association au bon dossier et la réponse du service.

## Collections natives et fichiers audio

Les collections natives pCloud sont des listes rattachées au compte, distinctes des fichiers de playlists. Voir [le modèle des collections](https://docs.pcloud.com/methods/collection/). Le chiffrement des manifestes du projet ne transforme pas ces objets en collections modifiables dans le lecteur pCloud officiel.

Un lien explicitement choisi vers une collection peut servir à l'import en lecture seule. La documentation de [getcollectionpublink](https://docs.pcloud.com/methods/public_links/getcollectionpublink.html) précise que le lien suit les changements de la collection. Les métadonnées et fichiers exposés par cette collection sont accessibles aux détenteurs du lien : leur partage est une décision distincte du partage des manifestes chiffrés.

Dans la 0.4 publiée et les modes historiques, l’application n’utilise pas de jeton pour éditer ces collections : les listes importées sont conservées et échangées au format `.rbx`, sans écriture bidirectionnelle officielle. La préparation 0.5 ajoute ce traitement avec une autorisation propre au compte musical, sous réserve d’essai réel (et de validation pCloud pour l’option OAuth). Les collections système ne sont jamais des cibles de mutation du client.

## Révocation et limites

Pour couper les accès du mode compte dédié, retirer l’autorisation locale puis révoquer l’autorisation concernée auprès de pCloud si la révocation distante est souhaitée. Pour le mode historique par liens, révoquer ses liens ; si les autres appareils les partagent, ils doivent être réappairés avec les nouveaux liens. Une clé commune divulguée doit être remplacée sur tous les appareils. Une révocation n’efface ni les playlists déjà déchiffrées ni les fichiers audio téléchargés. Une nouvelle clé ne rend pas secrets les anciens manifestes déjà accessibles avec l’ancienne clé.

Les copies Android et bureau doivent rester dans les espaces privés prévus par chaque système. L'application ne peut pas assurer la confidentialité sur un appareil compromis ou dont l'utilisateur autorisé exporte volontairement les secrets.

## Quarantaine locale des morceaux

La quarantaine appartient à l'application native, avec un composant local
indépendant du greffon pCloud. Le dossier par défaut est
`~/Musique/Quarantaine-Rhythmbox`, hors de la bibliothèque et du lecteur pCloud.
Le plan liste les chemins sources, destinations et empreintes SHA-256. Le
bouton de déplacement s'active après la case de confirmation du plan.

Les liens symboliques, fichiers à liens multiples, sources situées directement
sur pCloudDrive et destinations à l'intérieur des racines protégées sont
refusés. Une source dans la copie locale de musique peut être déplacée après
confirmation : **le client pCloud peut alors propager son retrait vers le
cloud**. Le module n'appelle pas d'API de suppression pCloud. L'isolation du
dossier de destination ne supprime pas cet effet de la réplication des sources.

Les fichiers sont copiés vers des noms créés exclusivement, vérifiés, puis
retirés de leur emplacement original ; aucun fichier existant n'est écrasé.
Un journal privé permet la restauration. Celle-ci demande confirmation et
refuse de remplacer un fichier présent à son ancien emplacement. Le journal,
les exclusions et la clé d'association restent hors des dossiers synchronisés.
Les titres déplacés sont exclus des prochaines publications et imports de
playlists ; les anciennes révisions déjà présentes dans pCloud restent en place.

Les racines protégées doivent inclure toutes les copies locales synchronisées,
y compris celles d'autres outils. Le seul chemin `~/pCloudDrive` ne permet pas
de découvrir toutes les synchronisations de l'ordinateur. La destination est
revérifiée au moment de l'opération. L'export d'association Android est aussi
refusé dans ces racines.

La quarantaine et la synchronisation des listes partagent le verrou
`sync-state/.sync.lock`. Le moteur recharge les exclusions privées sous ce
verrou avant de lire les données distantes ; les écritures des préférences
préservent les exclusions courantes. Une opération interrompue laisse une
barrière de récupération persistante qui suspend la synchronisation des listes
jusqu'à restauration. Cela empêche une synchronisation démarrée avec une
ancienne configuration de réintroduire les références mises en quarantaine.
